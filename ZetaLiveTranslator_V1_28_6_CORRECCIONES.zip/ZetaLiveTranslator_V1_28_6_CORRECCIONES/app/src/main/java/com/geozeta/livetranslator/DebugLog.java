package com.geozeta.livetranslator;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Registro opcional de pruebas (1.28.4).
 *
 * Guarda el texto que el OCR aceptó y la traducción que se mostró, para poder comparar
 * una versión con otra sin depender de la memoria. Está apagado por omisión: mientras
 * no se active desde la pantalla principal no escribe nada ni toca el disco.
 *
 * La escritura ocurre siempre en un hilo propio de prioridad mínima para no competir
 * con el ciclo LIVE, y cualquier fallo se ignora en silencio: el registro nunca debe
 * poder tumbar la traducción.
 */
public final class DebugLog {

    public static final String KEY_DEBUG_LOG = "debug_log_enabled";

    private static final String FILE_NAME = "zeta_registro.txt";
    private static final long MAX_BYTES = 512L * 1024L;

    private static final ExecutorService writer = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "ZetaDebugLog");
        thread.setPriority(Thread.MIN_PRIORITY);
        return thread;
    });

    // Solo la usa el hilo de escritura, por eso no necesita sincronización.
    private static final SimpleDateFormat STAMP = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);

    private static volatile Boolean enabledCache = null;

    private DebugLog() { }

    public static boolean isEnabled(Context context) {
        Boolean cached = enabledCache;
        if (cached != null) return cached;
        boolean value = false;
        try {
            SharedPreferences prefs = prefs(context);
            if (prefs != null) value = prefs.getBoolean(KEY_DEBUG_LOG, false);
        } catch (Exception ignored) { }
        enabledCache = value;
        return value;
    }

    public static void setEnabled(Context context, boolean enabled) {
        enabledCache = enabled;
        try {
            SharedPreferences prefs = prefs(context);
            if (prefs != null) prefs.edit().putBoolean(KEY_DEBUG_LOG, enabled).apply();
        } catch (Exception ignored) { }
    }

    /** Añade una línea al registro. No hace nada si el registro está apagado. */
    public static void append(Context context, String tag, String value) {
        if (context == null) return;
        if (!isEnabled(context)) return;
        final Context app = context.getApplicationContext();
        final long at = System.currentTimeMillis();
        final String safeTag = oneLine(tag);
        final String safeValue = oneLine(value);
        try {
            writer.execute(() -> {
                String line = STAMP.format(new Date(at)) + "\t" + safeTag + "\t" + safeValue + "\n";
                writeLine(app, line);
            });
        } catch (Exception ignored) { }
    }

    /** Devuelve el final del registro, que es la parte útil para revisar una prueba. */
    public static String readTail(Context context, int maxChars) {
        if (context == null || maxChars <= 0) return "";
        RandomAccessFile file = null;
        try {
            File target = logFile(context.getApplicationContext());
            if (target == null || !target.exists()) return "";
            long length = target.length();
            if (length <= 0L) return "";
            long from = Math.max(0L, length - (long) maxChars);
            file = new RandomAccessFile(target, "r");
            file.seek(from);
            int size = (int) Math.min(length - from, (long) maxChars);
            byte[] buffer = new byte[size];
            file.readFully(buffer);
            String text = new String(buffer, "UTF-8");
            if (from > 0L) {
                // El corte pudo caer a mitad de una línea: se descarta esa primera línea parcial.
                int firstBreak = text.indexOf('\n');
                if (firstBreak >= 0 && firstBreak + 1 < text.length()) text = text.substring(firstBreak + 1);
            }
            return text;
        } catch (Exception e) {
            return "";
        } catch (OutOfMemoryError e) {
            return "";
        } finally {
            if (file != null) {
                try { file.close(); } catch (Exception ignored) { }
            }
        }
    }

    public static void clear(Context context) {
        if (context == null) return;
        final Context app = context.getApplicationContext();
        try {
            writer.execute(() -> {
                File target = logFile(app);
                if (target == null) return;
                try { target.delete(); } catch (Exception ignored) { }
            });
        } catch (Exception ignored) { }
    }

    private static void writeLine(Context app, String line) {
        FileOutputStream out = null;
        try {
            File target = logFile(app);
            if (target == null) return;
            // Un teléfono no debe quedarse sin espacio por un registro de pruebas:
            // al pasar del límite se reinicia entero en vez de crecer sin control.
            boolean append = !(target.exists() && target.length() > MAX_BYTES);
            out = new FileOutputStream(target, append);
            if (!append) out.write("(registro reiniciado por tamaño)\n".getBytes("UTF-8"));
            out.write(line.getBytes("UTF-8"));
        } catch (Exception ignored) {
        } catch (OutOfMemoryError ignored) {
        } finally {
            if (out != null) {
                try { out.close(); } catch (Exception ignored) { }
            }
        }
    }

    private static File logFile(Context app) {
        try {
            File dir = app.getExternalFilesDir(null);
            if (dir == null) dir = app.getFilesDir();
            if (dir == null) return null;
            if (!dir.exists() && !dir.mkdirs()) return null;
            return new File(dir, FILE_NAME);
        } catch (Exception e) {
            return null;
        }
    }

    private static SharedPreferences prefs(Context context) {
        try {
            return context.getApplicationContext()
                    .getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        } catch (Exception e) {
            return null;
        }
    }

    private static String oneLine(String value) {
        if (value == null) return "";
        return value.replace("\r", " ").replace("\n", " ⏎ ").replace("\t", " ").trim();
    }
}
