package com.geozeta.livetranslator;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TranslatorEngine {
    public static final String MODE_AUTO = "auto";
    public static final String MODE_CHINESE = TranslateLanguage.CHINESE;
    public static final String MODE_ENGLISH = TranslateLanguage.ENGLISH;
    public static final String MODE_JAPANESE = TranslateLanguage.JAPANESE;
    public static final String MODE_KOREAN = TranslateLanguage.KOREAN;

    public interface Callback {
        void onSuccess(String original, String translated, String sourceName);
        void onError(String message);
    }

    private final Pattern cjkPattern = Pattern.compile("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]");
    private final Pattern chinesePattern = Pattern.compile("[\\u3400-\\u9FFF]");
    private final Pattern japanesePattern = Pattern.compile("[\\u3040-\\u30FF]");
    private final Pattern koreanPattern = Pattern.compile("[\\uAC00-\\uD7AF]");
    private final Pattern latinPattern = Pattern.compile("[A-Za-z]");
    private final Pattern expressiveWordPattern = Pattern.compile("[A-Za-z]{2,}");
    private static final int AUTO_UNLOCK_FAILURES = 3;
    private static final int AUTO_ENGLISH_ACCEPT_SCORE = 120;
    private static final int AUTO_CJK_ACCEPT_SCORE = 55;
    public static final String KEY_CUSTOM_GLOSSARY = "custom_glossary_en_es";
    private final Context appContext;
    private final SharedPreferences preferences;
    private final Set<String> englishVocabulary = new HashSet<>();
    private int autoFailureCount = 0;
    private String lastAutoMode = null;
    private final List<StableReading> recentStableReadings = new ArrayList<>();
    private String stableWindowMode = "";
    private String lastAcceptedStableKey = "";
    private String lastAcceptedStableMode = "";
    private int consecutiveEmptyFrames = 0;
    private static final int STABILITY_WINDOW_SIZE = 3;
    private static final long STABILITY_WINDOW_MS = 1800L;
    private static final long STABILITY_MIN_CONFIRM_MS = 240L;
    private String lastSourceText = "";
    private String lastSourceLanguage = "";
    private long lastSourceAt = 0L;
    private static final String CONTEXT_MARKER = "ZXQ9173";
    private final Map<String, TextRecognizer> recognizers = new HashMap<>();
    private final Map<String, Translator> translators = new HashMap<>();
    private final Map<String, String> translationCache = new LinkedHashMap<String, String>(160, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > 160;
        }
    };
    private static final Set<String> EXPRESSIVE_DICTIONARY = new HashSet<>(Arrays.asList(
            "a", "ah", "am", "are", "awesome", "bad", "beautiful", "better", "book", "boom",
            "bye", "call", "calm", "can", "come", "cool", "damn", "do", "done", "fine", "food",
            "go", "good", "great", "happy", "help", "hello", "hey", "home", "honey", "hope", "how",
            "i", "know", "later", "leave", "like", "little", "look", "love", "man", "maybe", "me",
            "mom", "more", "need", "never", "nice", "no", "not", "now", "of", "oh", "okay", "one",
            "please", "really", "right", "run", "sad", "see", "she", "shit", "so", "sorry", "stop",
            "sure", "thank", "thanks", "that", "the", "there", "think", "this", "time", "too", "very",
            "wait", "want", "we", "well", "what", "why", "wow", "yeah", "yes", "you"
    ));

    public TranslatorEngine(Context context) {
        appContext = context.getApplicationContext();
        preferences = appContext.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        loadEnglishVocabulary();
    }

    public void resetAutoState() {
        lastAutoMode = null;
        autoFailureCount = 0;
    }

    public void resetStabilityState() {
        recentStableReadings.clear();
        stableWindowMode = "";
        lastAcceptedStableKey = "";
        lastAcceptedStableMode = "";
        consecutiveEmptyFrames = 0;
    }

    public void noteNoTextDetected() {
        recentStableReadings.clear();
        consecutiveEmptyFrames++;
        // Dos fotogramas sin subtítulo indican que la línea anterior ya desapareció.
        // Así una frase idéntica puede volver a mostrarse más adelante en el video.
        if (consecutiveEmptyFrames >= 2) {
            lastAcceptedStableKey = "";
            lastAcceptedStableMode = "";
        }
    }

    public void resetContextState() {
        lastSourceText = "";
        lastSourceLanguage = "";
        lastSourceAt = 0L;
    }

    public void process(Bitmap crop, String mode, Callback callback) {
        process(crop, mode, false, callback);
    }

    public void process(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (crop == null || crop.isRecycled()) {
            callback.onError("No se pudo leer el recorte.");
            return;
        }
        if (MODE_AUTO.equals(mode)) {
            processAuto(crop, requireStable, callback);
        } else {
            processFixed(crop, mode, requireStable, callback);
        }
    }

    private void processFixed(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (!isModelReady(mode)) {
            callback.onError("Descarga " + readable(mode) + " → Español antes de usar este idioma.");
            return;
        }

        // Para inglés se intenta primero la imagen original: los bordes de colores y sombras
        // suelen deformarse al aumentar demasiado el contraste. Solo si no hay una frase útil
        // se usa la versión ampliada y contrastada. En otros idiomas se conserva el flujo anterior.
        Bitmap first = MODE_ENGLISH.equals(mode) ? crop : prepareForOcr(crop);
        processFixedAttempt(crop, first, mode, requireStable, true, callback);
    }

    private void processFixedAttempt(Bitmap original, Bitmap attempt, String mode, boolean requireStable,
                                     boolean allowFallback, Callback callback) {
        recognize(attempt, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                if (cleaned.trim().isEmpty() && allowFallback) {
                    Bitmap fallback = attempt == original ? prepareForOcr(original) : original;
                    if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                    processFixedAttempt(original, fallback, mode, requireStable, false, callback);
                    return;
                }
                if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                if (cleaned.trim().isEmpty()) {
                    callback.onError("No se detectó texto dentro del cuadro.");
                    return;
                }
                translateWhenStable(cleaned, mode, requireStable, callback);
            }

            @Override public void onError(String error) {
                if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                callback.onError(error);
            }
        });
    }

    private void processAuto(Bitmap crop, boolean requireStable, Callback callback) {
        String preferred = firstInstalledAutoMode();
        if (preferred == null) {
            callback.onError("Descarga por lo menos un idioma antes de usar Auto.");
            return;
        }
        Bitmap prepared = prepareForOcr(crop);
        String primaryMode = lastAutoMode != null && isModelReady(lastAutoMode) ? lastAutoMode : preferred;
        recognize(prepared, primaryMode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, primaryMode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, primaryMode);
                if (isAutoCandidateAcceptable(cleaned, primaryMode, score)) {
                    if (prepared != crop) prepared.recycle();
                    lastAutoMode = primaryMode;
                    autoFailureCount = 0;
                    translateWhenStable(cleaned, primaryMode, requireStable, callback);
                    return;
                }
                autoFailureCount++;
                if (lastAutoMode != null && autoFailureCount < AUTO_UNLOCK_FAILURES) {
                    if (prepared != crop) prepared.recycle();
                    callback.onError("Esperando texto claro en " + readable(primaryMode) + ".");
                    return;
                }
                scanAutoFallback(prepared, crop, primaryMode, requireStable, callback);
            }

            @Override public void onError(String error) {
                autoFailureCount++;
                if (lastAutoMode != null && autoFailureCount < AUTO_UNLOCK_FAILURES) {
                    if (prepared != crop) prepared.recycle();
                    callback.onError("Esperando texto claro en " + readable(primaryMode) + ".");
                    return;
                }
                scanAutoFallback(prepared, crop, primaryMode, requireStable, callback);
            }
        });
    }

    private void scanAutoFallback(Bitmap prepared, Bitmap original, String alreadyTried,
                                  boolean requireStable, Callback callback) {
        String[] modes = fallbackModes(alreadyTried);
        List<Candidate> candidates = new ArrayList<>();
        recognizeAutoAt(prepared, modes, 0, candidates, () -> {
            Candidate best = chooseBest(candidates);
            if (prepared != original) prepared.recycle();
            if (best != null && isAutoCandidateAcceptable(best.cleaned, best.sourceLanguage, best.score)) {
                lastAutoMode = best.sourceLanguage;
                autoFailureCount = 0;
                translateWhenStable(best.cleaned, best.sourceLanguage, requireStable, callback);
                return;
            }

            List<Candidate> originalCandidates = new ArrayList<>();
            recognizeAutoAt(original, autoModesOrder(), 0, originalCandidates, () -> {
                Candidate bestOriginal = chooseBest(originalCandidates);
                if (bestOriginal == null || !isAutoCandidateAcceptable(
                        bestOriginal.cleaned, bestOriginal.sourceLanguage, bestOriginal.score)) {
                    callback.onError("No se detectó texto claro dentro del cuadro.");
                    return;
                }
                lastAutoMode = bestOriginal.sourceLanguage;
                autoFailureCount = 0;
                translateWhenStable(bestOriginal.cleaned, bestOriginal.sourceLanguage, requireStable, callback);
            });
        });
    }

    private boolean isAutoCandidateAcceptable(String text, String mode, int score) {
        if (text == null || text.trim().isEmpty()) return false;
        if (MODE_ENGLISH.equals(mode)) return score >= AUTO_ENGLISH_ACCEPT_SCORE;
        return score >= AUTO_CJK_ACCEPT_SCORE;
    }

    private String[] fallbackModes(String alreadyTried) {
        List<String> installed = installedAutoModes();
        installed.remove(alreadyTried);
        return installed.toArray(new String[0]);
    }

    private String[] autoModesOrder() {
        return installedAutoModes().toArray(new String[0]);
    }

    private List<String> installedAutoModes() {
        List<String> modes = new ArrayList<>();
        // Inglés siempre es la primera opción cuando está instalado.
        if (isModelReady(MODE_ENGLISH)) modes.add(MODE_ENGLISH);
        if (isModelReady(MODE_CHINESE)) modes.add(MODE_CHINESE);
        if (isModelReady(MODE_JAPANESE)) modes.add(MODE_JAPANESE);
        if (isModelReady(MODE_KOREAN)) modes.add(MODE_KOREAN);
        return modes;
    }

    private String firstInstalledAutoMode() {
        List<String> modes = installedAutoModes();
        return modes.isEmpty() ? null : modes.get(0);
    }

    private boolean isModelReady(String sourceLanguage) {
        if (TranslateLanguage.SPANISH.equals(sourceLanguage)) return true;
        return preferences.getBoolean(MainActivity.KEY_MODEL_PREFIX + sourceLanguage, false);
    }

    private void recognizeAutoAt(Bitmap bitmap, String[] modes, int index, List<Candidate> out, Runnable done) {
        if (index >= modes.length) {
            done.run();
            return;
        }
        String mode = modes[index];
        recognize(bitmap, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, mode);
                if (cleaned.trim().length() > 0) out.add(new Candidate(cleaned, mode, score));
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }

            @Override public void onError(String error) {
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }
        });
    }

    private Candidate chooseBest(List<Candidate> candidates) {
        Candidate best = null;
        for (Candidate candidate : candidates) {
            if (best == null || candidate.score > best.score) best = candidate;
        }
        return best;
    }

    private int scoreCandidate(String text, String mode) {
        if (text == null) return 0;
        String t = text.trim();
        if (t.length() == 0) return 0;
        int score = Math.min(t.length(), 160);
        int cjk = countMatches(cjkPattern, t);
        int chinese = countMatches(chinesePattern, t);
        int japanese = countMatches(japanesePattern, t);
        int korean = countMatches(koreanPattern, t);
        int latin = countMatches(latinPattern, t);
        int lineCount = countUsefulLines(t);
        if (lineCount > 1) score += Math.min(90, lineCount * 22);

        if (MODE_ENGLISH.equals(mode)) {
            if (isBadEnglishFalsePositive(t)) return -9999;
            score += latin * 3;
            if (isGoodEnglishLine(t)) score += 170 + scoreEnglishLine(t);
            if (countEnglishWords(t) <= 2 && commonEnglishWordScore(t) == 0) score -= 90;
            if (isLikelySpanishLine(t)) score -= 180;
            if (cjk > 0) score -= cjk * 2;
        } else if (MODE_CHINESE.equals(mode)) {
            score += chinese * 7;
            if (japanese > 0 || korean > 0) score -= 10;
        } else if (MODE_JAPANESE.equals(mode)) {
            score += japanese * 8 + chinese * 2;
        } else if (MODE_KOREAN.equals(mode)) {
            score += korean * 8;
        }
        return score;
    }

    private int countMatches(Pattern pattern, String text) {
        int count = 0;
        java.util.regex.Matcher m = pattern.matcher(text);
        while (m.find()) count++;
        return count;
    }

    private int countUsefulLines(String text) {
        if (text == null) return 0;
        String[] parts = text.replace("\r", "").split("\n");
        int count = 0;
        for (String p : parts) {
            if (p != null && p.trim().length() >= 2) count++;
        }
        return count;
    }

    private static class Candidate {
        final String cleaned;
        final String sourceLanguage;
        final int score;
        Candidate(String cleaned, String sourceLanguage, int score) {
            this.cleaned = cleaned;
            this.sourceLanguage = sourceLanguage;
            this.score = score;
        }
    }

    private static class StableReading {
        final String text;
        final String key;
        final String mode;
        final long timestamp;

        StableReading(String text, String key, String mode, long timestamp) {
            this.text = text;
            this.key = key;
            this.mode = mode;
            this.timestamp = timestamp;
        }
    }

    private Bitmap prepareForOcr(Bitmap crop) {
        if (crop == null || crop.isRecycled()) return crop;
        int width = crop.getWidth();
        int height = crop.getHeight();
        if (width <= 0 || height <= 0) return crop;

        // Escala el recorte para que el OCR lea mejor subtítulos pequeños.
        float scale = 1.0f;
        if (width < 900) scale = 1.75f;
        if (width < 620) scale = 2.25f;
        if (width < 430) scale = 2.7f;
        int newW = Math.max(width, Math.round(width * scale));
        int newH = Math.max(height, Math.round(height * scale));

        Bitmap scaled = Bitmap.createScaledBitmap(crop, newW, newH, true);
        Bitmap enhanced = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(enhanced);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float contrast = 1.48f;
        float translate = (-0.5f * contrast + 0.5f) * 255f;
        ColorMatrix matrix = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        canvas.drawBitmap(scaled, 0, 0, paint);
        if (scaled != crop) scaled.recycle();
        return enhanced;
    }

    private interface OcrCallback {
        void onResult(Text result, int imageWidth, int imageHeight);
        void onError(String error);
    }

    private void recognize(Bitmap crop, String mode, OcrCallback cb) {
        TextRecognizer recognizer = getRecognizer(mode);
        InputImage image = InputImage.fromBitmap(crop, 0);
        int width = crop.getWidth();
        int height = crop.getHeight();
        recognizer.process(image)
                .addOnSuccessListener(result -> cb.onResult(result, width, height))
                .addOnFailureListener(e -> cb.onError("Error OCR: " + safeMessage(e)));
    }

    private TextRecognizer getRecognizer(String mode) {
        String key = mode == null ? MODE_ENGLISH : mode;
        TextRecognizer existing = recognizers.get(key);
        if (existing != null) return existing;
        TextRecognizer created;
        if (MODE_CHINESE.equals(key)) {
            created = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        } else if (MODE_JAPANESE.equals(key)) {
            created = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        } else if (MODE_KOREAN.equals(key)) {
            created = TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        } else {
            created = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        }
        recognizers.put(key, created);
        return created;
    }

    private void translateWhenStable(String text, String sourceLanguage, boolean requireStable, Callback callback) {
        if (!requireStable) {
            translate(text, sourceLanguage, callback);
            return;
        }

        String stableText = selectStableText(text, sourceLanguage);
        if (stableText == null || stableText.trim().isEmpty()) {
            callback.onError("Esperando subtítulo estable.");
            return;
        }

        String acceptedKey = lastAcceptedStableKey;
        String acceptedMode = lastAcceptedStableMode;
        translate(stableText, sourceLanguage, new Callback() {
            @Override public void onSuccess(String original, String translated, String sourceName) {
                callback.onSuccess(original, translated, sourceName);
            }

            @Override public void onError(String message) {
                // Si el modelo falla, permite reintentar el mismo subtítulo en la siguiente captura.
                if (acceptedKey.equals(lastAcceptedStableKey)
                        && acceptedMode.equals(lastAcceptedStableMode)) {
                    lastAcceptedStableKey = "";
                    lastAcceptedStableMode = "";
                }
                callback.onError(message);
            }
        });
    }

    /**
     * Confirma el OCR por consenso: al menos dos de las últimas tres lecturas deben
     * representar el mismo subtítulo. Nunca fuerza una frase inestable por tiempo;
     * mientras no exista consenso, LIVE conserva la traducción anterior.
     */
    private String selectStableText(String text, String sourceLanguage) {
        String cleaned = normalizeBeforeTranslate(text, sourceLanguage);
        String normalized = normalizeKey(cleaned);
        if (normalized.isEmpty()) return null;

        String mode = sourceLanguage == null ? "" : sourceLanguage;
        long now = System.currentTimeMillis();
        consecutiveEmptyFrames = 0;

        if (mode.equals(lastAcceptedStableMode)
                && isSameAcceptedSubtitle(lastAcceptedStableKey, normalized)) {
            recentStableReadings.clear();
            stableWindowMode = mode;
            return null;
        }

        if (!mode.equals(stableWindowMode)) {
            recentStableReadings.clear();
            stableWindowMode = mode;
        }

        for (int i = recentStableReadings.size() - 1; i >= 0; i--) {
            if (now - recentStableReadings.get(i).timestamp > STABILITY_WINDOW_MS) {
                recentStableReadings.remove(i);
            }
        }

        recentStableReadings.add(new StableReading(cleaned, normalized, mode, now));
        while (recentStableReadings.size() > STABILITY_WINDOW_SIZE) {
            recentStableReadings.remove(0);
        }

        StableReading best = null;
        int bestMatches = 0;
        for (StableReading candidate : recentStableReadings) {
            int matches = 0;
            for (StableReading other : recentStableReadings) {
                if (areConsensusSimilar(candidate.key, other.key)) matches++;
            }
            if (matches > bestMatches
                    || (matches == bestMatches && isBetterStableReading(candidate, best))) {
                bestMatches = matches;
                best = candidate;
            }
        }

        if (best == null || bestMatches < 2) return null;

        long oldestMatchAt = now;
        StableReading bestReading = null;
        for (StableReading sample : recentStableReadings) {
            if (!areConsensusSimilar(best.key, sample.key)) continue;
            oldestMatchAt = Math.min(oldestMatchAt, sample.timestamp);
            if (isBetterStableReading(sample, bestReading)) bestReading = sample;
        }

        if (now - oldestMatchAt < STABILITY_MIN_CONFIRM_MS || bestReading == null) return null;

        lastAcceptedStableKey = bestReading.key;
        lastAcceptedStableMode = mode;
        recentStableReadings.clear();
        stableWindowMode = mode;
        return bestReading.text;
    }

    private boolean isBetterStableReading(StableReading candidate, StableReading currentBest) {
        if (candidate == null) return false;
        if (currentBest == null) return true;
        int candidateScore = stableReadingScore(candidate.text);
        int currentScore = stableReadingScore(currentBest.text);
        if (candidateScore != currentScore) return candidateScore > currentScore;
        return candidate.timestamp > currentBest.timestamp;
    }

    private int stableReadingScore(String text) {
        if (text == null) return Integer.MIN_VALUE;
        String clean = text.trim();
        int score = clean.length();
        int words = clean.isEmpty() ? 0 : clean.split("\\s+").length;
        score += Math.min(words, 16) * 6;
        if (clean.matches(".*[.!?…][\"']?$")) score += 12;
        if (clean.matches(".*\\b(I|you|he|she|we|they|it)\\b.*")) score += 5;
        score -= countSuspiciousCharacters(clean) * 15;
        return score;
    }

    private int countSuspiciousCharacters(String text) {
        if (text == null) return 0;
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c)
                    || "'.,?!:;-–—…".indexOf(c) >= 0) continue;
            count++;
        }
        return count;
    }

    private boolean areConsensusSimilar(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b)) return true;

        int max = Math.max(a.length(), b.length());
        int min = Math.min(a.length(), b.length());

        // Solo admite ampliaciones muy pequeñas del mismo OCR. No usa similitud por
        // conjunto de palabras porque podría confundir frases con significado opuesto
        // como "I want..." e "I don't want...".
        if (min >= 10 && (a.contains(b) || b.contains(a)) && min >= Math.round(max * 0.90f)) {
            return true;
        }

        int allowedDistance = Math.max(1, Math.min(3, max / 18));
        return Math.abs(a.length() - b.length()) <= allowedDistance
                && levenshteinDistance(a, b) <= allowedDistance;
    }

    private boolean isSameAcceptedSubtitle(String accepted, String current) {
        if (accepted == null || current == null || accepted.length() == 0 || current.length() == 0) {
            return false;
        }
        if (accepted.equals(current)) return true;
        int max = Math.max(accepted.length(), current.length());
        int min = Math.min(accepted.length(), current.length());
        if (max - min > Math.max(2, max / 14)) return false;
        return levenshteinDistance(accepted, current) <= Math.max(1, max / 18);
    }

    private int levenshteinDistance(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[b.length()];
    }

    private void detectLanguageThenTranslate(String text, Callback callback) {
        String guessed = guessFromCharacters(text);
        if (guessed != null) {
            translate(text, guessed, callback);
            return;
        }

        LanguageIdentifier identifier = LanguageIdentification.getClient();
        identifier.identifyLanguage(text)
                .addOnSuccessListener(languageCode -> {
                    identifier.close();
                    String src = mapLanguage(languageCode);
                    if (src == null || "und".equals(languageCode)) src = TranslateLanguage.ENGLISH;
                    translate(text, src, callback);
                })
                .addOnFailureListener(e -> {
                    identifier.close();
                    translate(text, TranslateLanguage.ENGLISH, callback);
                });
    }

    private void translate(String text, String sourceLanguage, Callback callback) {
        String src = sourceLanguage;
        if (MODE_AUTO.equals(src)) src = guessFromCharacters(text);
        if (src == null) src = TranslateLanguage.ENGLISH;

        String cleanForTranslate = normalizeBeforeTranslate(text, src);
        if (TranslateLanguage.ENGLISH.equals(src)) {
            String glossaryMatch = exactGlossaryTranslation(cleanForTranslate);
            if (glossaryMatch != null) {
                rememberSource(cleanForTranslate, src);
                callback.onSuccess(cleanForTranslate, glossaryMatch, readable(src));
                return;
            }
        }
        // LIVE traduce cada subtítulo de forma independiente. El contexto automático entre
        // líneas se desactiva porque puede mezclar dos diálogos distintos y empeorar el resultado.
        String context = null;
        String cacheKey = src + "|" + normalizeKey(cleanForTranslate);
        if (translationCache.containsKey(cacheKey)) {
            String cached = translationCache.get(cacheKey);
            rememberSource(cleanForTranslate, src);
            callback.onSuccess(cleanForTranslate, cached, readable(src));
            return;
        }

        if (TranslateLanguage.SPANISH.equals(src)) {
            rememberSource(cleanForTranslate, src);
            callback.onSuccess(cleanForTranslate, cleanForTranslate, "Español");
            return;
        }

        translateWithMlKit(cleanForTranslate, src, context, cacheKey, callback);
    }

    private void translateWithMlKit(String input, String sourceLanguage, String context,
                                    String cacheKey, Callback callback) {
        if (!isModelReady(sourceLanguage)) {
            callback.onError("Descarga " + readable(sourceLanguage) + " → Español antes de traducir.");
            return;
        }

        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String direct = fallbackEnglishToSpanish(input);
            if (direct != null && !direct.trim().isEmpty()) {
                translationCache.put(cacheKey, direct);
                rememberSource(input, sourceLanguage);
                callback.onSuccess(input, direct, readable(sourceLanguage));
                return;
            }
        }

        Translator translator = getTranslator(sourceLanguage);
        if (context != null) {
            String contextualInput = context + "\n" + CONTEXT_MARKER + "\n" + input;
            translator.translate(contextualInput)
                    .addOnSuccessListener(translated -> {
                        String extracted = extractContextTranslation(translated, input);
                        String polished = extracted == null ? "" : polishSpanish(extracted);
                        if (extracted != null
                                && !isSuspiciousResult(input, polished, sourceLanguage)) {
                            // Una traducción contextual depende de la línea anterior, por eso no se
                            // guarda con la misma clave que una traducción directa.
                            finishTranslation(input, sourceLanguage, null, extracted, callback);
                        } else {
                            translateDirect(translator, input, sourceLanguage, cacheKey, callback);
                        }
                    })
                    .addOnFailureListener(e -> translateDirect(
                            translator, input, sourceLanguage, cacheKey, callback));
        } else {
            translateDirect(translator, input, sourceLanguage, cacheKey, callback);
        }
    }

    private void translateDirect(Translator translator, String input, String sourceLanguage,
                                 String cacheKey, Callback callback) {
        translator.translate(input)
                .addOnSuccessListener(translated -> finishTranslation(
                        input, sourceLanguage, cacheKey, translated, callback))
                .addOnFailureListener(e -> callback.onError("Error al traducir: " + safeMessage(e)));
    }

    private void finishTranslation(String input, String sourceLanguage, String cacheKey, String translated, Callback callback) {
        String polished = polishSpanish(translated);
        if (isSuspiciousResult(input, polished, sourceLanguage)
                && TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String fallback = fallbackEnglishToSpanish(input);
            if (fallback != null && fallback.trim().length() > 0) polished = fallback;
        }
        // No mostramos el original ni una mezcla evidente como si fuera una traducción terminada.
        // En modo Vivo el cuadro conserva la última traducción fiable hasta la siguiente lectura válida.
        if (isSuspiciousResult(input, polished, sourceLanguage)) {
            callback.onError("No se obtuvo una traducción suficientemente confiable.");
            return;
        }
        if (cacheKey != null) translationCache.put(cacheKey, polished);
        rememberSource(input, sourceLanguage);
        callback.onSuccess(input, polished, readable(sourceLanguage));
    }

    private boolean isSuspiciousResult(String original, String translated, String sourceLanguage) {
        if (translated == null || translated.trim().isEmpty()) return true;
        if (looksUntranslated(original, translated)) return true;
        if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)
                || TranslateLanguage.KOREAN.equals(sourceLanguage)) {
            return countMatches(cjkPattern, translated) > 2;
        }
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            int strongEnglish = countStrongEnglishWords(translated);
            int spanishSignals = countSpanishSignals(translated);
            return strongEnglish >= 2 && spanishSignals == 0;
        }
        return false;
    }

    private int countStrongEnglishWords(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "the","this","that","these","those","you","your","yours","he","she","they",
                "we","our","where","when","why","what","who","how","with","from","have","has",
                "had","will","would","could","should","were","was","are","does","did","doing",
                "think","know","want","need","good","right","please","sorry","home"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }

    private int countSpanishSignals(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "el","la","los","las","un","una","que","de","del","en","por","para","con",
                "como","qué","dónde","cuando","porque","estoy","está","son","eres","tengo","tiene",
                "quiero","puedo","casa","bien","gracias","pero","muy","ya","aquí","allí"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }

    private String eligibleContext(String current, String sourceLanguage) {
        if (current == null || current.trim().length() == 0) return null;
        if (lastSourceText.length() == 0 || lastSourceLanguage.length() == 0) return null;
        if (!lastSourceLanguage.equals(sourceLanguage)) return null;
        if (System.currentTimeMillis() - lastSourceAt > 7000L) return null;

        String previous = lastSourceText.trim();
        String currentTrimmed = current.trim();
        if (normalizeKey(previous).equals(normalizeKey(currentTrimmed))) return null;
        if (areSimilarSubtitles(normalizeKey(previous), normalizeKey(currentTrimmed))) return null;

        int wordCount = currentTrimmed.split("\\s+").length;
        if (wordCount < 2 || wordCount > 7
                || currentTrimmed.length() > 90
                || previous.length() > 150) return null;

        boolean previousLooksIncomplete = !previous.matches(".*[.!?…][\"']?$" );
        String firstWord = normalizeKey(currentTrimmed).split(" ")[0];
        boolean continuationCue = Arrays.asList(
                "and", "but", "because", "so", "then", "that", "which", "who",
                "when", "where", "if", "unless", "to", "for", "from", "with",
                "without", "you", "he", "she", "they", "we", "it"
        ).contains(firstWord);

        return previousLooksIncomplete && continuationCue ? previous : null;
    }

    private String extractContextTranslation(String translated, String currentInput) {
        if (translated == null) return null;
        String upper = translated.toUpperCase(Locale.ROOT);
        int marker = upper.indexOf(CONTEXT_MARKER);
        if (marker < 0) return null;
        String current = translated.substring(marker + CONTEXT_MARKER.length())
                .replaceFirst("^[\\s:;,.!?\\-–—]+", "")
                .trim();
        if (current.length() == 0) return null;
        int maxReasonable = Math.max(80, currentInput.length() * 5);
        if (current.length() > maxReasonable) return null;
        return current;
    }

    private void rememberSource(String text, String sourceLanguage) {
        if (text == null || text.trim().length() == 0 || sourceLanguage == null) return;
        lastSourceText = text.trim();
        lastSourceLanguage = sourceLanguage;
        lastSourceAt = System.currentTimeMillis();
    }

    private Translator getTranslator(String sourceLanguage) {
        Translator existing = translators.get(sourceLanguage);
        if (existing != null) return existing;
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguage)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        Translator created = Translation.getClient(options);
        translators.put(sourceLanguage, created);
        return created;
    }

    private String normalizeBeforeTranslate(String text, String sourceLanguage) {
        if (text == null) return "";
        String t = joinOcrLines(text);
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            t = repairEnglishOcr(t);
            t = normalizeExpressiveEnglish(t);
        }
        return t;
    }

    private String joinOcrLines(String text) {
        if (text == null) return "";
        String[] lines = text.replace("\r", "").split("\n");
        StringBuilder out = new StringBuilder();
        Set<String> seen = new HashSet<>();
        for (String line : lines) {
            String s = line == null ? "" : line.trim();
            if (s.length() == 0) continue;
            String key = normalizeKey(s);
            if (key.length() > 0 && !seen.add(key)) continue;
            if (out.length() > 0) out.append(' ');
            out.append(s);
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    private String repairEnglishOcr(String text) {
        if (text == null) return "";
        String t = text.trim();
        t = stripCjkFromEnglish(t);
        t = t.replaceAll("(?<=[a-z])(?=[A-Z])", " ");
        t = t.replace('’', '\'');

        // Solo se conservan correcciones de confusiones OCR muy seguras. Las sustituciones
        // gramaticales agresivas se eliminaron porque podían cambiar palabras correctas.
        t = t.replaceAll("(?i)\\bschoo1\\b", "school");
        t = t.replaceAll("(?i)\\bmornlng\\b", "morning");
        t = t.replaceAll("(?i)\\bfinisbed\\b", "finished");
        t = t.replaceAll("(?i)\\bleam\\b", "learn");
        t = t.replaceAll("(?i)\\btomorow\\b", "tomorrow");
        t = t.replaceAll("(?i)\\bexacty\\b", "exactly");

        t = t.replaceAll("[.]{2,}", " ");
        t = t.replaceAll("[^A-Za-z0-9'.,?!:;\\- ]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String normalizeExpressiveEnglish(String text) {
        if (text == null || text.length() == 0) return "";
        Matcher matcher = expressiveWordPattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String original = matcher.group();
            String replacement = normalizeExpressiveWord(original);
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private String normalizeExpressiveWord(String word) {
        if (word == null || word.length() < 3 || !hasRunOfThree(word)) return word;
        String lower = word.toLowerCase(Locale.ROOT);
        String maxTwo = collapseRuns(lower, 2);
        String selected = EXPRESSIVE_DICTIONARY.contains(maxTwo) ? maxTwo : findDictionaryVariant(maxTwo, 0, new StringBuilder());
        if (selected == null) selected = maxTwo;
        if (word.equals(word.toUpperCase(Locale.ROOT))) return selected.toUpperCase(Locale.ROOT);
        if (Character.isUpperCase(word.charAt(0))) {
            return Character.toUpperCase(selected.charAt(0)) + selected.substring(1);
        }
        return selected;
    }

    private boolean hasRunOfThree(String word) {
        int run = 1;
        for (int i = 1; i < word.length(); i++) {
            if (Character.toLowerCase(word.charAt(i)) == Character.toLowerCase(word.charAt(i - 1))) {
                run++;
                if (run >= 3) return true;
            } else {
                run = 1;
            }
        }
        return false;
    }

    private String collapseRuns(String word, int maxRun) {
        StringBuilder out = new StringBuilder(word.length());
        char previous = 0;
        int run = 0;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c == previous) {
                run++;
            } else {
                previous = c;
                run = 1;
            }
            if (run <= maxRun) out.append(c);
        }
        return out.toString();
    }

    private String findDictionaryVariant(String word, int index, StringBuilder built) {
        if (index >= word.length()) {
            String candidate = built.toString();
            return EXPRESSIVE_DICTIONARY.contains(candidate) ? candidate : null;
        }
        char c = word.charAt(index);
        int end = index + 1;
        while (end < word.length() && word.charAt(end) == c) end++;
        int runLength = end - index;
        int originalLength = built.length();

        for (int i = 0; i < runLength; i++) built.append(c);
        String keep = findDictionaryVariant(word, end, built);
        if (keep != null) return keep;
        built.setLength(originalLength);

        if (runLength == 2) {
            built.append(c);
            String reduced = findDictionaryVariant(word, end, built);
            if (reduced != null) return reduced;
            built.setLength(originalLength);
        }
        return null;
    }

    private String stripCjkFromEnglish(String text) {
        if (text == null) return "";
        String t = text;
        // Quita traducciones chinas/japonesas/coreanas entre paréntesis para no contaminar el inglés.
        t = t.replaceAll("\\([^)]*[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF][^)]*\\)", " ");
        t = t.replaceAll("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]+", " ");
        return t;
    }

    private String cleanEnglishLine(String line) {
        if (line == null) return "";
        String s = normalizeExpressiveEnglish(repairEnglishOcr(line));
        s = s.replaceAll("^[^A-Za-z0-9]+", "");
        s = s.replaceAll("[^A-Za-z0-9.?!']+$", "");
        s = s.replaceAll("\\s+", " ").trim();
        return trimEnglishOcrNoise(s);
    }

    /**
     * Recorta basura corta que el OCR latino inventa al intentar leer caracteres chinos.
     * Es una operacion local y rapida: no espera otra captura ni consulta otro modelo.
     */
    private String trimEnglishOcrNoise(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String[] tokens = text.trim().split("\\s+");
        int start = 0;
        int end = tokens.length;
        while (start < end && isSuspiciousOcrToken(tokens[start])) start++;
        while (end > start && isSuspiciousOcrToken(tokens[end - 1])) end--;
        if (start >= end) return "";

        StringBuilder out = new StringBuilder();
        int badRun = 0;
        int goodCount = 0;
        for (int i = start; i < end; i++) {
            String token = tokens[i];
            boolean bad = isSuspiciousOcrToken(token);
            if (bad) {
                badRun++;
                if (goodCount >= 2 && badRun >= 2) break;
            } else {
                badRun = 0;
                goodCount++;
            }
            if (out.length() > 0) out.append(' ');
            out.append(token);
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    private boolean isSuspiciousOcrToken(String token) {
        if (token == null) return true;
        String raw = token.replaceAll("^[^A-Za-z0-9']+|[^A-Za-z0-9']+$", "");
        if (raw.isEmpty()) return true;
        if (raw.matches(".*\\d.*")) return true;
        String lower = raw.toLowerCase(Locale.ROOT).replace("'", "");
        if (lower.equals("a") || lower.equals("i")) return false;
        String commonShort = " ok hi yes no go why who how hey wow bye not the you me my we us he she her him our your his its mr ms dr ";
        if (commonShort.contains(" " + lower + " ")) return false;
        String contractions = " im ive ill id youre hes shes theyre were dont didnt doesnt cant wont isnt arent wasnt werent thats whats wheres whos lets ";
        if (contractions.contains(" " + lower + " ")) return false;
        if (lower.length() <= 2) {
            String allowed = " am an as at be by do go he if in is it me my no of oh on or so to up us we ";
            return !allowed.contains(" " + lower + " ");
        }
        if (lower.length() >= 4 && !lower.matches(".*[aeiouy].*")) return true;
        return raw.equals(raw.toUpperCase(Locale.ROOT)) && raw.length() <= 3;
    }

    private boolean isGoodEnglishLine(String s) {
        if (s == null) return false;
        String key = normalizeKey(s);
        if (key.length() < 2) return false;
        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        boolean sentenceMark = s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",") || s.contains("'");
        if (words >= 6 && (common > 0 || sentenceMark)) return true;
        if (words >= 2 && common > 0) return true;
        return key.equals("at home") || key.equals("thank you");
    }

    private int scoreEnglishLine(String s) {
        if (s == null) return -9999;
        String k = normalizeKey(s);
        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        int score = Math.min(s.length(), 120) + words * 14 + common * 26;
        if (s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",")) score += 14;
        if (words <= 2 && common == 0) score -= 80;
        if (isLikelySpanishLine(s)) score -= 180;
        return score;
    }

    private boolean isBadEnglishFalsePositive(String s) {
        if (s == null) return true;
        String k = normalizeKey(s);
        if (k.length() == 0) return true;

        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        boolean hasSentenceMark = s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",") || s.contains("'");
        boolean looksLikeTitle = words <= 3 && common == 0 && !s.matches(".*[a-z].*[a-z].*");
        boolean tooShortWithoutContext = words <= 2 && common == 0;
        return looksLikeTitle || (tooShortWithoutContext && !hasSentenceMark);
    }

    private int commonEnglishWordScore(String s) {
        return countVocabularyWords(s);
    }

    private int countVocabularyWords(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        Matcher matcher = Pattern.compile("[A-Za-z']+").matcher(text.toLowerCase(Locale.ROOT));
        int count = 0;
        while (matcher.find()) {
            String word = matcher.group().replace("'", "");
            if (isVocabularyWord(word)) count++;
        }
        return count;
    }

    private boolean isVocabularyWord(String word) {
        if (word == null || word.length() < 2) return false;
        if (englishVocabulary.contains(word)) return true;
        if (word.endsWith("s") && word.length() > 3 && englishVocabulary.contains(word.substring(0, word.length() - 1))) return true;
        if (word.endsWith("ed") && word.length() > 4) {
            String root = word.substring(0, word.length() - 2);
            if (englishVocabulary.contains(root) || englishVocabulary.contains(root + "e")) return true;
        }
        if (word.endsWith("ing") && word.length() > 5) {
            String root = word.substring(0, word.length() - 3);
            if (englishVocabulary.contains(root) || englishVocabulary.contains(root + "e")) return true;
        }
        return false;
    }

    private void loadEnglishVocabulary() {
        englishVocabulary.addAll(EXPRESSIVE_DICTIONARY);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                appContext.getAssets().open("english_ocr_vocabulary.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String word = line.trim().toLowerCase(Locale.ROOT);
                if (!word.isEmpty()) englishVocabulary.add(word);
            }
        } catch (Exception ignored) {
            // La app sigue funcionando con el vocabulario básico incorporado.
        }
    }

    private boolean isLikelySpanishLine(String s) {
        if (s == null) return false;
        String k = normalizeKey(s);
        return s.contains("¿") || s.contains("¡")
                || k.contains(" que ")
                || k.startsWith("que ")
                || k.contains(" donde ")
                || k.contains(" dónde ")
                || k.contains(" esta ")
                || k.contains(" está ")
                || k.contains(" ropa")
                || k.contains(" mama")
                || k.contains(" mamá")
                || k.contains(" nada")
                || k.contains(" casa")
                || k.contains(" fing");
    }

    private int countEnglishWords(String s) {
        if (s == null) return 0;
        java.util.regex.Matcher m = Pattern.compile("[A-Za-z]{2,}").matcher(s);
        int count = 0;
        while (m.find()) count++;
        return count;
    }

    private String cleanCjkLine(String line) {
        if (line == null) return "";
        String s = line;
        // Si hay inglés + CJK en una misma línea, conserva la parte CJK para OCR chino/japonés/coreano.
        s = s.replaceAll("[A-Za-z0-9][A-Za-z0-9'.,?!:;\\- ]+", " ");
        s = s.replaceAll("[()\\[\\]{}]", " ");
        s = s.replaceAll("\\s+", " ").trim();
        return s;
    }

    private boolean looksUntranslated(String original, String translated) {
        if (original == null || translated == null) return false;
        String a = normalizeKey(original);
        String b = normalizeKey(translated);
        if (a.length() == 0 || b.length() == 0) return false;
        return a.equals(b) || (b.contains(a) && b.length() <= a.length() + 4);
    }

    private String fallbackEnglishToSpanish(String text) {
        String k = normalizeKey(text);
        if (k.equals("at home")) return "En casa";
        if (k.equals("i am at home")) return "Estoy en casa";
        if (k.equals("i m at home")) return "Estoy en casa";
        if (k.equals("i am at school")) return "Estoy en la escuela";
        if (k.equals("i am at work")) return "Estoy en el trabajo";
        if (k.equals("good morning")) return "Buenos días";
        if (k.equals("good night")) return "Buenas noches";
        if (k.equals("thank you")) return "Gracias";
        if (k.equals("what are you doing")) return "¿Qué estás haciendo?";
        if (k.equals("where are you")) return "¿Dónde estás?";
        return null;
    }

    private String exactGlossaryTranslation(String sourceText) {
        String stored = preferences.getString(KEY_CUSTOM_GLOSSARY, "");
        if (stored == null || stored.trim().isEmpty()) return null;
        String sourceKey = normalizeKey(sourceText);
        for (String line : stored.replace("\r", "").split("\n")) {
            String entry = line.trim();
            if (entry.isEmpty() || entry.startsWith("#")) continue;
            int split = entry.indexOf("=>");
            if (split < 0) split = entry.indexOf('=');
            if (split <= 0) continue;
            String source = entry.substring(0, split).trim();
            String target = entry.substring(split + (entry.startsWith("=>", split) ? 2 : 1)).trim();
            if (!target.isEmpty() && normalizeKey(source).equals(sourceKey)) return target;
        }
        return null;
    }

    private String normalizeKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9áéíóúñü]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String cleanOcrResult(Text result, String mode, int imageWidth, int imageHeight) {
        if (result == null) return "";
        if (MODE_ENGLISH.equals(mode)) {
            // En inglés no volvemos al bloque completo cuando el análisis por líneas rechaza el texto.
            // Ese retroceso era precisamente lo que reintroducía basura china, marcas de agua y tokens rotos.
            return cleanEnglishFromLayout(result, imageWidth, imageHeight);
        }
        return cleanText(result.getText(), mode);
    }

    private static class EnglishLineCandidate {
        final String text;
        final Rect box;
        final int score;

        EnglishLineCandidate(String text, Rect box, int score) {
            this.text = text;
            this.box = box;
            this.score = score;
        }
    }

    /**
     * Selecciona el subtítulo inglés usando texto y posición. Esto evita mezclar la línea china,
     * marcas de agua y fragmentos aislados que antes terminaban dentro de la traducción.
     */
    private String cleanEnglishFromLayout(Text result, int imageWidth, int imageHeight) {
        List<EnglishLineCandidate> candidates = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String raw = line.getText();
                if (raw == null || raw.trim().isEmpty()) continue;
                String lower = raw.toLowerCase(Locale.ROOT);
                if (isWatermarkOrUi(raw, lower)) continue;

                int originalLatin = countMatches(latinPattern, raw);
                int originalCjk = countMatches(cjkPattern, raw);
                String cleaned = cleanEnglishLine(raw);
                if (cleaned.isEmpty() || isLikelySpanishLine(cleaned) || isBadEnglishFalsePositive(cleaned)) continue;

                int words = countEnglishWords(cleaned);
                int vocabularyWords = countVocabularyWords(cleaned);
                if (words < 2 && vocabularyWords == 0) continue;
                if (originalLatin < 3) continue;
                if (originalCjk > originalLatin * 2 && words < 4) continue;

                Rect box = line.getBoundingBox();
                if (box == null) box = new Rect(0, 0, imageWidth, Math.max(1, imageHeight));
                int score = scoreEnglishLine(cleaned);
                float widthRatio = imageWidth > 0 ? box.width() / (float) imageWidth : 0f;
                float centerY = imageHeight > 0 ? box.centerY() / (float) imageHeight : 0.5f;
                if (widthRatio >= 0.35f) score += 32;
                else if (widthRatio >= 0.18f) score += 14;
                if (centerY >= 0.35f) score += 10;
                score += Math.min(36, vocabularyWords * 7);
                if (originalCjk > 0) score -= Math.min(20, originalCjk / 2);
                candidates.add(new EnglishLineCandidate(cleaned, box, score));
            }
        }

        if (candidates.isEmpty()) return "";
        candidates.sort((a, b) -> {
            int top = Integer.compare(a.box.top, b.box.top);
            return top != 0 ? top : Integer.compare(a.box.left, b.box.left);
        });

        EnglishLineCandidate bestA = null;
        EnglishLineCandidate bestB = null;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            EnglishLineCandidate a = candidates.get(i);
            if (a.score > bestScore) {
                bestScore = a.score;
                bestA = a;
                bestB = null;
            }
            if (i + 1 < candidates.size()) {
                EnglishLineCandidate b = candidates.get(i + 1);
                if (linesBelongTogether(a, b, imageWidth, imageHeight)) {
                    int pairScore = a.score + b.score + 34;
                    if (pairScore > bestScore) {
                        bestScore = pairScore;
                        bestA = a;
                        bestB = b;
                    }
                }
            }
        }

        if (bestA == null || bestScore < 35) return "";
        String combined = bestB == null ? bestA.text : bestA.text + " " + bestB.text;
        combined = trimEnglishOcrNoise(combined.replaceAll("\\s+", " ").trim());
        return isGoodEnglishLine(combined) ? combined : "";
    }

    private boolean linesBelongTogether(EnglishLineCandidate a, EnglishLineCandidate b,
                                        int imageWidth, int imageHeight) {
        if (a == null || b == null) return false;
        int gap = b.box.top - a.box.bottom;
        int maxHeight = Math.max(1, Math.max(a.box.height(), b.box.height()));
        if (gap < -maxHeight / 2 || gap > maxHeight * 2) return false;

        int overlap = Math.max(0, Math.min(a.box.right, b.box.right) - Math.max(a.box.left, b.box.left));
        int minWidth = Math.max(1, Math.min(a.box.width(), b.box.width()));
        float overlapRatio = overlap / (float) minWidth;
        int centerDistance = Math.abs(a.box.centerX() - b.box.centerX());
        boolean horizontallyRelated = overlapRatio >= 0.18f
                || centerDistance <= Math.max(80, imageWidth / 4);
        if (!horizontallyRelated) return false;

        String ka = normalizeKey(a.text);
        String kb = normalizeKey(b.text);
        if (ka.equals(kb)) return false;
        return countEnglishWords(a.text) + countEnglishWords(b.text) >= 4;
    }

    private String cleanText(String raw, String mode) {
        if (raw == null) return "";
        String[] lines = raw.replace("\r", "").split("\n");
        StringBuilder cjk = new StringBuilder();
        StringBuilder all = new StringBuilder();
        List<String> englishLines = new ArrayList<>();

        for (String line : lines) {
            String s = line.trim();
            if (s.length() == 0) continue;
            String lower = s.toLowerCase(Locale.ROOT);
            if (isWatermarkOrUi(s, lower)) continue;

            if (MODE_ENGLISH.equals(mode)) {
                String e = cleanEnglishLine(s);
                if (e.length() == 0) continue;

                // Antes se elegía solo la “mejor” línea y por eso se perdían líneas de subtítulos largos.
                // Ahora se conservan todas las líneas útiles dentro del cuadro OCR.
                if (!isLikelySpanishLine(e) && !isBadEnglishFalsePositive(e)) {
                    if (isGoodEnglishLine(e) || commonEnglishWordScore(e) > 0) {
                        englishLines.add(e);
                    }
                }
                continue;
            }

            if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) {
                String onlyCjk = cleanCjkLine(s);
                if (cjkPattern.matcher(onlyCjk).find()) {
                    cjk.append(onlyCjk).append('\n');
                    continue;
                }
            }
            all.append(s).append('\n');
        }

        // Inglés: conserva como máximo las dos líneas más probables del subtítulo y respeta su orden.
        if (MODE_ENGLISH.equals(mode) && !englishLines.isEmpty()) {
            return selectBestEnglishLines(englishLines);
        }
        // CJK: devolver todas las líneas chinas/japonesas/coreanas detectadas.
        if ((MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) && cjk.length() > 0) {
            return cjk.toString().trim();
        }
        return all.toString().trim();
    }

    private String selectBestEnglishLines(List<String> lines) {
        if (lines == null || lines.isEmpty()) return "";
        int bestStart = 0;
        int bestEnd = 0;
        int bestScore = scoreEnglishLine(lines.get(0));

        for (int i = 0; i < lines.size(); i++) {
            int single = scoreEnglishLine(lines.get(i));
            if (single > bestScore) {
                bestScore = single;
                bestStart = i;
                bestEnd = i;
            }
            if (i + 1 < lines.size()) {
                int pair = single + scoreEnglishLine(lines.get(i + 1)) + 18;
                if (pair > bestScore) {
                    bestScore = pair;
                    bestStart = i;
                    bestEnd = i + 1;
                }
            }
        }

        StringBuilder out = new StringBuilder();
        for (int i = bestStart; i <= bestEnd; i++) {
            if (out.length() > 0) out.append(' ');
            out.append(lines.get(i));
        }
        return trimEnglishOcrNoise(out.toString().replaceAll("\\s+", " ").trim());
    }

    private boolean isWatermarkOrUi(String s, String lower) {
        return lower.contains("video eagle")
                || lower.contains("tencent")
                || lower.contains("zeta live translator")
                || lower.contains("ocr solo")
                || lower.contains("order by")
                || lower.contains("date added")
                || lower.contains("date published")
                || lower.contains("popular:")
                || lower.contains("mother language")
                || lower.contains("spanish order")
                || lower.contains("auto") && lower.contains("español")
                || lower.contains("chino") && lower.contains("es")
                || lower.contains("inglés") && lower.contains("es")
                || lower.contains("japonés") && lower.contains("es")
                || lower.contains("coreano") && lower.contains("es")
                || lower.equals("área")
                || lower.equals("trad.")
                || lower.equals("vivo")
                || lower.equals("pausa")
                || lower.equals("ok")
                || s.contains("腾讯视频")
                || s.contains("出品")
                || s.contains("云曦星空")
                || s.contains("AI专属");
    }

    private String polishSpanish(String translated) {
        if (translated == null) return "";
        String t = translated.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
        if (t.length() == 0) return t;
        return t.substring(0, 1).toUpperCase(Locale.ROOT) + t.substring(1);
    }

    private String guessFromCharacters(String text) {
        if (text == null) return null;
        if (koreanPattern.matcher(text).find()) return TranslateLanguage.KOREAN;
        if (japanesePattern.matcher(text).find()) return TranslateLanguage.JAPANESE;
        if (chinesePattern.matcher(text).find()) return TranslateLanguage.CHINESE;
        if (latinPattern.matcher(text).find()) return TranslateLanguage.ENGLISH;
        return null;
    }

    private String mapLanguage(String languageCode) {
        if (languageCode == null) return null;
        if (languageCode.startsWith("zh")) return TranslateLanguage.CHINESE;
        if (languageCode.startsWith("en")) return TranslateLanguage.ENGLISH;
        if (languageCode.startsWith("ja")) return TranslateLanguage.JAPANESE;
        if (languageCode.startsWith("ko")) return TranslateLanguage.KOREAN;
        if (languageCode.startsWith("es")) return TranslateLanguage.SPANISH;
        return null;
    }

    public void close() {
        for (TextRecognizer recognizer : recognizers.values()) {
            try { recognizer.close(); } catch (Exception ignored) { }
        }
        recognizers.clear();
        for (Translator translator : translators.values()) {
            try { translator.close(); } catch (Exception ignored) { }
        }
        translators.clear();
        translationCache.clear();
        resetStabilityState();
        resetContextState();
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) return "desconocido";
        return e.getMessage();
    }

    public String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        if (TranslateLanguage.SPANISH.equals(code)) return "Español";
        return code == null ? "Auto" : code;
    }
}
