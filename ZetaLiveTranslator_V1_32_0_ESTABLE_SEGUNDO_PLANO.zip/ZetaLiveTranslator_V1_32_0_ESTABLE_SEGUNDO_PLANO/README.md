# Zeta Live Translator 1.32.0

Traductor offline de subtítulos y texto visible en pantalla para **Inglés, Chino y Japonés → Español**. La aplicación está enfocada en usuarios de idioma español.

## Alcance

- Entrada: Inglés, Chino o Japonés.
- Salida fija: Español.
- Traducción manual o LIVE sobre otras aplicaciones.
- Sin reconocimiento de voz.
- Sin cuentas, inicio de sesión, nube ni funciones sociales.

## Funcionamiento sobre otras apps

Zeta utiliza:

1. permiso **Mostrar sobre otras apps** para la barra, el cuadro y los subtítulos;
2. autorización de captura de pantalla de Android para cada sesión;
3. servicio en primer plano con notificación permanente mientras el traductor está abierto.

En la pantalla principal se muestra el estado de superposición, notificaciones y optimización de batería. El botón **Abrir ajustes de batería** permite buscar Zeta y seleccionar **Sin restricciones** o **No optimizar** cuando el teléfono lo permita.

## Estabilidad

- Nunca inicia dos OCR o traducciones al mismo tiempo.
- Conserva solamente la captura más reciente que necesita procesar.
- Reduce automáticamente áreas demasiado grandes antes del OCR.
- En presión de memoria activa un modo temporal de menor consumo.
- Si una lectura queda bloqueada demasiado tiempo, reconstruye el motor sin cerrar el overlay ni solicitar nuevamente la captura.
- Guarda la posición del cuadro de captura, la barra y el subtítulo.

## Detectar idioma

- Analiza únicamente los modelos instalados.
- Detecta al inicio y después bloquea el idioma para mantener la velocidad.
- El botón muestra `Inglés✓`, `Chino✓` o `Japonés✓`.
- Tócalo para detectar nuevamente o mantenlo pulsado para cambiar manualmente.

## Uso

1. Descarga el idioma que necesites.
2. Prepara los permisos.
3. Revisa el ajuste de batería si el teléfono cierra aplicaciones agresivamente.
4. Pulsa **Iniciar traductor** y acepta la captura de pantalla.
5. Ajusta el cuadro alrededor de los subtítulos.
6. Pulsa **Traducir** o **LIVE**.

## Apariencia

Se puede personalizar:

- color, grosor y relleno del cuadro;
- tamaño, color, contorno y alineación del subtítulo;
- tamaño y transparencia de la barra flotante;
- posiciones del cuadro, barra y subtítulo.

Los subtítulos conservan fondo transparente, contorno y sombra para no tapar el video.

## Compilar en GitHub

1. Sube el contenido de esta carpeta a la raíz de un repositorio.
2. Abre **Actions → Build APK**.
3. Ejecuta **Run workflow**.
4. Descarga `ZetaLiveTranslator_APK_V1_32_0_ESTABLE_SEGUNDO_PLANO`.

El workflow ejecuta pruebas unitarias y genera un APK debug. Para Google Play todavía se requiere un AAB release firmado.

## Límites reales

Ningún OCR offline garantiza precisión total. Android puede cerrar cualquier aplicación si falta memoria, si el usuario fuerza su cierre o si el fabricante aplica restricciones propias. El servicio en primer plano, la optimización de imágenes y el ajuste de batería reducen el riesgo, pero no ofrecen una garantía absoluta.
