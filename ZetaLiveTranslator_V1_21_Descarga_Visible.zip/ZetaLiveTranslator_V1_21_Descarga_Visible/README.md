# Zeta Live Translator 1.21 - Descarga visible y verificable

Esta versión mejora el proceso de descarga individual de modelos offline sin inventar porcentajes que ML Kit no proporciona.

## Cambios principales

- Descarga manual e independiente para Inglés, Chino, Japonés y Coreano hacia Español.
- Servicio de descarga en primer plano para que el proceso tenga notificación propia.
- Barra animada mientras ML Kit trabaja.
- Tiempo transcurrido visible en formato `mm:ss`.
- Tipo y estado de conexión visible: Wi-Fi, datos, Ethernet, red sin internet o sin conexión.
- Etapas reales por componentes del par de traducción.
- Comprobación periódica cada 10 segundos para detectar si el modelo ya quedó instalado.
- Verificación final mediante `RemoteModelManager.isModelDownloaded` antes de marcar un idioma como Listo.
- Aviso si la descarga tarda más de tres minutos.
- Botón `Detener seguimiento` y opción `Reintentar` después de un fallo o detención.
- Recuperación del seguimiento si Android reinicia el servicio.
- Aviso preventivo si quedan menos de 150 MB libres.
- Mensajes claros cuando falta conexión o la instalación no puede verificarse.
- La app funciona desde el primer idioma instalado.
- El cuadro negro de traducción permanece visible desde el inicio.
- Zeta no utiliza `FLAG_SECURE`, por lo que no bloquea capturas por sí mismo.

## Qué significa el progreso

ML Kit no informa bytes descargados ni un porcentaje continuo. Por eso la aplicación no muestra cifras falsas. La información visible corresponde a:

- tiempo real transcurrido;
- conexión actual;
- componente actual;
- etapa del proceso;
- comprobación periódica;
- verificación final de instalación.

Para Inglés -> Español solo se necesita el componente Español porque Inglés está integrado en ML Kit. Para Chino, Japonés o Coreano se comprueba el modelo del idioma origen y el modelo Español.

## Flujo recomendado

1. Revisa los permisos.
2. Toca `Descargar Inglés`.
3. Observa la barra, tiempo, conexión y etapa.
4. Espera a que cambie a `Listo`.
5. Pulsa `Iniciar traductor`.
6. Ajusta el área morada y usa `Trad.` o `Vivo`.

## Limitaciones honestas

No existe un porcentaje real de bytes con la API de descarga de ML Kit. `Detener seguimiento` detiene el servicio y la supervisión de Zeta, pero ML Kit podría terminar internamente una descarga que ya había comenzado. Al pulsar `Reintentar`, la app vuelve a comprobar los componentes y aprovecha los que ya estén instalados.

Una aplicación externa con DRM puede seguir bloqueando capturas aunque Zeta no utilice `FLAG_SECURE`.
