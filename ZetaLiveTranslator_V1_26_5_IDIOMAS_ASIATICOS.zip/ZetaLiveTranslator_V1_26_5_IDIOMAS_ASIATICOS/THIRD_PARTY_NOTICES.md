# Third-party notices

The file `app/src/main/assets/english_ocr_vocabulary.txt` was generated from the English frequency list exposed by the open-source `wordfreq` project.

- Project: wordfreq
- License: Apache License 2.0
- Project page: https://github.com/rspeer/wordfreq

The vocabulary is used only to validate OCR candidates. It is not a translation model.
