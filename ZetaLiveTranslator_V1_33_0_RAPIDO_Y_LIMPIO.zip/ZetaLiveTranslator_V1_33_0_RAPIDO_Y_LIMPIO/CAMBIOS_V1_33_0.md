# Zeta Live Translator v1.33.0

## Traducción rápida para videos
- Inglés, Chino y Japonés usan la misma ruta rápida.
- LIVE revisa el área cada 240 ms sin iniciar dos OCR a la vez.
- Una lectura clara se traduce desde la primera captura.
- Se eliminó la confirmación obligatoria de dos capturas.
- Se eliminó el reescalado previo que ralentizaba y deformaba letras pequeñas.
- La mejora de imagen queda únicamente como respaldo cuando la primera lectura está vacía o contiene ruido.
- Si aparece un subtítulo mientras la lectura anterior sigue ocupada, se procesa la captura más reciente inmediatamente después.
- Las palabras cortas, frases largas y expresiones de un solo carácter CJK siguen la ruta rápida.

## Subtítulos
- Texto completamente blanco.
- Sin contorno negro.
- Sin sombra negra.
- Sin fondo negro.
- Fondo transparente y máximo de tres líneas.

## Segundo plano
- **Preparar segundo plano** guía notificaciones, superposición y batería en una sola secuencia.
- La batería se solicita directamente para Zeta mediante el paquete de la aplicación.
- Ya no abre la lista general donde había que buscar la app manualmente.
- El servicio de proyección continúa como servicio en primer plano con notificación.

## Interfaz
- Pantalla principal reducida a estado, iniciar, segundo plano y tres accesos compactos.
- Idiomas, Apariencia y Ajustes se abren en ventanas separadas.
- Se eliminaron las tarjetas largas y los textos repetidos.
