package com.geozeta.livetranslator;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class FastSubtitlePolicyTest {
    @Test public void clearShortEnglishUsesOnePass() {
        assertFalse(FastSubtitlePolicy.requiresEnhancedPass(true, 1, 0, 0, 60));
    }

    @Test public void clearLongEnglishUsesOnePass() {
        assertFalse(FastSubtitlePolicy.requiresEnhancedPass(true, 8, 0, 0, 180));
    }

    @Test public void clearSingleChineseCharacterUsesOnePass() {
        assertFalse(FastSubtitlePolicy.requiresEnhancedPass(false, 0, 1, 0, 0));
    }

    @Test public void clearSingleJapaneseCharacterUsesOnePass() {
        assertFalse(FastSubtitlePolicy.requiresEnhancedPass(false, 0, 1, 0, 0));
    }

    @Test public void emptyOrSuspiciousTextUsesFallback() {
        assertTrue(FastSubtitlePolicy.requiresEnhancedPass(false, 0, 0, 0, 0));
        assertTrue(FastSubtitlePolicy.requiresEnhancedPass(true, 1, 0, 1, 100));
    }
}
