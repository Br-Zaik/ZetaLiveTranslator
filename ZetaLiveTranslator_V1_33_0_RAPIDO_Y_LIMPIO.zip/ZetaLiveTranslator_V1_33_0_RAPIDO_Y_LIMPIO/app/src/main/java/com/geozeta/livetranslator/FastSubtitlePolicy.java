package com.geozeta.livetranslator;

/** Decides whether a second OCR pass is necessary without delaying clear subtitles. */
final class FastSubtitlePolicy {
    private FastSubtitlePolicy() { }

    static boolean requiresEnhancedPass(boolean english, int words, int scriptCount,
                                        int suspiciousCharacters, int englishScore) {
        if (english) {
            if (words >= 1 && suspiciousCharacters == 0) return false;
            return englishScore < 45 || suspiciousCharacters > 0;
        }
        if (scriptCount >= 1 && suspiciousCharacters == 0) return false;
        return scriptCount == 0 || suspiciousCharacters > 0;
    }
}
