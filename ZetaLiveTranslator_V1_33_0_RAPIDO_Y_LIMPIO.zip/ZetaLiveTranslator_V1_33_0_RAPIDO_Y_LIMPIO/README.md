# Zeta Live Translator 1.33.0

Traductor offline de texto visible en videos para **Inglés, Chino y Japonés → Español**.

## Uso

1. Abre **Idiomas** y descarga el idioma necesario.
2. Pulsa **Preparar segundo plano** y concede notificaciones, mostrar sobre otras apps y batería sin restricciones.
3. Pulsa **Iniciar traductor** y acepta la captura de pantalla.
4. Coloca el cuadro sobre los subtítulos y activa **LIVE**.

## Velocidad

- Intervalo LIVE de 240 ms para Inglés, Chino y Japonés.
- Una lectura clara se traduce de inmediato.
- No exige dos capturas para confirmar palabras cortas ni frases largas.
- No reduce ni reescala la imagen antes del OCR normal.
- Solo usa una lectura mejorada cuando el OCR directo queda vacío o contiene ruido.
- Nunca inicia dos OCR o traducciones simultáneas.

## Subtítulos

- Letras completamente blancas.
- Sin borde, sombra ni fondo negro.
- Fondo transparente.
- Hasta tres líneas, movibles y con tamaño configurable.

## Segundo plano

Zeta usa un servicio en primer plano de tipo `mediaProjection`, una notificación permanente y el permiso de superposición. El botón **Preparar segundo plano** solicita directamente que Android excluya a Zeta de la optimización de batería, sin abrir una lista general de aplicaciones.

## Interfaz

La pantalla principal contiene únicamente:

- estado del idioma;
- botón **Iniciar traductor**;
- estado del segundo plano;
- accesos a **Idiomas**, **Apariencia** y **Ajustes**.

## Compilar en GitHub

1. Sube el contenido de esta carpeta a la raíz de un repositorio.
2. Abre **Actions → Build APK**.
3. Ejecuta **Run workflow**.
4. Descarga `ZetaLiveTranslator_APK_V1_33_0_RAPIDO_Y_LIMPIO`.

El entorno actual no pudo descargar Gradle, por lo que el APK debe generarse mediante GitHub Actions o Android Studio.
