# Zeta Live Translator 1.26.7

Versión enfocada en dos objetivos: **interfaz principal compacta** y **mejor lectura/traducción de subtítulos en Inglés, Chino, Japonés y Coreano → Español**, manteniendo el procesamiento offline de ML Kit después de descargar los modelos.

## Interfaz principal

- Diseño compacto basado en la opción 2 aprobada.
- Menos texto y menos separación vertical.
- Solo aparecen las funciones reales de la pantalla principal: permisos, iniciar traductor, glosario y modelos por idioma.
- Lista compacta de los cuatro modelos y su estado.

## Traducción y OCR

- Inglés: reconoce mejor palabras solas y frases cortas como `No`, `OK`, `Hi`, `Why`, etc.
- Chino: acepta expresiones breves y caracteres independientes de alta confianza.
- Japonés: acepta hiragana/katakana breves y kanji independientes de alta confianza.
- Coreano: acepta expresiones breves de una sola sílaba de alta confianza.
- Auto cambia de idioma antes cuando el idioma anterior deja de coincidir.
- Auto ya no exige un puntaje excesivo para expresiones asiáticas cortas reales.
- Vivo mantiene el consenso de dos lecturas, pero reduce la espera mínima para no perder subtítulos rápidos.
- Las siglas latinas cortas dentro de texto asiático (`AI`, `3D`, etc.) ya no se borran automáticamente.
- La jerga asiática no se reescribe dentro de frases largas cuando el significado depende del contexto.
- Palabras iguales en inglés y español como `hotel`, `taxi` o `internet` pueden conservarse sin marcarse como fallo.

## Glosario de correcciones

Ahora admite los cuatro idiomas mediante prefijos:

```text
EN: Good morning => Buenos días
ZH: 你好 => Hola
JA: ありがとう => Gracias
KO: 고마워 => Gracias
```

Las entradas antiguas sin prefijo siguen tratándose como Inglés → Español.

## Modo Vivo

```text
Captura del cuadro
→ OCR del idioma elegido/Auto
→ limpieza segura
→ consenso de 2 lecturas
→ traducción offline
→ validación
→ subtítulo en español
```

El intervalo LIVE principal se mantiene en 400 ms. La mejora está en aceptar antes una lectura confirmada, no en hacer el ciclo más pesado.

## Compilar en GitHub

1. Sube el contenido de esta carpeta a la raíz del repositorio, incluida `.github`.
2. Abre **Actions → Build APK**.
3. Ejecuta **Run workflow**.
4. El workflow configura Java 17, Android 35 y Gradle 8.13.
5. Descarga el artefacto `ZetaLiveTranslator_APK_V1_26_7_4Idiomas_UICompacta`.

## Nota

La calidad final sigue dependiendo de la nitidez del subtítulo y del modelo offline de ML Kit. El cuadro de captura debe cubrir solo el área del subtítulo para reducir falsos positivos y mantener velocidad.
