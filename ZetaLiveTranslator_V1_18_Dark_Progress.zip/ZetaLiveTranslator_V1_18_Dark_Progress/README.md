# Zeta Live Translator V1.18

Versión con interfaz oscura profesional y seguimiento claro de la preparación offline.

## Cambios V1.18

- Diseño oscuro en gris grafito con acento azul.
- Pantalla más compacta, con solo dos acciones principales.
- Barra horizontal de progreso de 0 a 100%.
- Porcentaje basado en idiomas completados: 0%, 25%, 50%, 75% y 100%.
- Estado individual para Inglés, Chino, Japonés y Coreano.
- Temporizador visible mientras la descarga está activa.
- Detección de conexión antes de descargar.
- Mensajes de error más claros y opción de reintentar.
- Conserva los idiomas ya completados si una descarga posterior falla.
- Botones desactivados ahora se ven realmente desactivados.
- Mantiene todas las correcciones funcionales de la versión 1.16.

## Nota sobre el porcentaje

ML Kit no informa el porcentaje de bytes de cada modelo. Por eso la app muestra progreso real por idiomas terminados: cada uno representa 25% del proceso total. Mientras un modelo se descarga, se muestra su nombre y el tiempo transcurrido.
