# Zeta Live Translator V1.17

Versión corregida para traducir subtítulos sobre otras apps.


## Cambios V1.17

- La selección y el subtítulo conservan su posición proporcional al girar el teléfono.
- La captura cambia de tamaño sin crear otro `VirtualDisplay` con el mismo permiso.
- El modo Vivo elimina ciclos duplicados y comprueba dos lecturas consecutivas antes de traducir.
- Los subtítulos cortos pueden usar la frase anterior como contexto; si la separación no es segura, vuelve automáticamente a la traducción directa.
- Durante la captura se ocultan temporalmente todos los overlays, incluido el subtítulo traducido, para impedir que el OCR lea su propio texto.
- Normalización inteligente de palabras alargadas: `gooood` → `good`, `noooo` → `no`, `pleaaase` → `please`.
- Se eliminó la corrección peligrosa `were` → `we are` y los parches de frases específicas.
- Los reconocedores OCR y traductores se reutilizan mientras el servicio está abierto.
- Cierre limpio de callbacks, capturas y motores pendientes.
- Selector con puntos táctiles más precisos y barra flotante arrastrable de forma consistente.
- Mapeo proporcional entre el área visible y el bitmap capturado.

## Cambios V1.15

- Modo **Auto → Español** por defecto.
- OCR probado por idioma: Inglés, Chino, Japonés y Coreano.
- Se quitó el aviso grande de “No se detectó texto” para que no moleste en video.
- El cuadro ya no se recrea por accidente al tocar fuera.
- El cuadro se mueve tocando dentro y arrastrando.
- El cuadro se estira desde cualquiera de los puntos morados.
- Después de traducir, desaparece el cuadro y queda solo el subtítulo.
- Primera vez: usar internet y tocar **Preparar offline** para descargar modelos.

## Uso rápido

1. Abrir la app con internet.
2. Tocar **Preparar offline**.
3. Activar **Permiso sobre otras apps**.
4. Tocar **Iniciar traductor**.
5. En el video tocar **Área**.
6. Mover o estirar el cuadro sobre el subtítulo.
7. Tocar **OK**.
8. Tocar **Trad.** o **Vivo**.

Si el texto no aparece, no saldrá aviso grande en medio; solo ajusta el cuadro más cerca del subtítulo o pausa el video.


NOVEDAD V1.15:
- Subtítulo con fondo negro semitransparente y letras blancas.
- El cuadro ya no se recrea al tocar fuera; solo se mueve o estira.
- Traducción Auto→Español para Inglés, Chino, Japonés y Coreano.


NOVEDAD V1.15:
- El subtítulo se oculta solo durante el instante de captura para que el OCR no lo vuelva a leer.
- Puedes arrastrar el subtítulo y colocarlo donde quieras.
- Botón Ocultar/Mostrar para dar prioridad al video.
- La barra superior sigue movible.


NOVEDAD V1.15 TRADUCCIÓN:
- Prioriza la línea en inglés cuando hay inglés + chino al mismo tiempo, porque traduce mejor a español.
- Limpia OCR pegado y errores comunes: athome→at home, dothes→clothes, wheres→where is.
- Evita releer el subtítulo español propio como texto original.
- Filtros para no agarrar títulos raros o marcas si hay una frase real de subtítulo.


NOVEDAD V1.15:
- Corrige el error donde el OCR podía leer el subtítulo de la misma app o un título falso como "Scratchman Curse".
- Las ventanas flotantes usan FLAG_SECURE para que no se capturen como texto original.
- En Auto se rechazan falsos positivos cortos/títulos cuando hay subtítulos reales.
- Prioridad: traducción correcta antes que apariencia.


NOVEDAD V1.15:
- En vivo más rápido: menor espera de captura y ciclo más corto.
- Auto prueba primero el último idioma detectado y compara los resultados para elegir el texto más fiable.
- Caché de traducciones para no traducir la misma frase repetida.
- Flecha ‹ / › para ocultar o mostrar la barra larga.
- X cierra totalmente el traductor.
- El subtítulo queda estable, con prioridad sobre la configuración.


NOVEDAD V1.15 ANTI-CONGELADO:
- Si una traducción se queda colgada, la app libera el bloqueo sola.
- El botón Trad. fuerza una captura nueva y reinicia Auto para no quedarse con el mismo subtítulo.
- Se limpian screenshots viejos antes de capturar, para evitar repetir el texto anterior.
- Corrección de captura para evitar errores raros en el bitmap.


NOVEDAD V1.15:
- Corrección fuerte para subtítulos multilínea.
- Ya no toma solo la primera fila: junta todas las líneas útiles dentro del cuadro OCR.
- Mantiene las mejoras anti-congelado de V1.14.
- Mejor puntuación en Auto para bloques de varias líneas.
