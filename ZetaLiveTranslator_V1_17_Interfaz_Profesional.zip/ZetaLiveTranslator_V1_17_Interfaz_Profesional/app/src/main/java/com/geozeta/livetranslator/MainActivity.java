package com.geozeta.livetranslator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 501;
    private static final int REQ_NOTIFICATIONS = 502;
    private static final String PREFS = "zeta_live_translator";
    private static final String KEY_MODELS_READY = "models_ready";
    private static final String KEY_FIRST_RUN_DIALOG_SHOWN = "first_run_dialog_shown";

    private SharedPreferences prefs;

    private TextView statusTitle;
    private TextView statusDetail;
    private TextView modelsState;
    private TextView overlayState;
    private TextView notificationsState;
    private TextView captureState;
    private ProgressBar progress;
    private Button setupBtn;
    private Button permissionsBtn;
    private Button prepareBtn;
    private Button startBtn;

    private boolean preparingModels = false;
    private boolean guidedSetupPending = false;

    private final List<String> offlineSources = Arrays.asList(
            TranslateLanguage.CHINESE,
            TranslateLanguage.ENGLISH,
            TranslateLanguage.JAPANESE,
            TranslateLanguage.KOREAN
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        refreshStateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStateUi();
        if (!prefs.getBoolean(KEY_FIRST_RUN_DIALOG_SHOWN, false)) {
            prefs.edit().putBoolean(KEY_FIRST_RUN_DIALOG_SHOWN, true).apply();
            if (needsConfiguration()) {
                findViewById(android.R.id.content).post(this::showFirstRunDialog);
            }
        } else if (guidedSetupPending && !preparingModels) {
            continueGuidedSetup();
        }
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(0xFFF3F5FA);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(24));
        scrollView.addView(root, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout hero = makeCard();
        hero.setBackground(makeRoundedBackground(18, 0xFFFFFFFF, 0xFFE7EAF3, 1));
        hero.setPadding(dp(20), dp(22), dp(20), dp(22));

        TextView title = new TextView(this);
        title.setText("Zeta Live Translator");
        title.setTextSize(28);
        title.setTextColor(0xFF101828);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        hero.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Traduce subtítulos en tiempo real dentro de un área seleccionada. Configura los idiomas una vez con internet y luego úsala sin conexión.");
        subtitle.setTextSize(15);
        subtitle.setTextColor(0xFF475467);
        subtitle.setLineSpacing(0f, 1.15f);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(10);
        hero.addView(subtitle, subLp);

        TextView badge = makeBadge("Configuración guiada");
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(-2, -2);
        badgeLp.topMargin = dp(14);
        hero.addView(badge, badgeLp);
        root.addView(hero);

        LinearLayout statusCard = makeCard();
        addSectionTitle(statusCard, "Estado del sistema");
        modelsState = addStateRow(statusCard, "Idiomas offline", "Pendiente");
        overlayState = addStateRow(statusCard, "Permiso sobre otras apps", "Pendiente");
        notificationsState = addStateRow(statusCard, "Notificaciones", "Pendiente");
        captureState = addStateRow(statusCard, "Captura de pantalla", "Se solicita al iniciar");
        root.addView(statusCard, cardLp());

        LinearLayout actionCard = makeCard();
        addSectionTitle(actionCard, "Acciones principales");

        setupBtn = makePrimaryButton("Configurar ahora");
        setupBtn.setOnClickListener(v -> startGuidedSetup(false));
        actionCard.addView(setupBtn, actionLp());

        permissionsBtn = makeSecondaryButton("Conceder permisos");
        permissionsBtn.setOnClickListener(v -> openMissingPermission());
        actionCard.addView(permissionsBtn, actionLp());

        prepareBtn = makeSecondaryButton("Preparar idiomas offline");
        prepareBtn.setOnClickListener(v -> prepareOfflineModels(false));
        actionCard.addView(prepareBtn, actionLp());

        startBtn = makePrimaryButton("Iniciar traducción");
        startBtn.setOnClickListener(v -> startCaptureFlow());
        actionCard.addView(startBtn, actionLp());
        root.addView(actionCard, cardLp());

        LinearLayout resultCard = makeCard();
        addSectionTitle(resultCard, "Estado actual");

        statusTitle = new TextView(this);
        statusTitle.setTextSize(17);
        statusTitle.setTextColor(0xFF101828);
        statusTitle.setTypeface(Typeface.DEFAULT_BOLD);
        resultCard.addView(statusTitle, new LinearLayout.LayoutParams(-1, -2));

        statusDetail = new TextView(this);
        statusDetail.setTextSize(14);
        statusDetail.setTextColor(0xFF475467);
        statusDetail.setLineSpacing(0f, 1.15f);
        LinearLayout.LayoutParams detailLp = new LinearLayout.LayoutParams(-1, -2);
        detailLp.topMargin = dp(6);
        resultCard.addView(statusDetail, detailLp);

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(dp(34), dp(34));
        pLp.topMargin = dp(14);
        resultCard.addView(progress, pLp);
        root.addView(resultCard, cardLp());

        LinearLayout helpCard = makeCard();
        addSectionTitle(helpCard, "Uso rápido");
        addBullet(helpCard, "Pulsa Configurar ahora para descargar modelos y revisar permisos.");
        addBullet(helpCard, "Cuando todo esté listo, usa Iniciar traducción para otorgar el permiso de captura.");
        addBullet(helpCard, "Luego elige Área, ajusta el cuadro y usa Trad. o Vivo.");
        root.addView(helpCard, cardLp());

        setContentView(scrollView);
    }

    private void showFirstRunDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Configuración inicial")
                .setMessage("La app puede guiarte de una vez para conceder permisos y preparar los idiomas offline. Android pedirá algunos permisos del sistema en los pasos correspondientes.")
                .setPositiveButton("Configurar ahora", (dialog, which) -> startGuidedSetup(true))
                .setNegativeButton("Más tarde", null)
                .show();
    }

    private void startGuidedSetup(boolean includeStartAfterReady) {
        guidedSetupPending = true;
        updateStatus("Configuración en curso", "Se revisarán permisos y, si hace falta, se descargarán los idiomas offline.");
        continueGuidedSetup();
        if (includeStartAfterReady && !needsConfiguration()) {
            startCaptureFlow();
        }
    }

    private void continueGuidedSetup() {
        boolean notificationsGranted = areNotificationsReady();
        boolean overlayGranted = isOverlayReady();
        boolean modelsReady = areModelsReady();

        if (!notificationsGranted && Build.VERSION.SDK_INT >= 33) {
            updateStatus("Falta permiso de notificaciones", "Android mostrará el permiso para que la app pueda mantener su servicio visible en primer plano.");
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }

        if (!overlayGranted) {
            updateStatus("Falta permiso sobre otras apps", "Android abrirá la pantalla donde debes activar este permiso para mostrar la barra flotante.");
            requestOverlayPermission();
            return;
        }

        if (!modelsReady) {
            prepareOfflineModels(true);
            return;
        }

        guidedSetupPending = false;
        updateStatus("Todo listo", "La configuración principal está completa. Ahora pulsa Iniciar traducción para que Android solicite la captura de pantalla.");
        refreshStateUi();
    }

    private void openMissingPermission() {
        if (!areNotificationsReady() && Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }
        if (!isOverlayReady()) {
            requestOverlayPermission();
            return;
        }
        toast("Los permisos principales ya están concedidos.");
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } else {
            toast("El permiso sobre otras apps ya está activo.");
        }
    }

    private void startCaptureFlow() {
        if (!areModelsReady()) {
            updateStatus("Faltan idiomas offline", "Primero prepara los idiomas para evitar fallos de traducción sin conexión.");
            toast("Primero prepara los idiomas offline.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            updateStatus("Falta permiso sobre otras apps", "Activa ese permiso para mostrar la barra flotante encima del video.");
            requestOverlayPermission();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        updateStatus("Solicitando captura", "Android mostrará su cuadro oficial para autorizar la captura de pantalla.");
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, OverlayTranslatorService.class);
                service.putExtra(OverlayTranslatorService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(OverlayTranslatorService.EXTRA_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(service);
                } else {
                    startService(service);
                }
                updateStatus("Traductor iniciado", "La barra flotante ya puede usarse. Pulsa Área, ajusta el cuadro y luego usa Trad. o Vivo.");
                toast("Traductor iniciado.");
                moveTaskToBack(true);
            } else {
                updateStatus("Captura cancelada", "No se concedió el permiso de captura. Puedes intentarlo nuevamente cuando quieras.");
                toast("Permiso de captura cancelado.");
            }
        }
    }

    private void prepareOfflineModels(boolean fromGuidedSetup) {
        if (preparingModels) return;
        preparingModels = true;
        guidedSetupPending = guidedSetupPending || fromGuidedSetup;
        progress.setVisibility(View.VISIBLE);
        prepareBtn.setEnabled(false);
        setupBtn.setEnabled(false);
        updateStatus("Preparando idiomas offline", "Se descargarán los modelos para Inglés, Chino, Japonés y Coreano hacia Español.");
        downloadModelAt(0);
        refreshStateUi();
    }

    private void downloadModelAt(int index) {
        if (index >= offlineSources.size()) {
            preparingModels = false;
            progress.setVisibility(View.GONE);
            prepareBtn.setEnabled(true);
            setupBtn.setEnabled(true);
            prefs.edit().putBoolean(KEY_MODELS_READY, true).apply();
            updateStatus("Idiomas listos", "Los modelos offline ya quedaron preparados. Puedes traducir sin depender de internet.");
            toast("Modelos listos.");
            refreshStateUi();
            if (guidedSetupPending) continueGuidedSetup();
            return;
        }

        String source = offlineSources.get(index);
        updateStatus("Descargando idioma", "Preparando " + readable(source) + " → Español...");
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        Translator translator = Translation.getClient(options);
        translator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(unused -> {
                    translator.close();
                    downloadModelAt(index + 1);
                })
                .addOnFailureListener(e -> {
                    translator.close();
                    preparingModels = false;
                    guidedSetupPending = false;
                    progress.setVisibility(View.GONE);
                    prepareBtn.setEnabled(true);
                    setupBtn.setEnabled(true);
                    updateStatus("No se pudo completar la descarga", "Falló " + readable(source) + ". Revisa tu internet y vuelve a intentarlo.");
                    toast("Fallo descarga: " + e.getMessage());
                    refreshStateUi();
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) {
            refreshStateUi();
            if (guidedSetupPending && !preparingModels) {
                continueGuidedSetup();
            }
        }
    }

    private void refreshStateUi() {
        boolean modelsReady = areModelsReady();
        boolean overlayReady = isOverlayReady();
        boolean notificationsReady = areNotificationsReady();

        setStateBadge(modelsState, modelsReady ? "Listo" : (preparingModels ? "Descargando" : "Pendiente"),
                modelsReady ? 0xFFE8F5E9 : (preparingModels ? 0xFFEDE9FE : 0xFFFEF3F2),
                modelsReady ? 0xFF1B5E20 : (preparingModels ? 0xFF5B21B6 : 0xFFB42318));
        setStateBadge(overlayState, overlayReady ? "Listo" : "Pendiente",
                overlayReady ? 0xFFE8F5E9 : 0xFFFEF3F2,
                overlayReady ? 0xFF1B5E20 : 0xFFB42318);
        setStateBadge(notificationsState, notificationsReady ? "Listo" : "Opcional",
                notificationsReady ? 0xFFE8F5E9 : 0xFFFFF4E5,
                notificationsReady ? 0xFF1B5E20 : 0xFFB54708);
        setStateBadge(captureState, "Se pedirá al iniciar",
                0xFFF2F4F7,
                0xFF344054);

        permissionsBtn.setEnabled(!overlayReady || !notificationsReady);
        prepareBtn.setEnabled(!preparingModels);
        startBtn.setEnabled(modelsReady && overlayReady);

        if (modelsReady && overlayReady) {
            setupBtn.setText("Revisar configuración");
        } else {
            setupBtn.setText("Configurar ahora");
        }

        if (statusTitle.getText() == null || statusTitle.getText().length() == 0) {
            if (modelsReady && overlayReady) {
                updateStatus("App lista", "Ya puedes iniciar la traducción. Android pedirá el permiso de captura cuando pulses el botón correspondiente.");
            } else {
                updateStatus("Configuración pendiente", "Completa los permisos y prepara los idiomas para una experiencia más estable.");
            }
        }
    }

    private boolean needsConfiguration() {
        return !areModelsReady() || !isOverlayReady() || !areNotificationsReady();
    }

    private boolean areModelsReady() {
        return prefs.getBoolean(KEY_MODELS_READY, false);
    }

    private boolean isOverlayReady() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private boolean areNotificationsReady() {
        return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void updateStatus(String title, String detail) {
        statusTitle.setText(title);
        statusDetail.setText(detail);
    }

    private LinearLayout makeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(makeRoundedBackground(18, 0xFFFFFFFF, 0xFFE7EAF3, 1));
        card.setElevation(dp(2));
        return card;
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(16);
        return lp;
    }

    private void addSectionTitle(LinearLayout parent, String text) {
        TextView title = new TextView(this);
        title.setText(text);
        title.setTextSize(17);
        title.setTextColor(0xFF101828);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        parent.addView(title, new LinearLayout.LayoutParams(-1, -2));
    }

    private TextView addStateRow(LinearLayout parent, String label, String initialState) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.topMargin = dp(12);
        row.setLayoutParams(rowLp);

        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextSize(14);
        labelView.setTextColor(0xFF344054);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(0, -2, 1f);
        row.addView(labelView, labelLp);

        TextView stateView = makeBadge(initialState);
        row.addView(stateView);
        parent.addView(row);
        return stateView;
    }

    private void addBullet(LinearLayout parent, String text) {
        TextView bullet = new TextView(this);
        bullet.setText("• " + text);
        bullet.setTextSize(14);
        bullet.setTextColor(0xFF475467);
        bullet.setLineSpacing(0f, 1.15f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        parent.addView(bullet, lp);
    }

    private TextView makeBadge(String text) {
        TextView badge = new TextView(this);
        badge.setText(text);
        badge.setTextSize(12);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setTextColor(0xFF5B21B6);
        badge.setPadding(dp(10), dp(6), dp(10), dp(6));
        badge.setBackground(makeRoundedBackground(999, 0xFFF4EBFF, 0x00000000, 0));
        return badge;
    }

    private void setStateBadge(TextView badge, String text, int bgColor, int textColor) {
        badge.setText(text);
        badge.setTextColor(textColor);
        badge.setBackground(makeRoundedBackground(999, bgColor, 0x00000000, 0));
    }

    private Button makePrimaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(0xFFFFFFFF);
        b.setAllCaps(false);
        b.setPadding(dp(16), dp(15), dp(16), dp(15));
        b.setBackground(makeRoundedBackground(16, 0xFF6D28D9, 0x00000000, 0));
        return b;
    }

    private Button makeSecondaryButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setTextColor(0xFF344054);
        b.setAllCaps(false);
        b.setPadding(dp(16), dp(15), dp(16), dp(15));
        b.setBackground(makeRoundedBackground(16, 0xFFF2F4F7, 0xFFE4E7EC, 1));
        return b;
    }

    private LinearLayout.LayoutParams actionLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        return lp;
    }

    private GradientDrawable makeRoundedBackground(int radiusDp, int fillColor, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setColor(fillColor);
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        return code;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
