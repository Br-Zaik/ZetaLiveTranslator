package com.geozeta.livetranslator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pasa números chinos a cifras antes de traducir (十天 → 10天, 百分之七十 → 70%).
 * El traductor respeta las cifras mucho mejor que los números escritos.
 * Solo se cambian cuando van con una unidad o con 第 / 百分之, para no tocar
 * expresiones como 一会儿, 万一, 千万不要 o 七上八下.
 */
final class ChineseNumbers {
    private static final String NUMERALS = "零〇一二两兩三四五六七八九十百千万萬";
    private static final String UNITS = "天年月日个個次人位名岁歲里丈米层層级級倍只隻头頭条條道座秒招件本张張句步";
    private static final Pattern RUN = Pattern.compile("[" + NUMERALS + "]+");

    private ChineseNumbers() { }

    static String toDigits(String text) {
        if (text == null || text.isEmpty()) return text;
        Matcher m = RUN.matcher(text);
        StringBuilder out = new StringBuilder(text.length());
        int cursor = 0;
        while (m.find()) {
            String run = m.group();
            int start = m.start();
            int end = m.end();
            boolean percent = start >= 3 && text.startsWith("百分之", start - 3);
            boolean ordinal = start >= 1 && text.charAt(start - 1) == '第';
            boolean unit = end < text.length() && UNITS.indexOf(text.charAt(end)) >= 0;
            // "一" solo casi nunca es una cantidad importante y aparece en muchas palabras.
            boolean meaningful = !(run.length() == 1 && (run.equals("一") || run.equals("万") || run.equals("萬")
                    || run.equals("千") || run.equals("百") || run.equals("零") || run.equals("〇")));
            long value = meaningful && (percent || ordinal || unit) ? parse(run) : -1L;
            if (value < 0) continue;
            if (percent) {
                out.append(text, cursor, start - 3).append(value).append('%');
            } else {
                out.append(text, cursor, start).append(value);
            }
            cursor = end;
        }
        if (cursor == 0) return text;
        out.append(text.substring(cursor));
        return out.toString();
    }

    static long parse(String run) {
        long total = 0;
        long section = 0;
        long number = 0;
        boolean any = false;
        for (int i = 0; i < run.length(); i++) {
            char c = run.charAt(i);
            int digit = "零一二三四五六七八九".indexOf(c);
            if (c == '〇') digit = 0;
            if (c == '两' || c == '兩') digit = 2;
            if (digit >= 0) {
                number = digit;
                any = true;
                continue;
            }
            int unit = c == '十' ? 10 : c == '百' ? 100 : c == '千' ? 1000 : 0;
            if (unit > 0) {
                if (number == 0) number = 1;
                section += number * unit;
                number = 0;
                any = true;
            } else if (c == '万' || c == '萬') {
                section = (section + number) * 10000;
                total += section;
                section = 0;
                number = 0;
                any = true;
            }
        }
        return any ? total + section + number : -1L;
    }
}
