package com.geozeta.livetranslator;

import static org.junit.Assert.*;

import org.junit.Test;

public class ChineseNumbersTest {
    @Test public void casosDelVideo() {
        assertEquals("我们最快也要10天才能抵达", ChineseNumbers.toDigits("我们最快也要十天才能抵达"));
        assertEquals("兽域聚集了斗气大陆将近70%的魔兽家族", ChineseNumbers.toDigits("兽域聚集了斗气大陆将近百分之七十的魔兽家族"));
        assertEquals("但我族麾下拥有近10个附属族群", ChineseNumbers.toDigits("但我族麾下拥有近十个附属族群"));
    }

    @Test public void valores() {
        assertEquals(10, ChineseNumbers.parse("十"));
        assertEquals(15, ChineseNumbers.parse("十五"));
        assertEquals(25, ChineseNumbers.parse("二十五"));
        assertEquals(305, ChineseNumbers.parse("三百零五"));
        assertEquals(20000, ChineseNumbers.parse("两万"));
        assertEquals(10000000, ChineseNumbers.parse("千万"));
    }

    @Test public void noTocaExpresiones() {
        assertEquals("老夫先去睡一会儿", ChineseNumbers.toDigits("老夫先去睡一会儿"));
        assertEquals("万一他来了", ChineseNumbers.toDigits("万一他来了"));
        assertEquals("千万不要去", ChineseNumbers.toDigits("千万不要去"));
        assertEquals("至于那万兽至尊", ChineseNumbers.toDigits("至于那万兽至尊"));
        assertEquals("魔兽三大族群", ChineseNumbers.toDigits("魔兽三大族群"));
        assertEquals("一个人", ChineseNumbers.toDigits("一个人"));
        assertEquals("第3层", ChineseNumbers.toDigits("第三层"));
    }
}
