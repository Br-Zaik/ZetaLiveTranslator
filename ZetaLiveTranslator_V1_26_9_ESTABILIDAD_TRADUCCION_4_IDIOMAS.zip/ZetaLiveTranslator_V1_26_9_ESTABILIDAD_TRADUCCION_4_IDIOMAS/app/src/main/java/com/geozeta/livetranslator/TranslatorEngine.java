package com.geozeta.livetranslator;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TranslatorEngine {
    public static final String MODE_AUTO = "auto";
    public static final String MODE_CHINESE = TranslateLanguage.CHINESE;
    public static final String MODE_ENGLISH = TranslateLanguage.ENGLISH;
    public static final String MODE_JAPANESE = TranslateLanguage.JAPANESE;
    public static final String MODE_KOREAN = TranslateLanguage.KOREAN;

    public interface Callback {
        void onSuccess(String original, String translated, String sourceName);
        void onError(String message);
    }

    private final Pattern cjkPattern = Pattern.compile("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]");
    private final Pattern chinesePattern = Pattern.compile("[\\u3400-\\u9FFF]");
    private final Pattern japanesePattern = Pattern.compile("[\\u3040-\\u30FF]");
    private final Pattern koreanPattern = Pattern.compile("[\\uAC00-\\uD7AF]");
    private final Pattern latinPattern = Pattern.compile("[A-Za-z]");
    private final Pattern expressiveWordPattern = Pattern.compile("[A-Za-z]{2,}");
    private static final int AUTO_UNLOCK_FAILURES = 2;
    private static final int AUTO_ENGLISH_ACCEPT_SCORE = 120;
    private static final int AUTO_CJK_ACCEPT_SCORE = 35;
    public static final String KEY_CUSTOM_GLOSSARY = "custom_glossary_en_es";
    private final Context appContext;
    private final SharedPreferences preferences;
    private final ExecutorService mlExecutor;
    private final Set<String> englishVocabulary = new HashSet<>();
    private int autoFailureCount = 0;
    private int autoProbeCursor = 0;
    private String lastAutoMode = null;
    private final List<StableReading> recentStableReadings = new ArrayList<>();
    private String stableWindowMode = "";
    private String lastAcceptedStableKey = "";
    private String lastAcceptedStableMode = "";
    private int consecutiveEmptyFrames = 0;
    private static final int STABILITY_WINDOW_SIZE = 3;
    private static final long STABILITY_WINDOW_MS = 1500L;
    // Dos lecturas coherentes siguen siendo necesarias, pero sin añadir una espera artificial larga.
    private static final long STABILITY_MIN_CONFIRM_MS = 120L;
    private static final int MAX_OCR_PIXELS = 950000;
    private static final int MAX_OCR_WIDTH = 1500;
    private static final int MAX_OCR_HEIGHT = 620;
    private TextRecognizer activeRecognizer;
    private String activeRecognizerMode = "";
    private Translator activeTranslator;
    private String activeTranslatorSource = "";
    private final Map<String, String> translationCache = new LinkedHashMap<String, String>(160, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > 160;
        }
    };
    private static final Set<String> SHORT_ENGLISH_SUBTITLES = new HashSet<>(Arrays.asList(
            "a", "i", "ah", "am", "be", "bye", "come", "go", "help", "hello", "hey",
            "hi", "how", "look", "me", "no", "oh", "ok", "okay", "please", "really",
            "right", "run", "she", "sorry", "stop", "sure", "thanks", "wait", "we", "what",
            "who", "why", "wow", "yes", "you"
    ));
    private static final Set<String> SHORT_CHINESE_SUBTITLES = new HashSet<>(Arrays.asList(
            "嗯", "啊", "哦", "喂", "好", "不", "走", "来", "停", "对", "是", "我", "你",
            "他", "她", "谁", "啥", "滚", "行", "有", "没"
    ));
    private static final Set<String> SHORT_JAPANESE_SUBTITLES = new HashSet<>(Arrays.asList(
            "え", "あ", "うん", "はい", "いや", "何", "誰", "嘘", "嫌"
    ));
    private static final Set<String> SHORT_KOREAN_SUBTITLES = new HashSet<>(Arrays.asList(
            "네", "응", "왜", "뭐", "야", "와", "헐", "아", "어", "자", "가", "봐", "해", "줘", "쉿"
    ));

    private static final Set<String> EXPRESSIVE_DICTIONARY = new HashSet<>(Arrays.asList(
            "a", "ah", "am", "are", "awesome", "bad", "beautiful", "better", "book", "boom",
            "bye", "call", "calm", "can", "come", "cool", "damn", "do", "done", "fine", "food",
            "go", "good", "great", "happy", "help", "hello", "hey", "home", "honey", "hope", "how",
            "i", "know", "later", "leave", "like", "little", "look", "love", "man", "maybe", "me",
            "mom", "more", "need", "never", "nice", "no", "not", "now", "of", "oh", "okay", "one",
            "please", "really", "right", "run", "sad", "see", "she", "shit", "so", "sorry", "stop",
            "sure", "thank", "thanks", "that", "the", "there", "think", "this", "time", "too", "very",
            "wait", "want", "we", "well", "what", "why", "wow", "yeah", "yes", "you"
    ));

    public TranslatorEngine(Context context) {
        appContext = context.getApplicationContext();
        preferences = appContext.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        mlExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "ZetaMlWorker");
            thread.setPriority(Thread.NORM_PRIORITY - 1);
            return thread;
        });
        loadEnglishVocabulary();
    }

    public void resetAutoState() {
        lastAutoMode = null;
        autoFailureCount = 0;
        autoProbeCursor = 0;
    }

    public void resetStabilityState() {
        recentStableReadings.clear();
        stableWindowMode = "";
        lastAcceptedStableKey = "";
        lastAcceptedStableMode = "";
        consecutiveEmptyFrames = 0;
    }

    public boolean noteNoTextDetected() {
        recentStableReadings.clear();
        consecutiveEmptyFrames++;
        // Dos fotogramas sin texto confirman un hueco real entre subtítulos.
        if (consecutiveEmptyFrames >= 2) {
            lastAcceptedStableKey = "";
            lastAcceptedStableMode = "";
            return true;
        }
        return false;
    }

    public void resetContextState() {
        // Compatibilidad: el contexto automático fue eliminado en la versión 1.26.
    }

    public void process(Bitmap crop, String mode, Callback callback) {
        process(crop, mode, false, callback);
    }

    public void process(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (crop == null || crop.isRecycled()) {
            callback.onError("No se pudo leer el recorte.");
            return;
        }
        if (MODE_AUTO.equals(mode)) {
            processAuto(crop, requireStable, callback);
        } else {
            processFixed(crop, mode, requireStable, callback);
        }
    }

    private void processFixed(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (!isModelReady(mode)) {
            callback.onError("Descarga " + readable(mode) + " → Español antes de usar este idioma.");
            return;
        }

        // Para inglés se intenta primero la imagen original: los bordes de colores y sombras
        // suelen deformarse al aumentar demasiado el contraste. Solo si no hay una frase útil
        // se usa la versión ampliada y contrastada. En otros idiomas se conserva el flujo anterior.
        Bitmap first = MODE_ENGLISH.equals(mode) ? crop : prepareForOcr(crop);
        processFixedAttempt(crop, first, mode, requireStable, true, callback);
    }

    private void processFixedAttempt(Bitmap original, Bitmap attempt, String mode, boolean requireStable,
                                     boolean allowFallback, Callback callback) {
        recognize(attempt, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                if (cleaned.trim().isEmpty() && allowFallback) {
                    Bitmap fallback = attempt == original ? prepareForOcr(original) : original;
                    if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                    processFixedAttempt(original, fallback, mode, requireStable, false, callback);
                    return;
                }
                if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                if (cleaned.trim().isEmpty()) {
                    callback.onError("No se detectó texto dentro del cuadro.");
                    return;
                }
                translateWhenStable(cleaned, mode, requireStable, callback);
            }

            @Override public void onError(String error) {
                if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                callback.onError(error);
            }
        });
    }

    private void processAuto(Bitmap crop, boolean requireStable, Callback callback) {
        List<String> installed = installedAutoModes();
        if (installed.isEmpty()) {
            callback.onError("Descarga por lo menos un idioma antes de usar Auto.");
            return;
        }

        String primaryMode;
        if (lastAutoMode != null && installed.contains(lastAutoMode)) {
            primaryMode = lastAutoMode;
        } else {
            primaryMode = installed.get(autoProbeCursor % installed.size());
            autoProbeCursor = (autoProbeCursor + 1) % installed.size();
        }
        String secondaryMode = chooseAutoSecondary(installed, primaryMode);

        boolean needsPrepared = !MODE_ENGLISH.equals(primaryMode)
                || (secondaryMode != null && !MODE_ENGLISH.equals(secondaryMode));
        Bitmap prepared = needsPrepared ? prepareForOcr(crop) : null;
        Bitmap primaryBitmap = MODE_ENGLISH.equals(primaryMode) ? crop : prepared;

        recognize(primaryBitmap, primaryMode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, primaryMode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, primaryMode);
                if (isAutoCandidateAcceptable(cleaned, primaryMode, score)) {
                    recyclePrepared(prepared, crop);
                    lastAutoMode = primaryMode;
                    autoFailureCount = 0;
                    translateWhenStable(cleaned, primaryMode, requireStable, callback);
                    return;
                }
                autoFailureCount++;
                tryAutoSecondary(crop, prepared, secondaryMode, requireStable, callback);
            }

            @Override public void onError(String error) {
                autoFailureCount++;
                tryAutoSecondary(crop, prepared, secondaryMode, requireStable, callback);
            }
        });
    }

    private String chooseAutoSecondary(List<String> installed, String primaryMode) {
        if (installed == null || installed.size() < 2) return null;
        for (int i = 0; i < installed.size(); i++) {
            int index = (autoProbeCursor + i) % installed.size();
            String candidate = installed.get(index);
            if (!candidate.equals(primaryMode)) {
                autoProbeCursor = (index + 1) % installed.size();
                return candidate;
            }
        }
        return null;
    }

    private void tryAutoSecondary(Bitmap original, Bitmap prepared, String secondaryMode,
                                  boolean requireStable, Callback callback) {
        if (secondaryMode == null) {
            recyclePrepared(prepared, original);
            callback.onError("No se detectó texto claro dentro del cuadro.");
            return;
        }
        Bitmap bitmap = MODE_ENGLISH.equals(secondaryMode) ? original : prepared;
        recognize(bitmap, secondaryMode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, secondaryMode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, secondaryMode);
                recyclePrepared(prepared, original);
                if (!isAutoCandidateAcceptable(cleaned, secondaryMode, score)) {
                    callback.onError("No se detectó texto claro dentro del cuadro.");
                    return;
                }
                lastAutoMode = secondaryMode;
                autoFailureCount = 0;
                translateWhenStable(cleaned, secondaryMode, requireStable, callback);
            }

            @Override public void onError(String error) {
                recyclePrepared(prepared, original);
                callback.onError("No se detectó texto claro dentro del cuadro.");
            }
        });
    }

    private void recyclePrepared(Bitmap prepared, Bitmap original) {
        if (prepared != null && prepared != original && !prepared.isRecycled()) {
            prepared.recycle();
        }
    }

    private void scanAutoFallback(Bitmap prepared, Bitmap original, String alreadyTried,
                                  boolean requireStable, Callback callback) {
        String[] modes = fallbackModes(alreadyTried);
        List<Candidate> candidates = new ArrayList<>();
        recognizeAutoAt(prepared, modes, 0, candidates, () -> {
            Candidate best = chooseBest(candidates);
            if (prepared != original) prepared.recycle();
            if (best != null && isAutoCandidateAcceptable(best.cleaned, best.sourceLanguage, best.score)) {
                lastAutoMode = best.sourceLanguage;
                autoFailureCount = 0;
                translateWhenStable(best.cleaned, best.sourceLanguage, requireStable, callback);
                return;
            }

            List<Candidate> originalCandidates = new ArrayList<>();
            recognizeAutoAt(original, autoModesOrder(), 0, originalCandidates, () -> {
                Candidate bestOriginal = chooseBest(originalCandidates);
                if (bestOriginal == null || !isAutoCandidateAcceptable(
                        bestOriginal.cleaned, bestOriginal.sourceLanguage, bestOriginal.score)) {
                    callback.onError("No se detectó texto claro dentro del cuadro.");
                    return;
                }
                lastAutoMode = bestOriginal.sourceLanguage;
                autoFailureCount = 0;
                translateWhenStable(bestOriginal.cleaned, bestOriginal.sourceLanguage, requireStable, callback);
            });
        });
    }

    private boolean isAutoCandidateAcceptable(String text, String mode, int score) {
        if (text == null || text.trim().isEmpty()) return false;
        if (MODE_ENGLISH.equals(mode)) {
            if (isValidShortEnglishSubtitle(text)) return score >= 20;
            return score >= AUTO_ENGLISH_ACCEPT_SCORE;
        }
        if (isTrustedShortAsianSubtitle(text, mode)) return score >= 8;
        return score >= AUTO_CJK_ACCEPT_SCORE;
    }

    private String[] fallbackModes(String alreadyTried) {
        List<String> installed = installedAutoModes();
        installed.remove(alreadyTried);
        return installed.toArray(new String[0]);
    }

    private String[] autoModesOrder() {
        return installedAutoModes().toArray(new String[0]);
    }

    private List<String> installedAutoModes() {
        List<String> modes = new ArrayList<>();
        // Inglés siempre es la primera opción cuando está instalado.
        if (isModelReady(MODE_ENGLISH)) modes.add(MODE_ENGLISH);
        if (isModelReady(MODE_CHINESE)) modes.add(MODE_CHINESE);
        if (isModelReady(MODE_JAPANESE)) modes.add(MODE_JAPANESE);
        if (isModelReady(MODE_KOREAN)) modes.add(MODE_KOREAN);
        return modes;
    }

    private String firstInstalledAutoMode() {
        List<String> modes = installedAutoModes();
        return modes.isEmpty() ? null : modes.get(0);
    }

    private boolean isModelReady(String sourceLanguage) {
        if (TranslateLanguage.SPANISH.equals(sourceLanguage)) return true;
        return preferences.getBoolean(MainActivity.KEY_MODEL_PREFIX + sourceLanguage, false);
    }

    private void recognizeAutoAt(Bitmap bitmap, String[] modes, int index, List<Candidate> out, Runnable done) {
        if (index >= modes.length) {
            done.run();
            return;
        }
        String mode = modes[index];
        recognize(bitmap, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, mode);
                if (cleaned.trim().length() > 0) out.add(new Candidate(cleaned, mode, score));
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }

            @Override public void onError(String error) {
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }
        });
    }

    private Candidate chooseBest(List<Candidate> candidates) {
        Candidate best = null;
        for (Candidate candidate : candidates) {
            if (best == null || candidate.score > best.score) best = candidate;
        }
        return best;
    }

    private int scoreCandidate(String text, String mode) {
        if (text == null) return 0;
        String t = text.trim();
        if (t.length() == 0) return 0;
        int score = Math.min(t.length(), 160);
        int cjk = countMatches(cjkPattern, t);
        int chinese = countMatches(chinesePattern, t);
        int japanese = countMatches(japanesePattern, t);
        int korean = countMatches(koreanPattern, t);
        int latin = countMatches(latinPattern, t);
        int lineCount = countUsefulLines(t);
        if (lineCount > 1) score += Math.min(90, lineCount * 22);

        if (MODE_ENGLISH.equals(mode)) {
            if (isBadEnglishFalsePositive(t)) return -9999;
            score += latin * 3;
            if (isGoodEnglishLine(t)) score += 170 + scoreEnglishLine(t);
            if (countEnglishWords(t) <= 2 && commonEnglishWordScore(t) == 0) score -= 90;
            if (isLikelySpanishLine(t)) score -= 180;
            if (cjk > 0) score -= cjk * 2;
        } else if (MODE_CHINESE.equals(mode)) {
            score += chinese * 7;
            if (japanese > 0 || korean > 0) score -= 10;
        } else if (MODE_JAPANESE.equals(mode)) {
            score += japanese * 8 + chinese * 2;
        } else if (MODE_KOREAN.equals(mode)) {
            score += korean * 8;
        }
        if (isTrustedShortAsianSubtitle(t, mode)) score += 70;
        return score;
    }

    private int countMatches(Pattern pattern, String text) {
        int count = 0;
        java.util.regex.Matcher m = pattern.matcher(text);
        while (m.find()) count++;
        return count;
    }

    private int countUsefulLines(String text) {
        if (text == null) return 0;
        String[] parts = text.replace("\r", "").split("\n");
        int count = 0;
        for (String p : parts) {
            if (p != null && p.trim().length() >= 2) count++;
        }
        return count;
    }

    private static class Candidate {
        final String cleaned;
        final String sourceLanguage;
        final int score;
        Candidate(String cleaned, String sourceLanguage, int score) {
            this.cleaned = cleaned;
            this.sourceLanguage = sourceLanguage;
            this.score = score;
        }
    }

    private static class StableReading {
        final String text;
        final String key;
        final String mode;
        final long timestamp;

        StableReading(String text, String key, String mode, long timestamp) {
            this.text = text;
            this.key = key;
            this.mode = mode;
            this.timestamp = timestamp;
        }
    }

    private Bitmap prepareForOcr(Bitmap crop) {
        if (crop == null || crop.isRecycled()) return crop;
        int width = crop.getWidth();
        int height = crop.getHeight();
        if (width <= 0 || height <= 0) return crop;

        float scale = 1.0f;
        if (width < 900) scale = 1.55f;
        if (width < 620) scale = 1.90f;
        if (width < 430) scale = 2.20f;

        scale = Math.min(scale, MAX_OCR_WIDTH / (float) width);
        scale = Math.min(scale, MAX_OCR_HEIGHT / (float) height);
        double pixelsAtScale = width * (double) height * scale * scale;
        if (pixelsAtScale > MAX_OCR_PIXELS) {
            scale *= (float) Math.sqrt(MAX_OCR_PIXELS / pixelsAtScale);
        }
        scale = Math.max(1.0f, scale);

        int newW = Math.max(width, Math.round(width * scale));
        int newH = Math.max(height, Math.round(height * scale));
        Bitmap enhanced = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888);

        // Escala y aplica contraste en una sola superficie. La versión anterior creaba
        // además un bitmap intermedio grande, duplicando memoria en cada captura.
        Canvas canvas = new Canvas(enhanced);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float contrast = 1.38f;
        float translate = (-0.5f * contrast + 0.5f) * 255f;
        ColorMatrix matrix = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        Rect source = new Rect(0, 0, width, height);
        Rect target = new Rect(0, 0, newW, newH);
        canvas.drawBitmap(crop, source, target, paint);
        return enhanced;
    }

    private interface OcrCallback {
        void onResult(Text result, int imageWidth, int imageHeight);
        void onError(String error);
    }

    private void recognize(Bitmap crop, String mode, OcrCallback cb) {
        TextRecognizer recognizer = getRecognizer(mode);
        InputImage image = InputImage.fromBitmap(crop, 0);
        int width = crop.getWidth();
        int height = crop.getHeight();
        recognizer.process(image)
                .addOnSuccessListener(mlExecutor, result -> cb.onResult(result, width, height))
                .addOnFailureListener(mlExecutor, e -> cb.onError("Error OCR: " + safeMessage(e)));
    }

    private synchronized TextRecognizer getRecognizer(String mode) {
        String key = mode == null ? MODE_ENGLISH : mode;
        if (activeRecognizer != null && key.equals(activeRecognizerMode)) return activeRecognizer;
        if (activeRecognizer != null) {
            try { activeRecognizer.close(); } catch (Exception ignored) { }
            activeRecognizer = null;
        }
        TextRecognizer created;
        if (MODE_CHINESE.equals(key)) {
            created = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        } else if (MODE_JAPANESE.equals(key)) {
            created = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        } else if (MODE_KOREAN.equals(key)) {
            created = TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        } else {
            created = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        }
        activeRecognizer = created;
        activeRecognizerMode = key;
        return created;
    }

    private void translateWhenStable(String text, String sourceLanguage, boolean requireStable, Callback callback) {
        if (!requireStable) {
            translate(text, sourceLanguage, callback);
            return;
        }

        String stableText = selectStableText(text, sourceLanguage);
        if (stableText == null || stableText.trim().isEmpty()) {
            callback.onError("Esperando subtítulo estable.");
            return;
        }

        String acceptedKey = lastAcceptedStableKey;
        String acceptedMode = lastAcceptedStableMode;
        translate(stableText, sourceLanguage, new Callback() {
            @Override public void onSuccess(String original, String translated, String sourceName) {
                callback.onSuccess(original, translated, sourceName);
            }

            @Override public void onError(String message) {
                // Si el modelo falla, permite reintentar el mismo subtítulo en la siguiente captura.
                if (acceptedKey.equals(lastAcceptedStableKey)
                        && acceptedMode.equals(lastAcceptedStableMode)) {
                    lastAcceptedStableKey = "";
                    lastAcceptedStableMode = "";
                }
                callback.onError(message);
            }
        });
    }

    /**
     * Confirma el OCR por consenso: al menos dos de las últimas tres lecturas deben
     * representar el mismo subtítulo. Nunca fuerza una frase inestable por tiempo;
     * mientras no exista consenso, LIVE conserva la traducción anterior.
     */
    private String selectStableText(String text, String sourceLanguage) {
        String cleaned = normalizeBeforeTranslate(text, sourceLanguage);
        String normalized = normalizeKeyForLanguage(cleaned, sourceLanguage);
        if (normalized.isEmpty()) return null;

        String mode = sourceLanguage == null ? "" : sourceLanguage;
        long now = System.currentTimeMillis();
        consecutiveEmptyFrames = 0;

        if (mode.equals(lastAcceptedStableMode)
                && isSameAcceptedSubtitle(lastAcceptedStableKey, normalized)) {
            recentStableReadings.clear();
            stableWindowMode = mode;
            return null;
        }

        if (!mode.equals(stableWindowMode)) {
            recentStableReadings.clear();
            stableWindowMode = mode;
        }

        for (int i = recentStableReadings.size() - 1; i >= 0; i--) {
            if (now - recentStableReadings.get(i).timestamp > STABILITY_WINDOW_MS) {
                recentStableReadings.remove(i);
            }
        }

        recentStableReadings.add(new StableReading(cleaned, normalized, mode, now));
        while (recentStableReadings.size() > STABILITY_WINDOW_SIZE) {
            recentStableReadings.remove(0);
        }

        StableReading best = null;
        int bestMatches = 0;
        for (StableReading candidate : recentStableReadings) {
            int matches = 0;
            for (StableReading other : recentStableReadings) {
                if (areConsensusSimilar(candidate.key, other.key)) matches++;
            }
            if (matches > bestMatches
                    || (matches == bestMatches && isBetterStableReading(candidate, best))) {
                bestMatches = matches;
                best = candidate;
            }
        }

        if (best == null || bestMatches < 2) return null;

        long oldestMatchAt = now;
        StableReading bestReading = null;
        for (StableReading sample : recentStableReadings) {
            if (!areConsensusSimilar(best.key, sample.key)) continue;
            oldestMatchAt = Math.min(oldestMatchAt, sample.timestamp);
            if (isBetterStableReading(sample, bestReading)) bestReading = sample;
        }

        if (now - oldestMatchAt < STABILITY_MIN_CONFIRM_MS || bestReading == null) return null;

        lastAcceptedStableKey = bestReading.key;
        lastAcceptedStableMode = mode;
        recentStableReadings.clear();
        stableWindowMode = mode;
        return bestReading.text;
    }

    private boolean isBetterStableReading(StableReading candidate, StableReading currentBest) {
        if (candidate == null) return false;
        if (currentBest == null) return true;
        int candidateScore = stableReadingScore(candidate.text, candidate.mode);
        int currentScore = stableReadingScore(currentBest.text, currentBest.mode);
        if (candidateScore != currentScore) return candidateScore > currentScore;
        return candidate.timestamp > currentBest.timestamp;
    }

    private int stableReadingScore(String text, String mode) {
        if (text == null) return Integer.MIN_VALUE;
        String clean = text.trim();
        int score = clean.length();
        if (MODE_ENGLISH.equals(mode)) {
            int words = clean.isEmpty() ? 0 : clean.split("\\s+").length;
            int vocabularyWords = countVocabularyWords(clean);
            score += Math.min(words, 16) * 6;
            score += Math.min(vocabularyWords, 16) * 7;
            score -= Math.max(0, words - vocabularyWords - 2) * 3;
            if (clean.matches(".*[.!?…][\"']?$")) score += 12;
            if (clean.matches(".*\\b(I|you|he|she|we|they|it)\\b.*")) score += 5;
            score -= countSuspiciousCharacters(clean) * 15;
            return score;
        }
        int han = countMatches(chinesePattern, clean);
        int kana = countMatches(japanesePattern, clean);
        int hangul = countMatches(koreanPattern, clean);
        if (MODE_CHINESE.equals(mode)) {
            score += han * 9 - kana * 12 - hangul * 12;
        } else if (MODE_JAPANESE.equals(mode)) {
            score += kana * 10 + han * 5 - hangul * 12;
        } else if (MODE_KOREAN.equals(mode)) {
            score += hangul * 10 + han * 2 - kana * 12;
        }
        if (clean.matches(".*[。！？!?…」』]$")) score += 10;
        score -= countSuspiciousCharactersForMode(clean) * 8;
        return score;
    }

    private int countSuspiciousCharacters(String text) {
        if (text == null) return 0;
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c)
                    || "'.,?!:;-–—…".indexOf(c) >= 0) continue;
            count++;
        }
        return count;
    }

    private int countSuspiciousCharactersForMode(String text) {
        if (text == null) return 0;
        int count = 0;
        String allowed = "'.,?!:;-–—…，。！？：；、・〜～「」『』（）【】《》〈〉…·";
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c) || allowed.indexOf(c) >= 0) continue;
            count++;
        }
        return count;
    }

    private boolean areConsensusSimilar(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b)) return true;

        int max = Math.max(a.length(), b.length());
        int min = Math.min(a.length(), b.length());

        // En subtítulos muy cortos una sola letra/sílaba puede invertir el sentido.
        // Exigimos coincidencia exacta en vez de fusionar por distancia de edición.
        if (max <= 6) return false;
        if (hasCriticalMeaningDifference(a, b)) return false;

        // Solo admite ampliaciones muy pequeñas del mismo OCR. No usa similitud por
        // conjunto de palabras porque podría confundir frases con significado opuesto
        // como "I want..." e "I don't want...".
        if (min >= 10 && (a.contains(b) || b.contains(a)) && min >= Math.round(max * 0.90f)) {
            return true;
        }

        int allowedDistance = Math.max(1, Math.min(3, max / 18));
        return Math.abs(a.length() - b.length()) <= allowedDistance
                && levenshteinDistance(a, b) <= allowedDistance;
    }

    private boolean isSameAcceptedSubtitle(String accepted, String current) {
        if (accepted == null || current == null || accepted.length() == 0 || current.length() == 0) {
            return false;
        }
        if (accepted.equals(current)) return true;
        int max = Math.max(accepted.length(), current.length());
        int min = Math.min(accepted.length(), current.length());
        if (max <= 6 || hasCriticalMeaningDifference(accepted, current)) return false;
        if (max - min > Math.max(2, max / 14)) return false;
        return levenshteinDistance(accepted, current) <= Math.max(1, max / 18);
    }

    private boolean hasCriticalMeaningDifference(String a, String b) {
        if (!extractNumberSignature(a).equals(extractNumberSignature(b))) return true;
        return englishNegationSignature(a) != englishNegationSignature(b);
    }

    private int englishNegationSignature(String key) {
        String padded = " " + (key == null ? "" : key.toLowerCase(Locale.ROOT)) + " ";
        int mask = 0;
        if (padded.contains(" not ")) mask |= 1;
        if (padded.contains(" no ")) mask |= 2;
        if (padded.contains(" never ")) mask |= 4;
        if (padded.contains(" cant ") || padded.contains(" can t ")) mask |= 8;
        if (padded.contains(" dont ") || padded.contains(" don t ")) mask |= 16;
        if (padded.contains(" wont ") || padded.contains(" won t ")) mask |= 32;
        if (padded.contains(" isnt ") || padded.contains(" isn t ")
                || padded.contains(" arent ") || padded.contains(" aren t ")) mask |= 64;
        if (padded.contains(" didnt ") || padded.contains(" didn t ")
                || padded.contains(" doesnt ") || padded.contains(" doesn t ")) mask |= 128;
        return mask;
    }

    private String extractNumberSignature(String key) {
        Matcher matcher = Pattern.compile("\\d+").matcher(key == null ? "" : key);
        StringBuilder out = new StringBuilder();
        while (matcher.find()) {
            if (out.length() > 0) out.append('|');
            out.append(matcher.group());
        }
        return out.toString();
    }

    private int levenshteinDistance(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[b.length()];
    }

    private void detectLanguageThenTranslate(String text, Callback callback) {
        String guessed = guessFromCharacters(text);
        if (guessed != null) {
            translate(text, guessed, callback);
            return;
        }

        LanguageIdentifier identifier = LanguageIdentification.getClient();
        identifier.identifyLanguage(text)
                .addOnSuccessListener(mlExecutor, languageCode -> {
                    identifier.close();
                    String src = mapLanguage(languageCode);
                    if (src == null || "und".equals(languageCode)) src = TranslateLanguage.ENGLISH;
                    translate(text, src, callback);
                })
                .addOnFailureListener(mlExecutor, e -> {
                    identifier.close();
                    translate(text, TranslateLanguage.ENGLISH, callback);
                });
    }

    private void translate(String text, String sourceLanguage, Callback callback) {
        String src = sourceLanguage;
        if (MODE_AUTO.equals(src)) src = guessFromCharacters(text);
        if (src == null) src = TranslateLanguage.ENGLISH;

        String cleanForTranslate = normalizeBeforeTranslate(text, src);
        String glossaryMatch = exactGlossaryTranslation(cleanForTranslate, src);
        if (glossaryMatch != null) {
            callback.onSuccess(cleanForTranslate, glossaryMatch, readable(src));
            return;
        }
        if (TranslateLanguage.CHINESE.equals(src)
                || TranslateLanguage.JAPANESE.equals(src)
                || TranslateLanguage.KOREAN.equals(src)) {
            String asianExact = fallbackAsianToSpanish(cleanForTranslate, src);
            if (asianExact != null) {
                callback.onSuccess(cleanForTranslate, asianExact, readable(src));
                return;
            }
            String asianPhrase = fallbackAsianPhraseToSpanish(cleanForTranslate, src);
            if (asianPhrase != null) {
                callback.onSuccess(cleanForTranslate, asianPhrase, readable(src));
                return;
            }
        }
        // LIVE traduce cada subtítulo de forma independiente. No se mezcla con líneas anteriores.
        String cacheKey = src + "|" + normalizeKeyForLanguage(cleanForTranslate, src);
        if (translationCache.containsKey(cacheKey)) {
            String cached = translationCache.get(cacheKey);
            callback.onSuccess(cleanForTranslate, cached, readable(src));
            return;
        }

        if (TranslateLanguage.SPANISH.equals(src)) {
            callback.onSuccess(cleanForTranslate, cleanForTranslate, "Español");
            return;
        }

        translateWithMlKit(cleanForTranslate, src, cacheKey, callback);
    }

    private void translateWithMlKit(String input, String sourceLanguage,
                                    String cacheKey, Callback callback) {
        if (!isModelReady(sourceLanguage)) {
            callback.onError("Descarga " + readable(sourceLanguage) + " → Español antes de traducir.");
            return;
        }

        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String direct = fallbackEnglishToSpanish(input);
            if (direct != null && !direct.trim().isEmpty()) {
                translationCache.put(cacheKey, direct);
                callback.onSuccess(input, direct, readable(sourceLanguage));
                return;
            }
        }

        Translator translator = getTranslator(sourceLanguage);
        translateDirect(translator, input, sourceLanguage, cacheKey, callback);
    }

    private void translateDirect(Translator translator, String input, String sourceLanguage,
                                 String cacheKey, Callback callback) {
        translator.translate(input)
                .addOnSuccessListener(mlExecutor, translated -> finishTranslation(
                        input, sourceLanguage, cacheKey, translated, callback))
                .addOnFailureListener(mlExecutor, e -> callback.onError("Error al traducir: " + safeMessage(e)));
    }

    private void finishTranslation(String input, String sourceLanguage, String cacheKey, String translated, Callback callback) {
        String polished = polishSpanish(translated);
        if (isSuspiciousResult(input, polished, sourceLanguage)
                && TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String fallback = fallbackEnglishToSpanish(input);
            if (fallback != null && fallback.trim().length() > 0) polished = fallback;
        }
        // No mostramos el original ni una mezcla evidente como si fuera una traducción terminada.
        // En modo Vivo el cuadro conserva la última traducción fiable hasta la siguiente lectura válida.
        if (isSuspiciousResult(input, polished, sourceLanguage)) {
            callback.onError("No se obtuvo una traducción suficientemente confiable.");
            return;
        }
        if (cacheKey != null) translationCache.put(cacheKey, polished);
        callback.onSuccess(input, polished, readable(sourceLanguage));
    }

    private boolean isSuspiciousResult(String original, String translated, String sourceLanguage) {
        if (translated == null || translated.trim().isEmpty()) return true;
        if (looksUntranslated(original, translated)
                && !isAcceptableUnchangedTranslation(original, sourceLanguage)) return true;
        if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)
                || TranslateLanguage.KOREAN.equals(sourceLanguage)) {
            return countMatches(cjkPattern, translated) > 2;
        }
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            int strongEnglish = countStrongEnglishWords(translated);
            int spanishSignals = countSpanishSignals(translated);
            return strongEnglish >= 2 && spanishSignals == 0;
        }
        return false;
    }

    private int countStrongEnglishWords(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "the","this","that","these","those","you","your","yours","he","she","they",
                "we","our","where","when","why","what","who","how","with","from","have","has",
                "had","will","would","could","should","were","was","are","does","did","doing",
                "think","know","want","need","good","right","please","sorry","home"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }

    private int countSpanishSignals(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "el","la","los","las","un","una","que","de","del","en","por","para","con",
                "como","qué","dónde","cuando","porque","estoy","está","son","eres","tengo","tiene",
                "quiero","puedo","casa","bien","gracias","pero","muy","ya","aquí","allí"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }


    private synchronized Translator getTranslator(String sourceLanguage) {
        if (activeTranslator != null && sourceLanguage.equals(activeTranslatorSource)) return activeTranslator;
        if (activeTranslator != null) {
            try { activeTranslator.close(); } catch (Exception ignored) { }
            activeTranslator = null;
        }
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguage)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        activeTranslator = Translation.getClient(options);
        activeTranslatorSource = sourceLanguage;
        return activeTranslator;
    }

    private String normalizeBeforeTranslate(String text, String sourceLanguage) {
        if (text == null) return "";
        String t = joinOcrLines(text, sourceLanguage);
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            t = repairEnglishOcr(t);
            t = normalizeExpressiveEnglish(t);
        } else if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)
                || TranslateLanguage.KOREAN.equals(sourceLanguage)) {
            t = sanitizeAsianDelimitersAndCues(t, sourceLanguage);
            t = normalizeAsianOcrText(t, sourceLanguage);
            t = normalizeAsianColloquialisms(t, sourceLanguage);
        }
        return t;
    }

    private String joinOcrLines(String text, String sourceLanguage) {
        if (text == null) return "";
        String[] lines = text.replace("\r", "").split("\n");
        StringBuilder out = new StringBuilder();
        Set<String> seen = new HashSet<>();
        boolean compactCjk = TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage);
        for (String line : lines) {
            String s = line == null ? "" : line.trim();
            if (s.length() == 0) continue;
            String key = normalizeKeyForLanguage(s, sourceLanguage);
            if (key.length() > 0 && !seen.add(key)) continue;
            if (out.length() > 0 && !compactCjk) out.append(' ');
            out.append(s);
        }
        String joined = out.toString().replaceAll("[\t ]+", " ").trim();
        if (compactCjk) joined = joined.replaceAll("\\s+", "");
        return joined;
    }

    private String repairEnglishOcr(String text) {
        if (text == null) return "";
        String t = sanitizeSubtitleDelimitersAndCues(text.trim());
        t = stripCjkFromEnglish(t);
        t = t.replaceAll("(?<=[a-z])(?=[A-Z])", " ");
        t = t.replace('’', '\'');
        t = normalizeConversationalEnglish(t);

        // Solo se conservan correcciones de confusiones OCR muy seguras. Las sustituciones
        // gramaticales agresivas se eliminaron porque podían cambiar palabras correctas.
        t = t.replaceAll("(?i)\\bschoo1\\b", "school");
        t = t.replaceAll("(?i)\\bmornlng\\b", "morning");
        t = t.replaceAll("(?i)\\bfinisbed\\b", "finished");
        t = t.replaceAll("(?i)\\bleam\\b", "learn");
        t = t.replaceAll("(?i)\\btomorow\\b", "tomorrow");
        t = t.replaceAll("(?i)\\bexacty\\b", "exactly");

        // Reparaciones de inicio muy limitadas y de alta confianza observadas en subtítulos.
        t = t.replaceFirst("(?i)^[tl|]?decause\\b", "Because");
        t = t.replaceFirst("(?i)^[tl|]?because\\b", "Because");
        t = t.replaceFirst("(?i)^f?it['’]?s\\s+evening\\b", "It's evening");
        t = t.replaceFirst(
                "(?i)^[i1|]?so\\s+[l1|i]\\s+(?=(continued|walked|went|was|am|have|had|can|could|would|should|did|do|saw|heard|thought|knew|kept|started|decided|just)\\b)",
                "So I ");

        t = t.replaceAll("[.]{2,}", " ");
        t = t.replaceAll("[^A-Za-z0-9'.,?!:;\\- ]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    /**
     * Quita únicamente los delimitadores visuales del subtítulo y conserva el contenido,
     * incluidas las indicaciones sonoras/accesibles, para que también se traduzcan.
     */
    private String normalizeConversationalEnglish(String text) {
        if (text == null || text.isEmpty()) return "";
        String t = text;
        t = t.replaceAll("(?i)\\bimma\\b|\\bi['’]?ma\\b", "I'm going to");
        t = t.replaceAll("(?i)\\bgonna\\b", "going to");
        t = t.replaceAll("(?i)\\bwanna\\b", "want to");
        t = t.replaceAll("(?i)\\bgotta\\b", "have to");
        t = t.replaceAll("(?i)\\blemme\\b", "let me");
        t = t.replaceAll("(?i)\\bgimme\\b", "give me");
        t = t.replaceAll("(?i)\\bkinda\\b", "kind of");
        t = t.replaceAll("(?i)\\boutta\\b", "out of");
        t = t.replaceAll("(?i)\\bya\\b", "you");
        t = t.replaceAll("(?i)\\bI ain't\\b", "I am not");
        t = t.replaceAll("(?i)\\b(you|we|they) ain't\\b", "$1 are not");
        t = t.replaceAll("(?i)\\b(he|she|it) ain't\\b", "$1 is not");
        t = t.replaceAll("(?i)\\bthere ain't\\b", "there is not");
        String[][] droppedG = new String[][]{
                {"livin'", "living"}, {"goin'", "going"}, {"comin'", "coming"},
                {"doin'", "doing"}, {"gettin'", "getting"}, {"talkin'", "talking"},
                {"lookin'", "looking"}, {"thinkin'", "thinking"}, {"tryin'", "trying"},
                {"fightin'", "fighting"}, {"killin'", "killing"}, {"runnin'", "running"},
                {"workin'", "working"}, {"waitin'", "waiting"}, {"sayin'", "saying"},
                {"tellin'", "telling"}, {"makin'", "making"}, {"takin'", "taking"}
        };
        for (String[] pair : droppedG) {
            t = t.replaceAll("(?i)(?<![A-Za-z])" + Pattern.quote(pair[0]) + "(?![A-Za-z])", pair[1]);
        }
        return t;
    }

    private String sanitizeSubtitleDelimitersAndCues(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String t = text.replace('［', '[').replace('］', ']')
                .replace('（', '(').replace('）', ')')
                .replace('｛', '{').replace('｝', '}');
        t = stripLeadingSpeakerLabels(t);
        t = replaceBracketSegments(t, Pattern.compile("\\[([^\\[\\]]{1,80})\\]"));
        t = replaceBracketSegments(t, Pattern.compile("\\(([^()]{1,80})\\)"));
        t = replaceBracketSegments(t, Pattern.compile("\\{([^{}]{1,80})\\}"));
        t = t.replaceAll("[\\[\\](){}]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String stripLeadingSpeakerLabels(String text) {
        String t = text == null ? "" : text;
        Pattern leading = Pattern.compile("^\\s*\\[([^\\[\\]]{1,40})\\]\\s*");
        for (int i = 0; i < 2; i++) {
            Matcher matcher = leading.matcher(t);
            if (!matcher.find()) break;
            String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
            String trailing = t.substring(matcher.end()).trim();
            boolean cue = isSubtitleStageCue(inner);
            // Las acotaciones accesibles como [music] o [air whooshing] son contenido real
            // del subtítulo y deben conservarse para traducirse. Solo se retira una etiqueta
            // de hablante cuando hay diálogo después de ella.
            if (cue) break;
            if (!isLikelySpeakerLabel(inner) || trailing.isEmpty()) break;
            t = trailing;
        }
        return t;
    }

    private boolean isLikelySpeakerLabel(String text) {
        if (text == null) return false;
        String s = text.trim();
        if (s.isEmpty() || s.length() > 30) return false;
        if (s.matches(".*[.!?].*")) return false;
        String normalized = s.replaceAll("[^A-Za-z0-9' -]+", " ").replaceAll("\\s+", " ").trim();
        if (normalized.isEmpty()) return false;
        int words = normalized.split(" ").length;
        return words <= 4;
    }

    private String replaceBracketSegments(String text, Pattern pattern) {
        Matcher matcher = pattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
            // Conserva también descripciones de sonido/acción; ML Kit debe traducirlas.
            String replacement = " " + inner + " ";
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private boolean isSubtitleStageCue(String text) {
        if (text == null) return false;
        String cue = text.toLowerCase(Locale.ROOT)
                .replace('’', '\'')
                .replaceAll("[^a-z' ]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
        if (cue.isEmpty()) return true;
        int words = cue.split(" ").length;
        if (words > 7) return false;
        if (cue.matches("(soft |dramatic |background |upbeat |sad |tense )?music( playing| continues| fades| starts| stops)?")) return true;
        if (cue.matches("applause|laughter|laughs?|laughing|sighs?|sighing|gasps?|gasping|groans?|groaning|whispers?|whispering|screams?|screaming|cries|crying|sobs?|sobbing|chuckles?|chuckling|breathing|panting|footsteps|silence|inaudible|gunfire|gunshots?|shots?")) return true;
        if (cue.matches("(door|phone|bell|alarm|thunder|rain|wind|knock|knocking|gunshot|explosion|engine|drums?)( opens?| closes?| rings?| sounds?| continues?| fades?| stops?| starts?| roaring| rumbling| beating)?")) return true;
        return cue.matches(".*\\b(whoosh|whooshes|whooshing|whirring|buzzing|ringing|firing|shooting|beating|rumbling|roaring|crashing|crash|impact|exploding|grunting|grunts|yelling|shouting|screeching|creaking)\\b.*");
    }

    private String normalizeAsianOcrText(String text, String mode) {
        if (text == null) return "";
        String t = text.replace('　', ' ').trim();
        t = t.replaceAll("^[—―ー-\\s]+", "");
        t = t.replaceAll("[·•･ㆍ]+", " ");
        t = t.replaceAll("([。！？!?，,、…])\\1+", "$1");
        t = t.replaceAll("\\s+", MODE_KOREAN.equals(mode) ? " " : "");

        // No se eliminan a ciegas fragmentos latinos cortos: pueden ser nombres, siglas
        // o términos reales como AI/3D dentro de subtítulos asiáticos. El filtrado visual
        // y por escritura ya se realiza antes, en la selección de líneas OCR.
        return t.trim();
    }

    private String sanitizeAsianDelimitersAndCues(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return "";
        String t = text.replace('［', '[').replace('］', ']')
                .replace('【', '[').replace('】', ']')
                .replace('（', '(').replace('）', ')')
                .replace('｛', '{').replace('｝', '}');
        t = stripLeadingAsianSpeakerLabels(t, mode);
        t = replaceAsianBracketSegments(t, Pattern.compile("\\[([^\\[\\]]{1,80})\\]"), mode);
        t = replaceAsianBracketSegments(t, Pattern.compile("\\(([^()]{1,80})\\)"), mode);
        t = replaceAsianBracketSegments(t, Pattern.compile("\\{([^{}]{1,80})\\}"), mode);
        t = t.replaceAll("[\\[\\](){}]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String stripLeadingAsianSpeakerLabels(String text, String mode) {
        String t = text == null ? "" : text;
        // Anime, donghua y dramas usan con frecuencia [Nombre], 【Nombre】 o （Nombre）.
        Pattern leading = Pattern.compile("^\\s*[\\[【（(]([^\\]】）)]{1,24})[\\]】）)]\\s*");
        Matcher matcher = leading.matcher(t);
        if (!matcher.find()) return t;
        String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
        String trailing = t.substring(matcher.end()).trim();
        boolean cue = isAsianStageCue(inner, mode);
        boolean likelySpeaker = inner.length() <= 12
                && !inner.matches(".*[。！？!?，,、…].*");
        // Conservar indicaciones de sonido/acción en japonés, chino y coreano.
        if (cue) return t;
        if (likelySpeaker && !trailing.isEmpty()) return trailing;
        return t;
    }

    private String replaceAsianBracketSegments(String text, Pattern pattern, String mode) {
        Matcher matcher = pattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
            // Las descripciones sonoras son parte del subtítulo y también se traducen.
            String replacement = " " + inner + " ";
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private boolean isAsianStageCue(String text, String mode) {
        if (text == null) return false;
        String cue = text.replaceAll("\\s+", "").trim();
        if (cue.isEmpty()) return true;
        if (MODE_JAPANESE.equals(mode)) {
            return cue.matches("音楽|笑|笑い|笑い声|拍手|ため息|泣き声|足音|雨音|風の音|雷|悲鳴|叫び声|息切れ|銃声|爆発音|衝撃音|ドアの音|聞き取れない");
        }
        if (MODE_CHINESE.equals(mode)) {
            return cue.matches("音乐|笑|笑声|掌声|叹气|哭声|脚步声|雨声|风声|雷声|尖叫|尖叫声|喘息|枪声|爆炸声|撞击声|开门声|关门声|听不清");
        }
        if (MODE_KOREAN.equals(mode)) {
            return cue.matches("음악|웃음|웃음소리|박수|한숨|울음|발소리|빗소리|바람소리|천둥|비명|고함|숨소리|총성|폭발음|충격음|문소리|알아들을수없음");
        }
        return false;
    }

    private String normalizeAsianColloquialisms(String text, String mode) {
        if (text == null) return "";
        // No reescribimos jerga dentro de frases completas porque términos como やばい,
        // 대박 o 牛逼 cambian de matiz según el contexto. Las equivalencias realmente
        // seguras se resuelven solo cuando la línea completa coincide exactamente.
        return text.trim();
    }

    private String fallbackAsianPhraseToSpanish(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return null;
        String key = normalizeKeyForLanguage(text.trim(), mode);
        if (MODE_JAPANESE.equals(mode)) {
            if (key.equals("マジで") || key.equals("マジ")) return "¿En serio?";
            if (key.equals("すげえ") || key.equals("すげー") || key.equals("すごい")) return "Increíble";
            if (key.equals("ムカつく")) return "Me enfada";
            if (key.equals("うざい")) return "Qué molesto";
            if (key.equals("なんでだよ") || key.equals("なんで")) return "¿Por qué?";
            // やばい no se fuerza: puede ser negativo o positivo según el contexto.
        } else if (MODE_CHINESE.equals(mode)) {
            if (key.equals("咋回事") || key.equals("怎么回事")) return "¿Qué pasó?";
            if (key.equals("啥") || key.equals("什么")) return "¿Qué?";
            if (key.equals("牛逼")) return "Increíble";
            if (key.equals("卧槽")) return "Dios mío";
            if (key.equals("给力")) return "Genial";
            if (key.equals("没门")) return "Ni hablar";
            if (key.equals("坑爹")) return "Qué desastre";
            if (key.equals("不是吧") || key.equals("不会吧")) return "No puede ser";
        } else if (MODE_KOREAN.equals(mode)) {
            if (key.equals("대박")) return "Increíble";
            if (key.equals("헐")) return "No puede ser";
            if (key.equals("짱")) return "Lo máximo";
            if (key.equals("빡쳐") || key.equals("열받아")) return "Estoy enfadado";
            if (key.equals("개웃겨")) return "Qué risa";
            if (key.equals("노잼")) return "Aburrido";
            if (key.equals("꿀잼")) return "Muy divertido";
            if (key.equals("진짜")) return "De verdad";
            if (key.equals("뭐야")) return "¿Qué es eso?";
        }
        return null;
    }

    private String fallbackAsianToSpanish(String text, String mode) {
        String key = normalizeKeyForLanguage(text, mode);
        if (MODE_JAPANESE.equals(mode)) {
            if (key.equals("え") || key.equals("あ")) return key.equals("え") ? "¿Eh?" : "Ah";
            if (key.equals("うん") || key.equals("はい")) return "Sí";
            if (key.equals("いや")) return "No";
            if (key.equals("何")) return "¿Qué?";
            if (key.equals("誰")) return "¿Quién?";
            if (key.equals("嘘")) return "No puede ser";
            if (key.equals("こんにちは")) return "Hola";
            if (key.equals("ありがとう") || key.equals("ありがとうございます")) return "Gracias";
            if (key.equals("おはよう") || key.equals("おはようございます")) return "Buenos días";
            if (key.equals("こんばんは")) return "Buenas noches";
            if (key.equals("ごめん") || key.equals("ごめんなさい")) return "Lo siento";
            if (key.equals("すみません")) return "Disculpe";
            if (key.equals("本当に")) return "¿En serio?";
            if (key.equals("待って")) return "Espera";
            if (key.equals("行け")) return "Ve";
            if (key.equals("行こう")) return "Vamos";
            if (key.equals("やめろ") || key.equals("やめて")) return "Detente";
            if (key.equals("助けて")) return "Ayúdame";
            if (key.equals("大丈夫")) return "Está bien";
            if (key.equals("分かった") || key.equals("わかった")) return "Entendido";
            if (key.equals("気をつけて")) return "Cuidado";
        } else if (MODE_CHINESE.equals(mode)) {
            if (key.equals("嗯")) return "Sí";
            if (key.equals("啊")) return "Ah";
            if (key.equals("哦")) return "Oh";
            if (key.equals("喂")) return "¿Hola?";
            if (key.equals("好")) return "Bien";
            if (key.equals("不") || key.equals("没")) return "No";
            if (key.equals("停")) return "Alto";
            if (key.equals("谁")) return "¿Quién?";
            if (key.equals("啥")) return "¿Qué?";
            if (key.equals("我")) return "Yo";
            if (key.equals("你")) return "Tú";
            if (key.equals("你好")) return "Hola";
            if (key.equals("谢谢") || key.equals("多谢")) return "Gracias";
            if (key.equals("早上好")) return "Buenos días";
            if (key.equals("晚上好")) return "Buenas noches";
            if (key.equals("对不起")) return "Lo siento";
            if (key.equals("没关系")) return "No pasa nada";
            if (key.equals("再见")) return "Adiós";
            if (key.equals("真的吗")) return "¿De verdad?";
            if (key.equals("等等") || key.equals("等一下")) return "Espera";
            if (key.equals("快走") || key.equals("走吧")) return "Vamos";
            if (key.equals("住手")) return "Detente";
            if (key.equals("救命")) return "Ayuda";
            if (key.equals("小心")) return "Cuidado";
            if (key.equals("没事")) return "Está bien";
            if (key.equals("知道了") || key.equals("明白了")) return "Entendido";
            if (key.equals("不要") || key.equals("不行")) return "No";
        } else if (MODE_KOREAN.equals(mode)) {
            if (key.equals("네") || key.equals("응")) return "Sí";
            if (key.equals("아니")) return "No";
            if (key.equals("왜")) return "¿Por qué?";
            if (key.equals("뭐")) return "¿Qué?";
            if (key.equals("야")) return "Oye";
            if (key.equals("와")) return "Guau";
            if (key.equals("헐")) return "No puede ser";
            if (key.equals("아")) return "Ah";
            if (key.equals("안녕하세요")) return "Hola";
            if (key.equals("고마워") || key.equals("감사합니다")) return "Gracias";
            if (key.equals("미안해") || key.equals("죄송합니다")) return "Lo siento";
            if (key.equals("안녕")) return "Hola";
            if (key.equals("잘자")) return "Buenas noches";
            if (key.equals("정말대단해")) return "Increíble";
            if (key.equals("세상에")) return "No puede ser";
            if (key.equals("잠깐") || key.equals("기다려")) return "Espera";
            if (key.equals("가자")) return "Vamos";
            if (key.equals("멈춰")) return "Detente";
            if (key.equals("도와줘") || key.equals("살려줘")) return "Ayúdame";
            if (key.equals("조심해")) return "Cuidado";
            if (key.equals("괜찮아")) return "Está bien";
            if (key.equals("알았어")) return "Entendido";
            if (key.equals("안돼")) return "No";
            if (key.equals("하지마")) return "No lo hagas";
        }
        return null;
    }

    private String normalizeExpressiveEnglish(String text) {
        if (text == null || text.length() == 0) return "";
        Matcher matcher = expressiveWordPattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String original = matcher.group();
            String replacement = normalizeExpressiveWord(original);
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private String normalizeExpressiveWord(String word) {
        if (word == null || word.length() < 3 || !hasRunOfThree(word)) return word;
        String lower = word.toLowerCase(Locale.ROOT);
        String maxTwo = collapseRuns(lower, 2);
        String selected = EXPRESSIVE_DICTIONARY.contains(maxTwo) ? maxTwo : findDictionaryVariant(maxTwo, 0, new StringBuilder());
        if (selected == null) selected = maxTwo;
        if (word.equals(word.toUpperCase(Locale.ROOT))) return selected.toUpperCase(Locale.ROOT);
        if (Character.isUpperCase(word.charAt(0))) {
            return Character.toUpperCase(selected.charAt(0)) + selected.substring(1);
        }
        return selected;
    }

    private boolean hasRunOfThree(String word) {
        int run = 1;
        for (int i = 1; i < word.length(); i++) {
            if (Character.toLowerCase(word.charAt(i)) == Character.toLowerCase(word.charAt(i - 1))) {
                run++;
                if (run >= 3) return true;
            } else {
                run = 1;
            }
        }
        return false;
    }

    private String collapseRuns(String word, int maxRun) {
        StringBuilder out = new StringBuilder(word.length());
        char previous = 0;
        int run = 0;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c == previous) {
                run++;
            } else {
                previous = c;
                run = 1;
            }
            if (run <= maxRun) out.append(c);
        }
        return out.toString();
    }

    private String findDictionaryVariant(String word, int index, StringBuilder built) {
        if (index >= word.length()) {
            String candidate = built.toString();
            return EXPRESSIVE_DICTIONARY.contains(candidate) ? candidate : null;
        }
        char c = word.charAt(index);
        int end = index + 1;
        while (end < word.length() && word.charAt(end) == c) end++;
        int runLength = end - index;
        int originalLength = built.length();

        for (int i = 0; i < runLength; i++) built.append(c);
        String keep = findDictionaryVariant(word, end, built);
        if (keep != null) return keep;
        built.setLength(originalLength);

        if (runLength == 2) {
            built.append(c);
            String reduced = findDictionaryVariant(word, end, built);
            if (reduced != null) return reduced;
            built.setLength(originalLength);
        }
        return null;
    }

    private String stripCjkFromEnglish(String text) {
        if (text == null) return "";
        String t = text;
        // Quita traducciones chinas/japonesas/coreanas entre paréntesis para no contaminar el inglés.
        t = t.replaceAll("\\([^)]*[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF][^)]*\\)", " ");
        t = t.replaceAll("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]+", " ");
        return t;
    }

    private String cleanEnglishLine(String line) {
        if (line == null) return "";
        String s = normalizeExpressiveEnglish(repairEnglishOcr(line));
        s = s.replaceAll("^[^A-Za-z0-9]+", "");
        s = s.replaceAll("[^A-Za-z0-9.?!']+$", "");
        s = s.replaceAll("\\s+", " ").trim();
        return trimEnglishOcrNoise(s);
    }

    /**
     * Recorta basura corta que el OCR latino inventa al intentar leer caracteres chinos.
     * Es una operacion local y rapida: no espera otra captura ni consulta otro modelo.
     */
    private String trimEnglishOcrNoise(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String[] tokens = text.trim().split("\\s+");
        int start = 0;
        int end = tokens.length;
        while (start < end && isSuspiciousOcrToken(tokens[start])) start++;
        while (end > start && isSuspiciousOcrToken(tokens[end - 1])) end--;
        if (start >= end) return "";

        StringBuilder out = new StringBuilder();
        int badRun = 0;
        int goodCount = 0;
        for (int i = start; i < end; i++) {
            String token = tokens[i];
            boolean bad = isSuspiciousOcrToken(token);
            if (bad) {
                badRun++;
                if (goodCount >= 2 && badRun >= 2) break;
            } else {
                badRun = 0;
                goodCount++;
            }
            if (out.length() > 0) out.append(' ');
            out.append(token);
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    private boolean isSuspiciousOcrToken(String token) {
        if (token == null) return true;
        String raw = token.replaceAll("^[^A-Za-z0-9']+|[^A-Za-z0-9']+$", "");
        if (raw.isEmpty()) return true;
        // Números, edades, fechas y modelos son información real del subtítulo: no se eliminan.
        if (raw.matches("\\d+(?:[.,:/-]\\d+)*")) return false;
        if (raw.matches("(?i)(?:[A-Za-z]+\\d+[A-Za-z0-9]*|\\d+[A-Za-z]+[A-Za-z0-9]*)")) return false;
        String lower = raw.toLowerCase(Locale.ROOT).replace("'", "");
        if (lower.equals("a") || lower.equals("i")) return false;
        String commonShort = " ok hi yes no go why who how hey wow bye not the you me my we us he she her him our your his its mr ms dr ";
        if (commonShort.contains(" " + lower + " ")) return false;
        String contractions = " im ive ill id youre hes shes theyre were dont didnt doesnt cant wont isnt arent wasnt werent thats whats wheres whos lets ";
        if (contractions.contains(" " + lower + " ")) return false;
        if (lower.length() <= 2) {
            String allowed = " am an as at be by do go he if in is it me my no of oh on or so to up us we ";
            return !allowed.contains(" " + lower + " ");
        }
        if (lower.length() >= 4 && !lower.matches(".*[aeiouy].*")) return true;
        // Siglas comunes pueden ser parte del diálogo (FBI, CIA, AI, 3D, etc.).
        if (raw.equals(raw.toUpperCase(Locale.ROOT)) && raw.length() <= 3) {
            return !(raw.equals("FBI") || raw.equals("CIA") || raw.equals("AI") || raw.equals("TV") || raw.equals("USA"));
        }
        return false;
    }

    private boolean isValidShortEnglishSubtitle(String text) {
        if (text == null) return false;
        String key = normalizeKey(text);
        return SHORT_ENGLISH_SUBTITLES.contains(key);
    }

    private boolean isGoodEnglishLine(String s) {
        if (s == null) return false;
        if (isValidShortEnglishSubtitle(s)) return true;
        String key = normalizeKey(s);
        if (key.length() < 2) return false;
        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        boolean sentenceMark = s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",") || s.contains("'");
        if (words == 1 && common > 0 && key.length() >= 2) return true;
        if (words >= 6 && (common > 0 || sentenceMark)) return true;
        if (words >= 2 && common > 0) return true;
        return key.equals("at home") || key.equals("thank you");
    }

    private int scoreEnglishLine(String s) {
        if (s == null) return -9999;
        String k = normalizeKey(s);
        if (isValidShortEnglishSubtitle(s)) return 125 + Math.min(40, s.trim().length() * 5);
        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        int score = Math.min(s.length(), 120) + words * 14 + common * 26;
        if (s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",")) score += 14;
        if (words <= 2 && common == 0) score -= 80;
        if (isLikelySpanishLine(s)) score -= 180;
        return score;
    }

    private boolean isBadEnglishFalsePositive(String s) {
        if (s == null) return true;
        if (isValidShortEnglishSubtitle(s)) return false;
        String k = normalizeKey(s);
        if (k.length() == 0) return true;

        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        boolean hasSentenceMark = s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",") || s.contains("'");
        boolean looksLikeTitle = words <= 3 && common == 0 && !s.matches(".*[a-z].*[a-z].*");
        boolean tooShortWithoutContext = words <= 2 && common == 0;
        return looksLikeTitle || (tooShortWithoutContext && !hasSentenceMark);
    }

    private int commonEnglishWordScore(String s) {
        return countVocabularyWords(s);
    }

    private int countVocabularyWords(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        Matcher matcher = Pattern.compile("[A-Za-z']+").matcher(text.toLowerCase(Locale.ROOT));
        int count = 0;
        while (matcher.find()) {
            String word = matcher.group().replace("'", "");
            if (isVocabularyWord(word)) count++;
        }
        return count;
    }

    private boolean isVocabularyWord(String word) {
        if (word == null || word.isEmpty()) return false;
        if (word.equals("a") || word.equals("i")) return true;
        if (word.length() < 2) return false;
        if (englishVocabulary.contains(word)) return true;
        if (word.endsWith("s") && word.length() > 3 && englishVocabulary.contains(word.substring(0, word.length() - 1))) return true;
        if (word.endsWith("ed") && word.length() > 4) {
            String root = word.substring(0, word.length() - 2);
            if (englishVocabulary.contains(root) || englishVocabulary.contains(root + "e")) return true;
        }
        if (word.endsWith("ing") && word.length() > 5) {
            String root = word.substring(0, word.length() - 3);
            if (englishVocabulary.contains(root) || englishVocabulary.contains(root + "e")) return true;
        }
        return false;
    }

    private void loadEnglishVocabulary() {
        englishVocabulary.addAll(EXPRESSIVE_DICTIONARY);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                appContext.getAssets().open("english_ocr_vocabulary.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String word = line.trim().toLowerCase(Locale.ROOT);
                if (!word.isEmpty()) englishVocabulary.add(word);
            }
        } catch (Exception ignored) {
            // La app sigue funcionando con el vocabulario básico incorporado.
        }
    }

    private boolean isLikelySpanishLine(String s) {
        if (s == null) return false;
        String k = normalizeKey(s);
        return s.contains("¿") || s.contains("¡")
                || k.contains(" que ")
                || k.startsWith("que ")
                || k.contains(" donde ")
                || k.contains(" dónde ")
                || k.contains(" esta ")
                || k.contains(" está ")
                || k.contains(" ropa")
                || k.contains(" mama")
                || k.contains(" mamá")
                || k.contains(" nada")
                || k.contains(" casa")
                || k.contains(" fing");
    }

    private int countEnglishWords(String s) {
        if (s == null) return 0;
        java.util.regex.Matcher m = Pattern.compile("[A-Za-z]+").matcher(s);
        int count = 0;
        while (m.find()) count++;
        return count;
    }

    private String cleanCjkLine(String line, String mode) {
        if (line == null) return "";
        String s = line.replace('　', ' ').trim();
        s = sanitizeAsianDelimitersAndCues(s, mode);
        if (MODE_CHINESE.equals(mode)) {
            s = s.replaceAll("[\u3040-\u30FF\uAC00-\uD7AF]+", " ");
        } else if (MODE_JAPANESE.equals(mode)) {
            s = s.replaceAll("[\uAC00-\uD7AF]+", " ");
        } else if (MODE_KOREAN.equals(mode)) {
            s = s.replaceAll("[\u3040-\u30FF]+", " ");
        }
        s = s.replaceAll("\\s+", " ").trim();
        return hasEnoughScriptForMode(s, mode) ? s : "";
    }

    private boolean hasEnoughScriptForMode(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return false;
        int han = countMatches(chinesePattern, text);
        int kana = countMatches(japanesePattern, text);
        int hangul = countMatches(koreanPattern, text);
        if (MODE_CHINESE.equals(mode)) return han >= 2 || isTrustedShortAsianSubtitle(text, mode);
        if (MODE_JAPANESE.equals(mode)) return kana >= 1 || han >= 2 || isTrustedShortAsianSubtitle(text, mode);
        if (MODE_KOREAN.equals(mode)) return hangul >= 2 || isTrustedShortAsianSubtitle(text, mode);
        return false;
    }

    private boolean isTrustedShortAsianSubtitle(String text, String mode) {
        if (text == null) return false;
        String key = normalizeKeyForLanguage(text, mode);
        if (MODE_CHINESE.equals(mode)) return SHORT_CHINESE_SUBTITLES.contains(key);
        if (MODE_JAPANESE.equals(mode)) return SHORT_JAPANESE_SUBTITLES.contains(key);
        if (MODE_KOREAN.equals(mode)) return SHORT_KOREAN_SUBTITLES.contains(key);
        return false;
    }

    private boolean isAcceptableUnchangedTranslation(String original, String sourceLanguage) {
        if (!TranslateLanguage.ENGLISH.equals(sourceLanguage) || original == null) return false;
        String key = normalizeKey(original);
        if (key.isEmpty()) return false;
        String unchanged = " no hotel taxi internet pizza anime manga karaoke sushi ramen wifi video radio online offline ";
        return unchanged.contains(" " + key + " ");
    }

    private boolean looksUntranslated(String original, String translated) {
        if (original == null || translated == null) return false;
        String a = normalizeKey(original);
        String b = normalizeKey(translated);
        if (a.length() == 0 || b.length() == 0) return false;
        return a.equals(b) || (b.contains(a) && b.length() <= a.length() + 4);
    }

    private String fallbackEnglishToSpanish(String text) {
        String k = normalizeKey(text);
        if (k.equals("yes")) return "Sí";
        if (k.equals("no")) return "No";
        if (k.equals("ok") || k.equals("okay")) return "De acuerdo";
        if (k.equals("hi") || k.equals("hello")) return "Hola";
        if (k.equals("bye")) return "Adiós";
        if (k.equals("go")) return "Ve";
        if (k.equals("run")) return "Corre";
        if (k.equals("come")) return "Ven";
        if (k.equals("look")) return "Mira";
        if (k.equals("hey")) return "Oye";
        if (k.equals("why")) return "¿Por qué?";
        if (k.equals("what")) return "¿Qué?";
        if (k.equals("who")) return "¿Quién?";
        if (k.equals("how")) return "¿Cómo?";
        if (k.equals("help")) return "Ayuda";
        if (k.equals("wait")) return "Espera";
        if (k.equals("stop")) return "Alto";
        if (k.equals("sorry")) return "Lo siento";
        if (k.equals("thanks")) return "Gracias";
        if (k.equals("please")) return "Por favor";
        if (k.equals("really")) return "¿En serio?";
        if (k.equals("sure")) return "Claro";
        if (k.equals("wow")) return "Guau";
        if (k.equals("oh")) return "Oh";
        if (k.equals("ah")) return "Ah";
        if (k.equals("at home")) return "En casa";
        if (k.equals("i am at home")) return "Estoy en casa";
        if (k.equals("i m at home")) return "Estoy en casa";
        if (k.equals("i am at school")) return "Estoy en la escuela";
        if (k.equals("i am at work")) return "Estoy en el trabajo";
        if (k.equals("good morning")) return "Buenos días";
        if (k.equals("good night")) return "Buenas noches";
        if (k.equals("thank you")) return "Gracias";
        if (k.equals("what are you doing")) return "¿Qué estás haciendo?";
        if (k.equals("where are you")) return "¿Dónde estás?";
        if (k.equals("come on")) return "Vamos";
        if (k.equals("lets go") || k.equals("let s go")) return "Vamos";
        if (k.equals("get down")) return "Agáchate";
        if (k.equals("watch out")) return "Cuidado";
        if (k.equals("move")) return "Muévete";
        if (k.equals("hold on")) return "Espera";
        if (k.equals("get out")) return "Sal";
        if (k.equals("stay back")) return "Atrás";
        if (k.equals("drop it")) return "Suéltalo";
        if (k.equals("hands up")) return "Manos arriba";
        if (k.equals("are you okay")) return "¿Estás bien?";
        return null;
    }

    private String exactGlossaryTranslation(String sourceText, String sourceLanguage) {
        String stored = preferences.getString(KEY_CUSTOM_GLOSSARY, "");
        if (stored == null || stored.trim().isEmpty()) return null;
        String sourceKey = normalizeKeyForLanguage(sourceText, sourceLanguage);
        String wantedPrefix = glossaryPrefix(sourceLanguage);
        for (String line : stored.replace("\r", "").split("\n")) {
            String entry = line.trim();
            if (entry.isEmpty() || entry.startsWith("#")) continue;
            int split = entry.indexOf("=>");
            if (split < 0) split = entry.indexOf('=');
            if (split <= 0) continue;

            String source = entry.substring(0, split).trim();
            String target = entry.substring(split + (entry.startsWith("=>", split) ? 2 : 1)).trim();
            if (target.isEmpty()) continue;

            String entryPrefix = "";
            int colon = source.indexOf(':');
            if (colon > 0 && colon <= 3) {
                entryPrefix = source.substring(0, colon).trim().toUpperCase(Locale.ROOT);
                source = source.substring(colon + 1).trim();
            }

            // Las entradas antiguas sin prefijo siguen siendo Inglés → Español.
            if (entryPrefix.isEmpty()) {
                if (!MODE_ENGLISH.equals(sourceLanguage)) continue;
            } else if (!entryPrefix.equals(wantedPrefix)) {
                continue;
            }

            if (normalizeKeyForLanguage(source, sourceLanguage).equals(sourceKey)) return target;
        }
        return null;
    }

    private String glossaryPrefix(String sourceLanguage) {
        if (MODE_CHINESE.equals(sourceLanguage)) return "ZH";
        if (MODE_JAPANESE.equals(sourceLanguage)) return "JA";
        if (MODE_KOREAN.equals(sourceLanguage)) return "KO";
        return "EN";
    }

    private String normalizeKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9áéíóúñü]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String normalizeKeyForLanguage(String text, String mode) {
        if (text == null) return "";
        if (MODE_ENGLISH.equals(mode) || TranslateLanguage.SPANISH.equals(mode) || mode == null) {
            return normalizeKey(text);
        }
        return text.toLowerCase(Locale.ROOT)
                .replace('　', ' ')
                .replaceAll("[\\[\\](){}［］（）｛｝]", " ")
                .replaceAll("[^\\p{L}\\p{N}]+", "")
                .trim();
    }

    private String cleanOcrResult(Text result, String mode, int imageWidth, int imageHeight) {
        if (result == null) return "";
        if (MODE_ENGLISH.equals(mode)) {
            // En inglés no volvemos al bloque completo cuando el análisis por líneas rechaza el texto.
            // Ese retroceso era precisamente lo que reintroducía basura china, marcas de agua y tokens rotos.
            return cleanEnglishFromLayout(result, imageWidth, imageHeight);
        }
        if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) {
            return cleanAsianFromLayout(result, mode, imageWidth, imageHeight);
        }
        return cleanText(result.getText(), mode);
    }

    private static class AsianLineCandidate {
        final String text;
        final Rect box;
        final int score;

        AsianLineCandidate(String text, Rect box, int score) {
            this.text = text;
            this.box = box;
            this.score = score;
        }
    }

    private String cleanAsianFromLayout(Text result, String mode, int imageWidth, int imageHeight) {
        List<AsianLineCandidate> candidates = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String raw = line.getText();
                if (raw == null || raw.trim().isEmpty()) continue;
                String lower = raw.toLowerCase(Locale.ROOT);
                if (isWatermarkOrUi(raw, lower)) continue;
                String cleaned = cleanCjkLine(raw, mode);
                if (cleaned.isEmpty()) continue;
                int score = scoreAsianLine(cleaned, mode);
                Rect box = line.getBoundingBox();
                if (box == null) box = new Rect(0, 0, imageWidth, Math.max(1, imageHeight));
                float widthRatio = imageWidth > 0 ? box.width() / (float) imageWidth : 0f;
                float centerY = imageHeight > 0 ? box.centerY() / (float) imageHeight : 0.5f;
                if (widthRatio >= 0.35f) score += 30;
                else if (widthRatio >= 0.18f) score += 14;
                if (centerY >= 0.30f) score += 8;
                candidates.add(new AsianLineCandidate(cleaned, box, score));
            }
        }
        if (candidates.isEmpty()) return "";
        candidates.sort((a, b) -> {
            int top = Integer.compare(a.box.top, b.box.top);
            return top != 0 ? top : Integer.compare(a.box.left, b.box.left);
        });
        AsianLineCandidate bestA = null;
        AsianLineCandidate bestB = null;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            AsianLineCandidate a = candidates.get(i);
            if (a.score > bestScore) {
                bestScore = a.score;
                bestA = a;
                bestB = null;
            }
            if (i + 1 < candidates.size()) {
                AsianLineCandidate b = candidates.get(i + 1);
                if (asianLinesBelongTogether(a, b, imageWidth)) {
                    int pairScore = a.score + b.score + 28;
                    if (pairScore > bestScore) {
                        bestScore = pairScore;
                        bestA = a;
                        bestB = b;
                    }
                }
            }
        }
        if (bestA == null) return "";
        String separator = MODE_KOREAN.equals(mode) ? " " : "";
        String combined = bestB == null ? bestA.text : bestA.text + separator + bestB.text;
        combined = sanitizeAsianDelimitersAndCues(combined, mode);
        return hasEnoughScriptForMode(combined, mode) ? combined.trim() : "";
    }

    private int scoreAsianLine(String text, String mode) {
        int han = countMatches(chinesePattern, text);
        int kana = countMatches(japanesePattern, text);
        int hangul = countMatches(koreanPattern, text);
        int score = Math.min(120, text.length() * 2);
        if (MODE_CHINESE.equals(mode)) score += han * 10 - kana * 14 - hangul * 14;
        else if (MODE_JAPANESE.equals(mode)) score += kana * 11 + han * 6 - hangul * 14;
        else if (MODE_KOREAN.equals(mode)) score += hangul * 11 + han * 2 - kana * 14;
        if (text.matches(".*[。！？!?…」』]$")) score += 10;
        return score;
    }

    private boolean asianLinesBelongTogether(AsianLineCandidate a, AsianLineCandidate b, int imageWidth) {
        if (a == null || b == null) return false;
        int gap = b.box.top - a.box.bottom;
        int maxHeight = Math.max(1, Math.max(a.box.height(), b.box.height()));
        if (gap < -maxHeight / 2 || gap > maxHeight * 2) return false;
        int overlap = Math.max(0, Math.min(a.box.right, b.box.right) - Math.max(a.box.left, b.box.left));
        int minWidth = Math.max(1, Math.min(a.box.width(), b.box.width()));
        float overlapRatio = overlap / (float) minWidth;
        int centerDistance = Math.abs(a.box.centerX() - b.box.centerX());
        return overlapRatio >= 0.18f || centerDistance <= Math.max(80, imageWidth / 4);
    }

    private static class EnglishLineCandidate {
        final String text;
        final Rect box;
        final int score;

        EnglishLineCandidate(String text, Rect box, int score) {
            this.text = text;
            this.box = box;
            this.score = score;
        }
    }

    /**
     * Selecciona el subtítulo inglés usando texto y posición. Esto evita mezclar la línea china,
     * marcas de agua y fragmentos aislados que antes terminaban dentro de la traducción.
     */
    private String cleanEnglishFromLayout(Text result, int imageWidth, int imageHeight) {
        List<EnglishLineCandidate> candidates = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String raw = line.getText();
                if (raw == null || raw.trim().isEmpty()) continue;
                String lower = raw.toLowerCase(Locale.ROOT);
                if (isWatermarkOrUi(raw, lower)) continue;

                int originalLatin = countMatches(latinPattern, raw);
                int originalCjk = countMatches(cjkPattern, raw);
                String cleaned = cleanEnglishLine(raw);
                if (cleaned.isEmpty() || isLikelySpanishLine(cleaned) || isBadEnglishFalsePositive(cleaned)) continue;

                int words = countEnglishWords(cleaned);
                int vocabularyWords = countVocabularyWords(cleaned);
                if (words < 2 && vocabularyWords == 0 && !isValidShortEnglishSubtitle(cleaned)) continue;
                if (originalLatin < 3 && !isValidShortEnglishSubtitle(cleaned)) continue;
                if (originalCjk > originalLatin * 2 && words < 4) continue;

                Rect box = line.getBoundingBox();
                if (box == null) box = new Rect(0, 0, imageWidth, Math.max(1, imageHeight));
                int score = scoreEnglishLine(cleaned);
                float widthRatio = imageWidth > 0 ? box.width() / (float) imageWidth : 0f;
                float centerY = imageHeight > 0 ? box.centerY() / (float) imageHeight : 0.5f;
                if (widthRatio >= 0.35f) score += 32;
                else if (widthRatio >= 0.18f) score += 14;
                if (centerY >= 0.35f) score += 10;
                score += Math.min(36, vocabularyWords * 7);
                if (originalCjk > 0) score -= Math.min(20, originalCjk / 2);
                candidates.add(new EnglishLineCandidate(cleaned, box, score));
            }
        }

        if (candidates.isEmpty()) return "";
        candidates.sort((a, b) -> {
            int top = Integer.compare(a.box.top, b.box.top);
            return top != 0 ? top : Integer.compare(a.box.left, b.box.left);
        });

        EnglishLineCandidate bestA = null;
        EnglishLineCandidate bestB = null;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            EnglishLineCandidate a = candidates.get(i);
            if (a.score > bestScore) {
                bestScore = a.score;
                bestA = a;
                bestB = null;
            }
            if (i + 1 < candidates.size()) {
                EnglishLineCandidate b = candidates.get(i + 1);
                if (linesBelongTogether(a, b, imageWidth, imageHeight)) {
                    int pairScore = a.score + b.score + 34;
                    if (pairScore > bestScore) {
                        bestScore = pairScore;
                        bestA = a;
                        bestB = b;
                    }
                }
            }
        }

        if (bestA == null || bestScore < 35) return "";
        String combined = bestB == null ? bestA.text : bestA.text + " " + bestB.text;
        combined = trimEnglishOcrNoise(combined.replaceAll("\\s+", " ").trim());
        return isGoodEnglishLine(combined) ? combined : "";
    }

    private boolean linesBelongTogether(EnglishLineCandidate a, EnglishLineCandidate b,
                                        int imageWidth, int imageHeight) {
        if (a == null || b == null) return false;
        int gap = b.box.top - a.box.bottom;
        int maxHeight = Math.max(1, Math.max(a.box.height(), b.box.height()));
        if (gap < -maxHeight / 2 || gap > maxHeight * 2) return false;

        int overlap = Math.max(0, Math.min(a.box.right, b.box.right) - Math.max(a.box.left, b.box.left));
        int minWidth = Math.max(1, Math.min(a.box.width(), b.box.width()));
        float overlapRatio = overlap / (float) minWidth;
        int centerDistance = Math.abs(a.box.centerX() - b.box.centerX());
        boolean horizontallyRelated = overlapRatio >= 0.18f
                || centerDistance <= Math.max(80, imageWidth / 4);
        if (!horizontallyRelated) return false;

        String ka = normalizeKey(a.text);
        String kb = normalizeKey(b.text);
        if (ka.equals(kb)) return false;
        return countEnglishWords(a.text) + countEnglishWords(b.text) >= 4;
    }

    private String cleanText(String raw, String mode) {
        if (raw == null) return "";
        String[] lines = raw.replace("\r", "").split("\n");
        StringBuilder cjk = new StringBuilder();
        StringBuilder all = new StringBuilder();
        List<String> englishLines = new ArrayList<>();

        for (String line : lines) {
            String s = line.trim();
            if (s.length() == 0) continue;
            String lower = s.toLowerCase(Locale.ROOT);
            if (isWatermarkOrUi(s, lower)) continue;

            if (MODE_ENGLISH.equals(mode)) {
                String e = cleanEnglishLine(s);
                if (e.length() == 0) continue;

                // Antes se elegía solo la “mejor” línea y por eso se perdían líneas de subtítulos largos.
                // Ahora se conservan todas las líneas útiles dentro del cuadro OCR.
                if (!isLikelySpanishLine(e) && !isBadEnglishFalsePositive(e)) {
                    if (isGoodEnglishLine(e) || commonEnglishWordScore(e) > 0) {
                        englishLines.add(e);
                    }
                }
                continue;
            }

            if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) {
                String onlyCjk = cleanCjkLine(s, mode);
                if (cjkPattern.matcher(onlyCjk).find()) {
                    cjk.append(onlyCjk).append('\n');
                    continue;
                }
            }
            all.append(s).append('\n');
        }

        // Inglés: conserva como máximo las dos líneas más probables del subtítulo y respeta su orden.
        if (MODE_ENGLISH.equals(mode) && !englishLines.isEmpty()) {
            return selectBestEnglishLines(englishLines);
        }
        // CJK: devolver todas las líneas chinas/japonesas/coreanas detectadas.
        if ((MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) && cjk.length() > 0) {
            return cjk.toString().trim();
        }
        return all.toString().trim();
    }

    private String selectBestEnglishLines(List<String> lines) {
        if (lines == null || lines.isEmpty()) return "";
        int bestStart = 0;
        int bestEnd = 0;
        int bestScore = scoreEnglishLine(lines.get(0));

        for (int i = 0; i < lines.size(); i++) {
            int single = scoreEnglishLine(lines.get(i));
            if (single > bestScore) {
                bestScore = single;
                bestStart = i;
                bestEnd = i;
            }
            if (i + 1 < lines.size()) {
                int pair = single + scoreEnglishLine(lines.get(i + 1)) + 18;
                if (pair > bestScore) {
                    bestScore = pair;
                    bestStart = i;
                    bestEnd = i + 1;
                }
            }
        }

        StringBuilder out = new StringBuilder();
        for (int i = bestStart; i <= bestEnd; i++) {
            if (out.length() > 0) out.append(' ');
            out.append(lines.get(i));
        }
        return trimEnglishOcrNoise(out.toString().replaceAll("\\s+", " ").trim());
    }

    private boolean isWatermarkOrUi(String s, String lower) {
        return lower.contains("video eagle")
                || lower.contains("tencent")
                || lower.contains("zeta live translator")
                || lower.contains("ocr solo")
                || lower.contains("order by")
                || lower.contains("date added")
                || lower.contains("date published")
                || lower.contains("popular:")
                || lower.contains("mother language")
                || lower.contains("spanish order")
                || lower.contains("auto") && lower.contains("español")
                || lower.contains("chino") && lower.contains("es")
                || lower.contains("inglés") && lower.contains("es")
                || lower.contains("japonés") && lower.contains("es")
                || lower.contains("coreano") && lower.contains("es")
                || lower.equals("área")
                || lower.equals("trad.")
                || lower.equals("vivo")
                || lower.equals("pausa")
                || s.contains("腾讯视频")
                || s.contains("出品")
                || s.contains("云曦星空")
                || s.contains("AI专属");
    }

    private String polishSpanish(String translated) {
        if (translated == null) return "";
        String t = translated.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
        if (t.length() == 0) return t;
        return t.substring(0, 1).toUpperCase(Locale.ROOT) + t.substring(1);
    }

    private String guessFromCharacters(String text) {
        if (text == null) return null;
        if (koreanPattern.matcher(text).find()) return TranslateLanguage.KOREAN;
        if (japanesePattern.matcher(text).find()) return TranslateLanguage.JAPANESE;
        if (chinesePattern.matcher(text).find()) return TranslateLanguage.CHINESE;
        if (latinPattern.matcher(text).find()) return TranslateLanguage.ENGLISH;
        return null;
    }

    private String mapLanguage(String languageCode) {
        if (languageCode == null) return null;
        if (languageCode.startsWith("zh")) return TranslateLanguage.CHINESE;
        if (languageCode.startsWith("en")) return TranslateLanguage.ENGLISH;
        if (languageCode.startsWith("ja")) return TranslateLanguage.JAPANESE;
        if (languageCode.startsWith("ko")) return TranslateLanguage.KOREAN;
        if (languageCode.startsWith("es")) return TranslateLanguage.SPANISH;
        return null;
    }

    public synchronized void abortActiveOperations() {
        if (activeRecognizer != null) {
            try { activeRecognizer.close(); } catch (Exception ignored) { }
            activeRecognizer = null;
            activeRecognizerMode = "";
        }
        if (activeTranslator != null) {
            try { activeTranslator.close(); } catch (Exception ignored) { }
            activeTranslator = null;
            activeTranslatorSource = "";
        }
    }

    public synchronized void close() {
        abortActiveOperations();
        mlExecutor.shutdownNow();
        translationCache.clear();
        resetAutoState();
        resetStabilityState();
        resetContextState();
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) return "desconocido";
        return e.getMessage();
    }

    public String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        if (TranslateLanguage.SPANISH.equals(code)) return "Español";
        return code == null ? "Auto" : code;
    }
}
