#!/usr/bin/env python3
"""Revisa si las bibliotecas nativas de un APK o AAB son compatibles con páginas de 16 KB."""
import struct
import sys
import zipfile

PAGE = 16384
ABIS = ("arm64-v8a", "x86_64")


def load_alignment(data):
    """Menor alineación de los segmentos cargables de un ELF de 64 bits."""
    if data[:4] != b"\x7fELF" or data[4] != 2:
        return None
    phoff = struct.unpack_from("<Q", data, 32)[0]
    phentsize, phnum = struct.unpack_from("<HH", data, 54)
    aligns = []
    for i in range(phnum):
        offset = phoff + i * phentsize
        kind = struct.unpack_from("<I", data, offset)[0]
        if kind == 1:  # PT_LOAD
            aligns.append(struct.unpack_from("<Q", data, offset + 48)[0])
    return min(aligns) if aligns else None


def review(path):
    problems = 0
    seen = 0
    rows = []
    is_apk = path.endswith(".apk")
    with zipfile.ZipFile(path) as archive:
        for info in archive.infolist():
            if not info.filename.endswith(".so") or not any("/%s/" % abi in "/" + info.filename for abi in ABIS):
                continue
            seen += 1
            align = load_alignment(archive.read(info.filename))
            ok = align is not None and align >= PAGE
            note = ""
            if is_apk and info.compress_type == zipfile.ZIP_STORED:
                extra_len = len(info.extra)
                data_offset = info.header_offset + 30 + len(info.filename.encode()) + extra_len
                if data_offset % PAGE:
                    ok = False
                    note = "sin alinear en el APK"
            problems += 0 if ok else 1
            rows.append("| %s | %s | %s %s |" % (info.filename, align, "OK" if ok else "REVISAR", note))
    print("### Páginas de 16 KB: %s" % path)
    print("| Biblioteca | Alineación | Estado |")
    print("|---|---|---|")
    print("\n".join(rows) if rows else "| (sin bibliotecas nativas de 64 bits) | | |")
    print("\nBibliotecas revisadas: %d. Con problema: %d." % (seen, problems))
    return problems


if __name__ == "__main__":
    total = sum(review(p) for p in sys.argv[1:])
    sys.exit(1 if total else 0)
