# Política de privacidad de Zeta Live Translator

Última actualización: [FECHA]

Responsable: [TU NOMBRE] · Contacto: [TU CORREO DE CONTACTO]

## Qué hace la app

Zeta Live Translator lee el área de la pantalla que el usuario marca y muestra su traducción al español.

## Imágenes y textos

La captura y la traducción se hacen en el teléfono. La app no envía a ningún servidor las imágenes, los textos ni el audio, y no guarda las capturas.

## Conexión a internet

Se usa para descargar los paquetes de idioma cuando el usuario lo pide. Después, la lectura y la traducción funcionan sin conexión.

## Datos técnicos de Google ML Kit

La app usa ML Kit de Google. Según Google, ML Kit puede recopilar datos técnicos para diagnóstico y estadísticas de uso, como información del dispositivo y de la app, rendimiento, eventos, códigos de error e idiomas configurados. Estos datos se cifran en tránsito.

Más información: https://developers.google.com/ml-kit/android-data-disclosure

## Registro de pruebas

Está apagado por omisión. Si el usuario lo activa, se guarda en su teléfono, puede borrarse desde la app y solo sale si el usuario decide compartirlo. Según el nivel elegido puede incluir los textos leídos y sus traducciones.

## Permisos

- Captura de pantalla: leer el área marcada. Android pide confirmación cada vez.
- Mostrar sobre otras apps: dibujar la traducción y los controles.
- Notificaciones: indicar que la captura está activa y permitir detenerla.
- Internet: descargar los idiomas.

## Anuncios y venta de datos

La app no incluye anuncios y no vende datos.

## Menores

La app no está dirigida a menores de 13 años.

## Cambios

Esta política se publicará actualizada en esta misma página.
