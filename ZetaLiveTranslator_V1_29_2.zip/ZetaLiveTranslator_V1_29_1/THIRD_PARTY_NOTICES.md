# Third-party notices

## Translation

Machine translations are powered by Google Translate through Google ML Kit on-device translation.
https://cloud.google.com/translate

THIS SERVICE MAY CONTAIN TRANSLATIONS POWERED BY GOOGLE.

Review the full attribution requirements before publishing:
https://cloud.google.com/translate/attribution

## Google ML Kit

Text recognition, language identification and on-device translation use Google ML Kit, subject to its terms:
https://developers.google.com/ml-kit/terms

## Vocabulary list

`app/src/main/assets/english_ocr_vocabulary.txt` was generated from the English frequency data of the `wordfreq` project. It is used only to validate OCR candidates. It is not a translation model.

- Project: https://github.com/rspeer/wordfreq
- wordfreq code: Apache License 2.0.
- wordfreq data, and therefore this list: Creative Commons Attribution-ShareAlike 4.0, https://creativecommons.org/licenses/by-sa/4.0/
- The data includes sources that must be credited, among them SUBTLEX. See the wordfreq documentation for the complete list of sources and credits.

## Icons

The toolbar icons are based on Material Icons by Google, Apache License 2.0.
