package com.geozeta.livetranslator;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public class TranslationSchedulerTest {
    private final List<String> drops = new ArrayList<>();
    private final TranslationScheduler s = new TranslationScheduler((job, reason) -> drops.add(job.original + ":" + reason));

    private TranslationScheduler.Job job(String text, long seen) {
        return s.newJob(text, "zh", "Chino", text, false, seen, null, false);
    }

    @Test public void soloUnaActivaYUnaPendiente() {
        TranslationScheduler.Job a = job("甲甲甲甲甲甲甲甲", 0);
        assertSame(a, s.submit(a, 0));
        assertNull(s.submit(job("乙乙乙乙乙乙乙乙", 100), 100));
        TranslationScheduler.Job c = job("丙丙丙丙丙丙丙丙", 200);
        assertNull(s.submit(c, 200));
        assertEquals(1, drops.size());
        assertTrue(drops.get(0).endsWith(TranslationScheduler.DROP_SUPERSEDED));
        TranslationScheduler.Completion done = s.complete(a.id, 300);
        assertTrue(done.publish);
        assertSame(c, done.next);
    }

    @Test public void elViejoNoPisaAlNuevo() {
        TranslationScheduler.Job viejo = job("甲甲甲甲甲甲甲甲", 0);
        s.submit(viejo, 0);
        TranslationScheduler.Job nuevo = job("乙乙乙乙乙乙乙乙", 500);
        s.publishImmediate(nuevo, 500);
        TranslationScheduler.Completion done = s.complete(viejo.id, 700);
        assertFalse(done.publish);
        assertEquals(TranslationScheduler.DROP_OLDER_THAN_SHOWN, done.dropReason);
    }

    @Test public void resultadoAtrasadoConOtroDetrasNoSePublica() {
        s.publishImmediate(job("丁丁丁丁丁丁丁丁", 1900), 1900);
        TranslationScheduler.Job a = s.newJob("甲甲甲甲甲甲甲甲", "zh", "Chino", "甲甲甲甲甲甲甲甲", false, 0, null, false);
        s.submit(a, 0);
        TranslationScheduler.Job b = job("乙乙乙乙乙乙乙乙", 1000);
        s.submit(b, 1000);
        TranslationScheduler.Completion done = s.complete(a.id, 2000);
        assertFalse(done.publish);
        assertEquals(TranslationScheduler.DROP_TOO_OLD, done.dropReason);
        assertSame(b, done.next);
    }

    @Test public void sinOtraFraseDetrasSiSePublicaAunqueLaFuenteYaNoEste() {
        TranslationScheduler.Job a = job("甲甲甲甲甲甲甲甲", 0);
        s.submit(a, 0);
        assertTrue(s.complete(a.id, 9000).publish);
    }

    @Test public void cambioDeIdiomaConRespuestaEnVueloNoApareceNada() {
        TranslationScheduler.Job a = job("甲甲甲甲甲甲甲甲", 0);
        s.submit(a, 0);
        s.submit(job("乙乙乙乙乙乙乙乙", 10), 10);
        s.invalidate();
        TranslationScheduler.Completion done = s.complete(a.id, 100);
        assertFalse(done.publish);
        assertNull(done.next);
        assertFalse(s.hasActive());
    }

    @Test public void respuestaDeTrabajoAbandonadoSeIgnora() {
        TranslationScheduler.Job a = job("甲甲甲甲甲甲甲甲", 0);
        s.submit(a, 0);
        TranslationScheduler.Job b = job("乙乙乙乙乙乙乙乙", 10);
        s.submit(b, 10);
        assertNull(s.abandonIfStuck(100));
        assertSame(b, s.abandonIfStuck(TranslationScheduler.STUCK_AFTER_MS + 1));
        TranslationScheduler.Completion late = s.complete(a.id, 20000);
        assertFalse(late.publish);
        assertNull(late.next);
        assertTrue(s.hasActive());
    }

    @Test public void lecturaMasCompletaReemplazaSinContarComoPerdida() {
        s.submit(job("甲甲甲甲甲甲甲甲", 0), 0);
        s.submit(job("这是一句很长的话", 10), 10);
        s.submit(job("这是一句很长的话吧", 20), 20);
        assertTrue(drops.isEmpty());
    }

    /** Carteles cada 1,5 s y traducción de 2 s: la cola vieja se atrasa sin fin, la nueva no. */
    @Test public void conTelefonoLentoElRetrasoNoCrece() {
        int carteles = 60;
        long cada = 1500, traduce = 2000;

        long libre = 0, peorFifo = 0;
        ArrayDeque<Long> colaFifo = new ArrayDeque<>();
        for (int i = 0; i < carteles; i++) colaFifo.add(i * cada);
        while (!colaFifo.isEmpty()) {
            long llega = colaFifo.poll();
            long fin = Math.max(libre, llega) + traduce;
            peorFifo = Math.max(peorFifo, fin - llega);
            libre = fin;
        }

        long peorNuevo = 0;
        TranslationScheduler.Job activa = null;
        long finActiva = Long.MAX_VALUE;
        int siguiente = 0;
        for (long t = 0; t <= carteles * cada + 10 * traduce; t += 10) {
            if (activa != null && t >= finActiva) {
                TranslationScheduler.Job hecha = activa;
                TranslationScheduler.Completion c = s.complete(hecha.id, t);
                if (c.publish) peorNuevo = Math.max(peorNuevo, t - hecha.firstSeenAt);
                activa = c.next;
                finActiva = activa == null ? Long.MAX_VALUE : t + traduce;
            }
            if (siguiente < carteles && t >= siguiente * cada) {
                String texto = "第" + siguiente + "句完全不同的内容" + (char) ('甲' + siguiente);
                TranslationScheduler.Job j = s.newJob(texto, "zh", "Chino", texto + siguiente, false, t, null, false);
                TranslationScheduler.Job arranca = s.submit(j, t);
                if (arranca != null) {
                    activa = arranca;
                    finActiva = t + traduce;
                }
                siguiente++;
            }
        }
        System.out.println("Peor retraso cola antigua: " + peorFifo + " ms; nueva: " + peorNuevo + " ms; descartadas " + s.dropped + ", publicadas " + s.published);
        assertTrue("la cola antigua debía atrasarse", peorFifo > 30000);
        assertTrue("el retraso nuevo debe quedar acotado", peorNuevo <= 2 * traduce + cada);
        assertTrue(s.dropped > 0);
        assertTrue("un teléfono lento debe seguir mostrando frases", s.published >= carteles / 3);
    }
}
