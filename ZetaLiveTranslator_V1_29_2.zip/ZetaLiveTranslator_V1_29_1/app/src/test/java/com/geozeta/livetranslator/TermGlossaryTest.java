package com.geozeta.livetranslator;

import static org.junit.Assert.*;

import org.junit.Test;

import java.util.List;

public class TermGlossaryTest {
    private static final List<TermGlossary.Entry> BASE = TermGlossary.parse(
            "ZH:鼎 !鼎力 !鼎鼎 => caldero | cauldron\n"
            + "ZH:神识 => Sentido Divino | Divine Sense\n"
            + "ZH:望月 => Observador Lunar | Wangyue\n"
            + "ZH:望月城 => Ciudad Wangyue | Wangyue City\n"
            + "ZH: 你好 => Hola\n"
            + "EN:Tanlang => Lobo Codicioso | Tanlang\n");

    @Test public void cambiaTerminosDentroDeLaFrase() {
        TermGlossary.Plan plan = TermGlossary.apply("贪狼也不知晓此鼎的使用之法", "zh", BASE);
        assertEquals(1, plan.replaced);
        assertTrue(plan.input.contains("cauldron"));
        assertEquals("The greedy wolf does not know how to use this caldero",
                plan.restore("The greedy wolf does not know how to use this cauldron"));
    }

    @Test public void respetaLasExcepciones() {
        assertEquals(0, TermGlossary.apply("感谢你鼎力相助", "zh", BASE).replaced);
        assertEquals(0, TermGlossary.apply("鼎鼎大名", "zh", BASE).replaced);
    }

    @Test public void nombresConvertidosYRestaurados() {
        TermGlossary.Plan plan = TermGlossary.apply("此物在望月吸食之下", "zh", BASE);
        assertTrue(plan.input.contains("Wangyue"));
        assertEquals("Bajo la absorción de Observador Lunar", plan.restore("Bajo la absorción de Wangyue"));
        assertEquals(1, plan.survivingMarkers("Bajo la absorción de Wangyue"));
        assertEquals(0, plan.survivingMarkers("Bajo la luna"));
    }

    @Test public void terminoLargoGana() {
        TermGlossary.Plan plan = TermGlossary.apply("他回到望月城", "zh", BASE);
        assertTrue(plan.input.contains("Wangyue City"));
        assertEquals(1, plan.replaced);
    }

    @Test public void frasesSinBarraNoSeUsanComoTermino() {
        assertEquals(0, TermGlossary.apply("你好吗", "zh", BASE).replaced);
    }

    @Test public void inglesSoloPalabrasCompletas() {
        assertEquals(1, TermGlossary.apply("Tanlang knows", "en", BASE).replaced);
        assertEquals(0, TermGlossary.apply("Tanlangs know", "en", BASE).replaced);
    }

    @Test public void noToqueOtroIdioma() {
        assertEquals(0, TermGlossary.apply("此鼎", "ja", BASE).replaced);
    }

    @Test public void restaurarNoRompePalabrasQueContienenLaMarca() {
        TermGlossary.Plan plan = TermGlossary.apply("神识", "zh", BASE);
        assertEquals("Sentido Divino, divine senses", plan.restore("Divine Sense, divine senses"));
    }

    @Test public void listaBaseDeLaAppSeLeeEntera() throws Exception {
        java.nio.file.Path base = java.nio.file.Paths.get("src/main/assets/glosario_base.tsv");
        if (!java.nio.file.Files.exists(base)) base = java.nio.file.Paths.get("app/src/main/assets/glosario_base.tsv");
        String text = new String(java.nio.file.Files.readAllBytes(base), "UTF-8");
        int lines = 0;
        for (String line : text.split("\n")) if (!line.trim().isEmpty() && !line.startsWith("#")) lines++;
        assertEquals(lines, TermGlossary.parse(text).size());
    }
}
