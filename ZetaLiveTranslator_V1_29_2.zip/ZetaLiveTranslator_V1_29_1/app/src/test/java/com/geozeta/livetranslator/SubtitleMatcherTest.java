package com.geozeta.livetranslator;

import static org.junit.Assert.*;

import org.junit.Test;

public class SubtitleMatcherTest {
    private static boolean same(String a, String b) {
        return SubtitleMatcher.sameVisualSubtitle(SubtitleMatcher.normalizeKey(a), SubtitleMatcher.normalizeKey(b));
    }

    @Test public void negacionesNoSeDeduplican() {
        assertFalse(same("I want to go there", "I don't want to go there"));
        assertFalse(same("I can do this now", "I can't do this now"));
        assertFalse(same("我知道这件事情", "我不知道这件事情"));
        assertFalse(same("彼は学校に行きます", "彼は学校に行きません"));
        assertFalse(same("나는 학교에 갈 수 있어", "나는 학교에 갈 수 없어"));
    }

    @Test public void numerosEscritosNoSeDeduplican() {
        assertFalse(same("We have 12 days left", "We have 13 days left"));
        assertFalse(same("We have two days left", "We have three days left"));
        assertFalse(same("他在三天之内回来了", "他在五天之内回来了"));
    }

    @Test public void nombresParecidosEnFraseCortaNoSeDeduplican() {
        assertFalse(same("姚冰云来了", "姚冰雪来了"));
    }

    @Test public void ruidoDeOcrSiEsElMismoCartel() {
        assertTrue(same("贪狼也不知晓此鼎的使用之法", "贪狼也不知晓此鼎的使用之去"));
        assertTrue(same("Where are you going tonight", "Where are you going tonlght"));
    }

    @Test public void lecturaParcialDelMismoCartel() {
        assertTrue(same("此女修炼的功法的确玄妙", "此女修炼的功法的确"));
    }

    @Test public void frasesSinPuntuacionQueQuedanCortadas() {
        assertTrue(SubtitleMatcher.looksUnfinished("此物在望月吸食之下", "zh"));
        assertTrue(SubtitleMatcher.looksUnfinished("不但望月无法将她吸收", "zh"));
        assertFalse(SubtitleMatcher.looksUnfinished("实乃至宝", "zh"));
        assertFalse(SubtitleMatcher.looksUnfinished("此女修炼的功法的确玄妙", "zh"));
        assertTrue(SubtitleMatcher.looksUnfinished("行きたいけど", "ja"));
        assertFalse(SubtitleMatcher.looksUnfinished("行きたいです", "ja"));
        assertTrue(SubtitleMatcher.looksUnfinished("가고 싶지만", "ko"));
        assertFalse(SubtitleMatcher.looksUnfinished("가고 싶어요", "ko"));
        assertTrue(SubtitleMatcher.looksUnfinished("I went to the", "en"));
        assertFalse(SubtitleMatcher.looksUnfinished("I went home.", "en"));
        assertTrue(SubtitleMatcher.looksUnfinished("Hoy, mañana,", "en"));
    }

    @Test public void soloUneDentroDeLaVentanaYMismoIdioma() {
        assertTrue(SubtitleMatcher.canJoinContext("此物在望月吸食之下", "zh", 0, "古神之气依旧强盛", "zh", 2000));
        assertFalse(SubtitleMatcher.canJoinContext("此物在望月吸食之下", "zh", 0, "古神之气依旧强盛", "zh", 6000));
        assertFalse(SubtitleMatcher.canJoinContext("此物在望月吸食之下", "zh", 0, "古神之气依旧强盛", "ja", 2000));
        assertFalse(SubtitleMatcher.canJoinContext("实乃至宝", "zh", 0, "古神之气依旧强盛", "zh", 2000));
        assertFalse(SubtitleMatcher.canJoinContext("此物在望月吸食之下", "zh", 0, "此物在望月吸食之下", "zh", 1000));
    }

    @Test public void coreanoConservaEspacioAlUnir() {
        assertEquals("가고 싶지만 안돼", SubtitleMatcher.joinContext("가고 싶지만", "안돼", "ko"));
        assertEquals("甲乙", SubtitleMatcher.joinContext("甲", "乙", "zh"));
    }
}
