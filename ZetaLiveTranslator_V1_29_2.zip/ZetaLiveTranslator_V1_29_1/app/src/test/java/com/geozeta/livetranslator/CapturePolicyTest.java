package com.geozeta.livetranslator;

import static org.junit.Assert.*;

import org.junit.Test;

public class CapturePolicyTest {
    @Test public void elLimiteDeVerdadReduceEntradasGrandes() {
        int[][] casos = {{2400, 1080}, {1920, 1080}, {3200, 800}, {1080, 2400}, {2400, 300}, {4000, 3000}};
        for (int[] c : casos) {
            float s = CapturePolicy.firstPassScale(c[0], c[1]);
            int w = Math.round(c[0] * s), h = Math.round(c[1] * s);
            System.out.println(c[0] + "x" + c[1] + " -> " + w + "x" + h + " = " + (w * h) + " px");
            assertTrue(s <= 1f);
            assertTrue(w * (long) h <= CapturePolicy.MAX_OCR_PIXELS * 1.01);
            assertTrue(h <= CapturePolicy.MAX_OCR_HEIGHT + 1);
            assertTrue(w <= CapturePolicy.MAX_OCR_WIDTH + 1);
        }
    }

    @Test public void subtituloNormalNoSeToca() {
        assertEquals(1f, CapturePolicy.firstPassScale(1120, 150), 0.0001f);
        assertEquals(1f, CapturePolicy.firstPassScale(1600, 200), 0.0001f);
    }

    @Test public void elRescateAmpliaSinPasarseDelLimite() {
        float s = CapturePolicy.rescueScale(400, 100);
        assertTrue(s > 1f);
        float big = CapturePolicy.rescueScale(1500, 500);
        assertTrue(1500 * 500 * big * big <= CapturePolicy.MAX_OCR_PIXELS * 1.02);
    }

    @Test public void recorteGiganteSeReparte() {
        assertEquals(1, CapturePolicy.cropStep(1000, 500));
        int step = CapturePolicy.cropStep(2400, 1080);
        assertTrue(step >= 2);
        assertTrue((2400 / step) * (1080 / step) * 4L <= CapturePolicy.MAX_CROP_BYTES);
    }

    @Test public void elRitmoSeAdaptaAlTelefono() {
        assertEquals(15L, CapturePolicy.nextDelayMs(400, true, false, 0, 0));
        assertEquals(50L, CapturePolicy.nextDelayMs(40, false, false, 0, 0));
        assertEquals(200L, CapturePolicy.nextDelayMs(400, false, false, 0, 0));
        assertEquals(300L, CapturePolicy.nextDelayMs(2000, false, false, 0, 0));
        assertEquals(150L, CapturePolicy.nextDelayMs(0, false, true, 0, 0));
        assertTrue(CapturePolicy.nextDelayMs(400, false, false, 0, 3) > CapturePolicy.nextDelayMs(400, false, false, 0, 0));
        assertTrue(CapturePolicy.nextDelayMs(400, false, false, 5000, 0) > CapturePolicy.nextDelayMs(400, false, false, 0, 0));
    }
}
