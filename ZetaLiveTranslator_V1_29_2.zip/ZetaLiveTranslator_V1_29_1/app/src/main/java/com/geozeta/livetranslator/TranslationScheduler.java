package com.geozeta.livetranslator;

/**
 * Decide qué frase se traduce y cuál se puede publicar.
 *
 * Reglas: una traducción activa y una sola pendiente (la más nueva). Un resultado viejo nunca
 * pisa a uno más nuevo. Si la fuente desaparece y no hay otra frase detrás, el resultado sí se
 * publica. Todo descarte queda contado para poder medir lo que se pierde.
 *
 * No toca Android: el reloj se recibe como parámetro y el servicio lo usa siempre desde el hilo principal.
 */
final class TranslationScheduler {
    /** Más vieja que esto y con otra frase esperando detrás, la frase ya no merece mostrarse... */
    static final long MAX_AGE_WHEN_SUPERSEDED_MS = 1800L;
    /** ...salvo que la pantalla lleve este tiempo sin novedades: en un teléfono lento se muestra algo. */
    static final long MIN_REFRESH_WHEN_BEHIND_MS = 2000L;
    /** Una traducción que no responde en este tiempo deja de bloquear a las siguientes. */
    static final long STUCK_AFTER_MS = 15000L;

    static final String DROP_SUPERSEDED = "reemplazada";
    static final String DROP_TOO_OLD = "atrasada";
    static final String DROP_OLDER_THAN_SHOWN = "ya_hay_otra_mas_nueva";
    static final String DROP_INVALIDATED = "sesion_cambio";
    static final String DROP_LATE_CALLBACK = "respuesta_tardia";

    static final class Job {
        final long id;
        final long generation;
        final String original;
        final String sourceMode;
        final String sourceName;
        final String sourceKey;
        final boolean manual;
        final long firstSeenAt;
        final String pretranslated;
        final boolean joined;
        long startedAt;
        /** Datos solo para el registro; aquí no se interpretan. */
        Object meta;

        private Job(long id, long generation, String original, String sourceMode, String sourceName,
                    String sourceKey, boolean manual, long firstSeenAt, String pretranslated, boolean joined) {
            this.id = id;
            this.generation = generation;
            this.original = original;
            this.sourceMode = sourceMode;
            this.sourceName = sourceName;
            this.sourceKey = sourceKey;
            this.manual = manual;
            this.firstSeenAt = firstSeenAt;
            this.pretranslated = pretranslated;
            this.joined = joined;
        }
    }

    static final class Completion {
        final Job job;
        final boolean publish;
        final String dropReason;
        final Job next;

        Completion(Job job, boolean publish, String dropReason, Job next) {
            this.job = job;
            this.publish = publish;
            this.dropReason = dropReason;
            this.next = next;
        }
    }

    interface DropListener {
        void onDropped(Job job, String reason);
    }

    private final DropListener dropListener;
    private long generation = 0L;
    private long nextId = 1L;
    private long newestShownId = 0L;
    private long lastPublishedAt = Long.MIN_VALUE / 2L;
    private Job active;
    private Job pending;

    int submitted;
    int published;
    int dropped;
    int stuck;

    TranslationScheduler(DropListener dropListener) {
        this.dropListener = dropListener;
    }

    Job newJob(String original, String sourceMode, String sourceName, String sourceKey, boolean manual,
               long firstSeenAt, String pretranslated, boolean joined) {
        return new Job(nextId++, generation, original, sourceMode, sourceName, sourceKey, manual,
                firstSeenAt, pretranslated, joined);
    }

    long generation() {
        return generation;
    }

    boolean hasActive() {
        return active != null;
    }

    /** ¿Ya se está traduciendo esa misma frase? Evita traducirla dos veces. */
    boolean isActiveSimilar(String sourceKey, String sourceMode) {
        return active != null
                && active.generation == generation
                && equal(active.sourceMode, sourceMode)
                && SubtitleMatcher.sameVisualSubtitle(active.sourceKey, sourceKey);
    }

    /** Devuelve el trabajo que debe arrancar ya, o null si queda esperando. */
    Job submit(Job incoming, long now) {
        submitted++;
        if (incoming.generation != generation) {
            drop(incoming, DROP_INVALIDATED);
            return null;
        }
        if (active == null) {
            active = incoming;
            incoming.startedAt = now;
            return incoming;
        }
        if (pending != null) {
            boolean sameLine = equal(pending.sourceMode, incoming.sourceMode)
                    && SubtitleMatcher.sameVisualSubtitle(pending.sourceKey, incoming.sourceKey);
            if (sameLine && incoming.sourceKey.length() <= pending.sourceKey.length()) {
                // La lectura que ya espera es igual o más completa: la nueva no aporta nada.
                return null;
            }
            if (!sameLine) drop(pending, DROP_SUPERSEDED);
        }
        pending = incoming;
        return null;
    }

    /** Resultado inmediato (caché o glosario): se muestra y deja viejo todo lo anterior. */
    void publishImmediate(Job job, long now) {
        submitted++;
        published++;
        lastPublishedAt = now;
        noteShown(job);
        if (pending != null && pending.id < job.id) {
            drop(pending, DROP_SUPERSEDED);
            pending = null;
        }
    }

    void noteShown(Job job) {
        if (job.id > newestShownId) newestShownId = job.id;
    }

    Completion complete(long jobId, long now) {
        return finish(jobId, now, true);
    }

    Completion fail(long jobId, long now) {
        return finish(jobId, now, false);
    }

    private Completion finish(long jobId, long now, boolean success) {
        if (active == null || active.id != jobId) {
            // Respuesta de un trabajo ya abandonado: no publica ni arranca nada.
            return new Completion(null, false, DROP_LATE_CALLBACK, null);
        }
        Job job = active;
        active = null;
        String reason = null;
        if (job.generation != generation) {
            reason = DROP_INVALIDATED;
        } else if (job.id < newestShownId) {
            reason = DROP_OLDER_THAN_SHOWN;
        } else if (pending != null && !job.manual
                && now - job.firstSeenAt > MAX_AGE_WHEN_SUPERSEDED_MS
                && now - lastPublishedAt < MIN_REFRESH_WHEN_BEHIND_MS) {
            reason = DROP_TOO_OLD;
        }
        boolean publish = success && reason == null;
        if (publish) {
            published++;
            lastPublishedAt = now;
        }
        else if (reason != null) drop(job, reason);
        return new Completion(job, publish, reason, promotePending(now));
    }

    /**
     * Si la traducción activa no responde, se abandona (ML Kit no se puede cancelar) y su
     * respuesta tardía se ignora. Devuelve el trabajo que debe arrancar, o null.
     */
    Job abandonIfStuck(long now) {
        if (active == null || now - active.startedAt < STUCK_AFTER_MS) return null;
        stuck++;
        drop(active, "sin_respuesta");
        active = null;
        return promotePending(now);
    }

    /** Cambio de idioma, pausa, área o giro: nada de lo anterior puede aparecer ya. */
    void invalidate() {
        generation++;
        if (pending != null) {
            drop(pending, DROP_INVALIDATED);
            pending = null;
        }
    }

    private Job promotePending(long now) {
        Job next = pending;
        pending = null;
        if (next == null) return null;
        if (next.generation != generation) {
            drop(next, DROP_INVALIDATED);
            return null;
        }
        active = next;
        next.startedAt = now;
        return next;
    }

    private void drop(Job job, String reason) {
        dropped++;
        if (dropListener != null) dropListener.onDropped(job, reason);
    }

    private static boolean equal(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }
}
