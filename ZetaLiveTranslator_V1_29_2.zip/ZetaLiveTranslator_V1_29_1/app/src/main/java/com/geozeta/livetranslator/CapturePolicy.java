package com.geozeta.livetranslator;

/** Tamaños y ritmo de la captura. Sin Android para poder comprobar los números de verdad. */
final class CapturePolicy {
    static final int MAX_OCR_PIXELS = 720000;
    static final int MAX_OCR_WIDTH = 1920;
    static final int MAX_OCR_HEIGHT = 540;
    /** Tope de memoria del búfer de recorte, igual que el que ya tenía la app. */
    static final long MAX_CROP_BYTES = 8L * 1024L * 1024L;

    private CapturePolicy() { }

    /** Escala del primer OCR: nunca amplía y siempre respeta los tres límites. */
    static float firstPassScale(int width, int height) {
        if (width <= 0 || height <= 0) return 1f;
        float scale = 1f;
        scale = Math.min(scale, MAX_OCR_WIDTH / (float) width);
        scale = Math.min(scale, MAX_OCR_HEIGHT / (float) height);
        double pixels = width * (double) height * scale * scale;
        if (pixels > MAX_OCR_PIXELS) scale *= (float) Math.sqrt(MAX_OCR_PIXELS / pixels);
        return scale;
    }

    /** Escala del rescate con contraste: amplía recortes pequeños, sin pasarse de los límites. */
    static float rescueScale(int width, int height) {
        if (width <= 0 || height <= 0) return 1f;
        float scale = 1f;
        if (width < 900) scale = 1.45f;
        if (width < 620) scale = 1.70f;
        if (width < 430) scale = 1.90f;
        return Math.min(scale, firstPassScale(Math.round(width * scale), Math.round(height * scale)) * scale);
    }

    /** Salto entre píxeles al copiar un recorte enorme, para no reservar más que el tope. */
    static int cropStep(int width, int height) {
        long bytes = width * (long) height * 4L;
        if (bytes <= MAX_CROP_BYTES) return 1;
        return (int) Math.ceil(Math.sqrt(bytes / (double) MAX_CROP_BYTES));
    }

    /**
     * Espera antes de la siguiente lectura, según lo que tarda el OCR en este teléfono.
     *
     * @param awaitingConfirmation hay una frase nueva esperando su segunda lectura
     * @param noNewFrame la pantalla no cambió desde la última captura
     * @param silenceMs tiempo sin ver texto
     * @param thermalStatus estado térmico de Android (0 normal, 2 moderado, 3 o más severo)
     */
    static long nextDelayMs(long ocrMs, boolean awaitingConfirmation, boolean noNewFrame,
                            long silenceMs, int thermalStatus) {
        long extra = thermalStatus >= 3 ? 300L : (thermalStatus == 2 ? 100L : 0L);
        if (noNewFrame) return 150L + extra;
        if (awaitingConfirmation) return Math.max(15L, extra / 2L);
        long delay = Math.max(50L, Math.min(300L, ocrMs / 2L));
        if (silenceMs > 4000L) delay += 120L;
        return delay + extra;
    }
}
