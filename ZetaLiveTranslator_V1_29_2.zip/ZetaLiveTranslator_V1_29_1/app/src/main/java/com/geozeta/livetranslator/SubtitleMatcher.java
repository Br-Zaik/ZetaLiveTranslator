package com.geozeta.livetranslator;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Decide si dos lecturas son el mismo cartel o dos carteles distintos.
 * Sin dependencias de Android para poder probarla en la compilación.
 */
final class SubtitleMatcher {
    static final String ZH = "zh";
    static final String JA = "ja";
    static final String KO = "ko";
    static final String EN = "en";

    /** Una frase que parece cortada solo se une a la siguiente si esta llega dentro de esta ventana. */
    static final long CONTEXT_JOIN_WINDOW_MS = 5000L;
    /** Límite de la frase unida: más larga tarda demasiado y deja de caber en la caja. */
    static final int CONTEXT_JOIN_MAX_CHARS = 120;

    private static final Pattern DIGITS = Pattern.compile("\\d+");
    private static final Pattern ENGLISH_NUMBER = Pattern.compile(
            "\\b(zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|hundred|thousand|million)\\b");
    // "一" queda fuera a propósito: el OCR lo confunde con un guion y es el numeral que menos
    // cambia el sentido ("一个" frente a "三个" se sigue distinguiendo por el 三).
    private static final String HAN_NUMERALS = "零二两兩三四五六七八九十百千万萬亿億";
    private static final String[] KOREAN_NUMERALS = {"하나", "둘", "셋", "넷", "다섯", "여섯", "일곱", "여덟", "아홉"};

    private static final String[] ZH_TRAILING = {
            "和", "与", "與", "及", "或", "把", "被", "让", "讓", "将", "將", "而", "但", "却", "卻", "若",
            "如果", "虽然", "雖然", "因为", "因為", "所以", "不但", "不仅", "不僅",
            "之下", "之中", "之后", "之後", "之前", "之时", "之時", "之际", "之際", "的时候", "的時候"
    };
    private static final String[] ZH_LEADING = {
            "不但", "不仅", "不僅", "虽然", "雖然", "如果", "即使", "尽管", "儘管", "就算", "哪怕", "只要", "除非"
    };
    private static final String[] JA_TRAILING = {"が", "けど", "けれど", "ので", "のに", "ながら", "たら", "なら", "れば"};
    private static final String[] KO_TRAILING = {"지만", "면서", "어서", "아서", "으면", "하면", "는데", "고", "며"};
    private static final String[] EN_TRAILING = {
            "a", "an", "the", "to", "of", "for", "from", "with", "and", "or", "but", "because", "if",
            "when", "while", "that", "which", "who", "is", "are", "was", "were", "have", "has", "had",
            "will", "would", "can", "could", "should", "do", "does", "did", "not"
    };

    private SubtitleMatcher() { }

    static String normalizeKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    static int levenshtein(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[b.length()];
    }

    static int negationSignature(String key) {
        String safe = key == null ? "" : key.toLowerCase(Locale.ROOT);
        String padded = " " + safe + " ";
        String compact = safe.replaceAll("\\s+", "");
        int mask = 0;
        if (padded.contains(" not ") || padded.contains(" cannot ")) mask |= 1;
        if (padded.contains(" no ")) mask |= 2;
        if (padded.contains(" never ")) mask |= 4;
        if (padded.contains(" nothing ") || padded.contains(" nobody ") || padded.contains(" none ")) mask |= 8;
        if (padded.contains(" without ")) mask |= 16;
        // Cubre don't, can't, won't, isn't... en sus dos formas (con el apóstrofo ya convertido en espacio).
        if (padded.matches(".*[a-z]n t .*") || padded.matches(".* (cant|dont|wont|isnt|arent|didnt|doesnt|wasnt|werent|couldnt|wouldnt|shouldnt|havent|hasnt|hadnt) .*")) {
            mask |= 32;
        }
        if (compact.contains("不")) mask |= 1 << 8;
        if (compact.contains("没") || compact.contains("沒")) mask |= 1 << 9;
        if (compact.contains("别") || compact.contains("別") || compact.contains("莫") || compact.contains("勿")) mask |= 1 << 10;
        if (compact.contains("无") || compact.contains("無") || compact.contains("未")) mask |= 1 << 11;
        if (compact.contains("ない") || compact.contains("ません") || compact.contains("無い") || compact.endsWith("ぬ")) mask |= 1 << 12;
        if (compact.contains("않") || compact.contains("못") || compact.contains("없")
                || compact.contains("아니") || compact.contains("안돼") || compact.contains("안되")
                || compact.contains("안해") || compact.contains("안가") || compact.contains("안와")) mask |= 1 << 13;
        return mask;
    }

    /** Cifras y números escritos en el orden en que aparecen. */
    static String numberSignature(String key) {
        String safe = key == null ? "" : key.toLowerCase(Locale.ROOT);
        StringBuilder out = new StringBuilder();
        Matcher digits = DIGITS.matcher(safe);
        while (digits.find()) out.append(digits.group()).append('|');
        Matcher words = ENGLISH_NUMBER.matcher(safe);
        while (words.find()) out.append(words.group()).append('|');
        for (int i = 0; i < safe.length(); i++) {
            char c = safe.charAt(i);
            if (HAN_NUMERALS.indexOf(c) >= 0) out.append(c).append('|');
        }
        for (String numeral : KOREAN_NUMERALS) {
            if (safe.contains(numeral)) out.append(numeral).append('|');
        }
        return out.toString();
    }

    static boolean hasCriticalDifference(String a, String b) {
        return negationSignature(a) != negationSignature(b)
                || !numberSignature(a).equals(numberSignature(b));
    }

    /** CJK sin espacios: un carácter pesa mucho más que una letra de un idioma con palabras. */
    private static boolean isDense(String key) {
        if (key == null || key.isEmpty() || key.indexOf(' ') >= 0) return false;
        int cjk = 0;
        for (int i = 0; i < key.length(); i++) {
            char c = key.charAt(i);
            if ((c >= '぀' && c <= 'ヿ') || (c >= '㐀' && c <= '鿿')
                    || (c >= '가' && c <= '힯')) cjk++;
        }
        return cjk * 2 >= key.length();
    }

    /** Misma lectura con ruido mínimo. Se usa sin límite de tiempo, así que es estricta. */
    static boolean nearlyIdentical(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b)) return true;
        if (hasCriticalDifference(a, b)) return false;
        int min = Math.min(a.length(), b.length());
        int max = Math.max(a.length(), b.length());
        if (max <= 6) return false;
        if (min >= 12 && (a.contains(b) || b.contains(a)) && min >= Math.round(max * 0.93f)) return true;
        if (Math.abs(a.length() - b.length()) > Math.max(1, max / 20)) return false;
        return levenshtein(a, b) <= Math.max(1, max / 24);
    }

    /** Probablemente el mismo cartel visto otra vez. Solo se usa dentro de una ventana corta. */
    static boolean sameVisualSubtitle(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b)) return true;
        if (hasCriticalDifference(a, b)) return false;
        int min = Math.min(a.length(), b.length());
        int max = Math.max(a.length(), b.length());
        if (max <= 5) return false;
        boolean dense = isDense(a) && isDense(b);
        float containRatio = dense ? 0.70f : 0.62f;
        if ((a.contains(b) || b.contains(a)) && min >= Math.round(max * containRatio)) return true;
        if (min < Math.round(max * 0.80f)) return false;
        int allowed = dense ? Math.max(1, max / 8) : Math.max(2, max / 5);
        return levenshtein(a, b) <= allowed;
    }

    /**
     * La frase parece seguir en el próximo cartel. Mucho chino, japonés y coreano no lleva
     * puntuación final, por eso también se miran las palabras con las que termina o empieza.
     */
    static boolean looksUnfinished(String text, String language) {
        String value = text == null ? "" : text.trim();
        if (value.isEmpty()) return false;
        char last = value.charAt(value.length() - 1);
        if (",，、:：;；-—–…".indexOf(last) >= 0 || value.endsWith("...")) return true;
        if (".。!！?？".indexOf(last) >= 0) return false;
        if (ZH.equals(language)) {
            if (endsWithAny(value, ZH_TRAILING)) return true;
            if (value.length() <= 16) {
                for (String opener : ZH_LEADING) if (value.startsWith(opener)) return true;
            }
            return false;
        }
        if (JA.equals(language)) return endsWithAny(value, JA_TRAILING);
        if (KO.equals(language)) return endsWithAny(value, KO_TRAILING);
        if (EN.equals(language)) {
            String key = " " + normalizeKey(value);
            for (String word : EN_TRAILING) if (key.endsWith(" " + word)) return true;
        }
        return false;
    }

    private static boolean endsWithAny(String value, String[] endings) {
        for (String ending : endings) if (value.endsWith(ending)) return true;
        return false;
    }

    /**
     * Une la frase anterior con la actual solo cuando la anterior quedó cortada, llega dentro
     * de la ventana y el resultado cabe. ML Kit no guarda memoria entre frases: darle ambas
     * mitades es la única forma de que vea la oración completa.
     */
    static boolean canJoinContext(String previous, String previousLanguage, long previousAt,
                                  String current, String currentLanguage, long now) {
        if (previous == null || current == null || previous.trim().isEmpty() || current.trim().isEmpty()) return false;
        if (previousLanguage == null || !previousLanguage.equals(currentLanguage)) return false;
        if (now - previousAt > CONTEXT_JOIN_WINDOW_MS || now < previousAt) return false;
        if (previous.trim().length() + current.trim().length() > CONTEXT_JOIN_MAX_CHARS) return false;
        if (sameVisualSubtitle(normalizeKey(previous), normalizeKey(current))) return false;
        return looksUnfinished(previous, previousLanguage);
    }

    static String joinContext(String first, String second, String language) {
        String a = first == null ? "" : first.trim();
        String b = second == null ? "" : second.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        // Chino y japonés no separan palabras con espacio; inglés y coreano sí.
        boolean spaced = !ZH.equals(language) && !JA.equals(language);
        return spaced ? a + " " + b : a + b;
    }
}
