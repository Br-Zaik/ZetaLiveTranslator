package com.geozeta.livetranslator;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.SystemClock;

import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TranslatorEngine {
    public static final String MODE_AUTO = "auto";
    public static final String MODE_CHINESE = TranslateLanguage.CHINESE;
    public static final String MODE_ENGLISH = TranslateLanguage.ENGLISH;
    public static final String MODE_JAPANESE = TranslateLanguage.JAPANESE;
    public static final String MODE_KOREAN = TranslateLanguage.KOREAN;

    public interface Callback {
        void onSuccess(String original, String translated, String sourceName);
        void onError(String message);
    }

    /**
     * OCR-only callback used by LIVE. Separating recognition from translation lets the
     * next frame be captured while ML Kit is translating the previous subtitle.
     */
    public interface RecognitionCallback {
        void onText(String original, String sourceLanguage, String sourceName);
        void onError(String message);
    }

    /** Resultado sin filtros del motor, para comparar el traductor por separado del OCR. */
    public interface RawCallback {
        void onResult(String translated, long elapsedMs, String error);
    }

    private final Pattern cjkPattern = Pattern.compile("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]");
    private final Pattern chinesePattern = Pattern.compile("[\\u3400-\\u9FFF]");
    private final Pattern japanesePattern = Pattern.compile("[\\u3040-\\u30FF]");
    private final Pattern koreanPattern = Pattern.compile("[\\uAC00-\\uD7AF]");
    private final Pattern latinPattern = Pattern.compile("[A-Za-z]");
    private final Pattern expressiveWordPattern = Pattern.compile("[A-Za-z]{2,}");
    private static final int AUTO_UNLOCK_FAILURES = 2;
    // 1.28.4: lecturas aceptadas del mismo idioma antes de fijar Auto en ese idioma.
    private static final int AUTO_LOCK_HITS = 2;
    private static final int AUTO_ENGLISH_ACCEPT_SCORE = 120;
    private static final int AUTO_CJK_ACCEPT_SCORE = 35;
    public static final String KEY_CUSTOM_GLOSSARY = "custom_glossary_en_es";
    private final Context appContext;
    private final SharedPreferences preferences;
    private final ExecutorService mlExecutor;
    private final Set<String> englishVocabulary = new HashSet<>();
    private int autoFailureCount = 0;
    private int autoProbeCursor = 0;
    private String lastAutoMode = null;
    // 1.28.4: una película no cambia de idioma a mitad de escena. Tras unas pocas lecturas
    // aceptadas Auto se fija en ese idioma y deja de probar un segundo OCR en cada fotograma.
    private String autoLockedMode = null;
    private int autoAcceptStreak = 0;
    private final List<StableReading> recentStableReadings = new ArrayList<>();
    private String stableWindowMode = "";
    private String lastAcceptedStableKey = "";
    private String lastAcceptedStableMode = "";
    private long lastAcceptedStableAt = 0L;
    private int consecutiveEmptyFrames = 0;
    private boolean lastStabilityWasSameSubtitle = false;
    private boolean lastStabilityDetectedChange = false;
    // Metadatos visuales de la línea seleccionada por OCR. Permiten distinguir una
    // corrección de la misma línea de un subtítulo realmente nuevo sin usar solo texto.
    private int lastCleanCenterYPermille = -1;
    private int lastCleanQualityScore = 0;
    private int lastAcceptedCenterYPermille = -1;
    private static final int STABILITY_WINDOW_SIZE = 3;
    private static final long STABILITY_WINDOW_MS = 1500L;
    // Dos lecturas coherentes siguen siendo necesarias, pero sin añadir una espera artificial larga.
    private static final long STABILITY_MIN_CONFIRM_MS = 20L;
    // Ventana en la que una lectura parecida se trata como el mismo cartel, no como uno nuevo.
    private static final long SAME_SUBTITLE_GUARD_MS = 1500L;
    // Tiempo sin texto para dar por terminado el cartel. Solo afecta al seguimiento interno:
    // la traducción visible se queda en pantalla hasta que llegue otra válida.
    private static final long SEGMENT_GONE_MS = 1500L;
    private static final int RESCUE_EVERY_BLANK_FRAMES = 4;
    private static final int RESCUE_EVERY_NOISY_FRAMES = 2;
    private static final int AUTO_ROTATE_BLANK_FRAMES = 6;
    private static final int AUTO_ROTATE_NOISY_FRAMES = 2;
    // Lecturas con algo en pantalla que el idioma actual no entiende antes de soltarlo.
    private static final int AUTO_RELEASE_AFTER_MISSES = 4;
    private final Pattern kanaLetterPattern = Pattern.compile("[\\u3041-\\u3096\\u30A1-\\u30FA]");
    private int autoMissStreak = 0;
    private volatile long currentFrameAt = 0L;
    private long lastAcceptedFirstSeenAt = 0L;
    private long lastTextSeenAt = 0L;
    private int blankRescueCounter = 0;
    private boolean rescueActive = false;
    private int autoBlankFrames = 0;
    private boolean lastRawHadKana = false;
    private volatile String lastRawOcr = "";
    private volatile String lastRawTranslation = "";
    // Zonas del recorte (0..1) tapadas por la propia caja o barra de Zeta.
    private volatile float[][] overlayExclusions = null;
    private String warmedTranslatorMode = "";
    private TextRecognizer activeRecognizer;
    private String activeRecognizerMode = "";
    private Translator activeTranslator;
    private String activeTranslatorSource = "";
    private int activeMlTasks = 0;
    private boolean closeRequested = false;
    private volatile String overlayTextToIgnore = "";
    private final Map<String, String> translationCache = new LinkedHashMap<String, String>(640, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > 640;
        }
    };
    private static final Set<String> SHORT_ENGLISH_SUBTITLES = new HashSet<>(Arrays.asList(
            "a", "i", "ah", "am", "be", "bye", "come", "go", "help", "hello", "hey",
            "hi", "how", "look", "me", "no", "oh", "ok", "okay", "please", "really",
            "right", "run", "she", "sorry", "stop", "sure", "thanks", "wait", "we", "what",
            "who", "why", "wow", "yes", "you", "down", "duck", "freeze", "move", "now",
            "stay", "back", "careful", "easy", "fine", "ready", "again", "never", "maybe",
            "please", "listen", "hurry", "quiet", "sorry", "mayday", "master", "sir",
            "yes sir", "no sir", "got it", "i know", "all right", "alright", "hold on",
            "get down", "watch out", "come on", "let go", "stay here", "stay close",
            "occupational hazard", "your neck okay", "the pilot s a hitman",
            "we ve been compromised", "shoot you down"
    ));
    private static final Set<String> SHORT_CHINESE_SUBTITLES = new HashSet<>(Arrays.asList(
            "嗯", "啊", "哦", "喂", "好", "不", "走", "来", "停", "对", "是", "我", "你",
            "他", "她", "谁", "啥", "滚", "行", "有", "没", "别", "快", "看", "听", "等",
            "救命", "谢谢", "为什么", "怎么", "真的", "可以", "不要", "等等", "小心", "快走",
            "过来", "出去", "回来", "闭嘴", "没事", "没关系", "对不起", "再见",
            "快跑", "别动", "放开", "放开我", "跟我来", "你是谁", "我没事", "我知道",
            "明白", "不可能", "别怕", "小声点", "安静", "加油", "醒醒", "起来",
            "师父", "師父", "刚来", "剛來", "别走", "別走", "跟紧我", "跟緊我"
    ));
    private static final Set<String> SHORT_JAPANESE_SUBTITLES = new HashSet<>(Arrays.asList(
            "え", "あ", "うん", "はい", "いや", "何", "誰", "嘘", "嫌", "ええ", "そう",
            "そうだ", "そうか", "だめ", "ダメ", "待って", "やめて", "助けて", "本当", "本当に",
            "大丈夫", "無理", "危険", "行け", "行こう", "来い", "早く", "ありがとう", "ごめん",
            "ごめんね", "すみません", "さようなら", "おい", "ねえ", "何だ", "なんで", "どうして",
            "最高", "最低", "今日", "明日", "昨日", "元気", "全部", "一緒", "先生", "先輩", "後輩",
            "了解", "まさか", "逃げろ", "動くな", "離せ", "ついて来い", "ついてきて", "誰だ",
            "平気", "怖くない", "静かに", "頑張れ", "起きろ", "起きて", "伏せろ", "戻れ",
            "ここにいて", "そばにいて", "行くぞ", "別れるな"
    ));
    private static final Set<String> SHORT_KOREAN_SUBTITLES = new HashSet<>(Arrays.asList(
            "네", "응", "왜", "뭐", "야", "와", "헐", "아", "어", "자", "가", "봐", "해", "줘", "쉿",
            "아니", "안돼", "잠깐", "기다려", "도와줘", "진짜", "정말", "괜찮아", "괜찮아요",
            "미안", "미안해", "고마워", "감사합니다", "빨리", "조심해", "가자", "여기", "저기", "누구", "뭐야", "왜요",
            "도망쳐", "움직이지마", "놔", "놔줘", "따라와", "너누구야", "난괜찮아", "알겠어",
            "말도안돼", "걱정하지마", "조용히", "힘내", "일어나", "엎드려", "돌아와",
            "가지마", "곁에있어", "내옆에있어", "무슨일이야"
    ));

    private static final Set<String> EXPRESSIVE_DICTIONARY = new HashSet<>(Arrays.asList(
            "a", "ah", "am", "are", "awesome", "bad", "beautiful", "better", "book", "boom",
            "bye", "call", "calm", "can", "come", "cool", "damn", "do", "done", "fine", "food",
            "go", "good", "great", "happy", "help", "hello", "hey", "home", "honey", "hope", "how",
            "i", "know", "later", "leave", "like", "little", "look", "love", "man", "maybe", "me",
            "mom", "more", "need", "never", "nice", "no", "not", "now", "of", "oh", "okay", "one",
            "please", "really", "right", "run", "sad", "see", "she", "shit", "so", "sorry", "stop",
            "sure", "thank", "thanks", "that", "the", "there", "think", "this", "time", "too", "very",
            "wait", "want", "we", "well", "what", "why", "wow", "yeah", "yes", "you"
    ));

    public TranslatorEngine(Context context) {
        appContext = context.getApplicationContext();
        preferences = appContext.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        mlExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "ZetaMlWorker");
            thread.setPriority(Thread.NORM_PRIORITY - 1);
            return thread;
        });
        loadEnglishVocabulary();
        baseTerms = loadBaseTerms();
    }

    private final List<TermGlossary.Entry> baseTerms;
    private String parsedUserGlossary = null;
    private List<TermGlossary.Entry> userTerms = new ArrayList<>();

    private List<TermGlossary.Entry> loadBaseTerms() {
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                appContext.getAssets().open("glosario_base.tsv"), "UTF-8"))) {
            String line;
            while ((line = reader.readLine()) != null) text.append(line).append('\n');
        } catch (Exception ignored) {
            // Sin la lista base la app traduce igual, solo sin términos fijos.
        }
        return TermGlossary.parse(text.toString());
    }

    /** Lista del usuario primero: si repite un término de la base, gana la suya. */
    private synchronized List<TermGlossary.Entry> currentTerms() {
        String stored = preferences.getString(KEY_CUSTOM_GLOSSARY, "");
        if (stored == null) stored = "";
        if (!stored.equals(parsedUserGlossary)) {
            parsedUserGlossary = stored;
            userTerms = TermGlossary.parse(stored);
        }
        List<TermGlossary.Entry> all = new ArrayList<>(userTerms);
        for (TermGlossary.Entry base : baseTerms) {
            boolean overridden = false;
            for (TermGlossary.Entry mine : userTerms) {
                if (mine.lang.equals(base.lang) && mine.source.equals(base.source)) overridden = true;
            }
            if (!overridden) all.add(base);
        }
        return all;
    }

    /** Aplica la lista de términos a una frase ya limpia. Público para la prueba del motor. */
    public TermGlossary.Plan planTerms(String cleanText, String sourceLanguage) {
        return TermGlossary.apply(cleanText, sourceLanguage, currentTerms());
    }

    /** Texto listo para traducir, tal como lo haría el modo en vivo. Para la prueba del motor. */
    public String prepareForTest(String text, String sourceLanguage) {
        return normalizeBeforeTranslate(text, sourceLanguage);
    }

    public void resetAutoState() {
        lastAutoMode = null;
        autoFailureCount = 0;
        autoProbeCursor = 0;
        autoLockedMode = null;
        autoAcceptStreak = 0;
        autoMissStreak = 0;
        autoBlankFrames = 0;
    }

    /** Idioma que Auto ya tiene fijado, o null mientras sigue detectando. */
    public String getAutoLockedMode() {
        return autoLockedMode;
    }

    /** Idioma con el que Auto debe leer este fotograma. */
    private String autoPrimaryMode(List<String> installed) {
        if (autoLockedMode != null && installed.contains(autoLockedMode)) return autoLockedMode;
        if (lastAutoMode != null && installed.contains(lastAutoMode)) return lastAutoMode;
        // El cursor ya no avanza en cada fotograma: cambiar de OCR exige cerrar un modelo y
        // cargar otro, y en las escenas sin subtítulo eso se repetía sin ningún beneficio.
        return installed.get(autoProbeCursor % installed.size());
    }

    private boolean isAutoLocked() {
        return autoLockedMode != null;
    }

    private void noteAutoAccepted(String mode) {
        if (mode == null) return;
        if (!mode.equals(lastAutoMode)) autoAcceptStreak = 0;
        lastAutoMode = mode;
        autoFailureCount = 0;
        autoMissStreak = 0;
        if (autoAcceptStreak < AUTO_LOCK_HITS) autoAcceptStreak++;
        if (autoAcceptStreak >= AUTO_LOCK_HITS) autoLockedMode = mode;
    }

    /**
     * Decide si todavía vale la pena gastar un segundo OCR en este fotograma.
     *
     * - Sin texto: es el hueco normal entre dos subtítulos. Probar otro idioma ahí solo
     *   duplicaba el trabajo sin poder encontrar nada.
     * - Con texto y el idioma fijado: un fotograma borroso no suelta el idioma; hacen falta
     *   varias lecturas reales que no encajen (AUTO_UNLOCK_FAILURES).
     * - Con texto y sin fijar: se prueba el segundo candidato como antes.
     */
    private boolean shouldProbeAutoSecondary(boolean hadText) {
        if (!hadText) return false;
        autoFailureCount++;
        if (!isAutoLocked()) return true;
        if (autoFailureCount >= AUTO_UNLOCK_FAILURES) {
            autoLockedMode = null;
            autoAcceptStreak = 0;
            return true;
        }
        return false;
    }

    public synchronized void resetStabilityState() {
        recentStableReadings.clear();
        stableWindowMode = "";
        lastAcceptedStableKey = "";
        lastAcceptedStableMode = "";
        lastAcceptedStableAt = 0L;
        consecutiveEmptyFrames = 0;
        lastStabilityWasSameSubtitle = false;
        lastStabilityDetectedChange = false;
        lastCleanCenterYPermille = -1;
        lastCleanQualityScore = 0;
        lastAcceptedCenterYPermille = -1;
        lastAcceptedFirstSeenAt = 0L;
        lastTextSeenAt = 0L;
        rescueActive = false;
    }

    public synchronized void forgetAcceptedSubtitle() {
        recentStableReadings.clear();
        stableWindowMode = "";
        lastAcceptedStableKey = "";
        lastAcceptedStableMode = "";
        lastAcceptedStableAt = 0L;
        consecutiveEmptyFrames = 0;
        lastStabilityWasSameSubtitle = false;
        lastStabilityDetectedChange = false;
        lastCleanCenterYPermille = -1;
        lastCleanQualityScore = 0;
        lastAcceptedCenterYPermille = -1;
    }

    /**
     * Anota un fotograma sin texto. Devuelve true cuando el cartel lleva tiempo suficiente sin
     * verse como para darlo por terminado; si la misma frase reaparece será un cartel nuevo.
     * Nunca borra la traducción visible: eso solo lo decide otra traducción válida o el usuario.
     */
    public synchronized boolean noteNoTextDetected() {
        consecutiveEmptyFrames++;
        if (consecutiveEmptyFrames < 2) return false;
        recentStableReadings.clear();
        stableWindowMode = "";
        if (lastAcceptedStableKey.isEmpty() || lastTextSeenAt <= 0L) return false;
        if (frameNow() - lastTextSeenAt < SEGMENT_GONE_MS) return false;
        lastAcceptedStableKey = "";
        lastAcceptedStableMode = "";
        lastAcceptedStableAt = 0L;
        lastAcceptedCenterYPermille = -1;
        return true;
    }

    private volatile long typicalOcrMs = 0L;

    /** Lo que tarda el OCR en este teléfono: en uno lento, dos lecturas necesitan más margen. */
    public void setTypicalOcrMs(long ms) {
        typicalOcrMs = ms;
    }

    private long stabilityWindowMs() {
        return Math.max(STABILITY_WINDOW_MS, Math.min(4000L, typicalOcrMs * 3L));
    }

    /** Momento en que se capturó el fotograma actual. Lo fija el servicio antes del OCR. */
    public void setFrameTime(long elapsedRealtimeMs) {
        currentFrameAt = elapsedRealtimeMs;
    }

    private long frameNow() {
        long at = currentFrameAt;
        return at > 0L ? at : SystemClock.elapsedRealtime();
    }

    /**
     * La pantalla no cambió desde la última lectura, así que esa lectura ya es estable: una
     * segunda daría lo mismo. Devuelve {texto, idioma}, o null si no había nada pendiente.
     */
    public synchronized String[] confirmReadingOnUnchangedScreen() {
        if (recentStableReadings.isEmpty()) return null;
        StableReading last = recentStableReadings.get(recentStableReadings.size() - 1);
        String text = acceptStableReading(last.text, last.key, last.mode, frameNow(),
                last.centerYPermille, last.timestamp);
        return new String[]{text, last.mode};
    }

    /** Primer fotograma en el que se vio la frase que acaba de aceptarse. */
    public synchronized long getLastAcceptedFirstSeenAt() {
        return lastAcceptedFirstSeenAt;
    }

    public String getLastRawOcr() {
        return lastRawOcr;
    }

    public String getLastRawTranslation() {
        return lastRawTranslation;
    }

    /** Zonas del recorte tapadas por la interfaz de Zeta, en proporción 0..1: {izq, arriba, der, abajo}. */
    public void setOverlayExclusions(float[][] exclusions) {
        overlayExclusions = exclusions;
    }

    private boolean isCoveredByOverlay(Rect box, int imageWidth, int imageHeight) {
        float[][] zones = overlayExclusions;
        if (zones == null || box == null || imageWidth <= 0 || imageHeight <= 0) return false;
        float cx = box.centerX() / (float) imageWidth;
        float cy = box.centerY() / (float) imageHeight;
        for (float[] zone : zones) {
            if (cx >= zone[0] && cx <= zone[2] && cy >= zone[1] && cy <= zone[3]) return true;
        }
        return false;
    }

    /** Texto español que Zeta está mostrando en su propio overlay. Se usa únicamente
     * para evitar que el OCR vuelva a leer la interfaz de Zeta sin ocultarla/parpadear. */
    public void setOverlayTextToIgnore(String text) {
        overlayTextToIgnore = text == null ? "" : text.trim();
    }

    public void process(Bitmap crop, String mode, Callback callback) {
        process(crop, mode, false, callback);
    }

    public void process(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (crop == null || crop.isRecycled()) {
            callback.onError("No se pudo leer el recorte.");
            return;
        }
        if (MODE_AUTO.equals(mode)) {
            processAuto(crop, requireStable, callback);
        } else {
            processFixed(crop, mode, requireStable, callback);
        }
    }

    /**
     * LIVE path: perform OCR/stability only and return the accepted source text.
     * Translation is deliberately started separately by the service, so a slow translation
     * cannot prevent OCR from seeing the next subtitle.
     */
    public void recognizeStable(Bitmap crop, String mode, boolean requireStable, RecognitionCallback callback) {
        if (crop == null || crop.isRecycled()) {
            callback.onError("No se pudo leer el recorte.");
            return;
        }
        if (MODE_AUTO.equals(mode)) {
            recognizeAutoText(crop, requireStable, callback);
        } else {
            recognizeFixedText(crop, mode, requireStable, callback);
        }
    }

    public void translateRecognized(String text, String sourceLanguage, Callback callback) {
        if (text == null || text.trim().isEmpty()) {
            callback.onError("No hay texto para traducir.");
            return;
        }
        translate(text, sourceLanguage, callback);
    }

    private void recognizeFixedText(Bitmap crop, String mode, boolean requireStable, RecognitionCallback callback) {
        if (!isModelReady(mode)) {
            callback.onError("Descarga " + readable(mode) + " → Español antes de usar este idioma.");
            return;
        }
        recognizeFixedTextAttempt(crop, crop, mode, requireStable, true, callback);
    }

    private void recognizeFixedTextAttempt(Bitmap original, Bitmap attempt, String mode, boolean requireStable,
                                           boolean allowFallback, RecognitionCallback callback) {
        recognize(attempt, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                if (cleaned.trim().isEmpty() && allowFallback && shouldRescue(result, requireStable)) {
                    recognizeFixedTextAttempt(original, prepareForOcr(original), mode, requireStable, false, callback);
                    return;
                }
                if (attempt != original) {
                    rememberRescueOutcome(!cleaned.trim().isEmpty());
                    if (!attempt.isRecycled()) attempt.recycle();
                }
                if (cleaned.trim().isEmpty()) {
                    callback.onError("No se detectó texto dentro del cuadro.");
                    return;
                }
                emitStableRecognition(cleaned, mode, requireStable, callback);
            }

            @Override public void onError(String error) {
                if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                callback.onError(error);
            }
        });
    }

    /**
     * El segundo OCR con contraste antes se lanzaba en TODOS los fotogramas sin subtítulo, que
     * son la mayoría, y duplicaba el trabajo. Ahora es periódico, y se mantiene seguido solo
     * mientras esté dando resultado (subtítulo de bajo contraste).
     */
    private synchronized boolean shouldRescue(Text result, boolean requireStable) {
        if (!requireStable || rescueActive) return true;
        boolean sawSomething = result != null && result.getText() != null && !result.getText().trim().isEmpty();
        blankRescueCounter++;
        return blankRescueCounter % (sawSomething ? RESCUE_EVERY_NOISY_FRAMES : RESCUE_EVERY_BLANK_FRAMES) == 0;
    }

    private synchronized void rememberRescueOutcome(boolean found) {
        rescueActive = found;
    }

    private void recognizeAutoText(Bitmap crop, boolean requireStable, RecognitionCallback callback) {
        List<String> installed = installedAutoModes();
        if (installed.isEmpty()) {
            callback.onError("Descarga por lo menos un idioma antes de usar Auto.");
            return;
        }

        final String primaryMode = autoPrimaryMode(installed);

        recognize(crop, primaryMode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, primaryMode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, primaryMode);
                if (isAutoCandidateAcceptable(cleaned, primaryMode, score)) {
                    noteAutoAccepted(primaryMode);
                    emitStableRecognition(cleaned, primaryMode, requireStable, callback);
                    return;
                }
                boolean hadText = cleaned != null && !cleaned.trim().isEmpty();
                if (!hadText) {
                    boolean hadRaw = result != null && result.getText() != null && !result.getText().trim().isEmpty();
                    if (hadRaw && ++autoMissStreak >= AUTO_RELEASE_AFTER_MISSES) {
                        // El OCR ve algo pero el idioma actual no lo entiende: hay que probar otro.
                        autoMissStreak = 0;
                        autoLockedMode = null;
                        autoAcceptStreak = 0;
                        lastAutoMode = null;
                    }
                    if (!isAutoLocked()) {
                        autoBlankFrames++;
                        if (autoBlankFrames % (hadRaw ? AUTO_ROTATE_NOISY_FRAMES : AUTO_ROTATE_BLANK_FRAMES) == 0) {
                            autoProbeCursor = (autoProbeCursor + 1) % installed.size();
                        }
                    }
                }
                if (!shouldProbeAutoSecondary(hadText)) {
                    callback.onError(hadText
                            ? "No se detectó texto claro dentro del cuadro."
                            : "No se detectó texto dentro del cuadro.");
                    return;
                }
                tryAutoSecondaryText(crop, chooseAutoSecondary(installed, primaryMode), requireStable, callback);
            }

            @Override public void onError(String error) {
                // Un fallo del reconocedor no dice nada sobre el idioma, así que no suelta el bloqueo.
                if (isAutoLocked()) {
                    callback.onError(error);
                    return;
                }
                autoFailureCount++;
                tryAutoSecondaryText(crop, chooseAutoSecondary(installed, primaryMode), requireStable, callback);
            }
        });
    }

    private void tryAutoSecondaryText(Bitmap crop, String secondaryMode, boolean requireStable,
                                      RecognitionCallback callback) {
        if (secondaryMode == null) {
            callback.onError("No se detectó texto claro dentro del cuadro.");
            return;
        }
        recognize(crop, secondaryMode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, secondaryMode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, secondaryMode);
                if (!isAutoCandidateAcceptable(cleaned, secondaryMode, score)) {
                    callback.onError("No se detectó texto claro dentro del cuadro.");
                    return;
                }
                noteAutoAccepted(secondaryMode);
                emitStableRecognition(cleaned, secondaryMode, requireStable, callback);
            }

            @Override public void onError(String error) {
                callback.onError("No se detectó texto claro dentro del cuadro.");
            }
        });
    }

    private void emitStableRecognition(String text, String sourceLanguage, boolean requireStable,
                                       RecognitionCallback callback) {
        if (!requireStable) {
            callback.onText(text, sourceLanguage, readable(sourceLanguage));
            return;
        }

        String stableText = selectStableText(text, sourceLanguage);
        if (stableText == null || stableText.trim().isEmpty()) {
            if (lastStabilityWasSameSubtitle) {
                callback.onError("Mismo subtítulo.");
            } else if (lastStabilityDetectedChange) {
                callback.onError("Cambio de subtítulo detectado.");
            } else {
                callback.onError("Esperando subtítulo estable.");
            }
            return;
        }
        callback.onText(stableText, sourceLanguage, readable(sourceLanguage));
    }

    private void processFixed(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (!isModelReady(mode)) {
            callback.onError("Descarga " + readable(mode) + " → Español antes de usar este idioma.");
            return;
        }

        // Flujo unificado para los cuatro idiomas: igual que el Inglés estable.
        // 1) OCR sobre el recorte original.
        // 2) Solo si no se detecta texto útil, un único fallback ampliado/contrastado.
        // El único cambio entre idiomas es el TextRecognizer y sus filtros lingüísticos.
        processFixedAttempt(crop, crop, mode, requireStable, true, callback);
    }

    private void processFixedAttempt(Bitmap original, Bitmap attempt, String mode, boolean requireStable,
                                     boolean allowFallback, Callback callback) {
        recognize(attempt, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                if (cleaned.trim().isEmpty() && allowFallback) {
                    Bitmap fallback = attempt == original ? prepareForOcr(original) : original;
                    if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                    processFixedAttempt(original, fallback, mode, requireStable, false, callback);
                    return;
                }
                if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                if (cleaned.trim().isEmpty()) {
                    callback.onError("No se detectó texto dentro del cuadro.");
                    return;
                }
                translateWhenStable(cleaned, mode, requireStable, callback);
            }

            @Override public void onError(String error) {
                if (attempt != original && !attempt.isRecycled()) attempt.recycle();
                callback.onError(error);
            }
        });
    }

    private void processAuto(Bitmap crop, boolean requireStable, Callback callback) {
        List<String> installed = installedAutoModes();
        if (installed.isEmpty()) {
            callback.onError("Descarga por lo menos un idioma antes de usar Auto.");
            return;
        }

        final String primaryMode = autoPrimaryMode(installed);

        // Auto usa exactamente la misma imagen original para Inglés, Chino, Japonés y Coreano.
        // No se crea una copia grande solo por ser un OCR asiático.
        recognize(crop, primaryMode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, primaryMode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, primaryMode);
                if (isAutoCandidateAcceptable(cleaned, primaryMode, score)) {
                    noteAutoAccepted(primaryMode);
                    translateWhenStable(cleaned, primaryMode, requireStable, callback);
                    return;
                }
                boolean hadText = cleaned != null && !cleaned.trim().isEmpty();
                if (!shouldProbeAutoSecondary(hadText)) {
                    callback.onError(hadText
                            ? "No se detectó texto claro dentro del cuadro."
                            : "No se detectó texto dentro del cuadro.");
                    return;
                }
                tryAutoSecondary(crop, chooseAutoSecondary(installed, primaryMode), requireStable, callback);
            }

            @Override public void onError(String error) {
                if (isAutoLocked()) {
                    callback.onError(error);
                    return;
                }
                autoFailureCount++;
                tryAutoSecondary(crop, chooseAutoSecondary(installed, primaryMode), requireStable, callback);
            }
        });
    }

    private String chooseAutoSecondary(List<String> installed, String primaryMode) {
        if (installed == null || installed.size() < 2) return null;
        for (int i = 0; i < installed.size(); i++) {
            int index = (autoProbeCursor + i) % installed.size();
            String candidate = installed.get(index);
            if (!candidate.equals(primaryMode)) {
                autoProbeCursor = (index + 1) % installed.size();
                return candidate;
            }
        }
        return null;
    }

    private void tryAutoSecondary(Bitmap original, String secondaryMode,
                                  boolean requireStable, Callback callback) {
        if (secondaryMode == null) {
            callback.onError("No se detectó texto claro dentro del cuadro.");
            return;
        }
        recognize(original, secondaryMode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, secondaryMode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, secondaryMode);
                if (!isAutoCandidateAcceptable(cleaned, secondaryMode, score)) {
                    callback.onError("No se detectó texto claro dentro del cuadro.");
                    return;
                }
                noteAutoAccepted(secondaryMode);
                translateWhenStable(cleaned, secondaryMode, requireStable, callback);
            }

            @Override public void onError(String error) {
                callback.onError("No se detectó texto claro dentro del cuadro.");
            }
        });
    }

    private boolean isAutoCandidateAcceptable(String text, String mode, int score) {
        if (text == null || text.trim().isEmpty()) return false;
        if (MODE_ENGLISH.equals(mode)) {
            if (isValidShortEnglishSubtitle(text)) return score >= 20;
            return score >= AUTO_ENGLISH_ACCEPT_SCORE;
        }
        if (isTrustedShortAsianSubtitle(text, mode)) return score >= 8;

        // Un kana en la lectura cruda delata japonés aunque el OCR chino lo haya limpiado, y
        // el chino casi nunca lleva kana. Sin esto Auto podía fijarse en el idioma equivocado.
        if (MODE_CHINESE.equals(mode) && lastRawHadKana && isModelReady(MODE_JAPANESE)) return false;
        if (MODE_JAPANESE.equals(mode) && countMatches(japanesePattern, text) == 0
                && isModelReady(MODE_CHINESE)) return false;

        // Han (kanji/hanzi) se comparte entre chino y japonés. En Auto no dejamos que
        // una frase japonesa conocida escrita solo con kanji sea aceptada primero como chino.
        // El modo manual no cambia: cada idioma conserva su reconocedor y sus filtros propios.
        if (MODE_CHINESE.equals(mode) && looksLikeJapaneseHanOnlyPhrase(text)) return false;
        if (MODE_JAPANESE.equals(mode) && looksLikeChineseHanOnlyPhrase(text)) return false;
        return score >= AUTO_CJK_ACCEPT_SCORE;
    }

    private String[] fallbackModes(String alreadyTried) {
        List<String> installed = installedAutoModes();
        installed.remove(alreadyTried);
        return installed.toArray(new String[0]);
    }

    private String[] autoModesOrder() {
        return installedAutoModes().toArray(new String[0]);
    }

    private List<String> installedAutoModes() {
        List<String> modes = new ArrayList<>();
        // Inglés siempre es la primera opción cuando está instalado.
        if (isModelReady(MODE_ENGLISH)) modes.add(MODE_ENGLISH);
        if (isModelReady(MODE_CHINESE)) modes.add(MODE_CHINESE);
        if (isModelReady(MODE_JAPANESE)) modes.add(MODE_JAPANESE);
        if (isModelReady(MODE_KOREAN)) modes.add(MODE_KOREAN);
        return modes;
    }

    private String firstInstalledAutoMode() {
        List<String> modes = installedAutoModes();
        return modes.isEmpty() ? null : modes.get(0);
    }

    private boolean isModelReady(String sourceLanguage) {
        if (TranslateLanguage.SPANISH.equals(sourceLanguage)) return true;
        return preferences.getBoolean(MainActivity.KEY_MODEL_PREFIX + sourceLanguage, false);
    }

    /**
     * 1.28.6: comprueba de verdad que los modelos marcados como listos siguen descargados.
     *
     * Antes esa comprobación solo la hacía la pantalla principal al abrirse. Si el sistema
     * o Google Play Services borraba un modelo y el usuario arrancaba Vivo sin volver a
     * pasar por la pantalla principal, cada frase fallaba con "Descarga X → Español" y no
     * había forma de salir de ahí.
     *
     * Solo corrige una bandera cuando ML Kit responde que el modelo NO está: si la consulta
     * falla (sin red, servicio ocupado) no se toca nada, para no apagar un idioma que sí
     * funciona. El español se verifica aparte porque sin él no traduce ningún idioma.
     */
    public void verifyDownloadedModels() {
        final String[] codes = new String[]{
                MODE_ENGLISH, MODE_CHINESE, MODE_JAPANESE, MODE_KOREAN
        };
        try {
            RemoteModelManager manager = RemoteModelManager.getInstance();
            checkSpanishModel(manager, codes);
        } catch (Exception ignored) {
            // Sin verificación se sigue confiando en las banderas guardadas.
        }
    }

    private void checkSpanishModel(RemoteModelManager manager, String[] codes) {
        TranslateRemoteModel spanish = new TranslateRemoteModel.Builder(TranslateLanguage.SPANISH).build();
        manager.isModelDownloaded(spanish)
                .addOnSuccessListener(ready -> {
                    if (!Boolean.TRUE.equals(ready)) {
                        // Sin español no se puede traducir ningún par: se apagan todos.
                        SharedPreferences.Editor editor = preferences.edit();
                        for (String code : codes) editor.putBoolean(MainActivity.KEY_MODEL_PREFIX + code, false);
                        editor.apply();
                        return;
                    }
                    for (String code : codes) checkSourceModel(manager, code);
                })
                .addOnFailureListener(error -> { });
    }

    private void checkSourceModel(RemoteModelManager manager, String code) {
        if (!isModelReady(code)) return;
        if (MODE_ENGLISH.equals(code)) {
            // El inglés no tiene modelo propio descargable: con español basta.
            return;
        }
        try {
            TranslateRemoteModel model = new TranslateRemoteModel.Builder(code).build();
            manager.isModelDownloaded(model)
                    .addOnSuccessListener(ready -> {
                        if (!Boolean.TRUE.equals(ready)) {
                            preferences.edit()
                                    .putBoolean(MainActivity.KEY_MODEL_PREFIX + code, false)
                                    .apply();
                        }
                    })
                    .addOnFailureListener(error -> { });
        } catch (Exception ignored) { }
    }

    private void recognizeAutoAt(Bitmap bitmap, String[] modes, int index, List<Candidate> out, Runnable done) {
        if (index >= modes.length) {
            done.run();
            return;
        }
        String mode = modes[index];
        recognize(bitmap, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, mode);
                if (cleaned.trim().length() > 0) out.add(new Candidate(cleaned, mode, score));
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }

            @Override public void onError(String error) {
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }
        });
    }

    private Candidate chooseBest(List<Candidate> candidates) {
        Candidate best = null;
        for (Candidate candidate : candidates) {
            if (best == null || candidate.score > best.score) best = candidate;
        }
        return best;
    }

    private int scoreCandidate(String text, String mode) {
        if (text == null) return 0;
        String t = text.trim();
        if (t.length() == 0) return 0;
        int score = Math.min(t.length(), 160);
        int cjk = countMatches(cjkPattern, t);
        int chinese = countMatches(chinesePattern, t);
        int japanese = countMatches(japanesePattern, t);
        int korean = countMatches(koreanPattern, t);
        int latin = countMatches(latinPattern, t);
        int lineCount = countUsefulLines(t);
        if (lineCount > 1) score += Math.min(90, lineCount * 22);

        if (MODE_ENGLISH.equals(mode)) {
            if (isBadEnglishFalsePositive(t)) return -9999;
            score += latin * 3;
            if (isGoodEnglishLine(t)) score += 170 + scoreEnglishLine(t);
            if (countEnglishWords(t) <= 2 && commonEnglishWordScore(t) == 0) score -= 90;
            if (isLikelySpanishLine(t)) score -= 180;
            if (cjk > 0) score -= cjk * 2;
        } else if (MODE_CHINESE.equals(mode)) {
            score += chinese * 7;
            if (japanese > 0 || korean > 0) score -= 10;
        } else if (MODE_JAPANESE.equals(mode)) {
            score += japanese * 8 + chinese * 2;
        } else if (MODE_KOREAN.equals(mode)) {
            score += korean * 8;
        }
        if (isTrustedShortAsianSubtitle(t, mode)) score += 70;
        return score;
    }

    private int countMatches(Pattern pattern, String text) {
        int count = 0;
        java.util.regex.Matcher m = pattern.matcher(text);
        while (m.find()) count++;
        return count;
    }

    private int countUsefulLines(String text) {
        if (text == null) return 0;
        String[] parts = text.replace("\r", "").split("\n");
        int count = 0;
        for (String p : parts) {
            if (p != null && p.trim().length() >= 2) count++;
        }
        return count;
    }

    private static class Candidate {
        final String cleaned;
        final String sourceLanguage;
        final int score;
        Candidate(String cleaned, String sourceLanguage, int score) {
            this.cleaned = cleaned;
            this.sourceLanguage = sourceLanguage;
            this.score = score;
        }
    }

    private static class StableReading {
        final String text;
        final String key;
        final String mode;
        final long timestamp;
        final int centerYPermille;
        final int qualityScore;

        StableReading(String text, String key, String mode, long timestamp,
                      int centerYPermille, int qualityScore) {
            this.text = text;
            this.key = key;
            this.mode = mode;
            this.timestamp = timestamp;
            this.centerYPermille = centerYPermille;
            this.qualityScore = qualityScore;
        }
    }

    private Bitmap prepareForOcr(Bitmap crop) {
        if (crop == null || crop.isRecycled()) return crop;
        int width = crop.getWidth();
        int height = crop.getHeight();
        if (width <= 0 || height <= 0) return crop;

        // Antes un Math.max() impedía reducir y el límite de píxeles no llegaba a aplicarse.
        float scale = CapturePolicy.rescueScale(width, height);
        int newW = Math.max(1, Math.round(width * scale));
        int newH = Math.max(1, Math.round(height * scale));
        Bitmap enhanced = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888);

        // Escala y aplica contraste en una sola superficie. La versión anterior creaba
        // además un bitmap intermedio grande, duplicando memoria en cada captura.
        Canvas canvas = new Canvas(enhanced);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float contrast = 1.38f;
        float translate = (-0.5f * contrast + 0.5f) * 255f;
        ColorMatrix matrix = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        Rect source = new Rect(0, 0, width, height);
        Rect target = new Rect(0, 0, newW, newH);
        canvas.drawBitmap(crop, source, target, paint);
        return enhanced;
    }

    private interface OcrCallback {
        void onResult(Text result, int imageWidth, int imageHeight);
        void onError(String error);
    }

    private void recognize(Bitmap crop, String mode, OcrCallback cb) {
        if (!beginMlTask()) {
            cb.onError("Motor OCR cerrado.");
            return;
        }
        try {
            TextRecognizer recognizer = getRecognizer(mode);
            InputImage image = InputImage.fromBitmap(crop, 0);
            int width = crop.getWidth();
            int height = crop.getHeight();

            // Un único callback al finalizar la Task. Así ningún idioma cambia/cierra su
            // recognizer desde onSuccess mientras ML Kit aún está ejecutando onComplete.
            recognizer.process(image).addOnCompleteListener(mlExecutor, task -> {
                // 1.28.6: la tarea sigue contando como activa durante TODO el cuerpo del
                // callback. Antes se descontaba en la primera línea, así que mientras este
                // cuerpo trabajaba el contador valía 0 y warmUpMode() o close() podían
                // cerrar y recrear el reconocedor justo encima. Esa era la carrera que
                // producía cierres inesperados. endMlTask() va ahora en el finally.
                try {
                    if (task.isSuccessful() && task.getResult() != null) {
                        cb.onResult(task.getResult(), width, height);
                    } else {
                        cb.onError("Error OCR: " + safeMessage(task.getException()));
                    }
                } catch (OutOfMemoryError oom) {
                    cb.onError("Memoria insuficiente durante OCR; reduce el cuadro de lectura.");
                } catch (RuntimeException pipelineError) {
                    cb.onError("Error procesando OCR: " + safeMessage(pipelineError));
                } finally {
                    endMlTask();
                }
            });
        } catch (OutOfMemoryError oom) {
            endMlTask();
            throw oom;
        } catch (RuntimeException e) {
            endMlTask();
            cb.onError("Error OCR: " + safeMessage(e));
        }
    }

    private synchronized TextRecognizer getRecognizer(String mode) {
        String key = mode == null ? MODE_ENGLISH : mode;
        if (activeRecognizer != null && key.equals(activeRecognizerMode)) return activeRecognizer;
        if (activeRecognizer != null) {
            try { activeRecognizer.close(); } catch (Exception ignored) { }
            activeRecognizer = null;
        }
        TextRecognizer created;
        if (MODE_CHINESE.equals(key)) {
            created = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        } else if (MODE_JAPANESE.equals(key)) {
            created = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        } else if (MODE_KOREAN.equals(key)) {
            created = TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        } else {
            created = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        }
        activeRecognizer = created;
        activeRecognizerMode = key;
        return created;
    }

    private void translateWhenStable(String text, String sourceLanguage, boolean requireStable, Callback callback) {
        if (!requireStable) {
            translate(text, sourceLanguage, callback);
            return;
        }

        String stableText = selectStableText(text, sourceLanguage);
        if (stableText == null || stableText.trim().isEmpty()) {
            if (lastStabilityWasSameSubtitle) {
                callback.onError("Mismo subtítulo.");
            } else if (lastStabilityDetectedChange) {
                callback.onError("Cambio de subtítulo detectado.");
            } else {
                callback.onError("Esperando subtítulo estable.");
            }
            return;
        }

        String acceptedKey = lastAcceptedStableKey;
        String acceptedMode = lastAcceptedStableMode;
        translate(stableText, sourceLanguage, new Callback() {
            @Override public void onSuccess(String original, String translated, String sourceName) {
                callback.onSuccess(original, translated, sourceName);
            }

            @Override public void onError(String message) {
                // Si el modelo falla, permite reintentar el mismo subtítulo en la siguiente captura.
                if (acceptedKey.equals(lastAcceptedStableKey)
                        && acceptedMode.equals(lastAcceptedStableMode)) {
                    lastAcceptedStableKey = "";
                    lastAcceptedStableMode = "";
                    lastAcceptedStableAt = 0L;
                }
                callback.onError(message);
            }
        });
    }

    /**
     * Confirma el OCR por consenso: al menos dos de las últimas tres lecturas deben
     * representar el mismo subtítulo. Nunca fuerza una frase inestable por tiempo;
     * mientras no exista consenso, LIVE conserva la traducción anterior.
     */
    private synchronized String selectStableText(String text, String sourceLanguage) {
        String cleaned = normalizeBeforeTranslate(text, sourceLanguage);
        String normalized = normalizeKeyForLanguage(cleaned, sourceLanguage);
        lastStabilityWasSameSubtitle = false;
        lastStabilityDetectedChange = false;
        if (normalized.isEmpty()) return null;

        String mode = sourceLanguage == null ? "" : sourceLanguage;
        long now = frameNow();
        int currentCenterY = lastCleanCenterYPermille;
        int currentQuality = lastCleanQualityScore;
        consecutiveEmptyFrames = 0;
        lastTextSeenAt = now;

        if (mode.equals(lastAcceptedStableMode)
                && isSameAcceptedSubtitle(lastAcceptedStableKey, normalized)
                && (lastAcceptedStableKey.equals(normalized)
                    || sameVisualBand(lastAcceptedCenterYPermille, currentCenterY))) {
            recentStableReadings.clear();
            stableWindowMode = mode;
            lastStabilityWasSameSubtitle = true;
            return null;
        }

        // Una pequeña ampliación/corrección del OCR justo después de aceptar una frase
        // no debe cambiar el español que ya está leyendo el usuario. Esperamos a que esa
        // lectura sobreviva fuera de esta ventana antes de tratarla como un subtítulo nuevo.
        if (mode.equals(lastAcceptedStableMode)
                && now - lastAcceptedStableAt <= SAME_SUBTITLE_GUARD_MS
                && sameVisualBand(lastAcceptedCenterYPermille, currentCenterY)
                && isLikelySameSubtitleRefinement(lastAcceptedStableKey, normalized, mode)) {
            recentStableReadings.clear();
            stableWindowMode = mode;
            lastStabilityWasSameSubtitle = true;
            return null;
        }

        boolean clearSwitch = lastAcceptedStableKey.isEmpty()
                || !mode.equals(lastAcceptedStableMode)
                || (visualBandDistance(lastAcceptedCenterYPermille, currentCenterY) > 260
                    && !lastAcceptedStableKey.equals(normalized))
                || isClearlyNewSubtitle(lastAcceptedStableKey, normalized, mode);

        // Solo las respuestas/acotaciones cortas de alta confianza entran desde una sola
        // lectura. Las frases normales de los cuatro idiomas usan dos OCR coherentes; esto
        // evita mostrar una lectura parcial y corregirla 100-200 ms después.
        if (clearSwitch && (isImmediateStableCandidate(cleaned, mode)
                || isHighConfidenceCompleteSubtitle(cleaned, mode, currentQuality))) {
            return acceptStableReading(cleaned, normalized, mode, now, currentCenterY, now);
        }

        if (!mode.equals(stableWindowMode)) {
            recentStableReadings.clear();
            stableWindowMode = mode;
        }

        for (int i = recentStableReadings.size() - 1; i >= 0; i--) {
            if (now - recentStableReadings.get(i).timestamp > stabilityWindowMs()) {
                recentStableReadings.remove(i);
            }
        }

        recentStableReadings.add(new StableReading(cleaned, normalized, mode, now,
                currentCenterY, currentQuality));
        while (recentStableReadings.size() > STABILITY_WINDOW_SIZE) {
            recentStableReadings.remove(0);
        }

        StableReading best = null;
        int bestMatches = 0;
        for (StableReading candidate : recentStableReadings) {
            int matches = 0;
            for (StableReading other : recentStableReadings) {
                if (sameVisualBand(candidate.centerYPermille, other.centerYPermille)
                        && areConsensusSimilar(candidate.key, other.key)) matches++;
            }
            if (matches > bestMatches
                    || (matches == bestMatches && isBetterStableReading(candidate, best))) {
                bestMatches = matches;
                best = candidate;
            }
        }

        if (best == null || bestMatches < 2) {
            if (recentStableReadings.size() >= 2 && !lastAcceptedStableKey.isEmpty()) {
                lastStabilityDetectedChange = true;
            }
            return null;
        }

        long oldestMatchAt = now;
        StableReading bestReading = null;
        for (StableReading sample : recentStableReadings) {
            if (!sameVisualBand(best.centerYPermille, sample.centerYPermille)
                    || !areConsensusSimilar(best.key, sample.key)) continue;
            oldestMatchAt = Math.min(oldestMatchAt, sample.timestamp);
            if (isBetterStableReading(sample, bestReading)) bestReading = sample;
        }

        if (now - oldestMatchAt < STABILITY_MIN_CONFIRM_MS || bestReading == null) return null;
        return acceptStableReading(bestReading.text, bestReading.key, mode, now,
                bestReading.centerYPermille, oldestMatchAt);
    }

    private String acceptStableReading(String text, String normalized, String mode, long now,
                                       int centerYPermille, long firstSeenAt) {
        lastAcceptedFirstSeenAt = firstSeenAt;
        lastAcceptedStableKey = normalized;
        lastAcceptedStableMode = mode;
        lastAcceptedStableAt = now;
        lastAcceptedCenterYPermille = centerYPermille;
        recentStableReadings.clear();
        stableWindowMode = mode;
        return text;
    }

    private boolean isHighConfidenceCompleteSubtitle(String text, String mode, int layoutQuality) {
        if (text == null || text.trim().isEmpty()) return false;
        String clean = text.trim();
        boolean terminal = clean.matches(".*[.!?…！？。][\"'」』）)]?$");

        if (MODE_ENGLISH.equals(mode)) {
            if (isBadEnglishFalsePositive(clean) || !isGoodEnglishLine(clean)) return false;
            if (countSuspiciousCharacters(clean) > 0) return false;
            int words = countEnglishWords(clean);
            int vocab = countVocabularyWords(clean);
            if (words < 3 || vocab < Math.max(2, (int) Math.ceil(words * 0.60))) return false;
            if (terminal) return true;
            // Muchos subtítulos incrustados no llevan puntuación. Una línea larga, limpia y
            // visualmente fuerte puede entrar en una sola lectura siempre que no termine
            // en una palabra que normalmente anuncia que la oración sigue incompleta.
            return layoutQuality >= 150 && words >= 6 && !endsLikeIncompleteEnglish(clean);
        }

        // Chino/Japonés/Coreano usan siempre dos lecturas rápidas para una frase normal.
        // Una sílaba/kanji final puede cambiar sujeto, negación o intención; aceptar una sola
        // lectura fue justamente lo que producía "traduce algo y luego lo corrige". Las
        // respuestas cortas seguras y acotaciones siguen entrando de inmediato por la ruta
        // isImmediateStableCandidate().
        return false;
    }

    private boolean endsLikeIncompleteEnglish(String text) {
        String key = normalizeKey(text);
        if (key.isEmpty()) return true;
        String[] incomplete = new String[]{
                "a", "an", "the", "to", "of", "for", "from", "with", "and", "or",
                "but", "because", "if", "when", "while", "that", "which", "who",
                "is", "are", "was", "were", "have", "has", "had", "will", "would",
                "can", "could", "should", "do", "does", "did", "not"
        };
        for (String word : incomplete) {
            if (key.equals(word) || key.endsWith(" " + word)) return true;
        }
        return false;
    }

    private boolean isImmediateStableCandidate(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return false;
        if (MODE_ENGLISH.equals(mode)) {
            return isValidShortEnglishSubtitle(text) && countSuspiciousCharacters(text) <= 1;
        }
        if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) {
            return isKnownAsianStageCueText(text, mode) || isTrustedShortAsianSubtitle(text, mode);
        }
        return false;
    }

    private boolean isLikelySameSubtitleRefinement(String accepted, String current, String mode) {
        if (accepted == null || current == null || accepted.isEmpty() || current.isEmpty()) return false;
        if (accepted.equals(current)) return true;
        if (hasCriticalMeaningDifference(accepted, current)) return false;
        int max = Math.max(accepted.length(), current.length());
        int min = Math.min(accepted.length(), current.length());
        if (max <= 6 || min < 4) return false;

        // Las lecturas parciales suelen ser prefijos/sufijos de la misma línea. Solo usamos
        // esta tolerancia durante 650 ms tras aceptar una frase, nunca de forma permanente.
        if ((accepted.contains(current) || current.contains(accepted))
                && min >= Math.round(max * 0.60f)) return true;

        int allowed = MODE_ENGLISH.equals(mode)
                ? Math.max(1, Math.min(4, max / 9))
                : Math.max(1, Math.min(3, max / 8));
        return min >= Math.round(max * 0.80f)
                && levenshteinDistance(accepted, current) <= allowed;
    }

    private boolean isClearlyNewSubtitle(String accepted, String current, String mode) {
        if (accepted == null || accepted.isEmpty()) return true;
        if (current == null || current.isEmpty() || accepted.equals(current)) return false;
        if (hasCriticalMeaningDifference(accepted, current)) return true;
        if (areConsensusSimilar(accepted, current)) return false;

        int max = Math.max(accepted.length(), current.length());
        int min = Math.min(accepted.length(), current.length());
        if (max <= 6) return true;

        if (MODE_ENGLISH.equals(mode)) {
            Set<String> a = new HashSet<>(Arrays.asList(accepted.split("\\s+")));
            Set<String> b = new HashSet<>(Arrays.asList(current.split("\\s+")));
            a.remove("");
            b.remove("");
            int shared = 0;
            for (String token : a) if (b.contains(token)) shared++;
            int smaller = Math.max(1, Math.min(a.size(), b.size()));
            float overlap = shared / (float) smaller;
            if (overlap <= 0.45f) return true;
            return levenshteinDistance(accepted, current) > Math.max(3, max / 3);
        }

        if (min < Math.round(max * 0.55f)) return true;
        return levenshteinDistance(accepted, current) > Math.max(2, max / 3);
    }

    private boolean isFastStableEnglishCandidate(String text, String mode) {
        if (!MODE_ENGLISH.equals(mode) || text == null || text.trim().isEmpty()) return false;
        String clean = text.trim();
        if (isBadEnglishFalsePositive(clean) || !isGoodEnglishLine(clean)) return false;
        if (countSuspiciousCharacters(clean) > 1) return false;
        if (isValidShortEnglishSubtitle(clean)) return true;
        int words = countEnglishWords(clean);
        int vocabulary = countVocabularyWords(clean);
        boolean sentenceMark = clean.matches(".*[.!?…][\"']?$");
        if (words == 1 && vocabulary >= 1 && clean.length() >= 2) return true;
        if (words >= 2 && vocabulary >= 1 && clean.length() >= 4) return true;
        return sentenceMark && words >= 1 && vocabulary >= 1;
    }

    private boolean isFastStableAsianCandidate(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return false;
        if (!(MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode))) return false;
        if (isKnownAsianStageCueText(text, mode) || isTrustedShortAsianSubtitle(text, mode)) return true;
        if (countSuspiciousCharactersForMode(text) > 1) return false;

        int han = countMatches(chinesePattern, text);
        int kana = countMatches(japanesePattern, text);
        int hangul = countMatches(koreanPattern, text);
        if (MODE_CHINESE.equals(mode)) return han >= 2;
        if (MODE_JAPANESE.equals(mode)) return (kana + han) >= 2 && (kana >= 1 || han >= 2);
        if (MODE_KOREAN.equals(mode)) return hangul >= 2;
        return false;
    }

    private boolean isKnownAsianStageCueText(String text, String mode) {
        if (text == null) return false;
        String key = normalizeKeyForLanguage(text, mode);
        return !key.isEmpty() && isAsianStageCue(key, mode);
    }

    private boolean isBetterStableReading(StableReading candidate, StableReading currentBest) {
        if (candidate == null) return false;
        if (currentBest == null) return true;
        int candidateScore = stableReadingScore(candidate.text, candidate.mode)
                + Math.min(120, Math.max(0, candidate.qualityScore)) / 4;
        int currentScore = stableReadingScore(currentBest.text, currentBest.mode)
                + Math.min(120, Math.max(0, currentBest.qualityScore)) / 4;
        if (candidateScore != currentScore) return candidateScore > currentScore;
        return candidate.timestamp > currentBest.timestamp;
    }

    private int stableReadingScore(String text, String mode) {
        if (text == null) return Integer.MIN_VALUE;
        String clean = text.trim();
        int score = clean.length();
        if (MODE_ENGLISH.equals(mode)) {
            int words = clean.isEmpty() ? 0 : clean.split("\\s+").length;
            int vocabularyWords = countVocabularyWords(clean);
            score += Math.min(words, 16) * 6;
            score += Math.min(vocabularyWords, 16) * 7;
            score -= Math.max(0, words - vocabularyWords - 2) * 3;
            if (clean.matches(".*[.!?…][\"']?$")) score += 12;
            if (clean.matches(".*\\b(I|you|he|she|we|they|it)\\b.*")) score += 5;
            score -= countSuspiciousCharacters(clean) * 15;
            return score;
        }
        int han = countMatches(chinesePattern, clean);
        int kana = countMatches(japanesePattern, clean);
        int hangul = countMatches(koreanPattern, clean);
        int latin = countMatches(latinPattern, clean);
        if (MODE_CHINESE.equals(mode)) {
            score += han * 9 - kana * 12 - hangul * 12 - Math.min(40, latin * 3);
        } else if (MODE_JAPANESE.equals(mode)) {
            score += kana * 10 + han * 5 - hangul * 12 - Math.min(40, latin * 3);
        } else if (MODE_KOREAN.equals(mode)) {
            score += hangul * 10 + han * 2 - kana * 12 - Math.min(40, latin * 3);
        }
        if (clean.matches(".*[。！？!?…」』]$")) score += 10;
        score -= countSuspiciousCharactersForMode(clean) * 8;
        return score;
    }

    private int countSuspiciousCharacters(String text) {
        if (text == null) return 0;
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c)
                    || "'.,?!:;-–—…".indexOf(c) >= 0) continue;
            count++;
        }
        return count;
    }

    private int countSuspiciousCharactersForMode(String text) {
        if (text == null) return 0;
        int count = 0;
        String allowed = "'.,?!:;-–—…，。！？：；、・〜～「」『』（）【】《》〈〉…·";
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c) || allowed.indexOf(c) >= 0) continue;
            count++;
        }
        return count;
    }

    private boolean areConsensusSimilar(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b)) return true;

        int max = Math.max(a.length(), b.length());
        int min = Math.min(a.length(), b.length());

        // En subtítulos muy cortos una sola letra/sílaba puede invertir el sentido.
        // Exigimos coincidencia exacta en vez de fusionar por distancia de edición.
        if (max <= 6) return false;
        if (hasCriticalMeaningDifference(a, b)) return false;

        // Solo admite ampliaciones muy pequeñas del mismo OCR. No usa similitud por
        // conjunto de palabras porque podría confundir frases con significado opuesto
        // como "I want..." e "I don't want...".
        if (min >= 10 && (a.contains(b) || b.contains(a)) && min >= Math.round(max * 0.90f)) {
            return true;
        }

        int allowedDistance = Math.max(1, Math.min(3, max / 18));
        return Math.abs(a.length() - b.length()) <= allowedDistance
                && levenshteinDistance(a, b) <= allowedDistance;
    }

    private boolean isSameAcceptedSubtitle(String accepted, String current) {
        if (accepted == null || current == null || accepted.length() == 0 || current.length() == 0) {
            return false;
        }
        if (accepted.equals(current)) return true;
        int max = Math.max(accepted.length(), current.length());
        int min = Math.min(accepted.length(), current.length());
        if (max <= 6 || hasCriticalMeaningDifference(accepted, current)) return false;
        if (max - min > Math.max(2, max / 14)) return false;
        return levenshteinDistance(accepted, current) <= Math.max(1, max / 18);
    }

    private boolean hasCriticalMeaningDifference(String a, String b) {
        return SubtitleMatcher.hasCriticalDifference(a, b);
    }

    private int levenshteinDistance(String a, String b) {
        return SubtitleMatcher.levenshtein(a, b);
    }

    private void detectLanguageThenTranslate(String text, Callback callback) {
        String guessed = guessFromCharacters(text);
        if (guessed != null) {
            translate(text, guessed, callback);
            return;
        }

        LanguageIdentifier identifier = LanguageIdentification.getClient();
        identifier.identifyLanguage(text)
                .addOnSuccessListener(mlExecutor, languageCode -> {
                    identifier.close();
                    String src = mapLanguage(languageCode);
                    if (src == null || "und".equals(languageCode)) src = TranslateLanguage.ENGLISH;
                    translate(text, src, callback);
                })
                .addOnFailureListener(mlExecutor, e -> {
                    identifier.close();
                    translate(text, TranslateLanguage.ENGLISH, callback);
                });
    }

    /**
     * Devuelve una traducción inmediata si ya existe en caché/glosario o si es una frase
     * segura incorporada. No inicia ML Kit y por eso puede prepararse mientras otra frase
     * sigue traduciéndose, reduciendo la cola sin saltarse subtítulos.
     */
    public String getImmediateTranslation(String text, String sourceLanguage) {
        if (text == null || text.trim().isEmpty()) return null;
        String src = sourceLanguage;
        if (MODE_AUTO.equals(src)) src = guessFromCharacters(text);
        if (src == null) src = TranslateLanguage.ENGLISH;
        String clean = normalizeBeforeTranslate(text, src);
        if (clean.isEmpty()) return null;

        String glossary = exactGlossaryTranslation(clean, src);
        if (glossary != null) return polishSpanish(glossary);
        if (TranslateLanguage.ENGLISH.equals(src)) {
            String direct = fallbackEnglishToSpanish(clean);
            if (direct != null) return polishSpanish(direct);
        } else if (TranslateLanguage.CHINESE.equals(src)
                || TranslateLanguage.JAPANESE.equals(src)
                || TranslateLanguage.KOREAN.equals(src)) {
            String direct = fallbackAsianToSpanish(clean, src);
            if (direct == null) direct = fallbackAsianPhraseToSpanish(clean, src);
            if (direct != null) return polishSpanish(direct);
        }
        String cacheKey = src + "|" + normalizeKeyForLanguage(clean, src);
        return getCachedTranslation(cacheKey);
    }

    private synchronized String getCachedTranslation(String key) {
        if (key == null) return null;
        return translationCache.get(key);
    }

    private synchronized void putCachedTranslation(String key, String value) {
        if (key == null || value == null || value.trim().isEmpty()) return;
        translationCache.put(key, value);
    }

    private void translate(String text, String sourceLanguage, Callback callback) {
        String src = sourceLanguage;
        if (MODE_AUTO.equals(src)) src = guessFromCharacters(text);
        if (src == null) src = TranslateLanguage.ENGLISH;

        String cleanForTranslate = normalizeBeforeTranslate(text, src);
        String glossaryMatch = exactGlossaryTranslation(cleanForTranslate, src);
        if (glossaryMatch != null) {
            callback.onSuccess(cleanForTranslate, glossaryMatch, readable(src));
            return;
        }
        if (TranslateLanguage.CHINESE.equals(src)
                || TranslateLanguage.JAPANESE.equals(src)
                || TranslateLanguage.KOREAN.equals(src)) {
            String asianExact = fallbackAsianToSpanish(cleanForTranslate, src);
            if (asianExact != null) {
                callback.onSuccess(cleanForTranslate, asianExact, readable(src));
                return;
            }
            String asianPhrase = fallbackAsianPhraseToSpanish(cleanForTranslate, src);
            if (asianPhrase != null) {
                callback.onSuccess(cleanForTranslate, asianPhrase, readable(src));
                return;
            }
        }
        // LIVE traduce cada subtítulo de forma independiente. No se mezcla con líneas anteriores.
        String cacheKey = src + "|" + normalizeKeyForLanguage(cleanForTranslate, src);
        String cached = getCachedTranslation(cacheKey);
        if (cached != null) {
            callback.onSuccess(cleanForTranslate, cached, readable(src));
            return;
        }

        if (TranslateLanguage.SPANISH.equals(src)) {
            callback.onSuccess(cleanForTranslate, cleanForTranslate, "Español");
            return;
        }

        TermGlossary.Plan plan = planTerms(cleanForTranslate, src);
        translateWithMlKit(cleanForTranslate, plan, src, cacheKey, callback);
    }

    private void translateWithMlKit(String input, TermGlossary.Plan plan, String sourceLanguage,
                                    String cacheKey, Callback callback) {
        if (!isModelReady(sourceLanguage)) {
            callback.onError("Descarga " + readable(sourceLanguage) + " → Español antes de traducir.");
            return;
        }

        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String direct = fallbackEnglishToSpanish(input);
            if (direct != null && !direct.trim().isEmpty()) {
                putCachedTranslation(cacheKey, direct);
                callback.onSuccess(input, direct, readable(sourceLanguage));
                return;
            }
        }

        Translator translator = getTranslator(sourceLanguage);
        translateDirect(translator, input, plan, sourceLanguage, cacheKey, callback);
    }

    private void translateDirect(Translator translator, String input, TermGlossary.Plan plan,
                                 String sourceLanguage, String cacheKey, Callback callback) {
        if (!beginMlTask()) {
            callback.onError("Motor de traducción cerrado.");
            return;
        }
        try {
            translator.translate(plan.input).addOnCompleteListener(mlExecutor, task -> {
                // 1.28.6: igual que en recognize(), el descuento va al final para que el
                // traductor no pueda cerrarse mientras este cuerpo lo sigue usando.
                try {
                    if (task.isSuccessful() && task.getResult() != null) {
                        finishTranslation(input, sourceLanguage, cacheKey, plan.restore(task.getResult()), callback);
                    } else {
                        callback.onError("Error al traducir: " + safeMessage(task.getException()));
                    }
                } catch (OutOfMemoryError oom) {
                    callback.onError("Memoria insuficiente durante traducción.");
                } catch (RuntimeException pipelineError) {
                    callback.onError("Error procesando traducción: " + safeMessage(pipelineError));
                } finally {
                    endMlTask();
                }
            });
        } catch (OutOfMemoryError oom) {
            endMlTask();
            throw oom;
        } catch (RuntimeException e) {
            endMlTask();
            callback.onError("Error al traducir: " + safeMessage(e));
        }
    }

    /**
     * Traduce sin caché, sin glosario y sin filtros. Sirve para saber qué parte de un error
     * viene del motor y qué parte del OCR, y para confirmar que un modelo responde sin red.
     */
    public void translateRaw(String text, String sourceLanguage, RawCallback callback) {
        if (!beginMlTask()) {
            callback.onResult(null, 0L, "Motor cerrado");
            return;
        }
        final long startedAt = SystemClock.elapsedRealtime();
        try {
            getTranslator(sourceLanguage).translate(text).addOnCompleteListener(mlExecutor, task -> {
                try {
                    long ms = SystemClock.elapsedRealtime() - startedAt;
                    if (task.isSuccessful() && task.getResult() != null) {
                        callback.onResult(task.getResult(), ms, null);
                    } else {
                        callback.onResult(null, ms, safeMessage(task.getException()));
                    }
                } finally {
                    endMlTask();
                }
            });
        } catch (RuntimeException e) {
            endMlTask();
            callback.onResult(null, SystemClock.elapsedRealtime() - startedAt, safeMessage(e));
        }
    }

    private void finishTranslation(String input, String sourceLanguage, String cacheKey, String translated, Callback callback) {
        lastRawTranslation = translated == null ? "" : translated;
        String polished = polishSpanish(translated);
        polished = contextualSpanishCorrections(input, polished, sourceLanguage);
        if (isSuspiciousResult(input, polished, sourceLanguage)
                && TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String fallback = fallbackEnglishToSpanish(input);
            if (fallback != null && fallback.trim().length() > 0) polished = fallback;
        }
        // No mostramos el original ni una mezcla evidente como si fuera una traducción terminada.
        // En modo Vivo el cuadro conserva la última traducción fiable hasta la siguiente lectura válida.
        if (isSuspiciousResult(input, polished, sourceLanguage)) {
            // 1.28.4: antes de rendirse se busca una traducción conocida. Perder el subtítulo
            // entero es peor para el usuario que mostrar la versión del glosario o del diccionario.
            String rescued = rescueTranslation(input, sourceLanguage, cacheKey);
            if (rescued == null) {
                callback.onError("No se obtuvo una traducción suficientemente confiable.");
                return;
            }
            polished = rescued;
        }
        if (cacheKey != null) putCachedTranslation(cacheKey, polished);
        callback.onSuccess(input, polished, readable(sourceLanguage));
    }

    /**
     * Último recurso cuando el motor devuelve algo que no parece español válido.
     * Devuelve null solo si de verdad no hay nada fiable que mostrar.
     */
    private String rescueTranslation(String input, String sourceLanguage, String cacheKey) {
        String glossary = exactGlossaryTranslation(input, sourceLanguage);
        if (glossary != null && !glossary.trim().isEmpty()) return polishSpanish(glossary);

        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String direct = fallbackEnglishToSpanish(input);
            if (direct != null && !direct.trim().isEmpty()) return polishSpanish(direct);
        } else if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)
                || TranslateLanguage.KOREAN.equals(sourceLanguage)) {
            String direct = fallbackAsianToSpanish(input, sourceLanguage);
            if (direct == null) direct = fallbackAsianPhraseToSpanish(input, sourceLanguage);
            if (direct != null && !direct.trim().isEmpty()) return polishSpanish(direct);
        }

        String cached = getCachedTranslation(cacheKey);
        if (cached != null && !cached.trim().isEmpty()
                && !isSuspiciousResult(input, cached, sourceLanguage)) {
            return cached;
        }
        return null;
    }

    private String contextualSpanishCorrections(String original, String translated, String sourceLanguage) {
        if (translated == null) return "";
        String out = translated.trim();
        String sourceKey = normalizeKeyForLanguage(original, sourceLanguage);
        if (sourceKey.isEmpty()) return out;

        if (MODE_ENGLISH.equals(sourceLanguage)) {
            String englishKey = normalizeKey(original);
            // Solo coincidencia exacta: con contains() una oración más larga quedaba amputada.
            if (englishKey.equals("we ve been compromised") || englishKey.equals("we have been compromised")) {
                return "Nos han comprometido";
            }
            if (englishKey.equals("the pilot s a hitman") || englishKey.equals("the pilot is a hitman")) {
                return "El piloto es un sicario";
            }
            if (englishKey.contains("tiny little pieces")) {
                out = out.replaceAll("(?i)pequeñ[oa]s? piezas pequeñ[oa]s?", "pedacitos")
                        .replaceAll("(?i)pequeñ[oa]s? trozos pequeñ[oa]s?", "pedacitos");
            }
            if (englishKey.contains("shoot you down")) {
                out = out.replaceAll("(?i)dispararte abajo", "derribarte")
                        .replaceAll("(?i)dispararte hacia abajo", "derribarte");
            }
            if (englishKey.equals("occupational hazard")) return "Riesgo laboral";
            if (englishKey.equals("your neck okay") || englishKey.equals("is your neck okay")) {
                return "¿Tienes bien el cuello?";
            }
            // En diálogos policiales, "Deputy + apellido" suele ser agente/alguacil, no cargo político.
            if (englishKey.matches(".*\\bdeputy [a-z][a-z'-]+.*")
                    && !englishKey.matches(".*\\b(parliament|congress|minister|mayor|secretary|political)\\b.*")) {
                out = out.replaceFirst("(?i)^Diputad[oa]\\b", "Agente");
            }
        } else if (MODE_CHINESE.equals(sourceLanguage)) {
            if (sourceKey.contains("鸡皮疙瘩") || sourceKey.contains("雞皮疙瘩")) {
                out = out.replaceAll("(?i)piel de pollo", "piel de gallina");
            }
        }
        return polishSpanish(out);
    }

    private boolean isSuspiciousResult(String original, String translated, String sourceLanguage) {
        if (translated == null || translated.trim().isEmpty()) return true;
        if (looksUntranslated(original, translated)
                && !isAcceptableUnchangedTranslation(original, sourceLanguage)) return true;
        if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)
                || TranslateLanguage.KOREAN.equals(sourceLanguage)) {
            // Hasta 2 caracteres sueltos se dejan a la vista: suelen ser un nombre que el motor
            // no supo transcribir, y borrarlos escondería el fallo o partiría ese nombre.
            int leftovers = countMatches(cjkPattern, translated);
            return leftovers > 2 || (leftovers > 0 && countMatches(latinPattern, translated) < 4);
        }
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            int strongEnglish = countStrongEnglishWords(translated);
            int spanishSignals = countSpanishSignals(translated);
            return strongEnglish >= 2 && spanishSignals == 0;
        }
        return false;
    }

    private int countStrongEnglishWords(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "the","this","that","these","those","you","your","yours","he","she","they",
                "we","our","where","when","why","what","who","how","with","from","have","has",
                "had","will","would","could","should","were","was","are","does","did","doing",
                "think","know","want","need","good","right","please","sorry","home"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }

    private int countSpanishSignals(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "el","la","los","las","un","una","que","de","del","en","por","para","con",
                "como","qué","dónde","cuando","porque","estoy","está","son","eres","tengo","tiene",
                "quiero","puedo","casa","bien","gracias","pero","muy","ya","aquí","allí"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }


    private synchronized Translator getTranslator(String sourceLanguage) {
        if (activeTranslator != null && sourceLanguage.equals(activeTranslatorSource)) return activeTranslator;
        if (activeTranslator != null) {
            try { activeTranslator.close(); } catch (Exception ignored) { }
            activeTranslator = null;
        }
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguage)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        activeTranslator = Translation.getClient(options);
        activeTranslatorSource = sourceLanguage;
        return activeTranslator;
    }

    private String normalizeBeforeTranslate(String text, String sourceLanguage) {
        if (text == null) return "";
        String t = joinOcrLines(text, sourceLanguage);
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            t = repairEnglishOcr(t);
            t = normalizeExpressiveEnglish(t);
        } else if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)
                || TranslateLanguage.KOREAN.equals(sourceLanguage)) {
            t = sanitizeAsianDelimitersAndCues(t, sourceLanguage);
            t = normalizeAsianOcrText(t, sourceLanguage);
            t = normalizeAsianColloquialisms(t, sourceLanguage);
        }
        return t;
    }

    private String joinOcrLines(String text, String sourceLanguage) {
        if (text == null) return "";
        String[] lines = text.replace("\r", "").split("\n");
        StringBuilder out = new StringBuilder();
        boolean compactCjk = TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage);
        // 1.28.6: solo se descarta una línea repetida INMEDIATAMENTE antes (eco del OCR
        // sobre el mismo cartel). Antes se descartaba cualquier repetición del cartel
        // completo, y en un diálogo de dos personas con la misma frase ("- ¿Qué? / - ¿Qué?")
        // se perdía una mitad real del subtítulo.
        String previousKey = "";
        for (String line : lines) {
            String s = line == null ? "" : line.trim();
            if (s.length() == 0) continue;
            String key = normalizeKeyForLanguage(s, sourceLanguage);
            if (key.length() > 0 && key.equals(previousKey)) continue;
            previousKey = key;
            if (out.length() > 0 && !compactCjk) out.append(' ');
            out.append(s);
        }
        String joined = out.toString().replaceAll("[\t ]+", " ").trim();
        if (compactCjk) joined = joined.replaceAll("\\s+", "");
        return joined;
    }

    private String repairEnglishOcr(String text) {
        if (text == null) return "";
        String t = sanitizeSubtitleDelimitersAndCues(text.trim());
        t = stripCjkFromEnglish(t);
        // 1.28.6: separa palabras pegadas por el OCR, pero ya no rompe nombres propios.
        // Antes "McGregor" salía "Mc Gregor" e "iPhone" se convertía en "i Phone", y el
        // traductor recibía dos palabras inventadas.
        //
        // Se marca con un carácter de control el punto que NO debe partirse, se parte el
        // resto y se quita la marca. Así el prefijo queda pegado a su nombre.
        t = t.replaceAll("(?<![A-Za-z])([Mm]a?c)(?=[A-Z][a-z])", "$1\u0001");
        t = t.replaceAll("(?<![A-Za-z])([ieaxk])(?=[A-Z][a-z])", "$1\u0001");
        t = t.replaceAll("(?<=[a-z])(?=[A-Z])", " ");
        t = t.replace("\u0001", "");
        t = t.replace('’', '\'');
        t = normalizeConversationalEnglish(t);

        // Solo se conservan correcciones de confusiones OCR muy seguras. Las sustituciones
        // gramaticales agresivas se eliminaron porque podían cambiar palabras correctas.
        t = t.replaceAll("(?i)\\bschoo1\\b", "school");
        t = t.replaceAll("(?i)\\bmornlng\\b", "morning");
        t = t.replaceAll("(?i)\\bfinisbed\\b", "finished");
        t = t.replaceAll("(?i)\\bleam\\b", "learn");
        t = t.replaceAll("(?i)\\btomorow\\b", "tomorrow");
        t = t.replaceAll("(?i)\\bexacty\\b", "exactly");
        t = t.replaceAll("(?i)\\bmnan\\b", "man");
        t = t.replaceAll("(?i)\\bpeopie\\b", "people");
        t = t.replaceAll("(?i)\\bthls\\b", "this");
        t = t.replaceAll("(?i)\\bwlth\\b", "with");
        t = t.replaceAll("(?i)\\byou['’]?re\\b", "you're");
        t = t.replaceAll("(?i)\\bl['’]?m\\b", "I'm");

        // Reparaciones de inicio muy limitadas y de alta confianza observadas en subtítulos.
        t = t.replaceFirst("(?i)^[tl|]?decause\\b", "Because");
        t = t.replaceFirst("(?i)^[tl|]?because\\b", "Because");
        t = t.replaceFirst("(?i)^f?it['’]?s\\s+evening\\b", "It's evening");
        t = t.replaceFirst(
                "(?i)^[i1|]?so\\s+[l1|i]\\s+(?=(continued|walked|went|was|am|have|had|can|could|would|should|did|do|saw|heard|thought|knew|kept|started|decided|just)\\b)",
                "So I ");

        t = t.replaceAll("[.]{2,}", " ");
        t = t.replaceAll("[^A-Za-z0-9'.,?!:;\\- ]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    /**
     * Quita únicamente los delimitadores visuales del subtítulo y conserva el contenido,
     * incluidas las indicaciones sonoras/accesibles, para que también se traduzcan.
     */
    private String normalizeConversationalEnglish(String text) {
        if (text == null || text.isEmpty()) return "";
        String t = text;
        t = t.replaceAll("(?i)\\bimma\\b|\\bi['’]?ma\\b", "I'm going to");
        t = t.replaceAll("(?i)\\bgonna\\b", "going to");
        t = t.replaceAll("(?i)\\bwanna\\b", "want to");
        t = t.replaceAll("(?i)\\bgotta\\b", "have to");
        t = t.replaceAll("(?i)\\blemme\\b", "let me");
        t = t.replaceAll("(?i)\\bgimme\\b", "give me");
        t = t.replaceAll("(?i)\\bkinda\\b", "kind of");
        t = t.replaceAll("(?i)\\boutta\\b", "out of");
        t = t.replaceAll("(?i)\\bya\\b", "you");
        t = t.replaceAll("(?i)\\bI ain't\\b", "I am not");
        t = t.replaceAll("(?i)\\b(you|we|they) ain't\\b", "$1 are not");
        t = t.replaceAll("(?i)\\b(he|she|it) ain't\\b", "$1 is not");
        t = t.replaceAll("(?i)\\bthere ain't\\b", "there is not");
        String[][] droppedG = new String[][]{
                {"livin'", "living"}, {"goin'", "going"}, {"comin'", "coming"},
                {"doin'", "doing"}, {"gettin'", "getting"}, {"talkin'", "talking"},
                {"lookin'", "looking"}, {"thinkin'", "thinking"}, {"tryin'", "trying"},
                {"fightin'", "fighting"}, {"killin'", "killing"}, {"runnin'", "running"},
                {"workin'", "working"}, {"waitin'", "waiting"}, {"sayin'", "saying"},
                {"tellin'", "telling"}, {"makin'", "making"}, {"takin'", "taking"}
        };
        for (String[] pair : droppedG) {
            t = t.replaceAll("(?i)(?<![A-Za-z])" + Pattern.quote(pair[0]) + "(?![A-Za-z])", pair[1]);
        }
        return t;
    }

    private String sanitizeSubtitleDelimitersAndCues(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String t = text.replace('［', '[').replace('］', ']')
                .replace('（', '(').replace('）', ')')
                .replace('｛', '{').replace('｝', '}');
        t = stripLeadingSpeakerLabels(t);
        t = replaceBracketSegments(t, Pattern.compile("\\[([^\\[\\]]{1,80})\\]"));
        t = replaceBracketSegments(t, Pattern.compile("\\(([^()]{1,80})\\)"));
        t = replaceBracketSegments(t, Pattern.compile("\\{([^{}]{1,80})\\}"));
        t = t.replaceAll("[\\[\\](){}]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String stripLeadingSpeakerLabels(String text) {
        String t = text == null ? "" : text;
        Pattern leading = Pattern.compile("^\\s*\\[([^\\[\\]]{1,40})\\]\\s*");
        for (int i = 0; i < 2; i++) {
            Matcher matcher = leading.matcher(t);
            if (!matcher.find()) break;
            String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
            String trailing = t.substring(matcher.end()).trim();
            boolean cue = isSubtitleStageCue(inner);
            // Las acotaciones accesibles como [music] o [air whooshing] son contenido real
            // del subtítulo y deben conservarse para traducirse. Solo se retira una etiqueta
            // de hablante cuando hay diálogo después de ella.
            if (cue) break;
            if (!isLikelySpeakerLabel(inner) || trailing.isEmpty()) break;
            t = trailing;
        }
        return t;
    }

    private boolean isLikelySpeakerLabel(String text) {
        if (text == null) return false;
        String s = text.trim();
        if (s.isEmpty() || s.length() > 30) return false;
        if (s.matches(".*[.!?].*")) return false;
        String normalized = s.replaceAll("[^A-Za-z0-9' -]+", " ").replaceAll("\\s+", " ").trim();
        if (normalized.isEmpty()) return false;
        int words = normalized.split(" ").length;
        return words <= 4;
    }

    private String replaceBracketSegments(String text, Pattern pattern) {
        Matcher matcher = pattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
            // Conserva también descripciones de sonido/acción; ML Kit debe traducirlas.
            String replacement = " " + inner + " ";
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private boolean isSubtitleStageCue(String text) {
        if (text == null) return false;
        String cue = text.toLowerCase(Locale.ROOT)
                .replace('’', '\'')
                .replaceAll("[^a-z' ]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
        if (cue.isEmpty()) return true;
        int words = cue.split(" ").length;
        if (words > 7) return false;
        if (cue.matches("(soft |dramatic |background |upbeat |sad |tense )?music( playing| continues| fades| starts| stops)?")) return true;
        if (cue.matches("applause|laughter|laughs?|laughing|sighs?|sighing|gasps?|gasping|groans?|groaning|whispers?|whispering|screams?|screaming|cries|crying|sobs?|sobbing|chuckles?|chuckling|breathing|panting|footsteps|silence|inaudible|gunfire|gunshots?|shots?")) return true;
        if (cue.matches("(door|phone|bell|alarm|thunder|rain|wind|knock|knocking|gunshot|explosion|engine|drums?)( opens?| closes?| rings?| sounds?| continues?| fades?| stops?| starts?| roaring| rumbling| beating)?")) return true;
        return cue.matches(".*\\b(whoosh|whooshes|whooshing|whirring|buzzing|ringing|firing|shooting|beating|rumbling|roaring|crashing|crash|impact|exploding|grunting|grunts|yelling|shouting|screeching|creaking)\\b.*");
    }

    private String normalizeAsianOcrText(String text, String mode) {
        if (text == null) return "";
        String t = normalizeFullWidthAscii(text).replace('　', ' ').trim();
        t = t.replaceAll("^[>»›→▶▷]+\\s*", "");
        // El guion va al inicio de la clase para que Java no lo interprete como un rango.
        // La forma anterior (ー-\s) lanzaba PatternSyntaxException en los OCR asiáticos.
        t = t.replaceAll("^[-—―ー\\s]+", "");
        t = t.replaceAll("[·•･ㆍ]+", " ");
        t = t.replaceAll("([。！？!?，,、…])\\1+", "$1");
        t = t.replaceAll("\\s+", MODE_KOREAN.equals(mode) ? " " : "");

        // No se eliminan a ciegas fragmentos latinos cortos: pueden ser nombres, siglas
        // o términos reales como AI/3D dentro de subtítulos asiáticos. El filtrado visual
        // y por escritura ya se realiza antes, en la selección de líneas OCR.
        return t.trim();
    }

    private String normalizeFullWidthAscii(String text) {
        if (text == null || text.isEmpty()) return "";
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= '\uFF01' && c <= '\uFF5E') c = (char) (c - 0xFEE0);
            out.append(c);
        }
        return out.toString();
    }

    private String sanitizeAsianDelimitersAndCues(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return "";
        String t = text.replace('［', '[').replace('］', ']')
                .replace('【', '[').replace('】', ']')
                .replace('（', '(').replace('）', ')')
                .replace('｛', '{').replace('｝', '}');
        t = stripLeadingAsianSpeakerLabels(t, mode);
        t = replaceAsianBracketSegments(t, Pattern.compile("\\[([^\\[\\]]{1,80})\\]"), mode);
        t = replaceAsianBracketSegments(t, Pattern.compile("\\(([^()]{1,80})\\)"), mode);
        t = replaceAsianBracketSegments(t, Pattern.compile("\\{([^{}]{1,80})\\}"), mode);
        t = t.replaceAll("[\\[\\](){}]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String stripLeadingAsianSpeakerLabels(String text, String mode) {
        String t = text == null ? "" : text;
        // Anime, donghua y dramas usan con frecuencia [Nombre], 【Nombre】 o （Nombre）.
        Pattern leading = Pattern.compile("^\\s*[\\[【（(]([^\\]】）)]{1,24})[\\]】）)]\\s*");
        Matcher matcher = leading.matcher(t);
        if (!matcher.find()) return t;
        String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
        String trailing = t.substring(matcher.end()).trim();
        boolean cue = isAsianStageCue(inner, mode);
        boolean likelySpeaker = inner.length() <= 12
                && !inner.matches(".*[。！？!?，,、…].*");
        // Conservar indicaciones de sonido/acción en japonés, chino y coreano.
        if (cue) return t;
        if (likelySpeaker && !trailing.isEmpty()) return trailing;
        return t;
    }

    private String replaceAsianBracketSegments(String text, Pattern pattern, String mode) {
        Matcher matcher = pattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
            // Las descripciones sonoras son parte del subtítulo y también se traducen.
            String replacement = " " + inner + " ";
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private boolean isAsianStageCue(String text, String mode) {
        if (text == null) return false;
        String cue = text.replaceAll("\\s+", "").trim();
        if (cue.isEmpty()) return true;
        if (MODE_JAPANESE.equals(mode)) {
            return cue.matches("音楽|笑|笑い|笑い声|拍手|ため息|泣き声|足音|雨音|風の音|雷|悲鳴|叫び声|息切れ|銃声|爆発音|衝撃音|ドアの音|聞き取れない");
        }
        if (MODE_CHINESE.equals(mode)) {
            return cue.matches("音乐|笑|笑声|掌声|叹气|哭声|脚步声|雨声|风声|雷声|尖叫|尖叫声|喘息|枪声|爆炸声|撞击声|开门声|关门声|听不清");
        }
        if (MODE_KOREAN.equals(mode)) {
            return cue.matches("음악|웃음|웃음소리|박수|한숨|울음|발소리|빗소리|바람소리|천둥|비명|고함|숨소리|총성|폭발음|충격음|문소리|알아들을수없음");
        }
        return false;
    }

    private String normalizeAsianColloquialisms(String text, String mode) {
        if (text == null) return "";
        String t = text.trim();
        // No reescribimos jerga ambigua dentro de frases completas. Solo normalizamos
        // formas coloquiales japonesas de alta confianza para que ML Kit reciba una forma
        // estándar sin cambiar el significado.
        if (MODE_JAPANESE.equals(mode)) {
            t = t.replaceAll("がんばろ[ー〜～]+ね[ー〜～]*", "がんばろうね");
            t = t.replaceAll("頑張ろ[ー〜～]+ね[ー〜～]*", "頑張ろうね");
            t = t.replaceAll("行こ[ー〜～]+", "行こう");
            t = t.replaceAll("しよ[ー〜～]+", "しよう");
            t = t.replaceAll("やろ[ー〜～]+", "やろう");
            // Katakana + ら suele ser un plural coloquial de personas/grupos. Cambiar ら por
            // たち ayuda a evitar salidas tipo “et al.” sin tocar el nombre en katakana.
            t = t.replaceAll("([ァ-ヺー]{2,})ら(?=($|[はがをにとでへ、。！？!?]))", "$1たち");
        }
        return t;
    }

    private String fallbackAsianPhraseToSpanish(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return null;
        String key = normalizeKeyForLanguage(text.trim(), mode);
        if (MODE_JAPANESE.equals(mode)) {
            // Casos de regresión exactos observados en anime/letras: solo coincidencia completa.
            if (key.equals("まだ止めないでまだ止めないで")) return "No te detengas todavía";
            if (key.equals("走って転んで")) return "Corre y cae";
            if (key.equals("世界が待ってるこの一瞬を")) return "El mundo está esperando este momento";
            if (key.equals("命を投げ出さないで")) return "No desperdicies tu vida";
            if (key.equals("どんな顔すればいいかわかんないよ")) return "No sé qué cara poner";
            if (key.equals("マジで") || key.equals("マジ")) return "¿En serio?";
            if (key.equals("すげえ") || key.equals("すげー") || key.equals("すごい")) return "Increíble";
            if (key.equals("ムカつく")) return "Me enfada";
            if (key.equals("うざい")) return "Qué molesto";
            if (key.equals("なんでだよ") || key.equals("なんで")) return "¿Por qué?";
            if (key.equals("どうした") || key.equals("どうしたの")) return "¿Qué pasó?";
            if (key.equals("何してる") || key.equals("何してるの") || key.equals("何をしてるの")) return "¿Qué estás haciendo?";
            if (key.equals("知らない") || key.equals("わからない") || key.equals("分からない")) return "No lo sé";
            if (key.equals("心配するな") || key.equals("心配しないで")) return "No te preocupes";
            if (key.equals("信じて") || key.equals("俺を信じろ") || key.equals("私を信じて")) return "Confía en mí";
            if (key.equals("任せて") || key.equals("任せろ")) return "Déjamelo a mí";
            if (key.equals("頑張って") || key.equals("がんばって")) return "Ánimo";
            if (key.equals("急いで") || key.equals("早くして")) return "Date prisa";
            if (key.equals("ただいま")) return "Ya llegué";
            if (key.equals("おかえり") || key.equals("おかえりなさい")) return "Bienvenido a casa";
            if (key.equals("まさか")) return "No puede ser";
            if (key.equals("了解") || key.equals("了解した")) return "Entendido";
            if (key.equals("ちょっと待って") || key.equals("ちょっと待て")) return "Espera un momento";
            if (key.equals("逃げろ") || key.equals("逃げて")) return "¡Huye!";
            if (key.equals("動くな") || key.equals("動かないで")) return "No te muevas";
            if (key.equals("離せ") || key.equals("離して")) return "Suéltame";
            if (key.equals("ついて来い") || key.equals("ついてきて")) return "Sígueme";
            if (key.equals("誰だ") || key.equals("お前は誰だ")) return "¿Quién eres?";
            if (key.equals("何言ってる") || key.equals("何を言ってる")) return "¿Qué estás diciendo?";
            if (key.equals("気にするな") || key.equals("気にしないで")) return "No te preocupes";
            if (key.equals("ふざけるな")) return "No juegues conmigo";
            if (key.equals("頑張れ") || key.equals("がんばれ")) return "¡Ánimo!";
            if (key.equals("起きろ") || key.equals("起きて")) return "Despierta";
            if (key.equals("伏せろ") || key.equals("伏せて")) return "¡Agáchate!";
            if (key.equals("行くぞ")) return "Vamos";
            if (key.equals("いってきます")) return "Ya me voy";
            if (key.equals("いってらっしゃい")) return "Que te vaya bien";
            if (key.equals("がんばろうね") || key.equals("頑張ろうね")) return "Vamos a dar lo mejor de nosotros";
            if (key.equals("ここにいて") || key.equals("そばにいて")) return "Quédate conmigo";
            if (key.equals("絶対に許さない")) return "Nunca te perdonaré";
            if (key.equals("もう大丈夫")) return "Ya está bien";
            // やばい no se fuerza: puede ser negativo o positivo según el contexto.
        } else if (MODE_CHINESE.equals(mode)) {
            if (key.equals("我鸡皮疙瘩都掉一地") || key.equals("我雞皮疙瘩都掉一地")) return "Se me puso la piel de gallina";
            if (key.equals("师父") || key.equals("師父")) return "Maestro";
            if (key.equals("刚来刚来") || key.equals("剛來剛來")) return "Acabo de llegar";
            if (key.equals("放心我什么都没听见") || key.equals("放心我什麼都沒聽見")) return "Tranquilo, no escuché nada";
            if (key.equals("现在不是吵架的时候") || key.equals("現在不是吵架的時候")) return "Ahora no es momento de discutir";
            if (key.equals("咋回事") || key.equals("怎么回事")) return "¿Qué pasó?";
            if (key.equals("啥") || key.equals("什么")) return "¿Qué?";
            if (key.equals("牛逼")) return "Increíble";
            if (key.equals("卧槽")) return "Dios mío";
            if (key.equals("给力")) return "Genial";
            if (key.equals("没门")) return "Ni hablar";
            if (key.equals("坑爹")) return "Qué desastre";
            if (key.equals("不是吧") || key.equals("不会吧")) return "No puede ser";
            if (key.equals("怎么了") || key.equals("发生什么了")) return "¿Qué pasó?";
            if (key.equals("你在干什么") || key.equals("你干什么呢")) return "¿Qué estás haciendo?";
            if (key.equals("我不知道") || key.equals("不知道")) return "No lo sé";
            if (key.equals("别担心") || key.equals("不用担心")) return "No te preocupes";
            if (key.equals("相信我")) return "Confía en mí";
            if (key.equals("交给我") || key.equals("让我来")) return "Déjamelo a mí";
            if (key.equals("快点") || key.equals("快一点")) return "Date prisa";
            if (key.equals("你没事吧") || key.equals("你还好吗")) return "¿Estás bien?";
            if (key.equals("快跑") || key.equals("快逃")) return "¡Corre!";
            if (key.equals("别动")) return "No te muevas";
            if (key.equals("放开我") || key.equals("放手")) return "Suéltame";
            if (key.equals("跟我来") || key.equals("跟着我")) return "Sígueme";
            if (key.equals("你是谁") || key.equals("你到底是谁")) return "¿Quién eres?";
            if (key.equals("我没事") || key.equals("我很好")) return "Estoy bien";
            if (key.equals("你说什么") || key.equals("你说啥")) return "¿Qué dijiste?";
            if (key.equals("我不相信") || key.equals("不可能")) return "No lo creo";
            if (key.equals("别怕") || key.equals("不要怕")) return "No tengas miedo";
            if (key.equals("安静") || key.equals("小声点")) return "Silencio";
            if (key.equals("醒醒") || key.equals("快醒醒")) return "Despierta";
            if (key.equals("起来") || key.equals("快起来")) return "Levántate";
            if (key.equals("加油")) return "¡Ánimo!";
            if (key.equals("我回来了")) return "He vuelto";
            if (key.equals("我爱你")) return "Te quiero";
            if (key.equals("师父")) return "Maestro";
            if (key.equals("刚来") || key.equals("刚来刚来")) return "Acabo de llegar";
            if (key.equals("放心我什么都没听见") || key.equals("放心我什么也没听见")) return "Tranquilo, no escuché nada";
            if (key.equals("我才不怕呢") || key.equals("我才不怕")) return "No tengo miedo";
            if (key.equals("我鸡皮疙瘩都掉一地") || key.equals("鸡皮疙瘩都起来了")) return "Se me puso la piel de gallina";
            if (key.equals("你什么时候走过来的") || key.equals("你什么时候过来的")) return "¿Cuándo llegaste?";
            if (key.equals("师父这回玩大了") || key.equals("师父这次玩大了")) return "Maestro, esta vez se pasó";
            if (key.equals("这小东西想要我的命") || key.equals("这个小东西想要我的命")) return "Esta cosita quiere matarme";
            if (key.equals("别走")) return "No te vayas";
            if (key.equals("跟紧我")) return "No te separes de mí";
        } else if (MODE_KOREAN.equals(mode)) {
            if (key.equals("돈은넉넉하니까얼마든지다시시작할수있어")) return "Tengo dinero de sobra, así que puedo volver a empezar cuando quiera";
            if (key.equals("결국또실패할거야")) return "Al final volverás a fracasar";
            if (key.equals("성공하면돼성공")) return "Solo tienes que tener éxito. ¿Éxito?";
            if (key.equals("넌실패한도망자일뿐이야")) return "Solo eres un fugitivo fracasado";
            if (key.equals("모두버린거야")) return "Lo tiraste todo por la borda";
            if (key.equals("대박")) return "Increíble";
            if (key.equals("헐")) return "No puede ser";
            if (key.equals("짱")) return "Lo máximo";
            if (key.equals("빡쳐") || key.equals("열받아")) return "Estoy enfadado";
            if (key.equals("개웃겨")) return "Qué risa";
            if (key.equals("노잼")) return "Aburrido";
            if (key.equals("꿀잼")) return "Muy divertido";
            if (key.equals("진짜")) return "De verdad";
            if (key.equals("뭐야")) return "¿Qué es eso?";
            if (key.equals("무슨일이야")) return "¿Qué pasó?";
            if (key.equals("뭐하는거야") || key.equals("뭐하고있어")) return "¿Qué estás haciendo?";
            if (key.equals("모르겠어") || key.equals("몰라")) return "No lo sé";
            if (key.equals("걱정마") || key.equals("걱정하지마")) return "No te preocupes";
            if (key.equals("날믿어") || key.equals("나를믿어")) return "Confía en mí";
            if (key.equals("나한테맡겨") || key.equals("내가할게")) return "Déjamelo a mí";
            if (key.equals("빨리와") || key.equals("서둘러")) return "Date prisa";
            if (key.equals("괜찮니")) return "¿Estás bien?";
            if (key.equals("도망쳐") || key.equals("도망가")) return "¡Corre!";
            if (key.equals("움직이지마") || key.equals("움직이지마라")) return "No te muevas";
            if (key.equals("놔줘") || key.equals("놓아줘")) return "Suéltame";
            if (key.equals("따라와")) return "Sígueme";
            if (key.equals("너누구야") || key.equals("넌누구야")) return "¿Quién eres?";
            if (key.equals("난괜찮아") || key.equals("나괜찮아")) return "Estoy bien";
            if (key.equals("뭐라고") || key.equals("뭐라고했어")) return "¿Qué dijiste?";
            if (key.equals("믿을수없어") || key.equals("말도안돼")) return "No lo puedo creer";
            if (key.equals("무서워하지마")) return "No tengas miedo";
            if (key.equals("조용히") || key.equals("조용히해")) return "Silencio";
            if (key.equals("일어나") || key.equals("일어나봐")) return "Despierta";
            if (key.equals("힘내")) return "¡Ánimo!";
            if (key.equals("돌아와")) return "Vuelve";
            if (key.equals("사랑해")) return "Te quiero";
            if (key.equals("가지마") || key.equals("가지마요")) return "No te vayas";
            if (key.equals("내옆에있어") || key.equals("곁에있어")) return "Quédate conmigo";
            if (key.equals("절대용서못해")) return "Nunca te perdonaré";
            if (key.equals("이제괜찮아")) return "Ya está bien";
        }
        return null;
    }

    private String fallbackAsianStageCueToSpanish(String key, String mode) {
        if (key == null || key.isEmpty()) return null;
        if (MODE_JAPANESE.equals(mode)) {
            if (key.equals("音楽")) return "[Música]";
            if (key.equals("拍手")) return "[Aplausos]";
            if (key.equals("笑") || key.equals("笑い") || key.equals("笑い声")) return "[Risas]";
            if (key.equals("ため息")) return "[Suspiro]";
            if (key.equals("悲鳴") || key.equals("叫び声")) return "[Gritos]";
            if (key.equals("足音")) return "[Pasos]";
            if (key.equals("雨音")) return "[Lluvia]";
            if (key.equals("風の音")) return "[Viento]";
            if (key.equals("雷")) return "[Trueno]";
            if (key.equals("銃声")) return "[Disparos]";
            if (key.equals("爆発音")) return "[Explosión]";
            if (key.equals("泣き声")) return "[Llanto]";
            if (key.equals("息切れ")) return "[Jadeos]";
            if (key.equals("聞き取れない")) return "[Inaudible]";
            if (key.equals("www") || key.equals("ｗｗｗ")) return "[Risas]";
        } else if (MODE_CHINESE.equals(mode)) {
            if (key.equals("音乐")) return "[Música]";
            if (key.equals("掌声")) return "[Aplausos]";
            if (key.equals("笑") || key.equals("笑声")) return "[Risas]";
            if (key.equals("叹气")) return "[Suspiro]";
            if (key.equals("尖叫") || key.equals("尖叫声")) return "[Gritos]";
            if (key.equals("脚步声")) return "[Pasos]";
            if (key.equals("雨声")) return "[Lluvia]";
            if (key.equals("风声")) return "[Viento]";
            if (key.equals("雷声")) return "[Trueno]";
            if (key.equals("枪声")) return "[Disparos]";
            if (key.equals("爆炸声")) return "[Explosión]";
            if (key.equals("哭声")) return "[Llanto]";
            if (key.equals("喘息")) return "[Jadeos]";
            if (key.equals("听不清")) return "[Inaudible]";
            if (key.equals("哈哈") || key.equals("哈哈哈") || key.equals("哈哈哈哈")) return "[Risas]";
        } else if (MODE_KOREAN.equals(mode)) {
            if (key.equals("음악")) return "[Música]";
            if (key.equals("박수")) return "[Aplausos]";
            if (key.equals("웃음") || key.equals("웃음소리")) return "[Risas]";
            if (key.equals("한숨")) return "[Suspiro]";
            if (key.equals("비명") || key.equals("고함")) return "[Gritos]";
            if (key.equals("발소리")) return "[Pasos]";
            if (key.equals("빗소리")) return "[Lluvia]";
            if (key.equals("바람소리")) return "[Viento]";
            if (key.equals("천둥")) return "[Trueno]";
            if (key.equals("총성")) return "[Disparos]";
            if (key.equals("폭발음")) return "[Explosión]";
            if (key.equals("울음")) return "[Llanto]";
            if (key.equals("숨소리")) return "[Jadeos]";
            if (key.equals("알아들을수없음")) return "[Inaudible]";
            if (key.equals("ㅋㅋ") || key.equals("ㅋㅋㅋ") || key.equals("ㅎㅎ") || key.equals("ㅎㅎㅎ")) return "[Risas]";
        }
        return null;
    }

    private String fallbackAsianToSpanish(String text, String mode) {
        String key = normalizeKeyForLanguage(text, mode);
        String stageCue = fallbackAsianStageCueToSpanish(key, mode);
        if (stageCue != null) return stageCue;
        if (MODE_JAPANESE.equals(mode)) {
            if (key.equals("え") || key.equals("あ")) return key.equals("え") ? "¿Eh?" : "Ah";
            if (key.equals("うん") || key.equals("はい")) return "Sí";
            if (key.equals("いや")) return "No";
            if (key.equals("何")) return "¿Qué?";
            if (key.equals("誰")) return "¿Quién?";
            if (key.equals("嘘")) return "No puede ser";
            if (key.equals("こんにちは")) return "Hola";
            if (key.equals("ありがとう") || key.equals("ありがとうございます")) return "Gracias";
            if (key.equals("おはよう") || key.equals("おはようございます")) return "Buenos días";
            if (key.equals("こんばんは")) return "Buenas noches";
            if (key.equals("ごめん") || key.equals("ごめんなさい")) return "Lo siento";
            if (key.equals("すみません")) return "Disculpe";
            if (key.equals("本当に")) return "¿En serio?";
            if (key.equals("待って")) return "Espera";
            if (key.equals("行け")) return "Ve";
            if (key.equals("行こう")) return "Vamos";
            if (key.equals("やめろ") || key.equals("やめて")) return "Detente";
            if (key.equals("助けて")) return "Ayúdame";
            if (key.equals("大丈夫")) return "Está bien";
            if (key.equals("分かった") || key.equals("わかった")) return "Entendido";
            if (key.equals("気をつけて")) return "Cuidado";
        } else if (MODE_CHINESE.equals(mode)) {
            if (key.equals("嗯")) return "Sí";
            if (key.equals("啊")) return "Ah";
            if (key.equals("哦")) return "Oh";
            if (key.equals("喂")) return "¿Hola?";
            if (key.equals("好")) return "Bien";
            if (key.equals("不") || key.equals("没")) return "No";
            if (key.equals("停")) return "Alto";
            if (key.equals("谁")) return "¿Quién?";
            if (key.equals("啥")) return "¿Qué?";
            if (key.equals("我")) return "Yo";
            if (key.equals("你")) return "Tú";
            if (key.equals("你好")) return "Hola";
            if (key.equals("谢谢") || key.equals("多谢")) return "Gracias";
            if (key.equals("早上好")) return "Buenos días";
            if (key.equals("晚上好")) return "Buenas noches";
            if (key.equals("对不起")) return "Lo siento";
            if (key.equals("没关系")) return "No pasa nada";
            if (key.equals("再见")) return "Adiós";
            if (key.equals("真的吗")) return "¿De verdad?";
            if (key.equals("等等") || key.equals("等一下")) return "Espera";
            if (key.equals("快走") || key.equals("走吧")) return "Vamos";
            if (key.equals("住手")) return "Detente";
            if (key.equals("救命")) return "Ayuda";
            if (key.equals("小心")) return "Cuidado";
            if (key.equals("没事")) return "Está bien";
            if (key.equals("知道了") || key.equals("明白了")) return "Entendido";
            if (key.equals("不要") || key.equals("不行")) return "No";
        } else if (MODE_KOREAN.equals(mode)) {
            if (key.equals("네") || key.equals("응")) return "Sí";
            if (key.equals("아니")) return "No";
            if (key.equals("왜")) return "¿Por qué?";
            if (key.equals("뭐")) return "¿Qué?";
            if (key.equals("야")) return "Oye";
            if (key.equals("와")) return "Guau";
            if (key.equals("헐")) return "No puede ser";
            if (key.equals("아")) return "Ah";
            if (key.equals("안녕하세요")) return "Hola";
            if (key.equals("고마워") || key.equals("감사합니다")) return "Gracias";
            if (key.equals("미안해") || key.equals("죄송합니다")) return "Lo siento";
            if (key.equals("안녕")) return "Hola";
            if (key.equals("잘자")) return "Buenas noches";
            if (key.equals("정말대단해")) return "Increíble";
            if (key.equals("세상에")) return "No puede ser";
            if (key.equals("잠깐") || key.equals("기다려")) return "Espera";
            if (key.equals("가자")) return "Vamos";
            if (key.equals("멈춰")) return "Detente";
            if (key.equals("도와줘") || key.equals("살려줘")) return "Ayúdame";
            if (key.equals("조심해")) return "Cuidado";
            if (key.equals("괜찮아")) return "Está bien";
            if (key.equals("알았어")) return "Entendido";
            if (key.equals("안돼")) return "No";
            if (key.equals("하지마")) return "No lo hagas";
        }
        return null;
    }

    private String normalizeExpressiveEnglish(String text) {
        if (text == null || text.length() == 0) return "";
        Matcher matcher = expressiveWordPattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String original = matcher.group();
            String replacement = normalizeExpressiveWord(original);
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private String normalizeExpressiveWord(String word) {
        if (word == null || word.length() < 3 || !hasRunOfThree(word)) return word;
        String lower = word.toLowerCase(Locale.ROOT);
        String maxTwo = collapseRuns(lower, 2);
        String selected = EXPRESSIVE_DICTIONARY.contains(maxTwo) ? maxTwo : findDictionaryVariant(maxTwo, 0, new StringBuilder());
        if (selected == null) selected = maxTwo;
        if (word.equals(word.toUpperCase(Locale.ROOT))) return selected.toUpperCase(Locale.ROOT);
        if (Character.isUpperCase(word.charAt(0))) {
            return Character.toUpperCase(selected.charAt(0)) + selected.substring(1);
        }
        return selected;
    }

    private boolean hasRunOfThree(String word) {
        int run = 1;
        for (int i = 1; i < word.length(); i++) {
            if (Character.toLowerCase(word.charAt(i)) == Character.toLowerCase(word.charAt(i - 1))) {
                run++;
                if (run >= 3) return true;
            } else {
                run = 1;
            }
        }
        return false;
    }

    private String collapseRuns(String word, int maxRun) {
        StringBuilder out = new StringBuilder(word.length());
        char previous = 0;
        int run = 0;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c == previous) {
                run++;
            } else {
                previous = c;
                run = 1;
            }
            if (run <= maxRun) out.append(c);
        }
        return out.toString();
    }

    private String findDictionaryVariant(String word, int index, StringBuilder built) {
        if (index >= word.length()) {
            String candidate = built.toString();
            return EXPRESSIVE_DICTIONARY.contains(candidate) ? candidate : null;
        }
        char c = word.charAt(index);
        int end = index + 1;
        while (end < word.length() && word.charAt(end) == c) end++;
        int runLength = end - index;
        int originalLength = built.length();

        for (int i = 0; i < runLength; i++) built.append(c);
        String keep = findDictionaryVariant(word, end, built);
        if (keep != null) return keep;
        built.setLength(originalLength);

        if (runLength == 2) {
            built.append(c);
            String reduced = findDictionaryVariant(word, end, built);
            if (reduced != null) return reduced;
            built.setLength(originalLength);
        }
        return null;
    }

    private String stripCjkFromEnglish(String text) {
        if (text == null) return "";
        String t = text;
        // Quita traducciones chinas/japonesas/coreanas entre paréntesis para no contaminar el inglés.
        t = t.replaceAll("\\([^)]*[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF][^)]*\\)", " ");
        t = t.replaceAll("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]+", " ");
        return t;
    }

    private String cleanEnglishLine(String line) {
        if (line == null) return "";
        String s = normalizeExpressiveEnglish(repairEnglishOcr(line));
        s = s.replaceAll("^[^A-Za-z0-9]+", "");
        s = s.replaceAll("[^A-Za-z0-9.?!']+$", "");
        s = s.replaceAll("\\s+", " ").trim();
        return trimEnglishOcrNoise(s);
    }

    /**
     * Recorta basura corta que el OCR latino inventa al intentar leer caracteres chinos.
     * Es una operacion local y rapida: no espera otra captura ni consulta otro modelo.
     */
    private String trimEnglishOcrNoise(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String[] tokens = text.trim().split("\\s+");
        int start = 0;
        int end = tokens.length;
        while (start < end && isSuspiciousOcrToken(tokens[start])) start++;
        while (end > start && isSuspiciousOcrToken(tokens[end - 1])) end--;
        if (start >= end) return "";

        StringBuilder out = new StringBuilder();
        int badRun = 0;
        int goodCount = 0;
        for (int i = start; i < end; i++) {
            String token = tokens[i];
            boolean bad = isSuspiciousOcrToken(token);
            if (bad) {
                badRun++;
                if (goodCount >= 2 && badRun >= 2) break;
            } else {
                badRun = 0;
                goodCount++;
            }
            if (out.length() > 0) out.append(' ');
            out.append(token);
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    private boolean isSuspiciousOcrToken(String token) {
        if (token == null) return true;
        String raw = token.replaceAll("^[^A-Za-z0-9']+|[^A-Za-z0-9']+$", "");
        if (raw.isEmpty()) return true;
        // Números, edades, fechas y modelos son información real del subtítulo: no se eliminan.
        if (raw.matches("\\d+(?:[.,:/-]\\d+)*")) return false;
        if (raw.matches("(?i)(?:[A-Za-z]+\\d+[A-Za-z0-9]*|\\d+[A-Za-z]+[A-Za-z0-9]*)")) return false;
        String lower = raw.toLowerCase(Locale.ROOT).replace("'", "");
        if (lower.equals("a") || lower.equals("i")) return false;
        String commonShort = " ok hi yes no go why who how hey wow bye not the you me my we us he she her him our your his its mr ms dr ";
        if (commonShort.contains(" " + lower + " ")) return false;
        String contractions = " im ive ill id youre hes shes theyre were dont didnt doesnt cant wont isnt arent wasnt werent thats whats wheres whos lets ";
        if (contractions.contains(" " + lower + " ")) return false;
        if (lower.length() <= 2) {
            String allowed = " am an as at be by do go he if in is it me my no of oh on or so to up us we ";
            return !allowed.contains(" " + lower + " ");
        }
        if (lower.length() >= 4 && !lower.matches(".*[aeiouy].*")) return true;
        // Siglas comunes pueden ser parte del diálogo (FBI, CIA, AI, 3D, etc.).
        if (raw.equals(raw.toUpperCase(Locale.ROOT)) && raw.length() <= 3) {
            return !(raw.equals("FBI") || raw.equals("CIA") || raw.equals("AI") || raw.equals("TV") || raw.equals("USA"));
        }
        return false;
    }

    private boolean isValidShortEnglishSubtitle(String text) {
        if (text == null) return false;
        String key = normalizeKey(text);
        return SHORT_ENGLISH_SUBTITLES.contains(key);
    }

    private boolean isGoodEnglishLine(String s) {
        if (s == null) return false;
        if (isValidShortEnglishSubtitle(s)) return true;
        String key = normalizeKey(s);
        if (key.length() < 2) return false;
        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        boolean sentenceMark = s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",") || s.contains("'");
        if (words == 1 && common > 0 && key.length() >= 2) return true;
        if (words >= 6 && (common > 0 || sentenceMark)) return true;
        if (words >= 2 && common > 0) return true;
        return key.equals("at home") || key.equals("thank you");
    }

    private int scoreEnglishLine(String s) {
        if (s == null) return -9999;
        String k = normalizeKey(s);
        if (isValidShortEnglishSubtitle(s)) return 125 + Math.min(40, s.trim().length() * 5);
        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        int score = Math.min(s.length(), 120) + words * 14 + common * 26;
        if (s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",")) score += 14;
        if (words <= 2 && common == 0) score -= 80;
        if (isLikelySpanishLine(s)) score -= 180;
        return score;
    }

    private boolean isBadEnglishFalsePositive(String s) {
        if (s == null) return true;
        if (isValidShortEnglishSubtitle(s)) return false;
        String k = normalizeKey(s);
        if (k.length() == 0) return true;

        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        boolean hasSentenceMark = s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",") || s.contains("'");
        boolean looksLikeTitle = words <= 3 && common == 0 && !s.matches(".*[a-z].*[a-z].*");
        boolean tooShortWithoutContext = words <= 2 && common == 0;
        return looksLikeTitle || (tooShortWithoutContext && !hasSentenceMark);
    }

    private int commonEnglishWordScore(String s) {
        return countVocabularyWords(s);
    }

    private int countVocabularyWords(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        Matcher matcher = Pattern.compile("[A-Za-z']+").matcher(text.toLowerCase(Locale.ROOT));
        int count = 0;
        while (matcher.find()) {
            String word = matcher.group().replace("'", "");
            if (isVocabularyWord(word)) count++;
        }
        return count;
    }

    private boolean isVocabularyWord(String word) {
        if (word == null || word.isEmpty()) return false;
        if (word.equals("a") || word.equals("i")) return true;
        if (word.length() < 2) return false;
        if (englishVocabulary.contains(word)) return true;
        if (word.endsWith("s") && word.length() > 3 && englishVocabulary.contains(word.substring(0, word.length() - 1))) return true;
        if (word.endsWith("ed") && word.length() > 4) {
            String root = word.substring(0, word.length() - 2);
            if (englishVocabulary.contains(root) || englishVocabulary.contains(root + "e")) return true;
        }
        if (word.endsWith("ing") && word.length() > 5) {
            String root = word.substring(0, word.length() - 3);
            if (englishVocabulary.contains(root) || englishVocabulary.contains(root + "e")) return true;
        }
        return false;
    }

    private void loadEnglishVocabulary() {
        englishVocabulary.addAll(EXPRESSIVE_DICTIONARY);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                appContext.getAssets().open("english_ocr_vocabulary.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String word = line.trim().toLowerCase(Locale.ROOT);
                if (!word.isEmpty()) englishVocabulary.add(word);
            }
        } catch (Exception ignored) {
            // La app sigue funcionando con el vocabulario básico incorporado.
        }
    }

    private boolean isLikelySpanishLine(String s) {
        if (s == null) return false;
        String k = normalizeKey(s);
        return s.contains("¿") || s.contains("¡")
                || k.contains(" que ")
                || k.startsWith("que ")
                || k.contains(" donde ")
                || k.contains(" dónde ")
                || k.contains(" esta ")
                || k.contains(" está ")
                || k.contains(" ropa")
                || k.contains(" mama")
                || k.contains(" mamá")
                || k.contains(" nada")
                || k.contains(" casa")
                || k.contains(" fing");
    }

    private int countEnglishWords(String s) {
        if (s == null) return 0;
        java.util.regex.Matcher m = Pattern.compile("[A-Za-z]+").matcher(s);
        int count = 0;
        while (m.find()) count++;
        return count;
    }

    private String cleanCjkLine(String line, String mode) {
        if (line == null) return "";
        String s = line.replace('　', ' ').trim();
        // Marcadores visuales de diálogo no forman parte del contenido lingüístico.
        s = s.replaceAll("^[>»›→▶▷]+\\s*", "");
        s = sanitizeAsianDelimitersAndCues(s, mode);
        if (MODE_CHINESE.equals(mode)) {
            s = s.replaceAll("[\u3040-\u30FF\uAC00-\uD7AF]+", " ");
        } else if (MODE_JAPANESE.equals(mode)) {
            s = s.replaceAll("[\uAC00-\uD7AF]+", " ");
        } else if (MODE_KOREAN.equals(mode)) {
            s = s.replaceAll("[\u3040-\u30FF]+", " ");
        }
        if (isMostlyLatinLine(s, mode)) return "";
        // Letra suelta separada del texto: resto del OCR, no un término como "T恤" o "X光".
        s = s.replaceAll("^[A-Za-z]\\s+(?=[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF])", "");
        s = stripLatinTranscriptNoise(s, mode);
        s = s.replaceAll("\\s+", " ").trim();
        return hasEnoughScriptForMode(s, mode) ? s : "";
    }

    /** Subtítulo bilingüe: la línea en español o inglés no debe colarse en la entrada asiática. */
    private boolean isMostlyLatinLine(String text, String mode) {
        int latin = countMatches(latinPattern, text);
        if (latin < 6) return false;
        int target = MODE_KOREAN.equals(mode)
                ? countMatches(koreanPattern, text)
                : countMatches(chinesePattern, text) + countMatches(japanesePattern, text);
        return latin > target * 2;
    }

    private String stripLatinTranscriptNoise(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return "";
        if (!(MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode))) {
            return text;
        }
        int targetScript = MODE_KOREAN.equals(mode)
                ? countMatches(koreanPattern, text)
                : countMatches(chinesePattern, text) + countMatches(japanesePattern, text);
        if (targetScript < 3) return text;

        Matcher latinWords = Pattern.compile("[A-Za-z][A-Za-z'’-]{2,}").matcher(text);
        int longLatinWords = 0;
        while (latinWords.find()) longLatinWords++;
        if (longLatinWords < 2) return text;

        // Cuando el OCR pega una pista romaji/inglesa a una línea CJK/Coreana, quitamos
        // solo palabras latinas largas. Siglas cortas y tokens como AI/3D permanecen.
        String cleaned = text.replaceAll("(?<![A-Za-z0-9])[A-Za-z][A-Za-z'’-]{2,}(?![A-Za-z0-9])", " ");
        return cleaned.replaceAll("\\s+", " ").trim();
    }

    private boolean hasEnoughScriptForMode(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return false;
        if (isKnownAsianStageCueText(text, mode)) return true;
        int han = countMatches(chinesePattern, text);
        int kana = countMatches(japanesePattern, text);
        int hangul = countMatches(koreanPattern, text);
        if (MODE_CHINESE.equals(mode)) return han >= 2 || isTrustedShortAsianSubtitle(text, mode);
        if (MODE_JAPANESE.equals(mode)) return kana >= 1 || han >= 2 || isTrustedShortAsianSubtitle(text, mode);
        if (MODE_KOREAN.equals(mode)) return hangul >= 2 || isTrustedShortAsianSubtitle(text, mode);
        return false;
    }

    private boolean isTrustedShortAsianSubtitle(String text, String mode) {
        if (text == null) return false;
        String key = normalizeKeyForLanguage(text, mode);
        if (MODE_CHINESE.equals(mode)) return SHORT_CHINESE_SUBTITLES.contains(key);
        if (MODE_JAPANESE.equals(mode)) return SHORT_JAPANESE_SUBTITLES.contains(key);
        if (MODE_KOREAN.equals(mode)) return SHORT_KOREAN_SUBTITLES.contains(key);
        return false;
    }

    private boolean looksLikeJapaneseHanOnlyPhrase(String text) {
        if (text == null) return false;
        String key = normalizeKeyForLanguage(text, MODE_JAPANESE);
        if (key.isEmpty()) return false;
        if (countMatches(japanesePattern, key) > 0 || countMatches(koreanPattern, key) > 0) return false;
        if (countMatches(chinesePattern, key) != key.length()) return false;
        return SHORT_JAPANESE_SUBTITLES.contains(key) && !SHORT_CHINESE_SUBTITLES.contains(key);
    }

    private boolean looksLikeChineseHanOnlyPhrase(String text) {
        if (text == null) return false;
        String key = normalizeKeyForLanguage(text, MODE_CHINESE);
        if (key.isEmpty()) return false;
        if (countMatches(japanesePattern, key) > 0 || countMatches(koreanPattern, key) > 0) return false;
        if (countMatches(chinesePattern, key) != key.length()) return false;
        return SHORT_CHINESE_SUBTITLES.contains(key) && !SHORT_JAPANESE_SUBTITLES.contains(key);
    }

    private boolean isAcceptableUnchangedTranslation(String original, String sourceLanguage) {
        if (!TranslateLanguage.ENGLISH.equals(sourceLanguage) || original == null) return false;
        String key = normalizeKey(original);
        if (key.isEmpty()) return false;
        String unchanged = " no hotel taxi internet pizza anime manga karaoke sushi ramen wifi video radio online offline ";
        return unchanged.contains(" " + key + " ");
    }

    private boolean looksUntranslated(String original, String translated) {
        if (original == null || translated == null) return false;
        String a = normalizeKey(original);
        String b = normalizeKey(translated);
        if (a.length() == 0 || b.length() == 0) return false;
        return a.equals(b) || (b.contains(a) && b.length() <= a.length() + 4);
    }

    private String fallbackEnglishStageCueToSpanish(String key) {
        if (key == null || key.isEmpty()) return null;
        if (key.equals("music") || key.equals("music playing")) return "[Música]";
        if (key.equals("applause")) return "[Aplausos]";
        if (key.equals("laughter") || key.equals("laughing") || key.equals("laughs")) return "[Risas]";
        if (key.equals("sigh") || key.equals("sighs") || key.equals("sighing")) return "[Suspiro]";
        if (key.equals("screaming") || key.equals("screams") || key.equals("yelling")) return "[Gritos]";
        if (key.equals("crying") || key.equals("sobbing")) return "[Llanto]";
        if (key.equals("footsteps")) return "[Pasos]";
        if (key.equals("gunfire") || key.equals("gunshots") || key.equals("gunshot")) return "[Disparos]";
        if (key.equals("explosion") || key.equals("explosions")) return "[Explosión]";
        if (key.equals("inaudible")) return "[Inaudible]";
        return null;
    }

    private String fallbackEnglishToSpanish(String text) {
        String k = normalizeKey(text);
        String cue = fallbackEnglishStageCueToSpanish(k);
        if (cue != null) return cue;
        // Correcciones de alta confianza observadas en pruebas reales de películas.
        // Son frases completas, no reemplazos parciales que puedan alterar otros contextos.
        if (k.equals("deputy harris")) return "Agente Harris";
        if (k.equals("mayday mayday we ve been compromised") || k.equals("mayday mayday we have been compromised")) return "Mayday. Mayday. Nos han comprometido";
        if (k.equals("the pilot s a hitman") || k.equals("the pilot is a hitman")) return "El piloto es un sicario";
        if (k.equals("into tiny little pieces") || k.equals("tiny little pieces")) return "En pedacitos";
        if (k.equals("it s there to shoot you down") || k.equals("its there to shoot you down")) return "Está ahí para derribarte";
        if (k.equals("occupational hazard")) return "Riesgo laboral";
        if (k.equals("your neck okay") || k.equals("is your neck okay")) return "¿Tienes bien el cuello?";
        if (k.equals("i can pay you good money")) return "Puedo pagarte bien";
        if (k.equals("i own a roadhouse out in the florida keys")) return "Tengo un bar en los Cayos de Florida";
        if (k.equals("yesterday she shot herself")) return "Ayer se disparó";
        if (k.equals("will you stomp his ass out") || k.equals("you gonna stomp his ass out")) return "¿Vas a darle una paliza?";
        if (k.equals("you re telling me one man did this") || k.equals("you are telling me one man did this")) return "¿Me estás diciendo que un solo hombre hizo esto?";
        if (k.equals("i protect the hive")) return "Protejo la colmena";
        if (k.equals("beekeepers is a special program") || k.equals("the beekeepers is a special program")) return "Beekeepers es un programa especial";
        if (k.equals("this place was crabgrass and weeds")) return "Este lugar estaba lleno de maleza y hierba";
        if (k.equals("you ever win") || k.equals("did you ever win")) return "¿Alguna vez has ganado?";
        if (k.equals("what happened")) return "¿Qué pasó?";
        if (k.equals("what are you doing")) return "¿Qué estás haciendo?";
        if (k.equals("i don t know") || k.equals("i dont know")) return "No lo sé";
        if (k.equals("i don t care") || k.equals("i dont care")) return "No me importa";
        if (k.equals("leave me alone")) return "Déjame en paz";
        if (k.equals("get out of here")) return "Sal de aquí";
        if (k.equals("stay with me")) return "Quédate conmigo";
        if (k.equals("trust me")) return "Confía en mí";
        if (k.equals("listen to me")) return "Escúchame";
        if (k.equals("we need to go")) return "Tenemos que irnos";
        if (k.equals("hurry up")) return "Date prisa";
        if (k.equals("i love you")) return "Te quiero";
        if (k.equals("i hate you")) return "Te odio";
        if (k.equals("it s okay") || k.equals("its okay")) return "Está bien";
        if (k.equals("it s over") || k.equals("its over")) return "Se acabó";
        if (k.equals("not yet")) return "Todavía no";
        if (k.equals("right now")) return "Ahora mismo";
        if (k.equals("are you all right") || k.equals("are you alright")) return "¿Estás bien?";
        if (k.equals("yes")) return "Sí";
        if (k.equals("no")) return "No";
        if (k.equals("ok") || k.equals("okay")) return "De acuerdo";
        if (k.equals("hi") || k.equals("hello")) return "Hola";
        if (k.equals("bye")) return "Adiós";
        if (k.equals("go")) return "Ve";
        if (k.equals("run")) return "Corre";
        if (k.equals("come")) return "Ven";
        if (k.equals("look")) return "Mira";
        if (k.equals("hey")) return "Oye";
        if (k.equals("why")) return "¿Por qué?";
        if (k.equals("what")) return "¿Qué?";
        if (k.equals("who")) return "¿Quién?";
        if (k.equals("how")) return "¿Cómo?";
        if (k.equals("help")) return "Ayuda";
        if (k.equals("wait")) return "Espera";
        if (k.equals("stop")) return "Alto";
        if (k.equals("sorry")) return "Lo siento";
        if (k.equals("thanks")) return "Gracias";
        if (k.equals("please")) return "Por favor";
        if (k.equals("really")) return "¿En serio?";
        if (k.equals("sure")) return "Claro";
        if (k.equals("wow")) return "Guau";
        if (k.equals("oh")) return "Oh";
        if (k.equals("ah")) return "Ah";
        if (k.equals("at home")) return "En casa";
        if (k.equals("i am at home")) return "Estoy en casa";
        if (k.equals("i m at home")) return "Estoy en casa";
        if (k.equals("i am at school")) return "Estoy en la escuela";
        if (k.equals("i am at work")) return "Estoy en el trabajo";
        if (k.equals("good morning")) return "Buenos días";
        if (k.equals("good night")) return "Buenas noches";
        if (k.equals("thank you")) return "Gracias";
        if (k.equals("what are you doing")) return "¿Qué estás haciendo?";
        if (k.equals("where are you")) return "¿Dónde estás?";
        if (k.equals("come on")) return "Vamos";
        if (k.equals("lets go") || k.equals("let s go")) return "Vamos";
        if (k.equals("get down")) return "Agáchate";
        if (k.equals("watch out")) return "Cuidado";
        if (k.equals("move")) return "Muévete";
        if (k.equals("hold on")) return "Espera";
        if (k.equals("get out")) return "Sal";
        if (k.equals("stay back")) return "Atrás";
        if (k.equals("drop it")) return "Suéltalo";
        if (k.equals("hands up")) return "Manos arriba";
        if (k.equals("are you okay")) return "¿Estás bien?";
        if (k.equals("you got this")) return "Tú puedes";
        if (k.equals("i got this") || k.equals("i ve got this")) return "Yo me encargo";
        if (k.equals("don t move") || k.equals("dont move")) return "No te muevas";
        if (k.equals("stay down")) return "Quédate abajo";
        if (k.equals("get back")) return "Retrocede";
        if (k.equals("back off")) return "Aléjate";
        if (k.equals("follow me")) return "Sígueme";
        if (k.equals("let me go")) return "Suéltame";
        if (k.equals("don t worry") || k.equals("dont worry")) return "No te preocupes";
        if (k.equals("don t be afraid") || k.equals("dont be afraid")) return "No tengas miedo";
        if (k.equals("are you serious")) return "¿Hablas en serio?";
        if (k.equals("what the hell")) return "¿Qué demonios?";
        if (k.equals("what did you say")) return "¿Qué dijiste?";
        if (k.equals("who are you")) return "¿Quién eres?";
        if (k.equals("i m fine") || k.equals("im fine") || k.equals("i am fine")) return "Estoy bien";
        if (k.equals("i m coming") || k.equals("im coming") || k.equals("i am coming")) return "Ya voy";
        if (k.equals("he s dead") || k.equals("he is dead")) return "Está muerto";
        if (k.equals("she s dead") || k.equals("she is dead")) return "Está muerta";
        if (k.equals("we re out of time") || k.equals("we are out of time")) return "Se nos acabó el tiempo";
        if (k.equals("we re running out of time") || k.equals("we are running out of time")) return "Se nos acaba el tiempo";
        if (k.equals("calm down")) return "Cálmate";
        if (k.equals("wake up")) return "Despierta";
        if (k.equals("get up")) return "Levántate";
        if (k.equals("be quiet")) return "Silencio";
        return null;
    }

    private String exactGlossaryTranslation(String sourceText, String sourceLanguage) {
        String stored = preferences.getString(KEY_CUSTOM_GLOSSARY, "");
        if (stored == null || stored.trim().isEmpty()) return null;
        String sourceKey = normalizeKeyForLanguage(sourceText, sourceLanguage);
        String wantedPrefix = glossaryPrefix(sourceLanguage);
        for (String line : stored.replace("\r", "").split("\n")) {
            String entry = line.trim();
            if (entry.isEmpty() || entry.startsWith("#")) continue;
            int split = entry.indexOf("=>");
            if (split < 0) split = entry.indexOf('=');
            if (split <= 0) continue;

            String source = entry.substring(0, split).trim();
            String target = entry.substring(split + (entry.startsWith("=>", split) ? 2 : 1)).trim();
            // En un término "español | marca" la marca es solo para el traductor.
            int bar = target.indexOf('|');
            if (bar >= 0) target = target.substring(0, bar).trim();
            if (target.isEmpty()) continue;

            String entryPrefix = "";
            int colon = source.indexOf(':');
            if (colon > 0 && colon <= 3) {
                entryPrefix = source.substring(0, colon).trim().toUpperCase(Locale.ROOT);
                source = source.substring(colon + 1).trim();
            }

            // Las entradas antiguas sin prefijo siguen siendo Inglés → Español.
            if (entryPrefix.isEmpty()) {
                if (!MODE_ENGLISH.equals(sourceLanguage)) continue;
            } else if (!entryPrefix.equals(wantedPrefix)) {
                continue;
            }

            if (normalizeKeyForLanguage(source, sourceLanguage).equals(sourceKey)) return target;
        }
        return null;
    }

    private String glossaryPrefix(String sourceLanguage) {
        if (MODE_CHINESE.equals(sourceLanguage)) return "ZH";
        if (MODE_JAPANESE.equals(sourceLanguage)) return "JA";
        if (MODE_KOREAN.equals(sourceLanguage)) return "KO";
        return "EN";
    }

    private String normalizeKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9áéíóúñü]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String normalizeKeyForLanguage(String text, String mode) {
        if (text == null) return "";
        if (MODE_ENGLISH.equals(mode) || TranslateLanguage.SPANISH.equals(mode) || mode == null) {
            return normalizeKey(text);
        }
        return text.toLowerCase(Locale.ROOT)
                .replace('　', ' ')
                .replaceAll("[\\[\\](){}［］（）｛｝]", " ")
                .replaceAll("[^\\p{L}\\p{N}]+", "")
                .trim();
    }

    private boolean isDisplayedOverlayLine(String raw, String mode) {
        String ignored = overlayTextToIgnore;
        if (raw == null || ignored == null || ignored.trim().isEmpty()) return false;
        // El overlay siempre está en español. Para CJK normalmente ni siquiera pasa el filtro
        // de escritura; esta comparación adicional protege también el modo Inglés/Auto.
        String rawKey = normalizeKey(raw);
        String ignoredKey = normalizeKey(ignored);
        if (rawKey.isEmpty() || ignoredKey.isEmpty()) return false;
        if (rawKey.equals(ignoredKey)) return true;
        int min = Math.min(rawKey.length(), ignoredKey.length());
        int max = Math.max(rawKey.length(), ignoredKey.length());
        if (min < 4) return false;
        if ((ignoredKey.contains(rawKey) || rawKey.contains(ignoredKey))
                && min >= Math.round(max * 0.45f)) return true;
        return min >= Math.round(max * 0.88f)
                && levenshteinDistance(rawKey, ignoredKey) <= Math.max(1, max / 12);
    }

    private String cleanOcrResult(Text result, String mode, int imageWidth, int imageHeight) {
        lastCleanCenterYPermille = -1;
        lastCleanQualityScore = 0;
        lastRawHadKana = false;
        if (result == null) return "";
        lastRawOcr = result.getText() == null ? "" : result.getText();
        lastRawHadKana = kanaLetterPattern.matcher(lastRawOcr).find();
        if (MODE_ENGLISH.equals(mode)) {
            // En inglés no volvemos al bloque completo cuando el análisis por líneas rechaza el texto.
            // Ese retroceso era precisamente lo que reintroducía basura china, marcas de agua y tokens rotos.
            return cleanEnglishFromLayout(result, imageWidth, imageHeight);
        }
        if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) {
            return cleanAsianFromLayout(result, mode, imageWidth, imageHeight);
        }
        return cleanText(result.getText(), mode);
    }

    private static class AsianLineCandidate {
        final String text;
        final Rect box;
        final int score;

        AsianLineCandidate(String text, Rect box, int score) {
            this.text = text;
            this.box = box;
            this.score = score;
        }
    }

    private String cleanAsianFromLayout(Text result, String mode, int imageWidth, int imageHeight) {
        List<AsianLineCandidate> candidates = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String raw = line.getText();
                if (raw == null || raw.trim().isEmpty()) continue;
                if (isDisplayedOverlayLine(raw, mode)) continue;
                if (isCoveredByOverlay(line.getBoundingBox(), imageWidth, imageHeight)) continue;
                String lower = raw.toLowerCase(Locale.ROOT);
                if (isWatermarkOrUi(raw, lower)) continue;
                String cleaned = cleanCjkLine(raw, mode);
                if (cleaned.isEmpty()) continue;
                int score = scoreAsianLine(cleaned, mode);
                Rect box = line.getBoundingBox();
                if (box == null) box = new Rect(0, 0, imageWidth, Math.max(1, imageHeight));
                float widthRatio = imageWidth > 0 ? box.width() / (float) imageWidth : 0f;
                float centerY = imageHeight > 0 ? box.centerY() / (float) imageHeight : 0.5f;
                if (widthRatio >= 0.35f) score += 30;
                else if (widthRatio >= 0.18f) score += 14;
                if (centerY >= 0.30f) score += 8;
                candidates.add(new AsianLineCandidate(cleaned, box, score));
            }
        }
        if (candidates.isEmpty()) return "";
        candidates.sort((a, b) -> {
            int top = Integer.compare(a.box.top, b.box.top);
            return top != 0 ? top : Integer.compare(a.box.left, b.box.left);
        });
        AsianLineCandidate bestA = null;
        AsianLineCandidate bestB = null;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            AsianLineCandidate a = candidates.get(i);
            if (a.score > bestScore) {
                bestScore = a.score;
                bestA = a;
                bestB = null;
            }
            if (i + 1 < candidates.size()) {
                AsianLineCandidate b = candidates.get(i + 1);
                if (asianLinesBelongTogether(a, b, imageWidth, mode)) {
                    int pairScore = a.score + b.score + 28;
                    if (pairScore > bestScore) {
                        bestScore = pairScore;
                        bestA = a;
                        bestB = b;
                    }
                }
            }
        }
        if (bestA == null) return "";
        rememberLayoutMetadata(bestA.box, bestB == null ? null : bestB.box, imageHeight, bestScore);
        String separator = MODE_KOREAN.equals(mode) ? " " : "";
        String combined = bestB == null ? bestA.text : bestA.text + separator + bestB.text;
        combined = sanitizeAsianDelimitersAndCues(combined, mode);
        return hasEnoughScriptForMode(combined, mode) ? combined.trim() : "";
    }

    private void rememberLayoutMetadata(Rect first, Rect second, int imageHeight, int qualityScore) {
        if (imageHeight <= 0 || first == null) {
            lastCleanCenterYPermille = -1;
            lastCleanQualityScore = Math.max(0, qualityScore);
            return;
        }
        int top = first.top;
        int bottom = first.bottom;
        if (second != null) {
            top = Math.min(top, second.top);
            bottom = Math.max(bottom, second.bottom);
        }
        int center = top + Math.max(0, bottom - top) / 2;
        lastCleanCenterYPermille = Math.max(0, Math.min(1000, Math.round(center * 1000f / imageHeight)));
        lastCleanQualityScore = Math.max(0, qualityScore);
    }

    private boolean sameVisualBand(int a, int b) {
        if (a < 0 || b < 0) return true;
        return Math.abs(a - b) <= 180;
    }

    private int visualBandDistance(int a, int b) {
        if (a < 0 || b < 0) return 0;
        return Math.abs(a - b);
    }

    private int scoreAsianLine(String text, String mode) {
        int han = countMatches(chinesePattern, text);
        int kana = countMatches(japanesePattern, text);
        int hangul = countMatches(koreanPattern, text);
        int score = Math.min(120, text.length() * 2);
        if (isKnownAsianStageCueText(text, mode)) score += 80;
        int latin = countMatches(latinPattern, text);
        if (MODE_CHINESE.equals(mode)) score += han * 10 - kana * 14 - hangul * 14 - Math.min(48, latin * 4);
        else if (MODE_JAPANESE.equals(mode)) score += kana * 11 + han * 6 - hangul * 14 - Math.min(48, latin * 4);
        else if (MODE_KOREAN.equals(mode)) score += hangul * 11 + han * 2 - kana * 14 - Math.min(48, latin * 4);
        if (text.matches(".*[。！？!?…」』]$")) score += 10;
        return score;
    }

    private boolean asianLinesBelongTogether(AsianLineCandidate a, AsianLineCandidate b, int imageWidth, String mode) {
        if (a == null || b == null) return false;
        // Una acotación como [音楽] es un subtítulo independiente y no debe pegarse a diálogo.
        if (isKnownAsianStageCueText(a.text, mode) || isKnownAsianStageCueText(b.text, mode)) return false;
        int gap = b.box.top - a.box.bottom;
        int maxHeight = Math.max(1, Math.max(a.box.height(), b.box.height()));
        if (gap < -maxHeight / 2 || gap > maxHeight * 2) return false;
        int overlap = Math.max(0, Math.min(a.box.right, b.box.right) - Math.max(a.box.left, b.box.left));
        int minWidth = Math.max(1, Math.min(a.box.width(), b.box.width()));
        float overlapRatio = overlap / (float) minWidth;
        int centerDistance = Math.abs(a.box.centerX() - b.box.centerX());
        return overlapRatio >= 0.18f || centerDistance <= Math.max(80, imageWidth / 4);
    }

    private static class EnglishLineCandidate {
        final String text;
        final Rect box;
        final int score;

        EnglishLineCandidate(String text, Rect box, int score) {
            this.text = text;
            this.box = box;
            this.score = score;
        }
    }

    /**
     * Selecciona el subtítulo inglés usando texto y posición. Esto evita mezclar la línea china,
     * marcas de agua y fragmentos aislados que antes terminaban dentro de la traducción.
     */
    private String cleanEnglishFromLayout(Text result, int imageWidth, int imageHeight) {
        List<EnglishLineCandidate> candidates = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String raw = line.getText();
                if (raw == null || raw.trim().isEmpty()) continue;
                if (isDisplayedOverlayLine(raw, MODE_ENGLISH)) continue;
                if (isCoveredByOverlay(line.getBoundingBox(), imageWidth, imageHeight)) continue;
                String lower = raw.toLowerCase(Locale.ROOT);
                if (isWatermarkOrUi(raw, lower)) continue;

                int originalLatin = countMatches(latinPattern, raw);
                int originalCjk = countMatches(cjkPattern, raw);
                String cleaned = cleanEnglishLine(raw);
                if (cleaned.isEmpty() || isLikelySpanishLine(cleaned) || isBadEnglishFalsePositive(cleaned)) continue;

                int words = countEnglishWords(cleaned);
                int vocabularyWords = countVocabularyWords(cleaned);
                boolean knownPhrase = fallbackEnglishToSpanish(cleaned) != null;
                if (words < 2 && vocabularyWords == 0
                        && !isValidShortEnglishSubtitle(cleaned) && !knownPhrase) continue;
                if (originalLatin < 3 && !isValidShortEnglishSubtitle(cleaned) && !knownPhrase) continue;
                if (originalCjk > originalLatin * 2 && words < 4 && !knownPhrase) continue;

                Rect box = line.getBoundingBox();
                if (box == null) box = new Rect(0, 0, imageWidth, Math.max(1, imageHeight));
                int score = scoreEnglishLine(cleaned);
                if (knownPhrase) score += 150;
                float widthRatio = imageWidth > 0 ? box.width() / (float) imageWidth : 0f;
                float centerY = imageHeight > 0 ? box.centerY() / (float) imageHeight : 0.5f;
                if (widthRatio >= 0.35f) score += 32;
                else if (widthRatio >= 0.18f) score += 14;
                if (centerY >= 0.35f) score += 10;
                score += Math.min(36, vocabularyWords * 7);
                if (originalCjk > 0) score -= Math.min(20, originalCjk / 2);
                candidates.add(new EnglishLineCandidate(cleaned, box, score));
            }
        }

        if (candidates.isEmpty()) return "";
        candidates.sort((a, b) -> {
            int top = Integer.compare(a.box.top, b.box.top);
            return top != 0 ? top : Integer.compare(a.box.left, b.box.left);
        });

        EnglishLineCandidate bestA = null;
        EnglishLineCandidate bestB = null;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            EnglishLineCandidate a = candidates.get(i);
            if (a.score > bestScore) {
                bestScore = a.score;
                bestA = a;
                bestB = null;
            }
            if (i + 1 < candidates.size()) {
                EnglishLineCandidate b = candidates.get(i + 1);
                if (linesBelongTogether(a, b, imageWidth, imageHeight)) {
                    int pairScore = a.score + b.score + 34;
                    if (pairScore > bestScore) {
                        bestScore = pairScore;
                        bestA = a;
                        bestB = b;
                    }
                }
            }
        }

        if (bestA == null || bestScore < 35) return "";
        rememberLayoutMetadata(bestA.box, bestB == null ? null : bestB.box, imageHeight, bestScore);
        String combined = bestB == null ? bestA.text : bestA.text + " " + bestB.text;
        combined = trimEnglishOcrNoise(combined.replaceAll("\\s+", " ").trim());
        return isGoodEnglishLine(combined) ? combined : "";
    }

    private boolean linesBelongTogether(EnglishLineCandidate a, EnglishLineCandidate b,
                                        int imageWidth, int imageHeight) {
        if (a == null || b == null) return false;
        int gap = b.box.top - a.box.bottom;
        int maxHeight = Math.max(1, Math.max(a.box.height(), b.box.height()));
        if (gap < -maxHeight / 2 || gap > maxHeight * 2) return false;

        int overlap = Math.max(0, Math.min(a.box.right, b.box.right) - Math.max(a.box.left, b.box.left));
        int minWidth = Math.max(1, Math.min(a.box.width(), b.box.width()));
        float overlapRatio = overlap / (float) minWidth;
        int centerDistance = Math.abs(a.box.centerX() - b.box.centerX());
        boolean horizontallyRelated = overlapRatio >= 0.18f
                || centerDistance <= Math.max(80, imageWidth / 4);
        if (!horizontallyRelated) return false;

        String ka = normalizeKey(a.text);
        String kb = normalizeKey(b.text);
        if (ka.equals(kb)) return false;
        return countEnglishWords(a.text) + countEnglishWords(b.text) >= 4;
    }

    private String cleanText(String raw, String mode) {
        if (raw == null) return "";
        String[] lines = raw.replace("\r", "").split("\n");
        StringBuilder cjk = new StringBuilder();
        StringBuilder all = new StringBuilder();
        List<String> englishLines = new ArrayList<>();

        for (String line : lines) {
            String s = line.trim();
            if (s.length() == 0) continue;
            String lower = s.toLowerCase(Locale.ROOT);
            if (isWatermarkOrUi(s, lower)) continue;

            if (MODE_ENGLISH.equals(mode)) {
                String e = cleanEnglishLine(s);
                if (e.length() == 0) continue;

                // Antes se elegía solo la “mejor” línea y por eso se perdían líneas de subtítulos largos.
                // Ahora se conservan todas las líneas útiles dentro del cuadro OCR.
                if (!isLikelySpanishLine(e) && !isBadEnglishFalsePositive(e)) {
                    if (isGoodEnglishLine(e) || commonEnglishWordScore(e) > 0) {
                        englishLines.add(e);
                    }
                }
                continue;
            }

            if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) {
                String onlyCjk = cleanCjkLine(s, mode);
                if (cjkPattern.matcher(onlyCjk).find()) {
                    cjk.append(onlyCjk).append('\n');
                    continue;
                }
            }
            all.append(s).append('\n');
        }

        // Inglés: conserva como máximo las dos líneas más probables del subtítulo y respeta su orden.
        if (MODE_ENGLISH.equals(mode) && !englishLines.isEmpty()) {
            return selectBestEnglishLines(englishLines);
        }
        // CJK: devolver todas las líneas chinas/japonesas/coreanas detectadas.
        if ((MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) && cjk.length() > 0) {
            return cjk.toString().trim();
        }
        return all.toString().trim();
    }

    private String selectBestEnglishLines(List<String> lines) {
        if (lines == null || lines.isEmpty()) return "";
        int bestStart = 0;
        int bestEnd = 0;
        int bestScore = scoreEnglishLine(lines.get(0));

        for (int i = 0; i < lines.size(); i++) {
            int single = scoreEnglishLine(lines.get(i));
            if (single > bestScore) {
                bestScore = single;
                bestStart = i;
                bestEnd = i;
            }
            if (i + 1 < lines.size()) {
                int pair = single + scoreEnglishLine(lines.get(i + 1)) + 18;
                if (pair > bestScore) {
                    bestScore = pair;
                    bestStart = i;
                    bestEnd = i + 1;
                }
            }
        }

        StringBuilder out = new StringBuilder();
        for (int i = bestStart; i <= bestEnd; i++) {
            if (out.length() > 0) out.append(' ');
            out.append(lines.get(i));
        }
        return trimEnglishOcrNoise(out.toString().replaceAll("\\s+", " ").trim());
    }

    private boolean isWatermarkOrUi(String s, String lower) {
        return lower.contains("video eagle")
                || lower.contains("tencent")
                || lower.contains("zeta live translator")
                || lower.contains("powered by google")
                || lower.contains("ocr solo")
                || lower.contains("order by")
                || lower.contains("date added")
                || lower.contains("date published")
                || lower.contains("popular:")
                || lower.contains("mother language")
                || lower.contains("spanish order")
                || lower.contains("auto") && lower.contains("español")
                || lower.contains("chino") && lower.contains("es")
                || lower.contains("inglés") && lower.contains("es")
                || lower.contains("japonés") && lower.contains("es")
                || lower.contains("coreano") && lower.contains("es")
                || lower.equals("área")
                || lower.equals("trad.")
                || lower.equals("vivo")
                || lower.equals("pausa")
                || s.contains("腾讯视频")
                || s.contains("出品")
                || s.contains("云曦星空")
                || s.contains("AI专属");
    }

    private String polishSpanish(String translated) {
        if (translated == null) return "";
        String t = translated.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
        if (t.length() == 0) return t;
        // Correcciones de alta confianza. No reescribimos libremente la salida del motor.
        t = t.replaceAll("(?i)\\bprotego\\b", "protejo");
        t = t.replaceAll("(?i)\\bllaves de florida\\b", "Cayos de Florida");
        t = t.replaceAll("(?i)\\bkeys de florida\\b", "Cayos de Florida");
        return t.substring(0, 1).toUpperCase(Locale.ROOT) + t.substring(1);
    }

    private String guessFromCharacters(String text) {
        if (text == null) return null;
        if (koreanPattern.matcher(text).find()) return TranslateLanguage.KOREAN;
        if (japanesePattern.matcher(text).find()) return TranslateLanguage.JAPANESE;
        if (chinesePattern.matcher(text).find()) return TranslateLanguage.CHINESE;
        if (latinPattern.matcher(text).find()) return TranslateLanguage.ENGLISH;
        return null;
    }

    private String mapLanguage(String languageCode) {
        if (languageCode == null) return null;
        if (languageCode.startsWith("zh")) return TranslateLanguage.CHINESE;
        if (languageCode.startsWith("en")) return TranslateLanguage.ENGLISH;
        if (languageCode.startsWith("ja")) return TranslateLanguage.JAPANESE;
        if (languageCode.startsWith("ko")) return TranslateLanguage.KOREAN;
        if (languageCode.startsWith("es")) return TranslateLanguage.SPANISH;
        return null;
    }

    /**
     * Prepara los clientes del idioma antes de la primera frase LIVE. No descarga nada: una
     * palabra de prueba hace que el modelo se cargue ahora y no con el primer subtítulo, y
     * deja medido el arranque en frío. Si hay una tarea ML en curso, no toca clientes activos.
     */
    public void warmUpMode(String mode) {
        if (mode == null || MODE_AUTO.equals(mode) || !isModelReady(mode)) return;
        try {
            mlExecutor.execute(() -> {
                synchronized (TranslatorEngine.this) {
                    if (closeRequested || activeMlTasks > 0) return;
                }
                try {
                    getRecognizer(mode);
                    getTranslator(mode);
                    warmTranslator(mode);
                } catch (RuntimeException ignored) {
                    // El primer OCR/traductor real lo volverá a crear si hiciera falta.
                }
            });
        } catch (RuntimeException ignored) { }
    }

    private void warmTranslator(String mode) {
        synchronized (this) {
            if (mode.equals(warmedTranslatorMode)) return;
            warmedTranslatorMode = mode;
        }
        String sample = MODE_CHINESE.equals(mode) ? "你好"
                : MODE_JAPANESE.equals(mode) ? "こんにちは"
                : MODE_KOREAN.equals(mode) ? "안녕하세요" : "Hello";
        translateRaw(sample, mode, (translated, elapsedMs, error) -> DebugLog.metric(appContext,
                "CALENTAR", readable(mode) + " " + elapsedMs + "ms" + (error == null ? "" : " error")));
    }

    /**
     * Cancelación lógica solamente. ML Kit no expone cancelación de Task y cerrar un
     * TextRecognizer/Translator mientras procesa puede desestabilizar especialmente los OCR
     * japonés, chino y coreano. Los resultados obsoletos se descartan en el servicio mediante
     * requestId; los clientes se liberan únicamente al cerrar el motor.
     */
    public synchronized void abortActiveOperations() {
        // Intencionalmente no cerramos clientes ML activos aquí.
    }

    private synchronized boolean beginMlTask() {
        if (closeRequested) return false;
        activeMlTasks++;
        return true;
    }

    private synchronized void endMlTask() {
        if (activeMlTasks > 0) activeMlTasks--;
        if (closeRequested && activeMlTasks == 0) closeClientsLocked();
    }

    private void closeClientsLocked() {
        if (activeRecognizer != null) {
            try { activeRecognizer.close(); } catch (Exception ignored) { }
            activeRecognizer = null;
            activeRecognizerMode = "";
        }
        if (activeTranslator != null) {
            try { activeTranslator.close(); } catch (Exception ignored) { }
            activeTranslator = null;
            activeTranslatorSource = "";
        }
        if (!mlExecutor.isShutdown()) mlExecutor.shutdown();
    }

    public synchronized void close() {
        closeRequested = true;
        if (activeMlTasks == 0) closeClientsLocked();
        synchronized (this) { translationCache.clear(); }
        resetAutoState();
        resetStabilityState();
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) return "desconocido";
        return e.getMessage();
    }

    public String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        if (TranslateLanguage.SPANISH.equals(code)) return "Español";
        return code == null ? "Auto" : code;
    }
}
