package com.geozeta.livetranslator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Términos y nombres que el traductor no conoce (鼎 = caldero, 神识 = Sentido Divino).
 *
 * Antes de traducir, cada término se cambia por su forma en inglés o su nombre en pinyin,
 * que el traductor deja pasar o traduce bien. Al final esa marca se cambia por el español
 * elegido. Si el traductor pierde la marca, la frase se queda como la dio el traductor.
 *
 * Formato de cada línea:  ZH:鼎 !鼎力 !鼎鼎 => caldero | cauldron
 *   - antes de "=>": idioma, término y, con "!", formas en las que NO debe cambiarse
 *   - después de "=>": el español y, tras "|", la marca que se le pasa al traductor
 * Sin "|" una línea es una frase completa: solo se usa si el subtítulo es exactamente eso.
 */
final class TermGlossary {

    static final class Entry {
        final String lang;
        final String source;
        final String target;
        final String hint;
        final List<String> exclusions;

        Entry(String lang, String source, String target, String hint, List<String> exclusions) {
            this.lang = lang;
            this.source = source;
            this.target = target;
            this.hint = hint;
            this.exclusions = exclusions;
        }
    }

    static final class Plan {
        final String input;
        final int replaced;
        private final List<String[]> markers;

        Plan(String input, int replaced, List<String[]> markers) {
            this.input = input;
            this.replaced = replaced;
            this.markers = markers;
        }

        /** Cambia en la traducción cada marca por el español elegido. */
        String restore(String output) {
            if (output == null || markers.isEmpty()) return output;
            String result = output;
            for (String[] marker : markers) {
                String hint = marker[0];
                String target = marker[1];
                if (hint.equalsIgnoreCase(target)) continue;
                Pattern pattern = Pattern.compile("(?<![\\p{L}\\p{N}])" + Pattern.quote(hint) + "(?![\\p{L}\\p{N}])",
                        Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
                result = pattern.matcher(result).replaceAll(Matcher.quoteReplacement(target));
            }
            return result;
        }

        /** Cuántas marcas siguen en la salida antes de restaurar; sirve para medir si el motor las respeta. */
        int survivingMarkers(String output) {
            if (output == null) return 0;
            String lower = output.toLowerCase(Locale.ROOT);
            int count = 0;
            for (String[] marker : markers) {
                if (lower.contains(marker[0].toLowerCase(Locale.ROOT))
                        || lower.contains(marker[1].toLowerCase(Locale.ROOT))) count++;
            }
            return count;
        }
    }

    private TermGlossary() { }

    static String prefixFor(String lang) {
        if (SubtitleMatcher.ZH.equals(lang)) return "ZH";
        if (SubtitleMatcher.JA.equals(lang)) return "JA";
        if (SubtitleMatcher.KO.equals(lang)) return "KO";
        return "EN";
    }

    /** Solo las líneas con "|": las demás son frases completas y las maneja el glosario exacto. */
    static List<Entry> parse(String text) {
        List<Entry> entries = new ArrayList<>();
        if (text == null) return entries;
        for (String rawLine : text.replace("\r", "").split("\n")) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int arrow = line.indexOf("=>");
            if (arrow <= 0) continue;
            String left = line.substring(0, arrow).trim();
            String right = line.substring(arrow + 2).trim();
            int bar = right.indexOf('|');
            if (bar < 0) continue;
            String target = right.substring(0, bar).trim();
            String hint = right.substring(bar + 1).trim();
            if (target.isEmpty()) continue;
            if (hint.isEmpty()) hint = target;

            String lang = "EN";
            int colon = left.indexOf(':');
            if (colon > 0 && colon <= 3) {
                lang = left.substring(0, colon).trim().toUpperCase(Locale.ROOT);
                left = left.substring(colon + 1).trim();
            }
            List<String> exclusions = new ArrayList<>();
            String source = null;
            for (String part : left.split("\\s+")) {
                if (part.isEmpty()) continue;
                if (part.startsWith("!")) {
                    if (part.length() > 1) exclusions.add(part.substring(1));
                } else if (source == null) {
                    source = part;
                } else {
                    source = source + " " + part;
                }
            }
            if (source == null || source.isEmpty()) continue;
            entries.add(new Entry(lang, source, target, hint, exclusions));
        }
        return entries;
    }

    static Plan apply(String text, String lang, List<Entry> entries) {
        List<String[]> markers = new ArrayList<>();
        if (text == null || text.isEmpty() || entries == null || entries.isEmpty()) {
            return new Plan(text, 0, markers);
        }
        String prefix = prefixFor(lang);
        boolean english = "EN".equals(prefix);
        boolean[] taken = new boolean[text.length()];
        List<int[]> spans = new ArrayList<>();
        List<Entry> chosen = new ArrayList<>();

        List<Entry> ordered = new ArrayList<>();
        for (Entry entry : entries) if (prefix.equals(entry.lang)) ordered.add(entry);
        // Primero los términos largos: 望月城 antes que 望月.
        Collections.sort(ordered, (a, b) -> Integer.compare(b.source.length(), a.source.length()));

        String haystack = english ? text.toLowerCase(Locale.ROOT) : text;
        for (Entry entry : ordered) {
            String needle = english ? entry.source.toLowerCase(Locale.ROOT) : entry.source;
            boolean[] blocked = new boolean[text.length()];
            for (String exclusion : entry.exclusions) {
                String ex = english ? exclusion.toLowerCase(Locale.ROOT) : exclusion;
                int at = haystack.indexOf(ex);
                while (at >= 0) {
                    for (int i = at; i < at + ex.length() && i < blocked.length; i++) blocked[i] = true;
                    at = haystack.indexOf(ex, at + 1);
                }
            }
            int at = haystack.indexOf(needle);
            while (at >= 0) {
                int end = at + needle.length();
                boolean free = true;
                for (int i = at; i < end; i++) {
                    if (taken[i] || blocked[i]) { free = false; break; }
                }
                if (free && english) {
                    free = (at == 0 || !Character.isLetterOrDigit(text.charAt(at - 1)))
                            && (end >= text.length() || !Character.isLetterOrDigit(text.charAt(end)));
                }
                if (free) {
                    for (int i = at; i < end; i++) taken[i] = true;
                    spans.add(new int[]{at, end});
                    chosen.add(entry);
                }
                at = haystack.indexOf(needle, end);
            }
        }
        if (spans.isEmpty()) return new Plan(text, 0, markers);

        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < spans.size(); i++) order.add(i);
        Collections.sort(order, (a, b) -> Integer.compare(spans.get(a)[0], spans.get(b)[0]));
        StringBuilder out = new StringBuilder(text.length() + 16);
        int cursor = 0;
        for (int index : order) {
            int[] span = spans.get(index);
            Entry entry = chosen.get(index);
            out.append(text, cursor, span[0]);
            // En chino y japonés la marca latina va entre espacios para que no se pegue a nada.
            if (!english && out.length() > 0 && out.charAt(out.length() - 1) != ' ') out.append(' ');
            out.append(entry.hint);
            if (!english && span[1] < text.length() && text.charAt(span[1]) != ' ') out.append(' ');
            cursor = span[1];
            boolean known = false;
            for (String[] marker : markers) if (marker[0].equalsIgnoreCase(entry.hint)) known = true;
            if (!known) markers.add(new String[]{entry.hint, entry.target});
        }
        out.append(text.substring(cursor));
        return new Plan(out.toString().trim(), spans.size(), markers);
    }
}
