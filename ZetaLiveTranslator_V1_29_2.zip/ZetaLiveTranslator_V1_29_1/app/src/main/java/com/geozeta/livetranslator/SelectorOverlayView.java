package com.geozeta.livetranslator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Área de lectura: la zona de la pantalla donde está el subtítulo original.
 * Solo se ve mientras se ajusta. Los controles se dibujan pequeños, pero se agarran con
 * un margen amplio para que el dedo no tenga que acertar en un punto.
 */
public class SelectorOverlayView extends View {
    public interface OnRectChangedListener { void onRectChanged(Rect rect); }

    private final Paint scrim = new Paint();
    private final Paint outline = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint corner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private OnRectChangedListener listener;

    private float lastX;
    private float lastY;
    private int mode = 0; // 0 none, 1 drag, 2 resize
    private int activeHandle = 0;

    private static final int H_NONE = 0;
    private static final int H_LEFT = 1;
    private static final int H_TOP = 2;
    private static final int H_RIGHT = 4;
    private static final int H_BOTTOM = 8;

    private final float minWidth;
    private final float minHeight;
    private final float handleTouch;
    private final float cornerLength;

    public SelectorOverlayView(Context context, Rect initial, int accentColor) {
        super(context);

        minWidth = dp(120);
        minHeight = dp(44);
        handleTouch = dp(34);
        cornerLength = dp(18);

        scrim.setColor(Color.argb(110, 0, 0, 0));
        scrim.setStyle(Paint.Style.FILL);

        outline.setStyle(Paint.Style.STROKE);
        outline.setStrokeWidth(dp(3));
        outline.setColor(Color.argb(150, 0, 0, 0));

        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(dp(1));
        border.setColor(accentColor);

        corner.setStyle(Paint.Style.STROKE);
        corner.setStrokeWidth(dp(3));
        corner.setStrokeCap(Paint.Cap.ROUND);
        corner.setColor(accentColor);

        hint.setColor(Color.WHITE);
        hint.setTextSize(dp(13));
        hint.setFakeBoldText(true);
        hint.setShadowLayer(dp(2), 0, dp(1), Color.BLACK);

        setRect(initial);
    }

    public void setOnRectChangedListener(OnRectChangedListener listener) {
        this.listener = listener;
    }

    public void setRect(Rect r) {
        rect.set(r.left, r.top, r.right, r.bottom);
        normalizeRect();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        // Se oscurece lo que queda fuera: así se ve de un vistazo qué parte se va a leer.
        canvas.drawRect(0, 0, w, rect.top, scrim);
        canvas.drawRect(0, rect.bottom, w, h, scrim);
        canvas.drawRect(0, rect.top, rect.left, rect.bottom, scrim);
        canvas.drawRect(rect.right, rect.top, w, rect.bottom, scrim);

        canvas.drawRect(rect, outline);
        canvas.drawRect(rect, border);
        drawCorner(canvas, rect.left, rect.top, 1, 1);
        drawCorner(canvas, rect.right, rect.top, -1, 1);
        drawCorner(canvas, rect.left, rect.bottom, 1, -1);
        drawCorner(canvas, rect.right, rect.bottom, -1, -1);
        float grip = cornerLength / 2f;
        canvas.drawLine(rect.centerX() - grip, rect.top, rect.centerX() + grip, rect.top, corner);
        canvas.drawLine(rect.centerX() - grip, rect.bottom, rect.centerX() + grip, rect.bottom, corner);
        canvas.drawLine(rect.left, rect.centerY() - grip, rect.left, rect.centerY() + grip, corner);
        canvas.drawLine(rect.right, rect.centerY() - grip, rect.right, rect.centerY() + grip, corner);

        String label = "Encierra solo el subtítulo original";
        float labelWidth = hint.measureText(label);
        float x = Math.max(dp(4), Math.min(rect.centerX() - labelWidth / 2f, w - labelWidth - dp(4)));
        float aboveY = rect.top - dp(10);
        float y = aboveY >= dp(20) ? aboveY : rect.bottom + dp(22);
        canvas.drawText(label, x, y, hint);
    }

    private void drawCorner(Canvas canvas, float x, float y, int dirX, int dirY) {
        canvas.drawLine(x, y, x + dirX * cornerLength, y, corner);
        canvas.drawLine(x, y, x, y + dirY * cornerLength, corner);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = x;
                lastY = y;
                activeHandle = findHandle(x, y);
                if (activeHandle != H_NONE) {
                    mode = 2;
                    return true;
                }
                if (rect.contains(x, y)) {
                    mode = 1;
                    return true;
                }
                // Importante: no crear otro cuadro accidentalmente.
                // Si tocas fuera del área, no cambia nada.
                mode = 0;
                return false;

            case MotionEvent.ACTION_MOVE:
                if (mode == 1) {
                    float dx = x - lastX;
                    float dy = y - lastY;
                    rect.offset(dx, dy);
                    clampRect();
                    lastX = x;
                    lastY = y;
                    notifyRect();
                    invalidate();
                    return true;
                }
                if (mode == 2) {
                    resizeFromHandle(activeHandle, x, y);
                    normalizeRect();
                    clampRect();
                    lastX = x;
                    lastY = y;
                    notifyRect();
                    invalidate();
                    return true;
                }
                return false;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                mode = 0;
                activeHandle = H_NONE;
                normalizeRect();
                clampRect();
                notifyRect();
                invalidate();
                return true;
        }
        return false;
    }

    private int findHandle(float x, float y) {
        float[][] points = new float[][]{
                {rect.left, rect.top, H_LEFT | H_TOP},
                {rect.centerX(), rect.top, H_TOP},
                {rect.right, rect.top, H_RIGHT | H_TOP},
                {rect.left, rect.centerY(), H_LEFT},
                {rect.right, rect.centerY(), H_RIGHT},
                {rect.left, rect.bottom, H_LEFT | H_BOTTOM},
                {rect.centerX(), rect.bottom, H_BOTTOM},
                {rect.right, rect.bottom, H_RIGHT | H_BOTTOM}
        };
        float bestDistance = handleTouch * handleTouch;
        int bestHandle = H_NONE;
        for (float[] point : points) {
            float dx = x - point[0];
            float dy = y - point[1];
            float distance = dx * dx + dy * dy;
            if (distance <= bestDistance) {
                bestDistance = distance;
                bestHandle = (int) point[2];
            }
        }
        return bestHandle;
    }

    private void resizeFromHandle(int handleCode, float x, float y) {
        if ((handleCode & H_LEFT) != 0) rect.left = Math.min(x, rect.right - minWidth);
        if ((handleCode & H_RIGHT) != 0) rect.right = Math.max(x, rect.left + minWidth);
        if ((handleCode & H_TOP) != 0) rect.top = Math.min(y, rect.bottom - minHeight);
        if ((handleCode & H_BOTTOM) != 0) rect.bottom = Math.max(y, rect.top + minHeight);
    }

    private void normalizeRect() {
        float left = Math.min(rect.left, rect.right);
        float right = Math.max(rect.left, rect.right);
        float top = Math.min(rect.top, rect.bottom);
        float bottom = Math.max(rect.top, rect.bottom);
        if (right - left < minWidth) right = left + minWidth;
        if (bottom - top < minHeight) bottom = top + minHeight;
        rect.set(left, top, right, bottom);
    }

    private void clampRect() {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (rect.width() > w) rect.right = rect.left + w;
        if (rect.height() > h) rect.bottom = rect.top + h;
        if (rect.left < 0) rect.offset(-rect.left, 0);
        if (rect.top < 0) rect.offset(0, -rect.top);
        if (rect.right > w) rect.offset(w - rect.right, 0);
        if (rect.bottom > h) rect.offset(0, h - rect.bottom);
    }

    private void notifyRect() {
        if (listener != null) {
            listener.onRectChanged(new Rect(
                    Math.round(rect.left),
                    Math.round(rect.top),
                    Math.round(rect.right),
                    Math.round(rect.bottom)
            ));
        }
    }

    private float dp(int value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
