package com.geozeta.livetranslator;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Registro opcional de pruebas (1.28.4).
 *
 * Tres niveles elegidos por el usuario: apagado (no toca el disco), solo tiempos (sin ningún
 * texto de la pantalla) y tiempos con textos. Está apagado por omisión, se puede borrar y
 * solo sale del teléfono si el usuario lo comparte.
 *
 * La escritura ocurre siempre en un hilo propio de prioridad mínima para no competir
 * con el ciclo LIVE, y cualquier fallo se ignora en silencio: el registro nunca debe
 * poder tumbar la traducción.
 */
public final class DebugLog {

    public static final String KEY_DEBUG_LOG = "debug_log_enabled";
    public static final String KEY_DEBUG_LEVEL = "debug_log_level";
    public static final int LEVEL_OFF = 0;
    public static final int LEVEL_METRICS = 1;
    public static final int LEVEL_WITH_TEXT = 2;
    private static final String KEY_LAST_EXIT = "debug_last_exit_seen";

    private static final String FILE_NAME = "zeta_registro.txt";
    private static final long MAX_BYTES = 512L * 1024L;

    private static final ExecutorService writer = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "ZetaDebugLog");
        thread.setPriority(Thread.MIN_PRIORITY);
        return thread;
    });

    // Solo la usa el hilo de escritura, por eso no necesita sincronización.
    private static final SimpleDateFormat STAMP = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);

    private static volatile Integer levelCache = null;
    private static volatile boolean crashCaptureInstalled = false;

    private DebugLog() { }

    public static int level(Context context) {
        Integer cached = levelCache;
        if (cached != null) return cached;
        int value = LEVEL_OFF;
        try {
            SharedPreferences prefs = prefs(context);
            if (prefs != null) {
                // Quien tenía activado el registro antiguo ya aceptó guardar textos.
                value = prefs.getInt(KEY_DEBUG_LEVEL, prefs.getBoolean(KEY_DEBUG_LOG, false) ? LEVEL_WITH_TEXT : LEVEL_OFF);
            }
        } catch (Exception ignored) { }
        levelCache = value;
        return value;
    }

    public static void setLevel(Context context, int level) {
        levelCache = level;
        try {
            SharedPreferences prefs = prefs(context);
            if (prefs != null) prefs.edit().putInt(KEY_DEBUG_LEVEL, level).apply();
        } catch (Exception ignored) { }
    }

    public static boolean isEnabled(Context context) {
        return level(context) > LEVEL_OFF;
    }

    /** Línea que contiene texto de la pantalla: solo se guarda en el nivel con textos. */
    public static void append(Context context, String tag, String value) {
        if (context == null || level(context) < LEVEL_WITH_TEXT) return;
        enqueue(context, tag, value);
    }

    /** Línea solo con números, sin texto de la pantalla. */
    public static void metric(Context context, String tag, String value) {
        if (context == null || level(context) < LEVEL_METRICS) return;
        enqueue(context, tag, value);
    }

    /**
     * Registro JSON por pares clave/valor. Las claves que empiezan por "t_" llevan texto de la
     * pantalla y se omiten salvo en el nivel con textos.
     */
    public static void json(Context context, String kind, Object... pairs) {
        if (context == null) return;
        int current = level(context);
        if (current < LEVEL_METRICS) return;
        StringBuilder out = new StringBuilder(160).append('{');
        appendJson(out, "tipo", kind);
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            String key = String.valueOf(pairs[i]);
            if (key.startsWith("t_") && current < LEVEL_WITH_TEXT) continue;
            out.append(',');
            appendJson(out, key, pairs[i + 1]);
        }
        enqueue(context, "J", out.append('}').toString());
    }

    private static void appendJson(StringBuilder out, String key, Object value) {
        out.append('"').append(key).append("\":");
        if (value instanceof Number || value instanceof Boolean) {
            out.append(value);
            return;
        }
        out.append('"');
        String text = value == null ? "" : String.valueOf(value);
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '"' || c == '\\') out.append('\\').append(c);
            else if (c < 0x20) out.append(' ');
            else out.append(c);
        }
        out.append('"');
    }

    private static void enqueue(Context context, String tag, String value) {
        final Context app = context.getApplicationContext();
        final long at = System.currentTimeMillis();
        final String safeTag = oneLine(tag);
        final String safeValue = oneLine(value);
        try {
            writer.execute(() -> {
                String line = STAMP.format(new Date(at)) + "\t" + safeTag + "\t" + safeValue + "\n";
                writeLine(app, line);
            });
        } catch (Exception ignored) { }
    }

    /** Guarda la causa de un cierre por excepción Java antes de que el proceso muera. */
    public static void installCrashCapture(Context context) {
        if (crashCaptureInstalled || context == null) return;
        crashCaptureInstalled = true;
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                if (isEnabled(app)) {
                    StringWriter trace = new StringWriter();
                    error.printStackTrace(new PrintWriter(trace));
                    writeLine(app, "CIERRE_JAVA\t" + thread.getName() + "\t" + oneLine(trace.toString()) + "\n");
                }
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    /** Copia al registro los cierres que Android recuerda: fallo nativo, ANR, memoria, etc. */
    public static void logRecentExits(Context context) {
        if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.R || !isEnabled(context)) return;
        final Context app = context.getApplicationContext();
        try {
            writer.execute(() -> {
                try {
                    ActivityManager manager = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
                    if (manager == null) return;
                    SharedPreferences prefs = prefs(app);
                    long seen = prefs == null ? 0L : prefs.getLong(KEY_LAST_EXIT, 0L);
                    long newest = seen;
                    List<ApplicationExitInfo> exits = manager.getHistoricalProcessExitReasons(null, 0, 8);
                    for (ApplicationExitInfo info : exits) {
                        if (info.getTimestamp() <= seen) continue;
                        newest = Math.max(newest, info.getTimestamp());
                        json(app, "cierre", "motivo", info.getReason(), "estado", info.getStatus(),
                                "importancia", info.getImportance(), "pss_kb", info.getPss(), "rss_kb", info.getRss(),
                                "detalle", info.getDescription(), "fecha_ms", info.getTimestamp());
                    }
                    if (prefs != null && newest != seen) prefs.edit().putLong(KEY_LAST_EXIT, newest).apply();
                } catch (Exception ignored) { }
            });
        } catch (Exception ignored) { }
    }

    /** Devuelve el final del registro, que es la parte útil para revisar una prueba. */
    public static String readTail(Context context, int maxChars) {
        if (context == null || maxChars <= 0) return "";
        RandomAccessFile file = null;
        try {
            File target = logFile(context.getApplicationContext());
            if (target == null || !target.exists()) return "";
            long length = target.length();
            if (length <= 0L) return "";
            long from = Math.max(0L, length - (long) maxChars);
            file = new RandomAccessFile(target, "r");
            file.seek(from);
            int size = (int) Math.min(length - from, (long) maxChars);
            byte[] buffer = new byte[size];
            file.readFully(buffer);
            String text = new String(buffer, "UTF-8");
            if (from > 0L) {
                // El corte pudo caer a mitad de una línea: se descarta esa primera línea parcial.
                int firstBreak = text.indexOf('\n');
                if (firstBreak >= 0 && firstBreak + 1 < text.length()) text = text.substring(firstBreak + 1);
            }
            return text;
        } catch (Exception e) {
            return "";
        } catch (OutOfMemoryError e) {
            return "";
        } finally {
            if (file != null) {
                try { file.close(); } catch (Exception ignored) { }
            }
        }
    }

    public static void clear(Context context) {
        if (context == null) return;
        final Context app = context.getApplicationContext();
        try {
            writer.execute(() -> {
                File target = logFile(app);
                if (target == null) return;
                try { target.delete(); } catch (Exception ignored) { }
            });
        } catch (Exception ignored) { }
    }

    private static void writeLine(Context app, String line) {
        FileOutputStream out = null;
        try {
            File target = logFile(app);
            if (target == null) return;
            // Un teléfono no debe quedarse sin espacio por un registro de pruebas:
            // al pasar del límite se reinicia entero en vez de crecer sin control.
            boolean append = !(target.exists() && target.length() > MAX_BYTES);
            out = new FileOutputStream(target, append);
            if (!append) out.write("(registro reiniciado por tamaño)\n".getBytes("UTF-8"));
            out.write(line.getBytes("UTF-8"));
        } catch (Exception ignored) {
        } catch (OutOfMemoryError ignored) {
        } finally {
            if (out != null) {
                try { out.close(); } catch (Exception ignored) { }
            }
        }
    }

    private static File logFile(Context app) {
        try {
            File dir = app.getExternalFilesDir(null);
            if (dir == null) dir = app.getFilesDir();
            if (dir == null) return null;
            if (!dir.exists() && !dir.mkdirs()) return null;
            return new File(dir, FILE_NAME);
        } catch (Exception e) {
            return null;
        }
    }

    private static SharedPreferences prefs(Context context) {
        try {
            return context.getApplicationContext()
                    .getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        } catch (Exception e) {
            return null;
        }
    }

    private static String oneLine(String value) {
        if (value == null) return "";
        return value.replace("\r", " ").replace("\n", " ⏎ ").replace("\t", " ").trim();
    }
}
