# Zeta Live Translator 1.29.1

Los cambios de esta versión están en `LEEME_V1_29_0.txt` y `LEEME_V1_29_1.txt`.

Versión enfocada en **estabilidad durante video real** y **mejor lectura/traducción de subtítulos en Inglés, Chino, Japonés y Coreano → Español**, conservando la interfaz principal compacta aprobada y el procesamiento offline de ML Kit después de descargar los modelos.

## Interfaz principal

- Diseño compacto basado en la opción 2 aprobada.
- Menos texto y menos separación vertical.
- Solo aparecen las funciones reales de la pantalla principal: permisos, iniciar traductor, glosario y modelos por idioma.
- Lista compacta de los cuatro modelos y su estado.

## Traducción y OCR

- Inglés: reconoce mejor palabras solas y frases cortas como `No`, `OK`, `Hi`, `Why`, etc.
- Chino: acepta expresiones breves y caracteres independientes de alta confianza.
- Japonés: acepta hiragana/katakana breves y kanji independientes de alta confianza.
- Coreano: acepta expresiones breves de una sola sílaba de alta confianza.
- Auto cambia de idioma antes cuando el idioma anterior deja de coincidir.
- Auto ya no exige un puntaje excesivo para expresiones asiáticas cortas reales.
- Vivo acepta desde la primera lectura las frases claras y cortas de alta confianza; solo usa consenso cuando el cambio parece una variación dudosa del mismo OCR.
- Las siglas latinas cortas dentro de texto asiático (`AI`, `3D`, etc.) ya no se borran automáticamente.
- La jerga asiática no se reescribe dentro de frases largas cuando el significado depende del contexto.
- Palabras iguales en inglés y español como `hotel`, `taxi` o `internet` pueden conservarse sin marcarse como fallo.

## Estabilidad y video real

- La captura ya no crea un bitmap completo de toda la pantalla cuando el formato normal permite recortar directamente el área OCR.
- Conversión y recorte se ejecutan fuera del hilo principal.
- Se mantiene un solo OCR activo y un solo traductor activo para no acumular los cuatro motores en memoria.
- Auto prueba como máximo dos OCR candidatos por fotograma en vez de recorrer repetidamente los cuatro idiomas.
- El preprocesamiento limita tamaño, píxeles y escala para evitar picos de memoria en japonés, chino y coreano.
- Las operaciones ML activas se dejan terminar de forma segura; sus resultados obsoletos se descartan sin cerrar el OCR a mitad del trabajo.
- Si el área OCR es excesivamente grande, se rechaza de forma controlada en vez de arriesgar un cierre por memoria.
- La última traducción permanece visible hasta que llega una nueva traducción válida; un hueco de OCR no hace desaparecer el cuadro.
- OCR y traducción trabajan en paralelo y solo se conserva la frase más reciente pendiente.
- Si una traducción falla, la misma frase puede reintentarse sin quedar bloqueada como “mismo subtítulo”.

## Limpieza para películas, anime, donghua y dramas

- Conserva números como `42`, fechas y cantidades.
- Las negaciones y números ya no se consideran el mismo subtítulo por similitud (`can`/`can't`, `do`/`don't`, etc.).
- Se eliminan etiquetas de hablante como `[Killa]` o `[The Elder]` antes de traducir.
- Se conservan y traducen indicaciones visibles de accesibilidad/sonido como `[air whooshing]`, `(man screaming)`, `(weapon firing rapidly)` o `(drums beating)`.
- Se normalizan de forma conservadora expresiones inglesas frecuentes de diálogo (`gonna`, `wanna`, `I'ma`, `livin'`, etc.) antes de ML Kit.
- Las expresiones muy cortas de los cuatro idiomas siguen teniendo tratamiento específico y rápido.

## Glosario de correcciones

Ahora admite los cuatro idiomas mediante prefijos:

```text
EN: Good morning => Buenos días
ZH: 你好 => Hola
JA: ありがとう => Gracias
KO: 고마워 => Gracias
```

Las entradas antiguas sin prefijo siguen tratándose como Inglés → Español.

## Mejoras 1.27.7

- Captura siguiente a 55 ms después de terminar el OCR anterior, sin lanzar dos OCR simultáneos.
- Warm-up seguro del reconocedor/traductor al iniciar Vivo.
- Caché ampliada para respuestas repetidas.
- Más frases frecuentes EN/ZH/JA/KO y reparaciones OCR inglesas conservadoras.
- La traducción ya mostrada no se reemplaza por pequeñas variaciones del mismo subtítulo.
- El fondo del subtítulo es negro con ~59 % de opacidad y el texto permanece blanco sin sombra.
- Los textos dentro del área OCR (incluidos textos de computadoras/pantallas del video) siguen siendo traducibles.

## Modo Vivo

```text
Captura del cuadro
→ OCR del idioma elegido/Auto
→ limpieza segura
→ consenso de 2 lecturas
→ traducción offline
→ validación
→ subtítulo en español
```

El intervalo LIVE principal es de 380 ms. La captura y el recorte pesado salen del hilo principal. Los cuatro idiomas usan el mismo flujo de OCR: primero el recorte original y, solo si no hay texto útil, un fallback único ampliado/contrastado. Los clientes OCR/traductor no se cierran mientras una tarea está activa.

## Flujo unificado 1.27.1

- Inglés, Chino, Japonés y Coreano usan la misma secuencia de captura y OCR.
- Todos leen primero el recorte original; el preprocesamiento ampliado queda solo como un fallback único cuando no se detecta texto.
- Auto usa la imagen original para todos los idiomas y prueba como máximo dos candidatos de forma secuencial.
- Los callbacks de OCR y traducción se ejecutan únicamente cuando la `Task` de ML Kit ya terminó.
- Si el postprocesado de OCR o traducción lanza una excepción Java o se queda sin memoria, se devuelve un error controlado en vez de dejar caer el proceso.
- Solo cambian el reconocedor y los filtros específicos de cada idioma.

## Compilar en GitHub

1. Sube el contenido de esta carpeta a la raíz del repositorio, incluida `.github`.
2. Abre **Actions → Build APK**.
3. Ejecuta **Run workflow**.
4. El workflow configura Java 17, Android 35 y Gradle 8.13.
5. Descarga el artefacto `ZetaLiveTranslator_APK_V1_27_2_ASIATICOS_CORREGIDOS_4Idiomas`.

## Nota

La calidad final sigue dependiendo de la nitidez del subtítulo y del modelo offline de ML Kit. El cuadro de captura debe cubrir solo el área del subtítulo para reducir falsos positivos y mantener velocidad.


## Corrección 1.27.2 - OCR asiáticos

- Corregida la expresión regular compartida que podía romper Japonés, Chino y Coreano con `PatternSyntaxException`.
- Ampliadas expresiones cortas seguras para los tres idiomas asiáticos sin cambiar el flujo estable de Inglés.
- Auto evita aceptar como Chino ciertas frases japonesas conocidas escritas solo con kanji, y viceversa.
- Se conserva el flujo OCR unificado de 1.27.1 y la interfaz compacta.

## Cambios 1.28.4

- **Auto se fija**: tras dos lecturas aceptadas del mismo idioma, Auto queda fijado y deja de probar un segundo OCR en cada fotograma. Los huecos entre subtítulos ya no gastan dos reconocedores. Solo dos lecturas seguidas con texto real que no encaja sueltan el idioma.
- **Rescate de traducción**: si la validación final descarta la salida del motor, antes de perder el subtítulo se prueba glosario, diccionario seguro del idioma y caché.
- **Registro de pruebas**: opcional y apagado por omisión. Guarda el texto aceptado por el OCR, la traducción mostrada y los fallos, para comparar una versión con otra. Se activa, comparte y borra desde la tarjeta "Registro de pruebas" de la pantalla principal.

## Cambios 1.28.6

Correcciones de la auditoría. No cambia nada en el uso de la app.

- **Carrera corregida en el motor**: `endMlTask()` se descontaba en la primera línea del callback, así que durante todo su cuerpo el contador valía 0 y `warmUpMode()` o `close()` podían cerrar el reconocedor o el traductor justo encima. Ahora va en un `finally` al final.
- **Verificación real de modelos**: el servicio comprueba al arrancar que los modelos marcados como listos siguen descargados, y corrige la bandera. Antes solo lo hacía la pantalla principal, y arrancar Vivo sin pasar por ella dejaba cada frase fallando sin salida.
- **Nombres propios enteros**: McGregor, MacArthur, iPhone, eBay, xBox y kWh ya no se parten en dos palabras.
- **Línea repetida**: solo se descarta el eco inmediato del OCR, no cualquier repetición del cartel. Un diálogo con la misma frase dos veces ya no pierde una mitad.
- **Español sin caracteres asiáticos**: primero se limpian los restos sueltos, después el control es estricto. El rescate de 1.28.4 evita perder el subtítulo.
- **Tiempos en el registro**: cada línea trae los milisegundos del OCR y de la traducción, más los píxeles del recorte.
