# Publicar en Google Play

Esta lista ayuda, pero no garantiza la aprobación. Revisada el 09/11/2026.

## Ya hecho en el proyecto

- Apunta a Android 36.
- Declara los servicios de captura y descarga.
- Pide cada permiso explicando para qué es.
- Notificación con botón Detener.
- Avisos de privacidad y atribución dentro de la app.

## Paso 1: crear la llave de subida (solo una vez)

Tu repositorio debe ser **privado** en este paso.

1. En GitHub: Settings > Secrets and variables > Actions > New repository secret.
2. Crea `ZETA_KEY_PASSWORD` con una contraseña larga. Guárdala también en otro sitio.
3. En Actions, ejecuta **Crear llave de subida**.
4. Descarga `llave-zeta-GUARDAR-Y-BORRAR`. Guarda `zeta-upload.jks` en un lugar seguro.
5. Crea el secreto `ZETA_KEYSTORE_BASE64` y pega el contenido de `zeta-upload-base64.txt`.
6. Borra esa ejecución en Actions.

Si pierdes la llave, Google puede cambiarla, pero es un trámite. No la subas nunca al repositorio.

## Paso 2: generar el archivo

Ejecuta **Build APK**. Descarga `ZetaLiveTranslator_GooglePlay_V1_29_1`. Dentro está el `.aab`.

También trae un `.apk` de la misma versión. Instálalo y pruébalo antes de publicar: esta versión va optimizada y puede portarse distinto a la de prueba. Sin llave sale sin firmar y no se instala.

Mira el resumen de la ejecución: la tabla de 16 KB debe decir OK en todas las filas.
Si alguna dice REVISAR, no publiques todavía y mándame esa tabla.

## Paso 3: lo que debes hacer en Play Console

| Tema | Qué poner |
|---|---|
| Política de privacidad | Publica `POLITICA_PRIVACIDAD.md` en una página pública, con tu correo |
| Permiso de pantalla | Declara el servicio de captura y sube un video corto mostrando la función |
| Descarga | Declara el servicio de sincronización de datos: descarga de idiomas a petición del usuario |
| Mostrar sobre otras apps | Justifica que dibuja la traducción sobre el video |
| Clasificación de contenido | Cuestionario de la consola |
| Pruebas | Haz las pruebas internas o cerradas que pida tu cuenta |
| Ficha | Icono de 512 px y gráfico de 1024 × 500. No uses imágenes de series sin derechos |

## Seguridad de los datos (borrador, tú eres el responsable)

Decir "no recopila nada" sería falso. La app no envía textos ni imágenes, pero Google indica que ML Kit recopila datos técnicos para diagnóstico y estadísticas, y que los cifra en tránsito y no los pasa a terceros.

- Recopilados por el SDK: información del dispositivo y de la app, rendimiento, configuración, eventos, códigos de error e idiomas configurados.
- Finalidad: diagnóstico y análisis.
- No se recopilan imágenes de pantalla, textos ni audio.
- Compara con la página oficial antes de enviar: https://developers.google.com/ml-kit/android-data-disclosure

## Descripción de la ficha

Debe incluir, por exigencia de Google:

> La traducción funciona con Google Translate. Más información: https://cloud.google.com/translate

Y una frase honesta sobre el offline:

> Necesita internet solo para descargar cada idioma. Después traduce sin conexión.

No prometas calidad de subtítulo humano ni "tiempo real" hasta tener medidas.
