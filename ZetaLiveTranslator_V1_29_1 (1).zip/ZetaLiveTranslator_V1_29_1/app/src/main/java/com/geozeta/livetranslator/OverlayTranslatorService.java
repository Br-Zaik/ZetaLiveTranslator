package com.geozeta.livetranslator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Debug;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

public class OverlayTranslatorService extends Service {
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_DATA = "projection_data";
    public static final String ACTION_STOP = "com.geozeta.livetranslator.STOP_TRANSLATOR";

    public static final String KEY_TEXT_SIZE = "overlay_text_size_sp";
    public static final String KEY_BG_ALPHA = "overlay_bg_alpha";
    public static final String KEY_ACCENT = "overlay_accent";
    public static final int DEFAULT_TEXT_SIZE = 18;
    public static final int DEFAULT_BG_ALPHA = 150;
    public static final int DEFAULT_ACCENT = 0xFF2DD4BF;

    private static final String CHANNEL_ID = "zeta_live_translator";
    private static final int NOTIFICATION_ID = 781;
    private static final long OCR_SLOW_NOTICE_MS = 12000L;
    private static final long OCR_RECOVER_MS = 25000L;
    private static final int MAX_ENGINE_RECOVERIES = 2;
    private static final long WATCHDOG_INTERVAL_MS = 2000L;
    private static final long METRICS_INTERVAL_MS = 30000L;
    private static final long TOOLBAR_AUTO_COLLAPSE_MS = 4000L;
    // Tras una frase, una lectura parecida dentro de esta ventana es el mismo cartel.
    private static final long SAME_SUBTITLE_GUARD_MS = 1500L;
    // Una frase que falló no se reintenta enseguida para no gastar batería en bucle.
    private static final long FAILED_RETRY_GUARD_MS = 2500L;

    private WindowManager windowManager;
    private Handler handler;
    private ExecutorService captureExecutor;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private PowerManager powerManager;
    private SharedPreferences prefs;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;
    private final Rect safeInsets = new Rect();

    private LinearLayout toolbar;
    private TextView handleBtn;
    private LinearLayout actionsRow;
    private LinearLayout selectionRow;
    private ImageView liveBtn;
    private ImageView subtitleBtn;
    private TextView langBtn;
    private TextView statusView;
    private TextView subtitleView;
    private SelectorOverlayView selectorView;
    private WindowManager.LayoutParams toolbarParams;
    private WindowManager.LayoutParams subtitleParams;
    private WindowManager.LayoutParams selectorParams;
    private WindowManager.LayoutParams statusParams;

    private volatile TranslatorEngine engine;
    private Runnable statusHideRunnable;
    private Rect selectorRect;
    private Rect selectorRectBeforeEdit;
    private int roiVersion = 1;
    private boolean selecting = false;
    private boolean live = false;
    private boolean busy = false;
    private boolean subtitleHidden = false;
    private boolean subtitleManuallyMoved = false;
    private boolean subtitleAnchorSet = false;
    private boolean subtitleAnchorFromBottom = true;
    private int subtitleAnchorCenterX = 0;
    private int subtitleAnchorEdgeY = 0;
    private boolean toolbarCollapsed = false;
    private volatile boolean destroyed = false;
    private boolean captureViewsHidden = false;
    private int selectorVisibilityBeforeCapture = View.VISIBLE;
    private int statusVisibilityBeforeCapture = View.GONE;
    private String lastShownSubtitle = "";
    private String lastNotificationText = "";
    private long statusVisibleUntil = 0L;
    private int requestSerial = 0;
    private volatile int activeRequestId = 0;
    private volatile int busyRequestId = 0;
    private long busyStartedAt = 0L;
    private long lastBusyNoticeAt = 0L;
    private volatile boolean captureWorkerActive = false;
    private boolean priorityCapturePending = false;
    private int engineRecoveries = 0;
    private byte[] cropBuffer;

    // Ritmo del bucle LIVE, adaptado a lo que tarda este teléfono.
    private long lastOcrMs = 0L;
    private boolean awaitingConfirmation = false;
    private boolean lastFrameUnchanged = false;
    private long lastTextSeenAt = 0L;
    private int thermalNow = 0;

    // Identidad del último cartel. El texto visible va aparte y solo lo cambia otra traducción.
    private String currentSourceKey = "";
    private String currentSourceMode = "";
    private long currentSourceCommittedAt = 0L;
    private String lastFailedTranslationKey = "";
    private long lastFailedTranslationAt = 0L;
    private String previousSegmentText = "";
    private String previousSegmentLanguage = "";
    private long previousSegmentAt = 0L;

    // Registro y contadores de la sesión.
    private final long sessionId = System.currentTimeMillis();
    private long sessionStartedAt = 0L;
    private int ocrCount = 0;
    private long ocrTotalMs = 0L;
    private int unchangedFrames = 0;
    private int lastOcrWidth = 0;
    private int lastOcrHeight = 0;
    private int lastCropWidth = 0;
    private int lastCropHeight = 0;

    private final TranslationScheduler scheduler = new TranslationScheduler(this::onJobDropped);

    private static final class SegmentMeta {
        long frameAt;
        long acceptedAt;
        long submittedAt;
        long ocrMs;
        int cropWidth;
        int cropHeight;
        int ocrWidth;
        int ocrHeight;
        int roi;
        String rawOcr;
    }

    // Auto lee Inglés, Chino, Japonés o Coreano y traduce a Español.
    private int languageIndex = 0;
    private final String[] languageModes = new String[]{
            TranslatorEngine.MODE_AUTO,
            TranslatorEngine.MODE_ENGLISH,
            TranslatorEngine.MODE_CHINESE,
            TranslatorEngine.MODE_JAPANESE,
            TranslatorEngine.MODE_KOREAN
    };

    private final Runnable liveRunnable = new Runnable() {
        @Override public void run() {
            if (!live || destroyed) return;
            // La siguiente captura se agenda al terminar el OCR anterior, no al terminar
            // la traducción. Así no se crea una cola de fotogramas.
            translateOnce(false);
        }
    };

    private final Runnable autoCollapseRunnable = () -> {
        if (live && !selecting && !toolbarCollapsed) setToolbarCollapsed(true);
    };

    private final Runnable watchdogRunnable = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            thermalNow = readThermalStatus();
            checkForStuckWork();
            handler.postDelayed(this, WATCHDOG_INTERVAL_MS);
        }
    };

    private final Runnable metricsRunnable = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            logSessionState();
            handler.postDelayed(this, METRICS_INTERVAL_MS);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        DebugLog.installCrashCapture(this);
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        if (!enterForeground()) return;
        captureExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "ZetaCaptureWorker");
            thread.setPriority(Thread.NORM_PRIORITY - 1);
            return thread;
        });
        engine = new TranslatorEngine(getApplicationContext());
        // Si el sistema borró un modelo, la marca se corrige aquí y no con cada frase fallando.
        engine.verifyDownloadedModels();
        readMetrics();
        selectorRect = defaultRect();
        chooseInitialLanguageMode();
        handler.postDelayed(watchdogRunnable, WATCHDOG_INTERVAL_MS);
        handler.postDelayed(metricsRunnable, METRICS_INTERVAL_MS);
    }

    private boolean enterForeground() {
        try {
            Notification notification = buildNotification("Traductor listo");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            return true;
        } catch (RuntimeException e) {
            DebugLog.metric(this, "ERROR_INICIO", e.getClass().getSimpleName());
            destroyed = true;
            stopSelf();
            return false;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (destroyed) return START_NOT_STICKY;
        // Android no conserva el permiso de captura: si recrea el servicio solo, no hay nada
        // que hacer aquí y volver a arrancar sin ese permiso cerraba la app en Android 14+.
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (resultCode == 0 || data == null) return START_NOT_STICKY;
        if (mediaProjection != null) {
            invalidateActiveRequest();
            releaseCaptureOnly();
            MediaProjection previousProjection = mediaProjection;
            mediaProjection = null;
            try { previousProjection.stop(); } catch (Exception ignored) { }
        }
        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            MediaProjection newProjection = manager.getMediaProjection(resultCode, data);
            mediaProjection = newProjection;
            newProjection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    if (!destroyed && mediaProjection == newProjection) stopSelf();
                }
            }, handler);
            setupInitialCapture();
        } catch (RuntimeException e) {
            DebugLog.metric(this, "ERROR_CAPTURA", e.getClass().getSimpleName());
            stopSelf();
            return START_NOT_STICKY;
        }
        sessionStartedAt = SystemClock.elapsedRealtime();
        DebugLog.json(this, "sesion", "sesion", sessionId, "android", Build.VERSION.SDK_INT,
                "telefono", Build.MANUFACTURER + " " + Build.MODEL,
                "app", BuildConfig.VERSION_NAME, "pantalla", screenWidth + "x" + screenHeight);
        showToolbar();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private long clock() {
        return SystemClock.elapsedRealtime();
    }

    private void setupInitialCapture() {
        if (mediaProjection == null || destroyed) return;
        releaseCaptureOnly();
        readMetrics();
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ZetaLiveTranslatorScreen",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
        );
    }

    /**
     * En una rotación no se vuelve a usar createVirtualDisplay con el mismo token.
     * Se conserva el VirtualDisplay y solo se cambia su tamaño y superficie.
     */
    private void resizeCaptureSurface() {
        if (mediaProjection == null || destroyed) return;
        ImageReader replacement = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        ImageReader previous = imageReader;
        try {
            if (virtualDisplay == null) {
                replacement.close();
                showStatus("Reinicia el traductor", 2200);
                return;
            }
            virtualDisplay.resize(screenWidth, screenHeight, screenDensity);
            virtualDisplay.setSurface(replacement.getSurface());
            imageReader = replacement;
            if (previous != null && previous != imageReader) previous.close();
        } catch (Exception e) {
            replacement.close();
            imageReader = previous;
            showStatus("No se pudo ajustar tras girar", 1800);
        }
    }

    private void readMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        safeInsets.set(0, 0, 0, 0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.view.WindowMetrics wm = windowManager.getMaximumWindowMetrics();
            Rect bounds = wm.getBounds();
            screenWidth = bounds.width();
            screenHeight = bounds.height();
            screenDensity = getResources().getDisplayMetrics().densityDpi;
            try {
                Insets insets = windowManager.getCurrentWindowMetrics().getWindowInsets()
                        .getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                safeInsets.set(insets.left, insets.top, insets.right, insets.bottom);
            } catch (RuntimeException ignored) {
                // Sin márgenes del sistema la caja solo se limita a los bordes de la pantalla.
            }
        } else {
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.densityDpi;
        }
    }

    private Rect defaultRect() {
        int w = Math.min(screenWidth - dp(24), Math.max(dp(260), (int) (screenWidth * 0.70f)));
        int h = Math.min(screenHeight - dp(32), Math.max(dp(70), (int) (screenHeight * 0.13f)));
        int left = Math.max(0, (screenWidth - w) / 2);
        int top = Math.max(0, (int) (screenHeight * 0.70f));
        return clampScreenRect(new Rect(left, top, left + w, top + h));
    }

    // ---------------------------------------------------------------------------------
    // Barra de controles
    // ---------------------------------------------------------------------------------

    private void showToolbar() {
        if (toolbar != null || destroyed) return;
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(3), dp(3), dp(3), dp(3));
        GradientDrawable toolbarBg = new GradientDrawable();
        toolbarBg.setColor(Color.argb(215, 17, 24, 39));
        toolbarBg.setCornerRadius(dp(24));
        toolbar.setBackground(toolbarBg);

        handleBtn = new TextView(this);
        handleBtn.setText("Z");
        handleBtn.setTextColor(Color.WHITE);
        handleBtn.setTextSize(16);
        handleBtn.setGravity(Gravity.CENTER);
        handleBtn.setContentDescription("Mostrar u ocultar los controles. Arrastra para mover.");
        toolbar.addView(handleBtn, new LinearLayout.LayoutParams(dp(42), dp(42)));

        actionsRow = new LinearLayout(this);
        actionsRow.setOrientation(LinearLayout.HORIZONTAL);
        actionsRow.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(actionsRow, new LinearLayout.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT));

        liveBtn = addIcon(actionsRow, R.drawable.ic_zeta_play, "Traducir en vivo con Google");
        ImageView areaBtn = addIcon(actionsRow, R.drawable.ic_zeta_area, "Ajustar el área de lectura");
        langBtn = addTextButton(actionsRow, "", "Cambiar idioma de origen");
        langBtn.setMinWidth(dp(48));
        ImageView onceBtn = addIcon(actionsRow, R.drawable.ic_zeta_translate, "Traducir una vez con Google");
        subtitleBtn = addIcon(actionsRow, R.drawable.ic_zeta_hide, "Ocultar la traducción");
        ImageView closeBtn = addIcon(actionsRow, R.drawable.ic_zeta_close, "Cerrar el traductor");

        selectionRow = new LinearLayout(this);
        selectionRow.setOrientation(LinearLayout.HORIZONTAL);
        selectionRow.setGravity(Gravity.CENTER_VERTICAL);
        selectionRow.setVisibility(View.GONE);
        toolbar.addView(selectionRow, new LinearLayout.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT));
        TextView cancelBtn = addTextButton(selectionRow, "Cancelar", "Descartar los cambios del área");
        TextView doneBtn = addTextButton(selectionRow, "Listo", "Guardar el área de lectura");
        doneBtn.setTextColor(accentColor());

        handleBtn.setOnClickListener(v -> setToolbarCollapsed(!toolbarCollapsed));
        liveBtn.setOnClickListener(v -> { toggleLive(); noteToolbarInteraction(); });
        areaBtn.setOnClickListener(v -> openSelector());
        langBtn.setOnClickListener(v -> { cycleLanguage(); noteToolbarInteraction(); });
        onceBtn.setOnClickListener(v -> { translateOnce(true); noteToolbarInteraction(); });
        subtitleBtn.setOnClickListener(v -> {
            subtitleHidden = !subtitleHidden;
            if (subtitleView != null) subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
            updateToolbarState();
            noteToolbarInteraction();
        });
        closeBtn.setOnClickListener(v -> stopSelf());
        cancelBtn.setOnClickListener(v -> closeSelector(false));
        doneBtn.setOnClickListener(v -> closeSelector(true));

        toolbarParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        toolbarParams.x = safeInsets.left + dp(8);
        toolbarParams.y = safeInsets.top + dp(8);
        View.OnTouchListener toolbarDragListener = new View.OnTouchListener() {
            int startX;
            int startY;
            float touchX;
            float touchY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = toolbarParams.x;
                        startY = toolbarParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - touchX);
                        int dy = (int) (event.getRawY() - touchY);
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true;
                        toolbarParams.x = Math.max(0, Math.min(startX + dx, Math.max(0, screenWidth - dp(44))));
                        toolbarParams.y = Math.max(0, Math.min(startY + dy, Math.max(0, screenHeight - dp(44))));
                        safeUpdate(toolbar, toolbarParams);
                        updateStatusPosition();
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) v.performClick();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return false;
            }
        };
        toolbar.setOnTouchListener(toolbarDragListener);
        handleBtn.setOnTouchListener(toolbarDragListener);
        updateToolbarState();
        safeAdd(toolbar, toolbarParams);
    }

    private ImageView addIcon(LinearLayout parent, int drawable, String description) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(drawable);
        icon.setColorFilter(Color.WHITE);
        icon.setScaleType(ImageView.ScaleType.CENTER);
        icon.setContentDescription(description);
        icon.setOnLongClickListener(v -> {
            showStatus(String.valueOf(v.getContentDescription()), 1200);
            return true;
        });
        parent.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return icon;
    }

    private TextView addTextButton(LinearLayout parent, String text, String description) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(10), 0, dp(10), 0);
        button.setContentDescription(description);
        button.setOnLongClickListener(v -> {
            showStatus(String.valueOf(v.getContentDescription()), 1200);
            return true;
        });
        parent.addView(button, new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, dp(44)));
        return button;
    }

    private void setToolbarCollapsed(boolean collapsed) {
        toolbarCollapsed = collapsed;
        updateToolbarState();
        if (!collapsed) keepToolbarInsideScreen();
        updateStatusPosition();
        noteToolbarInteraction();
    }

    private void noteToolbarInteraction() {
        if (handler == null) return;
        handler.removeCallbacks(autoCollapseRunnable);
        if (live && !selecting && !toolbarCollapsed) {
            handler.postDelayed(autoCollapseRunnable, TOOLBAR_AUTO_COLLAPSE_MS);
        }
    }

    private void keepToolbarInsideScreen() {
        if (toolbar == null || toolbarParams == null) return;
        int unspecified = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        toolbar.measure(unspecified, unspecified);
        int maxX = Math.max(0, screenWidth - toolbar.getMeasuredWidth());
        if (toolbarParams.x > maxX) {
            toolbarParams.x = maxX;
            safeUpdate(toolbar, toolbarParams);
        }
    }

    /** Refleja el estado actual en la barra. Un punto fijo de color, sin parpadeos. */
    private void updateToolbarState() {
        if (toolbar == null) return;
        boolean showActions = !selecting && !toolbarCollapsed;
        actionsRow.setVisibility(showActions ? View.VISIBLE : View.GONE);
        selectionRow.setVisibility(selecting ? View.VISIBLE : View.GONE);

        int stateColor = selecting ? Color.rgb(245, 158, 11)
                : live ? Color.rgb(34, 197, 94) : Color.rgb(100, 116, 139);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setShape(GradientDrawable.OVAL);
        handleBg.setColor(stateColor);
        handleBtn.setBackground(handleBg);

        liveBtn.setImageResource(live ? R.drawable.ic_zeta_pause : R.drawable.ic_zeta_play);
        liveBtn.setContentDescription(live ? "Pausar" : "Traducir en vivo con Google");
        subtitleBtn.setImageResource(subtitleHidden ? R.drawable.ic_zeta_show : R.drawable.ic_zeta_hide);
        subtitleBtn.setContentDescription(subtitleHidden ? "Mostrar la traducción" : "Ocultar la traducción");
        langBtn.setText(languageChip());
    }

    private String languageChip() {
        String mode = languageModes[languageIndex];
        if (!TranslatorEngine.MODE_AUTO.equals(mode)) return shortLanguage(mode);
        String locked = engine == null ? null : engine.getAutoLockedMode();
        return locked == null ? "Auto" : "Auto " + shortLanguage(locked);
    }

    private String shortLanguage(String mode) {
        if (TranslatorEngine.MODE_CHINESE.equals(mode)) return "ZH";
        if (TranslatorEngine.MODE_ENGLISH.equals(mode)) return "EN";
        if (TranslatorEngine.MODE_JAPANESE.equals(mode)) return "JA";
        if (TranslatorEngine.MODE_KOREAN.equals(mode)) return "KO";
        return "Auto";
    }

    // ---------------------------------------------------------------------------------
    // Área de lectura
    // ---------------------------------------------------------------------------------

    private int accentColor() {
        return prefs.getInt(KEY_ACCENT, DEFAULT_ACCENT);
    }

    private void openSelector() {
        if (selecting || destroyed) return;
        handler.removeCallbacks(autoCollapseRunnable);
        selectorRectBeforeEdit = new Rect(selectorRect);
        if (busy) invalidateActiveRequest();
        engine.resetStabilityState();
        invalidateTranslationQueue();
        showSelector();
        selecting = true;
        updateToolbarState();
        keepToolbarInsideScreen();
    }

    private void closeSelector(boolean accept) {
        if (!selecting) return;
        hideSelector();
        selecting = false;
        if (!accept && selectorRectBeforeEdit != null) selectorRect = selectorRectBeforeEdit;
        selectorRectBeforeEdit = null;
        roiVersion++;
        if (busy) invalidateActiveRequest();
        engine.resetStabilityState();
        resetTranslationSwitchState();
        invalidateTranslationQueue();
        repositionSubtitleIfAutomatic();
        updateToolbarState();
        keepToolbarInsideScreen();
        noteToolbarInteraction();
        if (accept && subtitleOverlapsSelector()) showStatus("La caja tapa el área de lectura", 1600);
        else showStatus(accept ? "Área guardada" : "Sin cambios", 800);
    }

    private void showSelector() {
        if (selectorView != null || destroyed) return;
        final SelectorOverlayView view = new SelectorOverlayView(this, selectorRect, accentColor());
        selectorView = view;
        view.setOnRectChangedListener(rect -> {
            // La vista puede no empezar en la esquina de la pantalla y la captura sí.
            int[] location = new int[2];
            view.getLocationOnScreen(location);
            rect.offset(location[0], location[1]);
            selectorRect = clampScreenRect(rect);
            repositionSubtitleIfAutomatic();
        });
        selectorParams = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        selectorParams.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        safeAdd(selectorView, selectorParams);
        view.post(() -> {
            int[] location = new int[2];
            view.getLocationOnScreen(location);
            if (location[0] != 0 || location[1] != 0) {
                Rect local = new Rect(selectorRect);
                local.offset(-location[0], -location[1]);
                view.setRect(local);
            }
        });
        bringToolbarToFront();
    }

    private void bringToolbarToFront() {
        if (toolbar != null && toolbarParams != null) {
            safeRemove(toolbar);
            safeAdd(toolbar, toolbarParams);
        }
    }

    private void hideSelector() {
        if (selectorView != null) {
            safeRemove(selectorView);
            selectorView = null;
        }
    }

    // ---------------------------------------------------------------------------------
    // Vivo, idioma y captura
    // ---------------------------------------------------------------------------------

    private void toggleLive() {
        live = !live;
        handler.removeCallbacks(liveRunnable);
        if (live) {
            if (selecting) closeSelector(true);
            showStatus("Preparando", 800);
            engine.resetStabilityState();
            engine.warmUpMode(languageModes[languageIndex]);
            lastTextSeenAt = clock();
            handler.postDelayed(liveRunnable, 35L);
        } else {
            priorityCapturePending = false;
            invalidateActiveRequest();
            invalidateTranslationQueue();
            showStatus("Pausado", 700);
            engine.resetStabilityState();
        }
        updateToolbarState();
    }

    private void cycleLanguage() {
        int installedCount = installedLanguageCount();
        if (installedCount <= 1) {
            chooseInitialLanguageMode();
        } else {
            int attempts = 0;
            do {
                languageIndex = (languageIndex + 1) % languageModes.length;
                attempts++;
            } while (attempts < languageModes.length
                    && !TranslatorEngine.MODE_AUTO.equals(languageModes[languageIndex])
                    && !isModeInstalled(languageModes[languageIndex]));
        }

        // El idioma elegido por el usuario tiene prioridad absoluta desde este instante.
        // El OCR/traductor anterior puede terminar internamente, pero ya no puede tocar el cuadro.
        priorityCapturePending = live;
        if (busy) {
            // ML Kit no permite cancelar con seguridad una lectura ya iniciada.
            invalidateActiveRequest();
        }
        engine.resetAutoState();
        engine.resetStabilityState();
        invalidateTranslationQueue();
        resetTranslationSwitchState();
        updateToolbarState();
        if (!busy) {
            engine.warmUpMode(languageModes[languageIndex]);
            if (live) {
                handler.removeCallbacks(liveRunnable);
                priorityCapturePending = false;
                handler.post(liveRunnable);
            }
        }
        showStatus(languageLabel(languageModes[languageIndex]) + " → Español", 1000);
    }

    private void chooseInitialLanguageMode() {
        // Inglés fijo es la opción inicial: evita que Auto pruebe OCR y modelos innecesarios.
        if (isModeInstalled(TranslatorEngine.MODE_ENGLISH)) {
            languageIndex = 1;
            return;
        }

        int onlyIndex = -1;
        int count = 0;
        for (int i = 1; i < languageModes.length; i++) {
            if (isModeInstalled(languageModes[i])) {
                count++;
                onlyIndex = i;
            }
        }
        languageIndex = count == 1 ? onlyIndex : 0;
    }

    private int installedLanguageCount() {
        int count = 0;
        for (int i = 1; i < languageModes.length; i++) {
            if (isModeInstalled(languageModes[i])) count++;
        }
        return count;
    }

    private boolean isModeInstalled(String mode) {
        return prefs.getBoolean(MainActivity.KEY_MODEL_PREFIX + mode, false);
    }

    private String languageLabel(String mode) {
        if (TranslatorEngine.MODE_AUTO.equals(mode)) return "Auto";
        if (TranslatorEngine.MODE_CHINESE.equals(mode)) return "Chino";
        if (TranslatorEngine.MODE_ENGLISH.equals(mode)) return "Inglés";
        if (TranslatorEngine.MODE_JAPANESE.equals(mode)) return "Japonés";
        if (TranslatorEngine.MODE_KOREAN.equals(mode)) return "Coreano";
        return "Auto";
    }

    private void translateOnce(boolean userRequested) {
        if (destroyed) return;
        long now = clock();
        if (busy) {
            // ML Kit no ofrece cancelación segura de una lectura OCR ya iniciada.
            // Nunca abrimos otra lectura ni cerramos el recognizer mientras la anterior sigue viva.
            if (userRequested) showStatus("Un momento…", 650);
            return;
        }
        boolean needsFreshFrame = false;
        if (selecting) {
            if (!userRequested) {
                // Mientras se ajusta el área no se captura: leer ahora haría parpadear el borde.
                handler.removeCallbacks(liveRunnable);
                handler.postDelayed(liveRunnable, 250L);
                return;
            }
            closeSelector(true);
            needsFreshFrame = true;
        }
        if (mediaProjection == null || imageReader == null) {
            showStatus("Falta permiso de captura", 1600);
            return;
        }
        if (userRequested) {
            lastShownSubtitle = "";
            engine.resetAutoState();
            engine.resetStabilityState();
            resetTranslationSwitchState();
        }
        busy = true;
        busyStartedAt = now;
        lastBusyNoticeAt = 0L;
        int requestId = ++requestSerial;
        activeRequestId = requestId;
        busyRequestId = requestId;
        if (needsFreshFrame) drainImages();
        hideAllForCleanCapture();
        final boolean manual = userRequested;
        if (needsFreshFrame) handler.postDelayed(() -> captureAndTranslate(0, requestId, manual), 30L);
        else captureAndTranslate(0, requestId, manual);
    }

    private void checkForStuckWork() {
        long now = clock();
        if (busy && now - busyStartedAt > OCR_SLOW_NOTICE_MS && now - lastBusyNoticeAt > OCR_SLOW_NOTICE_MS) {
            lastBusyNoticeAt = now;
            DebugLog.metric(this, "OCR_LENTO", (now - busyStartedAt) + "ms");
            showStatus("Lectura lenta…", 900);
        }
        if (busy && now - busyStartedAt > OCR_RECOVER_MS) recoverEngine();

        TranslationScheduler.Job next = scheduler.abandonIfStuck(now);
        if (next != null) startJob(next);
    }

    /**
     * Si una lectura no vuelve nunca se monta un motor nuevo. El viejo se cierra solo cuando
     * termine lo que tiene en curso, así nadie usa un objeto cerrado ni hay reinicios sin fin.
     */
    private void recoverEngine() {
        if (engineRecoveries >= MAX_ENGINE_RECOVERIES) {
            live = false;
            handler.removeCallbacks(liveRunnable);
            busy = false;
            busyRequestId = 0;
            updateToolbarState();
            showStatus("Reinicia el traductor", 2500);
            return;
        }
        engineRecoveries++;
        DebugLog.metric(this, "RECUPERACION", "motor nuevo " + engineRecoveries);
        TranslatorEngine stuck = engine;
        engine = new TranslatorEngine(getApplicationContext());
        stuck.close();
        busy = false;
        busyRequestId = 0;
        invalidateActiveRequest();
        invalidateTranslationQueue();
        resetTranslationSwitchState();
        if (live) {
            handler.removeCallbacks(liveRunnable);
            engine.warmUpMode(languageModes[languageIndex]);
            handler.postDelayed(liveRunnable, 200L);
        }
    }

    private void hideAllForCleanCapture() {
        if (captureViewsHidden) return;
        captureViewsHidden = true;
        if (selectorView != null) {
            selectorVisibilityBeforeCapture = selectorView.getVisibility();
            selectorView.setVisibility(View.INVISIBLE);
        }
        if (statusView != null) {
            statusVisibilityBeforeCapture = statusView.getVisibility();
            statusView.setVisibility(View.INVISIBLE);
        }
        // El subtítulo traducido NO se oculta durante cada captura: producía un parpadeo
        // constante. La zona que tapa se descarta por posición y su texto se descarta por contenido.
    }

    private boolean subtitleOverlapsSelector() {
        if (subtitleView == null || subtitleParams == null || selectorRect == null
                || subtitleView.getVisibility() != View.VISIBLE) return false;
        return Rect.intersects(subtitleBounds(), selectorRect);
    }

    private Rect subtitleBounds() {
        int width = subtitleParams.width > 0 ? subtitleParams.width : subtitleView.getWidth();
        int height = Math.max(dp(1), Math.max(subtitleView.getHeight(), subtitleView.getMeasuredHeight()));
        return new Rect(subtitleParams.x, subtitleParams.y, subtitleParams.x + width, subtitleParams.y + height);
    }

    private void restoreAfterCapture() {
        if (!captureViewsHidden) return;
        captureViewsHidden = false;
        if (selectorView != null) selectorView.setVisibility(selectorVisibilityBeforeCapture);
        if (statusView != null) {
            boolean statusStillValid = statusVisibilityBeforeCapture == View.VISIBLE
                    && statusVisibleUntil > clock();
            statusView.setVisibility(statusStillValid ? View.VISIBLE : View.GONE);
        }
    }

    /** Zonas del área de lectura tapadas por la interfaz de Zeta, en proporción 0..1. */
    private float[][] buildOverlayExclusions(Rect selection) {
        List<float[]> zones = new ArrayList<>(2);
        if (subtitleView != null && subtitleParams != null && subtitleView.getVisibility() == View.VISIBLE) {
            addExclusion(zones, selection, subtitleBounds());
        }
        if (toolbar != null && toolbarParams != null) {
            addExclusion(zones, selection, new Rect(toolbarParams.x, toolbarParams.y,
                    toolbarParams.x + toolbar.getWidth(), toolbarParams.y + toolbar.getHeight()));
        }
        return zones.isEmpty() ? null : zones.toArray(new float[0][]);
    }

    private void addExclusion(List<float[]> zones, Rect selection, Rect overlay) {
        if (selection.width() <= 0 || selection.height() <= 0) return;
        Rect overlap = new Rect(overlay);
        if (!overlap.intersect(selection)) return;
        zones.add(new float[]{
                (overlap.left - selection.left) / (float) selection.width(),
                (overlap.top - selection.top) / (float) selection.height(),
                (overlap.right - selection.left) / (float) selection.width(),
                (overlap.bottom - selection.top) / (float) selection.height()
        });
    }

    private void captureAndTranslate(int attempt, int requestId, boolean manualRequest) {
        if (destroyed) return;
        if (requestId != activeRequestId || imageReader == null) {
            restoreAfterCapture();
            finishRequest(requestId);
            return;
        }

        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                // Sin imagen nueva la pantalla no ha cambiado: no hay nada que leer. No es un
                // fallo; antes esto acababa reconstruyendo la captura una y otra vez.
                int retries = manualRequest ? 16 : 1;
                // Una orden manual sobre una imagen quieta necesita un fotograma: se le pide uno a Android.
                if (manualRequest && attempt == 8 && !captureWorkerActive) resizeCaptureSurface();
                if (attempt < retries) {
                    handler.postDelayed(() -> captureAndTranslate(attempt + 1, requestId, manualRequest), 25L);
                } else {
                    restoreAfterCapture();
                    unchangedFrames++;
                    lastFrameUnchanged = true;
                    if (manualRequest) showStatus("La pantalla no cambió", 900);
                    String[] confirmed = !manualRequest && awaitingConfirmation
                            ? engine.confirmReadingOnUnchangedScreen() : null;
                    if (confirmed != null) awaitingConfirmation = false;
                    finishRequest(requestId);
                    if (confirmed != null && live && !destroyed
                            && (requestId == activeRequestId)) {
                        SegmentMeta meta = new SegmentMeta();
                        meta.frameAt = engine.getLastAcceptedFirstSeenAt();
                        meta.acceptedAt = clock();
                        meta.roi = roiVersion;
                        meta.rawOcr = engine.getLastRawOcr();
                        handleRecognizedText(confirmed[0], confirmed[1], engine.readable(confirmed[1]), false, meta);
                    }
                }
                return;
            }
            lastFrameUnchanged = false;
            final Image capturedImage = image;
            final long frameAt = clock();
            final Rect requestedSelector = selectorRect == null ? defaultRect() : new Rect(selectorRect);
            final float[][] exclusions = buildOverlayExclusions(requestedSelector);
            final int requestedScreenWidth = Math.max(1, screenWidth);
            final int requestedScreenHeight = Math.max(1, screenHeight);
            final String requestedMode = languageModes[languageIndex];
            final int requestedRoi = roiVersion;
            image = null;

            // El fotograma ya quedó adquirido: restauramos enseguida los overlays y movemos
            // conversión, recorte y preparación fuera del hilo principal para evitar ANR/cierres.
            restoreAfterCapture();
            captureWorkerActive = true;
            try {
                captureExecutor.execute(() -> processCapturedImage(
                        capturedImage, requestId, manualRequest, requestedSelector,
                        requestedScreenWidth, requestedScreenHeight, requestedMode,
                        frameAt, exclusions, requestedRoi));
            } catch (RejectedExecutionException rejected) {
                captureWorkerActive = false;
                try { capturedImage.close(); } catch (Exception ignored) { }
                finishRequest(requestId);
            }
        } catch (Exception e) {
            if (image != null) {
                try { image.close(); } catch (Exception ignored) { }
            }
            restoreAfterCapture();
            DebugLog.metric(this, "ERROR_CAPTURA", safeMessage(e));
            finishRequest(requestId);
        }
    }

    private void processCapturedImage(Image image, int requestId, boolean manualRequest,
                                      Rect requestedSelector, int requestedScreenWidth,
                                      int requestedScreenHeight, String requestedMode,
                                      long frameAt, float[][] exclusions, int requestedRoi) {
        Bitmap crop = null;
        try {
            if (destroyed || requestId != activeRequestId) {
                handler.post(() -> finishRequest(requestId));
                return;
            }
            crop = imageToCropBitmap(image, requestedSelector, requestedScreenWidth, requestedScreenHeight);
            if (crop == null || crop.isRecycled()) {
                throw new IllegalStateException("No se pudo crear el recorte de pantalla");
            }
            final int cropWidth = crop.getWidth();
            final int cropHeight = crop.getHeight();

            // El límite se aplica antes del primer OCR, no solo en el rescate.
            float scale = CapturePolicy.firstPassScale(cropWidth, cropHeight);
            if (scale < 0.999f) {
                Bitmap scaled = Bitmap.createScaledBitmap(crop,
                        Math.max(2, Math.round(cropWidth * scale)),
                        Math.max(2, Math.round(cropHeight * scale)), true);
                if (scaled != crop) {
                    recycleBitmap(crop);
                    crop = scaled;
                }
            }

            final Bitmap requestCrop = crop;
            crop = null;
            final boolean requireStableText = !manualRequest;
            final long ocrStartedAt = clock();
            final int ocrWidth = requestCrop.getWidth();
            final int ocrHeight = requestCrop.getHeight();
            final TranslatorEngine requestEngine = engine;
            requestEngine.setFrameTime(frameAt);
            requestEngine.setOverlayExclusions(exclusions);
            try {
                requestEngine.recognizeStable(requestCrop, requestedMode, requireStableText, new TranslatorEngine.RecognitionCallback() {
                    @Override public void onText(String original, String sourceLanguage, String sourceName) {
                        final long ocrMs = clock() - ocrStartedAt;
                        final String rawOcr = requestEngine.getLastRawOcr();
                        final long firstSeen = manualRequest ? frameAt : requestEngine.getLastAcceptedFirstSeenAt();
                        recycleBitmap(requestCrop);
                        handler.post(() -> {
                            noteOcrFinished(ocrMs, cropWidth, cropHeight, ocrWidth, ocrHeight);
                            awaitingConfirmation = false;
                            lastTextSeenAt = clock();
                            finishRequest(requestId);
                            if (destroyed || requestId != activeRequestId) return;
                            if (!manualRequest && !live) return;
                            if (!requestedMode.equals(languageModes[languageIndex])) return;
                            SegmentMeta meta = new SegmentMeta();
                            meta.frameAt = firstSeen > 0L ? firstSeen : frameAt;
                            meta.acceptedAt = clock();
                            meta.ocrMs = ocrMs;
                            meta.cropWidth = cropWidth;
                            meta.cropHeight = cropHeight;
                            meta.ocrWidth = ocrWidth;
                            meta.ocrHeight = ocrHeight;
                            meta.roi = requestedRoi;
                            meta.rawOcr = rawOcr;
                            handleRecognizedText(original, sourceLanguage, sourceName, manualRequest, meta);
                        });
                    }

                    @Override public void onError(String message) {
                        final long ocrMs = clock() - ocrStartedAt;
                        recycleBitmap(requestCrop);
                        handler.post(() -> {
                            noteOcrFinished(ocrMs, cropWidth, cropHeight, ocrWidth, ocrHeight);
                            String lower = message == null ? "" : message.toLowerCase(Locale.ROOT);
                            boolean noText = lower.contains("no se detect") || lower.contains("esperando texto claro");
                            boolean changed = lower.contains("cambio de subtítulo") || lower.contains("esperando subtítulo");
                            awaitingConfirmation = changed;
                            if (!noText) lastTextSeenAt = clock();
                            boolean current = !destroyed && requestId == activeRequestId;
                            if (current && noText && !manualRequest && requestEngine.noteNoTextDetected()) {
                                clearSegmentIdentity();
                            }
                            finishRequest(requestId);
                            if (!current || (!manualRequest && !live)) return;
                            if (noText) {
                                if (manualRequest) showStatus("Sin texto", 900);
                            } else if (!changed && !lower.contains("mismo subtítulo")) {
                                reportProblem(message);
                            }
                        });
                    }
                });
            } catch (OutOfMemoryError oom) {
                recycleBitmap(requestCrop);
                throw oom;
            } catch (RuntimeException startError) {
                recycleBitmap(requestCrop);
                throw startError;
            }
        } catch (OutOfMemoryError oom) {
            recycleBitmap(crop);
            cropBuffer = null;
            handler.post(() -> {
                finishRequest(requestId);
                DebugLog.metric(this, "SIN_MEMORIA", "recorte");
                if (destroyed || requestId != activeRequestId) return;
                showStatus("Poca memoria: reduce el área", 1500);
            });
        } catch (Exception e) {
            recycleBitmap(crop);
            handler.post(() -> {
                finishRequest(requestId);
                DebugLog.metric(this, "ERROR_OCR", safeMessage(e));
            });
        } finally {
            captureWorkerActive = false;
            try { image.close(); } catch (Exception ignored) { }
        }
    }

    private void noteOcrFinished(long ocrMs, int cropWidth, int cropHeight, int ocrWidth, int ocrHeight) {
        lastOcrMs = ocrMs;
        ocrCount++;
        ocrTotalMs += ocrMs;
        lastCropWidth = cropWidth;
        lastCropHeight = cropHeight;
        lastOcrWidth = ocrWidth;
        lastOcrHeight = ocrHeight;
    }

    /** Solo llega a la pantalla lo que el usuario puede resolver; el resto va al registro. */
    private void reportProblem(String message) {
        DebugLog.metric(this, "AVISO", message);
        String lower = message == null ? "" : message.toLowerCase(Locale.ROOT);
        if (lower.contains("descarga")) showStatus("Falta el idioma", 1500);
        else if (lower.contains("memoria")) showStatus("Poca memoria: reduce el área", 1500);
    }

    private void recycleBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try { bitmap.recycle(); } catch (Exception ignored) { }
        }
    }

    private void drainImages() {
        if (imageReader == null) return;
        Image old = null;
        try {
            while ((old = imageReader.acquireLatestImage()) != null) {
                old.close();
                old = null;
            }
        } catch (Exception ignored) {
            if (old != null) { try { old.close(); } catch (Exception ignored2) { } }
        }
    }

    private Bitmap imageToCropBitmap(Image image, Rect selection, int sourceScreenWidth, int sourceScreenHeight) {
        if (image == null) return null;
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0) return null;
        Image.Plane plane = planes[0];
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        Rect cropRect = mapSelectorToBitmap(selection, imageWidth, imageHeight,
                sourceScreenWidth, sourceScreenHeight);

        // RGBA_8888 normalmente llega con 4 bytes por píxel. Empaquetamos solo las filas
        // del área OCR en lugar de crear un bitmap de toda la pantalla en cada captura.
        if (pixelStride == 4 && cropRect.width() > 0 && cropRect.height() > 0) {
            ByteBuffer source = plane.getBuffer().duplicate();
            int base = source.position();
            // Un área enorme ya no da error: se toma un píxel de cada "step".
            int step = CapturePolicy.cropStep(cropRect.width(), cropRect.height());
            int outWidth = Math.max(2, cropRect.width() / step);
            int outHeight = Math.max(2, cropRect.height() / step);
            int rowBytes = outWidth * 4;
            int needed = rowBytes * outHeight;
            // Este búfer solo lo toca el hilo de captura: se reutiliza para no generar basura.
            if (cropBuffer == null || cropBuffer.length < needed) cropBuffer = new byte[needed];
            byte[] packed = cropBuffer;
            for (int y = 0; y < outHeight; y++) {
                int sourcePos = base + (cropRect.top + y * step) * rowStride + cropRect.left * pixelStride;
                int targetPos = y * rowBytes;
                if (sourcePos < 0 || sourcePos + (outWidth * step * 4) > source.limit()) {
                    throw new IllegalStateException("Recorte fuera del búfer de captura");
                }
                if (step == 1) {
                    source.position(sourcePos);
                    source.get(packed, targetPos, rowBytes);
                } else {
                    for (int x = 0; x < outWidth; x++) {
                        int pixel = sourcePos + x * step * 4;
                        packed[targetPos + x * 4] = source.get(pixel);
                        packed[targetPos + x * 4 + 1] = source.get(pixel + 1);
                        packed[targetPos + x * 4 + 2] = source.get(pixel + 2);
                        packed[targetPos + x * 4 + 3] = source.get(pixel + 3);
                    }
                }
            }
            Bitmap crop = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888);
            crop.copyPixelsFromBuffer(ByteBuffer.wrap(packed, 0, needed));
            return crop;
        }

        // Compatibilidad con dispositivos que entreguen un formato/stride inusual.
        Bitmap full = imageToBitmapFallback(image);
        try {
            Rect safe = clampCrop(cropRect, full.getWidth(), full.getHeight());
            Bitmap result = Bitmap.createBitmap(full, safe.left, safe.top, safe.width(), safe.height());
            // createBitmap puede devolver el mismo objeto si el recorte abarca toda la imagen.
            // En ese caso hacemos una copia antes de liberar el bitmap temporal completo.
            if (result == full) {
                result = full.copy(Bitmap.Config.ARGB_8888, false);
            }
            return result;
        } finally {
            recycleBitmap(full);
        }
    }

    private Bitmap imageToBitmapFallback(Image image) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer().duplicate();
        buffer.rewind();
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = Math.max(0, rowStride - pixelStride * imageWidth);
        int bitmapWidth = imageWidth + rowPadding / Math.max(1, pixelStride);
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, imageHeight, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        if (bitmapWidth != imageWidth) {
            Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, imageWidth, imageHeight);
            bitmap.recycle();
            return cropped;
        }
        return bitmap;
    }

    private Rect mapSelectorToBitmap(Rect selection, int bitmapWidth, int bitmapHeight,
                                     int sourceScreenWidth, int sourceScreenHeight) {
        Rect safeSelection = selection == null ? defaultRect() : selection;
        float sx = sourceScreenWidth > 0 ? bitmapWidth / (float) sourceScreenWidth : 1f;
        float sy = sourceScreenHeight > 0 ? bitmapHeight / (float) sourceScreenHeight : 1f;
        Rect mapped = new Rect(
                Math.round(safeSelection.left * sx),
                Math.round(safeSelection.top * sy),
                Math.round(safeSelection.right * sx),
                Math.round(safeSelection.bottom * sy)
        );
        return clampCrop(mapped, bitmapWidth, bitmapHeight);
    }

    private Rect clampCrop(Rect r, int maxW, int maxH) {
        int left = Math.max(0, Math.min(r.left, maxW - 2));
        int top = Math.max(0, Math.min(r.top, maxH - 2));
        int right = Math.max(left + 2, Math.min(r.right, maxW));
        int bottom = Math.max(top + 2, Math.min(r.bottom, maxH));
        return new Rect(left, top, right, bottom);
    }

    private Rect clampScreenRect(Rect r) {
        int minW = Math.min(screenWidth, dp(120));
        int minH = Math.min(screenHeight, dp(44));
        int width = Math.max(minW, Math.min(r.width(), screenWidth));
        int height = Math.max(minH, Math.min(r.height(), screenHeight));
        int left = Math.max(0, Math.min(r.left, Math.max(0, screenWidth - width)));
        int top = Math.max(0, Math.min(r.top, Math.max(0, screenHeight - height)));
        return new Rect(left, top, left + width, top + height);
    }

    // ---------------------------------------------------------------------------------
    // De la frase leída a la traducción visible
    // ---------------------------------------------------------------------------------

    private void handleRecognizedText(String original, String sourceLanguage, String sourceName,
                                      boolean manualRequest, SegmentMeta meta) {
        String sourceKey = SubtitleMatcher.normalizeKey(original);
        if (sourceKey.isEmpty()) return;
        long now = clock();
        if (!manualRequest) {
            if (SubtitleMatcher.nearlyIdentical(lastFailedTranslationKey, sourceKey)
                    && now - lastFailedTranslationAt < FAILED_RETRY_GUARD_MS) {
                // Se olvida otra vez para que, pasada la pausa, el OCR pueda volver a ofrecerla.
                engine.forgetAcceptedSubtitle();
                return;
            }
            // Una traducción ya mostrada queda fija mientras el OCR solo esté refinando la misma frase.
            if (sourceLanguage != null && sourceLanguage.equals(currentSourceMode)
                    && now - currentSourceCommittedAt < SAME_SUBTITLE_GUARD_MS
                    && SubtitleMatcher.sameVisualSubtitle(currentSourceKey, sourceKey)) return;
            if (SubtitleMatcher.nearlyIdentical(currentSourceKey, sourceKey)) return;
            if (scheduler.isActiveSimilar(sourceKey, sourceLanguage)) return;
        }
        submitTranslation(original, sourceLanguage, sourceName, manualRequest, meta);
    }

    private void submitTranslation(String original, String sourceLanguage, String sourceName,
                                   boolean manualRequest, SegmentMeta meta) {
        if (destroyed) return;
        long now = clock();
        meta.submittedAt = now;

        // Sin esperas: la frase se traduce en cuanto el OCR la confirma. Si la anterior quedó
        // cortada, la segunda vuelta se traduce con las dos mitades y reemplaza a la primera.
        String text = original;
        boolean joined = false;
        if (!manualRequest && SubtitleMatcher.canJoinContext(previousSegmentText, previousSegmentLanguage,
                previousSegmentAt, original, sourceLanguage, now)) {
            text = SubtitleMatcher.joinContext(previousSegmentText, original, sourceLanguage);
            joined = true;
        }
        previousSegmentText = original;
        previousSegmentLanguage = sourceLanguage == null ? "" : sourceLanguage;
        previousSegmentAt = now;

        String sourceKey = SubtitleMatcher.normalizeKey(text);
        if (sourceKey.isEmpty()) return;
        String immediate = engine.getImmediateTranslation(text, sourceLanguage);
        TranslationScheduler.Job job = scheduler.newJob(text, sourceLanguage, sourceName, sourceKey,
                manualRequest, meta.frameAt, immediate, joined);
        job.meta = meta;

        if (immediate != null && !immediate.trim().isEmpty()) {
            scheduler.publishImmediate(job, now);
            boolean shown = handleTranslationResult(text, immediate, sourceName, sourceLanguage, manualRequest, job);
            logSegment(job, shown ? "cache" : "repetida", null, immediate);
            return;
        }
        TranslationScheduler.Job start = scheduler.submit(job, now);
        if (start != null) startJob(start);
    }

    private void startJob(final TranslationScheduler.Job job) {
        if (destroyed) return;
        final TranslatorEngine requestEngine = engine;
        requestEngine.translateRecognized(job.original, job.sourceMode, new TranslatorEngine.Callback() {
            @Override public void onSuccess(String translatedOriginal, String translated, String translatedSourceName) {
                handler.post(() -> onJobSucceeded(job, translatedOriginal, translated, translatedSourceName, requestEngine));
            }

            @Override public void onError(String message) {
                handler.post(() -> onJobFailed(job, message));
            }
        });
    }

    private void onJobSucceeded(TranslationScheduler.Job job, String translatedOriginal, String translated,
                                String translatedSourceName, TranslatorEngine requestEngine) {
        if (destroyed) return;
        TranslationScheduler.Completion done = scheduler.complete(job.id, clock());
        if (done.publish) {
            if (SubtitleMatcher.nearlyIdentical(lastFailedTranslationKey, job.sourceKey)) {
                lastFailedTranslationKey = "";
                lastFailedTranslationAt = 0L;
            }
            boolean shown = handleTranslationResult(translatedOriginal, translated,
                    translatedSourceName == null ? job.sourceName : translatedSourceName,
                    job.sourceMode, job.manual, job);
            logSegment(job, shown ? "mostrada" : "repetida", requestEngine.getLastRawTranslation(), translated);
        }
        if (done.next != null) startJob(done.next);
    }

    private void onJobFailed(TranslationScheduler.Job job, String message) {
        if (destroyed) return;
        long now = clock();
        TranslationScheduler.Completion done = scheduler.fail(job.id, now);
        if (done.job != null && done.dropReason == null) {
            lastFailedTranslationKey = job.sourceKey;
            lastFailedTranslationAt = now;
            // La última traducción válida se queda en pantalla. Si no hay otra frase detrás,
            // se permite que el OCR vuelva a ofrecer esta cuando pase la pausa de reintento.
            if (done.next == null) engine.forgetAcceptedSubtitle();
            logSegment(job, "fallo", null, null);
            reportProblem(message);
        }
        if (done.next != null) startJob(done.next);
    }

    private void onJobDropped(TranslationScheduler.Job job, String reason) {
        logSegment(job, "descartada", reason, null);
    }

    private void logSegment(TranslationScheduler.Job job, String state, String rawOutput, String finalOutput) {
        if (!DebugLog.isEnabled(this)) return;
        long now = clock();
        SegmentMeta meta = job.meta instanceof SegmentMeta ? (SegmentMeta) job.meta : new SegmentMeta();
        boolean dropped = "descartada".equals(state);
        DebugLog.json(this, "segmento",
                "sesion", sessionId,
                "seg", job.id,
                "idioma", job.sourceMode,
                "modo", languageModes[languageIndex],
                "roi", meta.roi,
                "recorte", meta.cropWidth + "x" + meta.cropHeight,
                "ocr_px", meta.ocrWidth + "x" + meta.ocrHeight,
                "ocr_ms", meta.ocrMs,
                "confirmar_ms", meta.acceptedAt - job.firstSeenAt,
                "espera_ms", job.startedAt > 0L ? job.startedAt - meta.submittedAt : -1L,
                "traducir_ms", job.startedAt > 0L ? now - job.startedAt : 0L,
                "total_ms", now - job.firstSeenAt,
                "unida", job.joined,
                "estado", state,
                "motivo", dropped ? rawOutput : "",
                "motor", "mlkit-17.0.3",
                "t_ocr_crudo", meta.rawOcr,
                "t_ocr", job.original,
                "t_salida_cruda", dropped ? "" : rawOutput,
                "t_salida", finalOutput);
    }

    private void logSessionState() {
        if (!DebugLog.isEnabled(this) || sessionStartedAt == 0L) return;
        Runtime runtime = Runtime.getRuntime();
        DebugLog.json(this, "estado",
                "sesion", sessionId,
                "minutos", (clock() - sessionStartedAt) / 60000L,
                "vivo", live,
                "ocr_n", ocrCount,
                "ocr_ms_media", ocrCount == 0 ? 0L : ocrTotalMs / ocrCount,
                "sin_cambio", unchangedFrames,
                "recorte", lastCropWidth + "x" + lastCropHeight,
                "ocr_px", lastOcrWidth + "x" + lastOcrHeight,
                "publicadas", scheduler.published,
                "descartadas", scheduler.dropped,
                "trabadas", scheduler.stuck,
                "java_mb", (runtime.totalMemory() - runtime.freeMemory()) >> 20,
                "nativa_mb", Debug.getNativeHeapAllocatedSize() >> 20,
                "termico", thermalNow);
    }

    private int readThermalStatus() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || powerManager == null) return 0;
        return powerManager.getCurrentThermalStatus();
    }

    private void invalidateTranslationQueue() {
        // Una traducción ya iniciada termina de forma natural; su resultado se descarta.
        scheduler.invalidate();
        lastFailedTranslationKey = "";
        lastFailedTranslationAt = 0L;
        previousSegmentText = "";
        previousSegmentLanguage = "";
        previousSegmentAt = 0L;
    }

    /** @return true si cambió lo que se ve en pantalla */
    private boolean handleTranslationResult(String original, String translated, String sourceName,
                                            String sourceMode, boolean manualRequest, TranslationScheduler.Job job) {
        String sourceKey = SubtitleMatcher.normalizeKey(original);
        String cleanTranslation = makeSubtitleText(translated);
        if (sourceKey.length() == 0 || cleanTranslation.length() == 0) return false;
        if (!manualRequest && SubtitleMatcher.nearlyIdentical(currentSourceKey, sourceKey)) return false;
        scheduler.noteShown(job);
        currentSourceKey = sourceKey;
        currentSourceMode = sourceMode == null ? "" : sourceMode;
        currentSourceCommittedAt = clock();
        showSubtitle(cleanTranslation, sourceName);
        return true;
    }

    private void resetTranslationSwitchState() {
        currentSourceKey = "";
        currentSourceMode = "";
        currentSourceCommittedAt = 0L;
    }

    /**
     * El cartel terminó: si la misma frase reaparece se trata como nueva. La traducción
     * visible no se toca; sigue en pantalla hasta que llegue otra válida.
     */
    private void clearSegmentIdentity() {
        currentSourceKey = "";
        currentSourceCommittedAt = 0L;
    }

    // ---------------------------------------------------------------------------------
    // Caja del subtítulo
    // ---------------------------------------------------------------------------------

    private void ensureSubtitleOverlay() {
        if (destroyed) return;
        if (subtitleView == null) {
            subtitleView = new TextView(this);
            subtitleView.setTextColor(Color.WHITE);
            subtitleView.setTextSize(prefs.getInt(KEY_TEXT_SIZE, DEFAULT_TEXT_SIZE));
            subtitleView.setGravity(Gravity.CENTER);
            subtitleView.setPadding(dp(12), dp(6), dp(12), dp(6));
            subtitleView.setMinHeight(dp(36));
            GradientDrawable subtitleBg = new GradientDrawable();
            subtitleBg.setColor(Color.argb(prefs.getInt(KEY_BG_ALPHA, DEFAULT_BG_ALPHA), 0, 0, 0));
            subtitleBg.setCornerRadius(dp(10));
            subtitleView.setBackground(subtitleBg);
            subtitleView.setIncludeFontPadding(false);
            subtitleView.setLineSpacing(0f, 1.05f);
            subtitleView.setSingleLine(false);
            subtitleView.setMaxLines(5);
            subtitleView.setEllipsize(TextUtils.TruncateAt.END);
            subtitleView.setOnTouchListener(new View.OnTouchListener() {
                int startX;
                int startY;
                float touchX;
                float touchY;
                boolean draggingSubtitle;

                @Override public boolean onTouch(View v, MotionEvent event) {
                    if (subtitleParams == null) return false;
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            draggingSubtitle = false;
                            startX = subtitleParams.x;
                            startY = subtitleParams.y;
                            touchX = event.getRawX();
                            touchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int moveX = (int) (event.getRawX() - touchX);
                            int moveY = (int) (event.getRawY() - touchY);
                            // Un temblor del dedo al tocar la caja no cuenta como moverla.
                            if (!draggingSubtitle && Math.abs(moveX) < dp(6) && Math.abs(moveY) < dp(6)) return true;
                            draggingSubtitle = true;
                            subtitleParams.x = keepInRange(startX + moveX, 0, screenWidth - v.getWidth());
                            subtitleParams.y = keepInRange(startY + moveY, 0, screenHeight - v.getHeight());
                            subtitleManuallyMoved = true;
                            safeUpdate(subtitleView, subtitleParams);
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (draggingSubtitle) {
                                subtitleAnchorSet = true;
                                subtitleAnchorFromBottom = true;
                                subtitleAnchorCenterX = subtitleParams.x + v.getWidth() / 2;
                                subtitleAnchorEdgeY = subtitleParams.y + v.getHeight();
                                if (subtitleOverlapsSelector()) showStatus("La caja tapa el área de lectura", 1600);
                            }
                            return true;
                        case MotionEvent.ACTION_CANCEL:
                            return true;
                    }
                    return false;
                }
            });
        }
        if (subtitleParams == null) {
            subtitleParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private void showSubtitle(String translated, String sourceName) {
        if (destroyed) return;
        String text = makeSubtitleText(translated);
        if (text.length() == 0) return;
        if (text.equals(lastShownSubtitle) && subtitleView != null) {
            subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
            return;
        }
        lastShownSubtitle = text;
        ensureSubtitleOverlay();
        engine.setOverlayTextToIgnore(text);
        // Se reemplaza directamente: nunca hay un instante con la caja vacía.
        subtitleView.setText(withAttribution(text));
        layoutSubtitle();
        if (subtitleView.getParent() == null) safeAdd(subtitleView, subtitleParams);
        else safeUpdate(subtitleView, subtitleParams);
        subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
        updateNotification(sourceName + " → Español");
        updateToolbarState();
    }

    /** Google exige indicar el origen junto a la traducción; se deja discreto, sin quitarlo. */
    private CharSequence withAttribution(String text) {
        SpannableStringBuilder styled = new SpannableStringBuilder(text);
        int start = styled.length();
        styled.append("\npowered by Google Translate");
        styled.setSpan(new RelativeSizeSpan(0.55f), start, styled.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        styled.setSpan(new ForegroundColorSpan(Color.argb(170, 255, 255, 255)), start, styled.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return styled;
    }

    /** La caja mide lo que su texto, con un máximo, y mantiene su punto de anclaje. */
    private void layoutSubtitle() {
        if (subtitleView == null || subtitleParams == null || selectorRect == null) return;
        int usableWidth = screenWidth - safeInsets.left - safeInsets.right - dp(16);
        int maxWidth = Math.max(dp(160), (int) (usableWidth * 0.92f));
        subtitleView.setMaxWidth(maxWidth);
        subtitleView.measure(
                View.MeasureSpec.makeMeasureSpec(maxWidth, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int width = subtitleView.getMeasuredWidth();
        int height = subtitleView.getMeasuredHeight();
        if (!subtitleAnchorSet) chooseAutomaticAnchor();
        int y = subtitleAnchorFromBottom ? subtitleAnchorEdgeY - height : subtitleAnchorEdgeY;
        subtitleParams.width = width;
        subtitleParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        subtitleParams.x = keepInRange(subtitleAnchorCenterX - width / 2,
                safeInsets.left, screenWidth - safeInsets.right - width);
        subtitleParams.y = keepInRange(y, safeInsets.top, screenHeight - safeInsets.bottom - height);
    }

    private void chooseAutomaticAnchor() {
        int gap = dp(6);
        subtitleAnchorSet = true;
        subtitleAnchorCenterX = selectorRect.centerX();
        if (selectorRect.top - gap - dp(72) >= safeInsets.top) {
            // Por encima del área de lectura: crece hacia arriba y nunca la tapa.
            subtitleAnchorFromBottom = true;
            subtitleAnchorEdgeY = selectorRect.top - gap;
        } else {
            subtitleAnchorFromBottom = false;
            subtitleAnchorEdgeY = selectorRect.bottom + gap;
        }
    }

    private void repositionSubtitleIfAutomatic() {
        if (subtitleView == null || subtitleParams == null || subtitleManuallyMoved) return;
        subtitleAnchorSet = false;
        layoutSubtitle();
        if (subtitleView.getParent() != null) safeUpdate(subtitleView, subtitleParams);
    }

    private int keepInRange(int value, int min, int max) {
        return Math.max(min, Math.min(value, Math.max(min, max)));
    }

    private String makeSubtitleText(String text) {
        if (text == null) return "";
        return text.replace("\r", " ")
                .replace("\n", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    // ---------------------------------------------------------------------------------
    // Avisos, notificación y ventanas
    // ---------------------------------------------------------------------------------

    private void showStatus(String text, long durationMs) {
        if (destroyed || text == null || text.trim().length() == 0) return;
        if (statusView == null) {
            statusView = new TextView(this);
            statusView.setTextColor(Color.WHITE);
            statusView.setTextSize(12);
            statusView.setGravity(Gravity.CENTER);
            statusView.setPadding(dp(10), dp(4), dp(10), dp(4));
            GradientDrawable statusBg = new GradientDrawable();
            statusBg.setColor(Color.argb(200, 17, 24, 39));
            statusBg.setCornerRadius(dp(10));
            statusView.setBackground(statusBg);
            statusParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            statusParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            updateStatusPosition();
            safeAdd(statusView, statusParams);
        } else {
            updateStatusPosition();
        }
        statusView.setText(text);
        statusView.setVisibility(View.VISIBLE);
        statusVisibleUntil = clock() + durationMs;
        if (statusHideRunnable != null) handler.removeCallbacks(statusHideRunnable);
        statusHideRunnable = () -> {
            statusVisibleUntil = 0L;
            if (!destroyed && statusView != null) statusView.setVisibility(View.GONE);
        };
        handler.postDelayed(statusHideRunnable, durationMs);
    }

    private void updateStatusPosition() {
        if (statusParams == null) return;
        statusParams.x = toolbarParams != null ? toolbarParams.x : dp(12);
        statusParams.y = toolbarParams != null ? toolbarParams.y + dp(54) : dp(86);
        statusParams.x = Math.max(0, Math.min(statusParams.x, Math.max(0, screenWidth - dp(80))));
        statusParams.y = Math.max(0, Math.min(statusParams.y, Math.max(0, screenHeight - dp(36))));
        if (statusView != null && statusView.getParent() != null) safeUpdate(statusView, statusParams);
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width,
                height,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        // Las coordenadas del área deben coincidir con las de la captura, también junto al notch.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return params;
    }

    private Notification buildNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Traductor en pantalla", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }
        Intent stop = new Intent(this, OverlayTranslatorService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent openPending = PendingIntent.getActivity(this, 3, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return builder.setSmallIcon(R.drawable.ic_stat_zeta)
                .setContentTitle("Zeta está leyendo tu pantalla")
                .setContentText(text)
                .setContentIntent(openPending)
                .setOngoing(true)
                .addAction(0, "Detener", stopPending)
                .build();
    }

    private void updateNotification(String text) {
        if (destroyed || text.equals(lastNotificationText)) return;
        lastNotificationText = text;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void safeAdd(View view, WindowManager.LayoutParams params) {
        if (destroyed || view == null || params == null) return;
        try { windowManager.addView(view, params); } catch (Exception ignored) { }
    }

    private void safeUpdate(View view, WindowManager.LayoutParams params) {
        if (destroyed || view == null || params == null) return;
        try { windowManager.updateViewLayout(view, params); } catch (Exception ignored) { }
    }

    private void safeRemove(View view) {
        if (view == null) return;
        try { windowManager.removeView(view); } catch (Exception ignored) { }
    }

    private void invalidateActiveRequest() {
        requestSerial++;
        activeRequestId = requestSerial;
        // Si hay ML Kit trabajando, busy se conserva hasta que llegue su callback real.
        // Así no iniciamos un segundo OCR sobre el mismo recognizer por accidente.
        restoreAfterCapture();
    }

    private void finishRequest(int requestId) {
        if (busyRequestId == requestId) {
            busyRequestId = 0;
            busy = false;
            busyStartedAt = 0L;
        }
        if (live && !destroyed && !busy) {
            handler.removeCallbacks(liveRunnable);
            long delay;
            if (priorityCapturePending) {
                priorityCapturePending = false;
                engine.warmUpMode(languageModes[languageIndex]);
                delay = 0L;
            } else {
                delay = CapturePolicy.nextDelayMs(lastOcrMs, awaitingConfirmation, lastFrameUnchanged,
                        clock() - lastTextSeenAt, thermalNow);
            }
            handler.postDelayed(liveRunnable, delay);
        }
    }

    private void releaseCaptureOnly() {
        if (virtualDisplay != null) {
            try { virtualDisplay.setSurface(null); } catch (Exception ignored) { }
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }

    @Override
    public void onDestroy() {
        logSessionState();
        destroyed = true;
        live = false;
        priorityCapturePending = false;
        busy = false;
        busyRequestId = 0;
        scheduler.invalidate();
        requestSerial++;
        activeRequestId = requestSerial;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (captureExecutor != null) captureExecutor.shutdownNow();
        if (engine != null) engine.close();
        if (toolbar != null) safeRemove(toolbar);
        if (selectorView != null) safeRemove(selectorView);
        if (subtitleView != null) safeRemove(subtitleView);
        if (engine != null) engine.setOverlayTextToIgnore("");
        if (statusView != null) safeRemove(statusView);
        releaseCaptureOnly();
        if (mediaProjection != null) {
            try { mediaProjection.stop(); } catch (Exception ignored) { }
            mediaProjection = null;
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (destroyed || selectorRect == null) return;
        final int oldWidth = Math.max(1, screenWidth);
        final int oldHeight = Math.max(1, screenHeight);
        final Rect oldSelector = new Rect(selectorRect);
        final int oldToolbarX = toolbarParams == null ? 0 : toolbarParams.x;
        final int oldToolbarY = toolbarParams == null ? 0 : toolbarParams.y;

        handler.removeCallbacks(liveRunnable);
        invalidateActiveRequest();
        invalidateTranslationQueue();
        handler.postDelayed(() -> {
            if (destroyed) return;
            readMetrics();
            selectorRect = scaleRect(oldSelector, oldWidth, oldHeight, screenWidth, screenHeight);
            selectorRect = clampScreenRect(selectorRect);
            roiVersion++;
            if (selectorView != null) selectorView.setRect(selectorRect);

            if (toolbarParams != null) {
                toolbarParams.x = scaleCoordinate(oldToolbarX, oldWidth, screenWidth);
                toolbarParams.y = scaleCoordinate(oldToolbarY, oldHeight, screenHeight);
                toolbarParams.x = Math.max(0, Math.min(toolbarParams.x, Math.max(0, screenWidth - dp(44))));
                toolbarParams.y = Math.max(0, Math.min(toolbarParams.y, Math.max(0, screenHeight - dp(44))));
                safeUpdate(toolbar, toolbarParams);
                keepToolbarInsideScreen();
            }

            if (subtitleManuallyMoved) {
                subtitleAnchorCenterX = scaleCoordinate(subtitleAnchorCenterX, oldWidth, screenWidth);
                subtitleAnchorEdgeY = scaleCoordinate(subtitleAnchorEdgeY, oldHeight, screenHeight);
            } else {
                subtitleAnchorSet = false;
            }
            if (subtitleView != null && subtitleParams != null) {
                layoutSubtitle();
                if (subtitleView.getParent() != null) safeUpdate(subtitleView, subtitleParams);
            }
            updateStatusPosition();
            resizeCaptureSurfaceWhenIdle(0);
            engine.resetStabilityState();
            if (live) handler.postDelayed(liveRunnable, 40L);
        }, 180);
    }

    private void resizeCaptureSurfaceWhenIdle(int attempt) {
        if (destroyed) return;
        if (captureWorkerActive && attempt < 12) {
            handler.postDelayed(() -> resizeCaptureSurfaceWhenIdle(attempt + 1), 40L);
            return;
        }
        resizeCaptureSurface();
    }

    private Rect scaleRect(Rect rect, int oldW, int oldH, int newW, int newH) {
        return new Rect(
                scaleCoordinate(rect.left, oldW, newW),
                scaleCoordinate(rect.top, oldH, newH),
                scaleCoordinate(rect.right, oldW, newW),
                scaleCoordinate(rect.bottom, oldH, newH)
        );
    }

    private int scaleCoordinate(int value, int oldSize, int newSize) {
        if (oldSize <= 0) return value;
        return Math.round((value / (float) oldSize) * newSize);
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) {
            return e == null ? "desconocido" : e.getClass().getSimpleName();
        }
        return e.getMessage();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
