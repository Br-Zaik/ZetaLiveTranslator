# Zeta Live Translator 1.24 - OCR inglés y glosario

Esta versión conserva el comportamiento rápido y estable de la 1.23. No cambia el movimiento libre del cuadro negro, el parpadeo de los controles ni la lógica de dos lecturas para sustituir una traducción ya visible.

## Mejoras implementadas

- El OCR inglés usa ahora la posición real de cada línea detectada, no solamente un bloque de texto completo.
- Se separa la línea inglesa de caracteres chinos, japoneses o coreanos en subtítulos bilingües.
- Se selecciona una sola línea o dos líneas contiguas que realmente pertenezcan al mismo subtítulo.
- Se descartan con más rigor marcas de agua, botones, números y fragmentos sin forma de palabra.
- Para inglés, primero se analiza la imagen original. La imagen ampliada y contrastada solo se usa como respaldo cuando la primera lectura no sirve.
- Se incorporó un vocabulario de 3500 palabras frecuentes para validar OCR. Este vocabulario no reemplaza el modelo de traducción: ayuda a no enviar basura al traductor.
- Se añadió un glosario editable de correcciones exactas Inglés → Español.
- La primera traducción válida sigue apareciendo rápido.
- Una traducción visible solo cambia después de dos lecturas parecidas, como en la 1.23.
- El cuadro negro continúa completamente movible y no muestra “Esperando subtítulo”.
- Auto sigue priorizando inglés; si solo hay un idioma instalado se usa directamente ese idioma.
- Zeta no utiliza `FLAG_SECURE`, por lo que no bloquea capturas por sí misma.

## Glosario de correcciones

En la pantalla principal pulsa **Glosario de correcciones**. Escribe una entrada por línea:

```text
Good morning => Buenos días
I am almost done => Ya casi termino
```

El glosario solo se aplica cuando la frase inglesa completa coincide. No reemplaza palabras sueltas a ciegas y no ralentiza el modo Vivo.

## Uso recomendado

1. Descarga Inglés → Español.
2. Inicia el traductor y acepta la captura.
3. Ajusta el cuadro morado únicamente alrededor de la línea inglesa.
4. Pulsa OK y activa Vivo.
5. Mueve el cuadro negro libremente al lugar que prefieras.

## Compilar en GitHub

1. Crea un repositorio nuevo.
2. Sube todo el contenido de esta carpeta, incluida `.github`.
3. Abre **Actions → Build APK**.
4. Ejecuta **Run workflow**.
5. Descarga el artefacto `ZetaLiveTranslator_APK_V1_24_OCR_Glosario`.

## Límite real

Esta versión sigue usando ML Kit como motor de traducción offline. La mejora principal está en entregar al traductor una frase inglesa limpia y completa. No incluye un modelo neuronal grande de cientos de megabytes porque integrarlo de forma estable exige un motor nativo, tokenizador y pruebas de memoria específicas para Android. Añadir solamente archivos pesados sin esa infraestructura volvería a provocar cierres.
