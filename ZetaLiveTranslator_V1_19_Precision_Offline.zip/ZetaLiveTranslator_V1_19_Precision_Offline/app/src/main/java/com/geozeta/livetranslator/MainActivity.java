package com.geozeta.livetranslator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 501;
    private static final int REQ_NOTIFICATIONS = 502;

    private static final String PREFS = "zeta_live_translator";
    private static final String KEY_FIRST_RUN_DIALOG_SHOWN = "first_run_dialog_shown_v19";
    private static final String KEY_LEGACY_MODELS_READY = "models_ready";
    private static final String KEY_MODEL_PREFIX = "model_pair_ready_";

    private static final int COLOR_BG = 0xFF0C0F14;
    private static final int COLOR_SURFACE = 0xFF151A21;
    private static final int COLOR_SURFACE_ALT = 0xFF1B222C;
    private static final int COLOR_BORDER = 0xFF2A3340;
    private static final int COLOR_TEXT = 0xFFF5F7FA;
    private static final int COLOR_TEXT_MUTED = 0xFFAAB4C3;
    private static final int COLOR_ACCENT = 0xFF3B82F6;
    private static final int COLOR_ACCENT_DARK = 0xFF2563EB;
    private static final int COLOR_SUCCESS = 0xFF31C48D;
    private static final int COLOR_WARNING = 0xFFF0B429;
    private static final int COLOR_ERROR = 0xFFF97066;
    private static final int COLOR_DISABLED = 0xFF303846;

    private SharedPreferences prefs;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private TextView generalBadge;
    private TextView modelsState;
    private TextView overlayState;
    private TextView notificationsState;
    private TextView captureState;
    private TextView progressPercent;
    private TextView progressCount;
    private TextView progressDetail;
    private TextView elapsedText;
    private TextView statusTitle;
    private TextView statusDetail;
    private ProgressBar progressBar;
    private Button setupBtn;
    private Button permissionsBtn;
    private Button prepareBtn;
    private Button startBtn;

    private final TextView[] modelStateViews = new TextView[6];
    private final boolean[] completedInCurrentRun = new boolean[6];

    private boolean preparingModels = false;
    private boolean guidedSetupPending = false;
    private int activeDownloadIndex = -1;
    private long downloadStartedAt = 0L;
    private Translator activeDownloadTranslator;
    private AdvancedOfflineTranslator professionalEngine;
    private int activeProfessionalPercent = 0;
    private long activeProfessionalLoaded = 0L;
    private long activeProfessionalTotal = 0L;
    private String activeProfessionalDetail = "";

    private final List<String> offlineSources = Arrays.asList(
            TranslateLanguage.ENGLISH,
            TranslateLanguage.CHINESE,
            TranslateLanguage.JAPANESE,
            TranslateLanguage.KOREAN
    );

    private final Runnable elapsedRunnable = new Runnable() {
        @Override
        public void run() {
            if (!preparingModels) return;
            long seconds = Math.max(0L, (SystemClock.elapsedRealtime() - downloadStartedAt) / 1000L);
            long minutes = seconds / 60L;
            long remainder = seconds % 60L;
            elapsedText.setText(String.format(Locale.US, "Tiempo transcurrido  %02d:%02d", minutes, remainder));
            uiHandler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        professionalEngine = new AdvancedOfflineTranslator(getApplicationContext());
        migrateLegacyReadyFlag();
        buildUi();
        refreshStateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStateUi();
        if (!prefs.getBoolean(KEY_FIRST_RUN_DIALOG_SHOWN, false)) {
            prefs.edit().putBoolean(KEY_FIRST_RUN_DIALOG_SHOWN, true).apply();
            if (needsConfiguration()) {
                findViewById(android.R.id.content).post(this::showFirstRunDialog);
            }
        } else if (guidedSetupPending && !preparingModels) {
            continueGuidedSetup();
        }
    }

    @Override
    protected void onDestroy() {
        uiHandler.removeCallbacksAndMessages(null);
        if (professionalEngine != null) {
            professionalEngine.destroy();
            professionalEngine = null;
        }
        if (activeDownloadTranslator != null) {
            try { activeDownloadTranslator.close(); } catch (Exception ignored) { }
            activeDownloadTranslator = null;
        }
        super.onDestroy();
    }

    private void migrateLegacyReadyFlag() {
        if (!prefs.getBoolean(KEY_LEGACY_MODELS_READY, false)) return;
        SharedPreferences.Editor editor = prefs.edit();
        for (String source : offlineSources) editor.putBoolean(modelKey(source), true);
        editor.apply();
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(COLOR_BG);
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(28));
        scrollView.addView(root, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(4), dp(6), dp(4), dp(10));

        TextView eyebrow = new TextView(this);
        eyebrow.setText("TRADUCCIÓN EN TIEMPO REAL");
        eyebrow.setTextSize(11);
        eyebrow.setLetterSpacing(0.12f);
        eyebrow.setTextColor(COLOR_ACCENT);
        eyebrow.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(eyebrow);

        TextView title = new TextView(this);
        title.setText("Zeta Live Translator");
        title.setTextSize(27);
        title.setTextColor(COLOR_TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(5);
        header.addView(title, titleLp);

        TextView subtitle = new TextView(this);
        subtitle.setText("Configura una vez los idiomas y traduce subtítulos sin conexión dentro de cualquier video.");
        subtitle.setTextSize(14);
        subtitle.setTextColor(COLOR_TEXT_MUTED);
        subtitle.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.topMargin = dp(7);
        header.addView(subtitle, subtitleLp);
        root.addView(header);

        LinearLayout summaryCard = makeCard();
        LinearLayout summaryTop = new LinearLayout(this);
        summaryTop.setOrientation(LinearLayout.HORIZONTAL);
        summaryTop.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout summaryText = new LinearLayout(this);
        summaryText.setOrientation(LinearLayout.VERTICAL);
        TextView summaryLabel = makeLabel("Estado general", 13, COLOR_TEXT_MUTED, false);
        summaryText.addView(summaryLabel);
        TextView summaryValue = makeLabel("Preparación de la aplicación", 18, COLOR_TEXT, true);
        LinearLayout.LayoutParams summaryValueLp = new LinearLayout.LayoutParams(-1, -2);
        summaryValueLp.topMargin = dp(3);
        summaryText.addView(summaryValue, summaryValueLp);
        summaryTop.addView(summaryText, new LinearLayout.LayoutParams(0, -2, 1f));

        generalBadge = makeBadge("Pendiente", COLOR_WARNING, 0x332A2100);
        summaryTop.addView(generalBadge);
        summaryCard.addView(summaryTop);

        TextView summaryHint = makeLabel("La app comprobará permisos, conexión y modelos antes de iniciar.", 13, COLOR_TEXT_MUTED, false);
        LinearLayout.LayoutParams summaryHintLp = new LinearLayout.LayoutParams(-1, -2);
        summaryHintLp.topMargin = dp(12);
        summaryCard.addView(summaryHint, summaryHintLp);
        root.addView(summaryCard, cardLp(dp(8)));

        LinearLayout quickActions = new LinearLayout(this);
        quickActions.setOrientation(LinearLayout.VERTICAL);

        setupBtn = makeButton("Configurar todo", true);
        setupBtn.setOnClickListener(v -> startGuidedSetup());
        quickActions.addView(setupBtn, buttonLp(0));

        startBtn = makeButton("Iniciar traductor", false);
        startBtn.setOnClickListener(v -> startCaptureFlow());
        quickActions.addView(startBtn, buttonLp(dp(10)));
        root.addView(quickActions, cardLp(dp(14)));

        LinearLayout progressCard = makeCard();
        addSectionHeader(progressCard, "Descarga offline", "4 idiomas básicos + 2 motores profesionales");

        LinearLayout percentRow = new LinearLayout(this);
        percentRow.setOrientation(LinearLayout.HORIZONTAL);
        percentRow.setGravity(Gravity.BOTTOM);
        LinearLayout.LayoutParams percentRowLp = new LinearLayout.LayoutParams(-1, -2);
        percentRowLp.topMargin = dp(15);

        progressPercent = makeLabel("0%", 28, COLOR_TEXT, true);
        percentRow.addView(progressPercent);
        progressCount = makeLabel("0 de 6 listos", 13, COLOR_TEXT_MUTED, false);
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(0, -2, 1f);
        countLp.leftMargin = dp(10);
        countLp.bottomMargin = dp(4);
        percentRow.addView(progressCount, countLp);
        progressCard.addView(percentRow, percentRowLp);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setProgressTintList(ColorStateList.valueOf(COLOR_ACCENT));
        progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(COLOR_BORDER));
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(9));
        progressLp.topMargin = dp(10);
        progressCard.addView(progressBar, progressLp);

        progressDetail = makeLabel("Todavía no se inició la descarga profesional.", 13, COLOR_TEXT_MUTED, false);
        LinearLayout.LayoutParams progressDetailLp = new LinearLayout.LayoutParams(-1, -2);
        progressDetailLp.topMargin = dp(10);
        progressCard.addView(progressDetail, progressDetailLp);

        elapsedText = makeLabel("", 12, COLOR_TEXT_MUTED, false);
        LinearLayout.LayoutParams elapsedLp = new LinearLayout.LayoutParams(-1, -2);
        elapsedLp.topMargin = dp(5);
        progressCard.addView(elapsedText, elapsedLp);

        String[] modelNames = new String[]{"Inglés básico", "Chino básico", "Japonés básico", "Coreano básico", "Inglés profesional", "Multilingüe profesional"};
        for (int i = 0; i < modelNames.length; i++) {
            modelStateViews[i] = addCompactStateRow(progressCard, modelNames[i], "Pendiente");
        }

        prepareBtn = makeSmallButton("Descargar o verificar modelos");
        prepareBtn.setOnClickListener(v -> prepareOfflineModels(false));
        progressCard.addView(prepareBtn, smallButtonLp());
        root.addView(progressCard, cardLp(dp(14)));

        LinearLayout permissionsCard = makeCard();
        addSectionHeader(permissionsCard, "Permisos", "Android exige confirmar algunos pasos manualmente");
        modelsState = addCompactStateRow(permissionsCard, "Idiomas offline", "Pendiente");
        overlayState = addCompactStateRow(permissionsCard, "Mostrar sobre otras apps", "Pendiente");
        notificationsState = addCompactStateRow(permissionsCard, "Notificaciones", "Pendiente");
        captureState = addCompactStateRow(permissionsCard, "Captura de pantalla", "Al iniciar");

        permissionsBtn = makeSmallButton("Revisar permisos pendientes");
        permissionsBtn.setOnClickListener(v -> openMissingPermission());
        permissionsCard.addView(permissionsBtn, smallButtonLp());
        root.addView(permissionsCard, cardLp(dp(14)));

        LinearLayout statusCard = makeCard();
        addSectionHeader(statusCard, "Actividad", "Información clara de lo que está ocurriendo");
        statusTitle = makeLabel("Configuración pendiente", 16, COLOR_TEXT, true);
        LinearLayout.LayoutParams statusTitleLp = new LinearLayout.LayoutParams(-1, -2);
        statusTitleLp.topMargin = dp(14);
        statusCard.addView(statusTitle, statusTitleLp);
        statusDetail = makeLabel("Completa la preparación para iniciar el traductor.", 13, COLOR_TEXT_MUTED, false);
        statusDetail.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams statusDetailLp = new LinearLayout.LayoutParams(-1, -2);
        statusDetailLp.topMargin = dp(6);
        statusCard.addView(statusDetail, statusDetailLp);
        root.addView(statusCard, cardLp(dp(14)));

        TextView note = makeLabel("Los modelos básicos avanzan por etapas. Los paquetes profesionales muestran porcentaje y megabytes descargados cuando el servidor informa el tamaño.", 12, 0xFF7F8A99, false);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(0f, 1.1f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.setMargins(dp(12), dp(18), dp(12), 0);
        root.addView(note, noteLp);

        setContentView(scrollView);
    }

    private void showFirstRunDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Preparar Zeta")
                .setMessage("La configuración guiada revisará permisos y preparará cuatro idiomas básicos, un modelo profesional de Inglés y un modelo multilingüe grande. La descarga puede superar 1 GB y tardar varios minutos.")
                .setPositiveButton("Configurar ahora", (dialog, which) -> startGuidedSetup())
                .setNegativeButton("Más tarde", null)
                .show();
    }

    private void startGuidedSetup() {
        guidedSetupPending = true;
        updateStatus("Configuración iniciada", "Se revisarán primero los permisos y luego los modelos offline.");
        continueGuidedSetup();
    }

    private void continueGuidedSetup() {
        if (!areNotificationsReady() && Build.VERSION.SDK_INT >= 33) {
            updateStatus("Permiso de notificaciones", "Confirma el permiso para mantener visible el servicio mientras traduce.");
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }

        if (!isOverlayReady()) {
            updateStatus("Permiso sobre otras apps", "Actívalo en la pantalla de Android que se abrirá a continuación.");
            requestOverlayPermission();
            return;
        }

        if (!areModelsReady()) {
            prepareOfflineModels(true);
            return;
        }

        guidedSetupPending = false;
        updateStatus("Configuración completa", "Todo está listo. Pulsa Iniciar traductor para autorizar la captura de pantalla.");
        refreshStateUi();
    }

    private void openMissingPermission() {
        if (!areNotificationsReady() && Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }
        if (!isOverlayReady()) {
            requestOverlayPermission();
            return;
        }
        toast("Los permisos principales ya están concedidos.");
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } else {
            toast("El permiso sobre otras apps ya está activo.");
        }
    }

    private void startCaptureFlow() {
        if (!areBasicModelsReady()) {
            updateStatus("Faltan modelos offline", "Descarga al menos los cuatro modelos básicos antes de iniciar.");
            toast("Primero completa los modelos básicos.");
            return;
        }
        if (!isOverlayReady()) {
            updateStatus("Falta permiso sobre otras apps", "Android necesita ese permiso para mostrar la barra flotante.");
            requestOverlayPermission();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        updateStatus("Esperando permiso de captura", "Confirma el cuadro oficial de Android para comenzar.");
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, OverlayTranslatorService.class);
            service.putExtra(OverlayTranslatorService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(OverlayTranslatorService.EXTRA_DATA, data);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(service);
            } else {
                startService(service);
            }
            updateStatus("Traductor iniciado", "Ajusta el área sobre los subtítulos y usa Trad. o Vivo.");
            toast("Traductor iniciado.");
            moveTaskToBack(true);
        } else {
            updateStatus("Captura cancelada", "No se inició el traductor porque el permiso fue rechazado.");
        }
    }

    private void prepareOfflineModels(boolean fromGuidedSetup) {
        if (preparingModels) {
            toast("La descarga ya está en curso.");
            return;
        }
        if (!isNetworkAvailable()) {
            guidedSetupPending = false;
            updateStatus("Sin conexión a internet", "Conéctate a Wi-Fi o datos móviles y vuelve a intentarlo.");
            progressDetail.setText("No se detectó conexión. La descarga no comenzó.");
            progressDetail.setTextColor(COLOR_ERROR);
            return;
        }

        preparingModels = true;
        guidedSetupPending = guidedSetupPending || fromGuidedSetup;
        activeDownloadIndex = -1;
        activeProfessionalPercent = 0;
        activeProfessionalLoaded = 0L;
        activeProfessionalTotal = 0L;
        activeProfessionalDetail = "";
        Arrays.fill(completedInCurrentRun, false);
        downloadStartedAt = SystemClock.elapsedRealtime();
        uiHandler.removeCallbacks(elapsedRunnable);
        uiHandler.post(elapsedRunnable);

        prepareBtn.setEnabled(false);
        setupBtn.setEnabled(false);
        progressDetail.setTextColor(COLOR_TEXT_MUTED);
        updateStatus("Descarga iniciada", "La app preparará cada idioma uno por uno y marcará los que terminen.");
        refreshStateUi();
        downloadModelAt(0);
    }

    private void downloadModelAt(int index) {
        if (!preparingModels) return;
        if (index >= modelStateViews.length) {
            finishModelPreparation();
            return;
        }

        if (index >= offlineSources.size()) {
            prepareProfessionalAt(index);
            return;
        }

        String source = offlineSources.get(index);
        if (isPairReady(source)) {
            completedInCurrentRun[index] = true;
            refreshDownloadUi();
            downloadModelAt(index + 1);
            return;
        }

        activeDownloadIndex = index;
        activeProfessionalPercent = 0;
        refreshDownloadUi();
        updateStatus("Descargando " + readable(source), "Espera a que este idioma cambie de Descargando a Listo. No cierres la aplicación.");

        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        activeDownloadTranslator = Translation.getClient(options);
        Translator translatorForTask = activeDownloadTranslator;

        translatorForTask.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(unused -> {
                    if (translatorForTask != activeDownloadTranslator && activeDownloadTranslator != null) return;
                    prefs.edit().putBoolean(modelKey(source), true).apply();
                    completedInCurrentRun[index] = true;
                    try { translatorForTask.close(); } catch (Exception ignored) { }
                    if (activeDownloadTranslator == translatorForTask) activeDownloadTranslator = null;
                    activeDownloadIndex = -1;
                    refreshDownloadUi();
                    downloadModelAt(index + 1);
                })
                .addOnFailureListener(e -> {
                    try { translatorForTask.close(); } catch (Exception ignored) { }
                    if (activeDownloadTranslator == translatorForTask) activeDownloadTranslator = null;
                    failModelPreparation(readable(source), friendlyDownloadError(e));
                });
    }

    private void prepareProfessionalAt(int index) {
        final boolean englishPack = index == 4;
        final String preferenceKey = englishPack
                ? AdvancedOfflineTranslator.KEY_PRO_EN_READY
                : AdvancedOfflineTranslator.KEY_PRO_MULTI_READY;
        final String languageCode = englishPack ? TranslateLanguage.ENGLISH : TranslateLanguage.CHINESE;
        final String label = englishPack ? "Inglés profesional" : "Multilingüe profesional";

        if (prefs.getBoolean(preferenceKey, false)) {
            completedInCurrentRun[index] = true;
            refreshDownloadUi();
            downloadModelAt(index + 1);
            return;
        }
        if (professionalEngine == null) {
            failModelPreparation(label, "No se pudo iniciar el motor profesional.");
            return;
        }

        activeDownloadIndex = index;
        activeProfessionalPercent = 0;
        activeProfessionalLoaded = 0L;
        activeProfessionalTotal = 0L;
        activeProfessionalDetail = label;
        updateStatus("Descargando " + label, "Este paquete es grande. Mantén la app abierta y una conexión estable.");
        refreshDownloadUi();

        professionalEngine.prepare(languageCode, new AdvancedOfflineTranslator.PrepareCallback() {
            @Override
            public void onProgress(int percent, long loadedBytes, long totalBytes, String detail) {
                if (!preparingModels || activeDownloadIndex != index) return;
                activeProfessionalPercent = percent;
                activeProfessionalLoaded = loadedBytes;
                activeProfessionalTotal = totalBytes;
                activeProfessionalDetail = detail == null ? label : detail;
                refreshDownloadUi();
            }

            @Override
            public void onSuccess() {
                if (!preparingModels || activeDownloadIndex != index) return;
                prefs.edit().putBoolean(preferenceKey, true).apply();
                completedInCurrentRun[index] = true;
                activeProfessionalPercent = 100;
                activeDownloadIndex = -1;
                refreshDownloadUi();
                downloadModelAt(index + 1);
            }

            @Override
            public void onError(String message) {
                if (!preparingModels || activeDownloadIndex != index) return;
                failModelPreparation(label, "No se pudo preparar el paquete profesional. " + message);
            }
        });
    }

    private void failModelPreparation(String label, String detail) {
        preparingModels = false;
        guidedSetupPending = false;
        activeDownloadIndex = -1;
        activeProfessionalPercent = 0;
        uiHandler.removeCallbacks(elapsedRunnable);
        prepareBtn.setEnabled(true);
        setupBtn.setEnabled(true);
        progressDetail.setText(detail);
        progressDetail.setTextColor(COLOR_ERROR);
        updateStatus("Falló " + label, detail);
        refreshStateUi();
    }

    private void finishModelPreparation() {
        preparingModels = false;
        guidedSetupPending = false;
        activeDownloadIndex = -1;
        uiHandler.removeCallbacks(elapsedRunnable);
        elapsedText.setText("Descarga finalizada");
        prepareBtn.setEnabled(true);
        setupBtn.setEnabled(true);
        progressDetail.setTextColor(COLOR_SUCCESS);
        progressDetail.setText("Los modelos básicos y profesionales están disponibles sin conexión.");
        updateStatus("Descarga completa", "Los cuatro idiomas y los dos motores profesionales ya están preparados para traducir al Español.");
        refreshStateUi();
        toast("Traductor profesional offline listo.");
    }

    private String friendlyDownloadError(Exception e) {
        String raw = e == null || e.getMessage() == null ? "" : e.getMessage();
        if (!isNetworkAvailable()) {
            return "La conexión se perdió durante la descarga. Reconéctate y pulsa Reintentar.";
        }
        if (raw.trim().isEmpty()) {
            return "ML Kit no pudo completar la descarga. Revisa internet, espacio libre y Servicios de Google Play.";
        }
        return "No se pudo descargar el modelo. Revisa internet y Servicios de Google Play. Detalle: " + raw;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) {
            refreshStateUi();
            if (guidedSetupPending && !preparingModels) continueGuidedSetup();
        }
    }

    private void refreshStateUi() {
        boolean modelsReady = areModelsReady();
        boolean overlayReady = isOverlayReady();
        boolean notificationsReady = areNotificationsReady();

        setBadge(modelsState, modelsReady ? "Listo" : (preparingModels ? "Descargando" : "Pendiente"),
                modelsReady ? COLOR_SUCCESS : (preparingModels ? COLOR_ACCENT : COLOR_WARNING));
        setBadge(overlayState, overlayReady ? "Listo" : "Pendiente", overlayReady ? COLOR_SUCCESS : COLOR_WARNING);
        setBadge(notificationsState, notificationsReady ? "Listo" : "Pendiente", notificationsReady ? COLOR_SUCCESS : COLOR_WARNING);
        setBadge(captureState, "Al iniciar", COLOR_TEXT_MUTED);

        boolean basicReady = areBasicModelsReady();
        boolean canStart = basicReady && overlayReady;
        String generalText = modelsReady && overlayReady
                ? "Profesional listo"
                : (canStart ? "Modo básico listo" : (preparingModels ? "Preparando" : "Pendiente"));
        int generalColor = modelsReady && overlayReady
                ? COLOR_SUCCESS
                : (canStart ? COLOR_WARNING : (preparingModels ? COLOR_ACCENT : COLOR_WARNING));
        setBadge(generalBadge, generalText, generalColor);

        permissionsBtn.setEnabled(!overlayReady || !notificationsReady);
        prepareBtn.setEnabled(!preparingModels);
        setupBtn.setEnabled(!preparingModels);
        startBtn.setEnabled(canStart && !preparingModels);

        refreshDownloadUi();
    }

    private void refreshDownloadUi() {
        int completed = countReadyStages();
        float fractional = completed;
        if (preparingModels && activeDownloadIndex >= 4 && activeDownloadIndex < modelStateViews.length) {
            fractional += Math.max(0f, Math.min(1f, activeProfessionalPercent / 100f));
        }
        int percent = Math.round((fractional * 100f) / modelStateViews.length);
        progressBar.setProgress(percent);
        progressPercent.setText(percent + "%");
        progressCount.setText(completed + " de " + modelStateViews.length + " listos");

        for (int i = 0; i < modelStateViews.length; i++) {
            boolean ready = isStageReady(i) || completedInCurrentRun[i];
            if (ready) {
                setBadge(modelStateViews[i], "Listo", COLOR_SUCCESS);
            } else if (preparingModels && i == activeDownloadIndex) {
                String value = i >= 4 && activeProfessionalPercent > 0 ? activeProfessionalPercent + "%" : "Descargando";
                setBadge(modelStateViews[i], value, COLOR_ACCENT);
            } else {
                setBadge(modelStateViews[i], "Pendiente", COLOR_TEXT_MUTED);
            }
        }

        if (preparingModels && activeDownloadIndex >= 0) {
            if (activeDownloadIndex < offlineSources.size()) {
                String name = readable(offlineSources.get(activeDownloadIndex));
                progressDetail.setText("Descargando " + name + " · etapa " + (activeDownloadIndex + 1) + " de " + modelStateViews.length);
            } else {
                String size = formatBytes(activeProfessionalLoaded);
                String total = activeProfessionalTotal > 0 ? " de " + formatBytes(activeProfessionalTotal) : "";
                progressDetail.setText(activeProfessionalDetail + " · archivo actual "
                        + activeProfessionalPercent + "% · " + size + total);
            }
            progressDetail.setTextColor(COLOR_ACCENT);
        } else if (completed == modelStateViews.length) {
            progressDetail.setText("Todos los modelos básicos y profesionales están preparados.");
            progressDetail.setTextColor(COLOR_SUCCESS);
        } else if (!preparingModels && progressDetail.getText().length() == 0) {
            progressDetail.setText("Pulsa Descargar o verificar modelos para comenzar.");
            progressDetail.setTextColor(COLOR_TEXT_MUTED);
        }
    }

    private int countReadyStages() {
        int count = 0;
        for (int i = 0; i < modelStateViews.length; i++) if (isStageReady(i)) count++;
        return count;
    }

    private boolean areBasicModelsReady() {
        for (int i = 0; i < offlineSources.size(); i++) {
            if (!isStageReady(i)) return false;
        }
        return true;
    }

    private boolean areModelsReady() {
        return countReadyStages() == modelStateViews.length;
    }

    private boolean isStageReady(int index) {
        if (index < offlineSources.size()) return isPairReady(offlineSources.get(index));
        if (index == 4) return prefs.getBoolean(AdvancedOfflineTranslator.KEY_PRO_EN_READY, false);
        if (index == 5) return prefs.getBoolean(AdvancedOfflineTranslator.KEY_PRO_MULTI_READY, false);
        return false;
    }

    private boolean isPairReady(String source) {
        return prefs.getBoolean(modelKey(source), false);
    }

    private String modelKey(String source) {
        return KEY_MODEL_PREFIX + source;
    }

    private String formatBytes(long bytes) {
        if (bytes <= 0L) return "0 MB";
        double mb = bytes / (1024.0 * 1024.0);
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb);
        return String.format(Locale.US, "%.2f GB", mb / 1024.0);
    }

    private boolean needsConfiguration() {
        return !areModelsReady() || !isOverlayReady() || !areNotificationsReady();
    }

    private boolean isOverlayReady() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private boolean areNotificationsReady() {
        return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        Network network = cm.getActiveNetwork();
        if (network == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(network);
        return caps != null
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
    }

    private void updateStatus(String title, String detail) {
        statusTitle.setText(title);
        statusDetail.setText(detail);
    }

    private LinearLayout makeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(16), dp(17), dp(17));
        card.setBackground(makeRoundedBackground(18, COLOR_SURFACE, COLOR_BORDER, 1));
        card.setElevation(dp(1));
        return card;
    }

    private LinearLayout.LayoutParams cardLp(int topMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = topMargin;
        return lp;
    }

    private void addSectionHeader(LinearLayout parent, String title, String subtitle) {
        parent.addView(makeLabel(title, 17, COLOR_TEXT, true));
        TextView subtitleView = makeLabel(subtitle, 12, COLOR_TEXT_MUTED, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(3);
        parent.addView(subtitleView, lp);
    }

    private TextView addCompactStateRow(LinearLayout parent, String label, String state) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.topMargin = dp(12);

        TextView labelView = makeLabel(label, 14, COLOR_TEXT_MUTED, false);
        row.addView(labelView, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView stateView = makeBadge(state, COLOR_TEXT_MUTED, 0x221C2430);
        row.addView(stateView);
        parent.addView(row, rowLp);
        return stateView;
    }

    private TextView makeLabel(String text, int sizeSp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private TextView makeBadge(String text, int color, int backgroundColor) {
        TextView badge = makeLabel(text, 12, color, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(10), dp(5), dp(10), dp(5));
        badge.setBackground(makeRoundedBackground(99, backgroundColor, color, 1));
        return badge;
    }

    private void setBadge(TextView badge, String text, int color) {
        badge.setText(text);
        badge.setTextColor(color);
        badge.setBackground(makeRoundedBackground(99, colorWithAlpha(color, 0x22), colorWithAlpha(color, 0x88), 1));
    }

    private Button makeButton(String text, boolean primary) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        button.setPadding(dp(16), dp(13), dp(16), dp(13));

        int enabledFill = primary ? COLOR_ACCENT : COLOR_SURFACE_ALT;
        int enabledStroke = primary ? COLOR_ACCENT : COLOR_BORDER;
        int enabledText = COLOR_TEXT;
        StateListDrawable background = new StateListDrawable();
        background.addState(new int[]{-android.R.attr.state_enabled}, makeRoundedBackground(14, COLOR_DISABLED, COLOR_DISABLED, 1));
        background.addState(new int[]{android.R.attr.state_pressed}, makeRoundedBackground(14, primary ? COLOR_ACCENT_DARK : COLOR_BORDER, enabledStroke, 1));
        background.addState(new int[]{}, makeRoundedBackground(14, enabledFill, enabledStroke, 1));
        button.setBackground(background);
        button.setTextColor(new ColorStateList(
                new int[][]{new int[]{-android.R.attr.state_enabled}, new int[]{}},
                new int[]{0xFF758092, enabledText}
        ));
        return button;
    }

    private Button makeSmallButton(String text) {
        Button button = makeButton(text, false);
        button.setTextSize(13);
        button.setTypeface(Typeface.DEFAULT);
        return button;
    }

    private LinearLayout.LayoutParams buttonLp(int topMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = topMargin;
        return lp;
    }

    private LinearLayout.LayoutParams smallButtonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
        lp.topMargin = dp(15);
        return lp;
    }

    private GradientDrawable makeRoundedBackground(int radiusDp, int fillColor, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setColor(fillColor);
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private int colorWithAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        return code;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
