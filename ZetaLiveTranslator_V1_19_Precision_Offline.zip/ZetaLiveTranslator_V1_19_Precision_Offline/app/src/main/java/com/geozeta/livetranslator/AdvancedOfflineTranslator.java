package com.geozeta.livetranslator;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Ejecuta modelos ONNX de traducción dentro de un WebView local mediante Transformers.js.
 * Los pesos se descargan una sola vez y quedan en el almacenamiento privado del WebView.
 * Si el motor no está disponible, el llamador debe volver al traductor ligero de ML Kit.
 */
public final class AdvancedOfflineTranslator {
    public static final String PREFS = "zeta_live_translator";
    public static final String KEY_PRO_EN_READY = "professional_model_en_ready_v19";
    public static final String KEY_PRO_MULTI_READY = "professional_model_multi_ready_v19";

    public interface PrepareCallback {
        void onProgress(int percent, long loadedBytes, long totalBytes, String detail);
        void onSuccess();
        void onError(String message);
    }

    public interface TranslationCallback {
        void onSuccess(String translated);
        void onError(String message);
    }

    private static final long PREPARE_TIMEOUT_MS = 25L * 60L * 1000L;
    private static final long TRANSLATE_TIMEOUT_MS = 90L * 1000L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicInteger requestCounter = new AtomicInteger(1);
    private final Map<String, PendingRequest> pending = new ConcurrentHashMap<>();
    private final Queue<Runnable> waitingForReady = new ArrayDeque<>();
    private final Context appContext;

    private WebView webView;
    private boolean ready = false;
    private boolean destroyed = false;
    private String initializationError = null;

    public AdvancedOfflineTranslator(Context context) {
        appContext = context.getApplicationContext();
        if (Looper.myLooper() == Looper.getMainLooper()) {
            createWebView();
        } else {
            mainHandler.post(this::createWebView);
        }
    }

    public void prepare(String languageCode, PrepareCallback callback) {
        if (callback == null) return;
        if (initializationError != null) {
            callback.onError(initializationError);
            return;
        }
        String requestId = "prepare_" + requestCounter.getAndIncrement();
        PendingRequest request = PendingRequest.forPrepare(callback);
        pending.put(requestId, request);
        scheduleTimeout(requestId, PREPARE_TIMEOUT_MS, "La descarga del motor profesional tardó demasiado.");
        runWhenReady(() -> evaluate("window.zetaPrepare(" + quote(languageCode) + "," + quote(requestId) + ");"));
    }

    public void translate(String text, String languageCode, TranslationCallback callback) {
        if (callback == null) return;
        if (initializationError != null) {
            callback.onError(initializationError);
            return;
        }
        String requestId = "translate_" + requestCounter.getAndIncrement();
        PendingRequest request = PendingRequest.forTranslation(callback);
        pending.put(requestId, request);
        scheduleTimeout(requestId, TRANSLATE_TIMEOUT_MS, "El motor profesional tardó demasiado en traducir.");
        runWhenReady(() -> evaluate("window.zetaTranslate(" + quote(text) + "," + quote(languageCode) + "," + quote(requestId) + ");"));
    }

    public void destroy() {
        if (destroyed) return;
        destroyed = true;
        ready = false;
        mainHandler.removeCallbacksAndMessages(null);
        for (Map.Entry<String, PendingRequest> entry : pending.entrySet()) {
            entry.getValue().fail("Motor cerrado.");
        }
        pending.clear();
        waitingForReady.clear();
        if (webView != null) {
            WebView old = webView;
            webView = null;
            try {
                old.removeJavascriptInterface("AndroidBridge");
                old.stopLoading();
                old.loadUrl("about:blank");
                old.clearHistory();
                old.removeAllViews();
                old.destroy();
            } catch (Exception ignored) { }
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void createWebView() {
        if (destroyed || webView != null) return;
        try {
            WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                    .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(appContext))
                    .build();

            WebView view = new WebView(appContext);
            WebSettings settings = view.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(false);
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);
            settings.setMediaPlaybackRequiresUserGesture(false);
            view.addJavascriptInterface(new JsBridge(), "AndroidBridge");
            view.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    return assetLoader.shouldInterceptRequest(request.getUrl());
                }

                @Override
                @SuppressWarnings("deprecation")
                public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                    return assetLoader.shouldInterceptRequest(Uri.parse(url));
                }
            });
            webView = view;
            view.loadUrl("https://appassets.androidplatform.net/assets/offline_engine/index.html");
        } catch (Exception e) {
            initializationError = "No se pudo iniciar el motor profesional: " + safeMessage(e);
            failAll(initializationError);
        }
    }

    private void runWhenReady(Runnable command) {
        mainHandler.post(() -> {
            if (destroyed) return;
            if (ready && webView != null) {
                command.run();
            } else {
                waitingForReady.offer(command);
            }
        });
    }

    private void evaluate(String javascript) {
        if (destroyed || webView == null) return;
        try {
            webView.evaluateJavascript(javascript, null);
        } catch (Exception e) {
            failAll("No se pudo ejecutar el motor profesional: " + safeMessage(e));
        }
    }

    private void scheduleTimeout(String requestId, long timeoutMs, String message) {
        Runnable timeout = () -> {
            PendingRequest request = pending.remove(requestId);
            if (request != null) request.fail(message);
        };
        PendingRequest request = pending.get(requestId);
        if (request != null) request.timeout = timeout;
        mainHandler.postDelayed(timeout, timeoutMs);
    }

    private void complete(String requestId) {
        PendingRequest request = pending.remove(requestId);
        if (request != null && request.timeout != null) mainHandler.removeCallbacks(request.timeout);
    }

    private void failAll(String message) {
        mainHandler.post(() -> {
            for (Map.Entry<String, PendingRequest> entry : pending.entrySet()) {
                PendingRequest request = entry.getValue();
                if (request.timeout != null) mainHandler.removeCallbacks(request.timeout);
                request.fail(message);
            }
            pending.clear();
            waitingForReady.clear();
        });
    }

    private String quote(String value) {
        return JSONObject.quote(value == null ? "" : value);
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().isEmpty()) return "error desconocido";
        return e.getMessage().trim();
    }

    private final class JsBridge {
        @JavascriptInterface
        public void onReady() {
            mainHandler.post(() -> {
                if (destroyed) return;
                ready = true;
                Runnable task;
                while ((task = waitingForReady.poll()) != null) task.run();
            });
        }

        @JavascriptInterface
        public void onProgress(String requestId, String modelLabel, String fileName,
                               double loaded, double total, int percent) {
            mainHandler.post(() -> {
                PendingRequest request = pending.get(requestId);
                if (request == null || request.prepareCallback == null) return;
                long loadedBytes = Math.max(0L, Math.round(loaded));
                long totalBytes = Math.max(0L, Math.round(total));
                String detail = modelLabel;
                if (fileName != null && !fileName.trim().isEmpty()) detail += " · " + shortFileName(fileName);
                request.prepareCallback.onProgress(Math.max(0, Math.min(100, percent)), loadedBytes, totalBytes, detail);
            });
        }

        @JavascriptInterface
        public void onPrepared(String requestId, String modelKey) {
            mainHandler.post(() -> {
                PendingRequest request = pending.get(requestId);
                if (request == null || request.prepareCallback == null) return;
                complete(requestId);
                request.prepareCallback.onSuccess();
            });
        }

        @JavascriptInterface
        public void onTranslated(String requestId, String translated) {
            mainHandler.post(() -> {
                PendingRequest request = pending.get(requestId);
                if (request == null || request.translationCallback == null) return;
                complete(requestId);
                request.translationCallback.onSuccess(translated == null ? "" : translated.trim());
            });
        }

        @JavascriptInterface
        public void onError(String requestId, String message) {
            mainHandler.post(() -> {
                PendingRequest request = pending.get(requestId);
                if (request == null) return;
                complete(requestId);
                request.fail(message == null || message.trim().isEmpty() ? "Error del motor profesional." : message.trim());
            });
        }
    }

    private String shortFileName(String fileName) {
        String value = fileName.replace('\\', '/');
        int slash = value.lastIndexOf('/');
        if (slash >= 0 && slash + 1 < value.length()) value = value.substring(slash + 1);
        if (value.length() > 38) value = value.substring(0, 35) + "...";
        return value;
    }

    private static final class PendingRequest {
        final PrepareCallback prepareCallback;
        final TranslationCallback translationCallback;
        Runnable timeout;

        private PendingRequest(PrepareCallback prepareCallback, TranslationCallback translationCallback) {
            this.prepareCallback = prepareCallback;
            this.translationCallback = translationCallback;
        }

        static PendingRequest forPrepare(PrepareCallback callback) {
            return new PendingRequest(callback, null);
        }

        static PendingRequest forTranslation(TranslationCallback callback) {
            return new PendingRequest(null, callback);
        }

        void fail(String message) {
            if (prepareCallback != null) prepareCallback.onError(message);
            if (translationCallback != null) translationCallback.onError(message);
        }
    }
}
