import { build } from 'esbuild';
import { cp, mkdir, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.resolve(here, '../app/src/main/assets/offline_engine');
const wasmOut = path.join(outDir, 'wasm');

await mkdir(outDir, { recursive: true });
await mkdir(wasmOut, { recursive: true });

await build({
  entryPoints: [path.join(here, 'src/engine.js')],
  outfile: path.join(outDir, 'engine.js'),
  bundle: true,
  format: 'esm',
  platform: 'browser',
  target: ['chrome100'],
  minify: true,
  sourcemap: false,
});

const ortDist = path.join(here, 'node_modules/onnxruntime-web/dist');
for (const file of await readdir(ortDist)) {
  if (file.endsWith('.wasm') || file.endsWith('.mjs') || file.endsWith('.js')) {
    await cp(path.join(ortDist, file), path.join(wasmOut, file));
  }
}

await writeFile(path.join(outDir, 'BUILD_INFO.txt'),
  'Generado por translator-web/build.mjs. Motor local Transformers.js + ONNX Runtime Web.\n');
