import { env, pipeline } from '@huggingface/transformers';

env.allowLocalModels = false;
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = '/assets/offline_engine/wasm/';
env.backends.onnx.wasm.numThreads = 1;
env.backends.onnx.wasm.proxy = false;

const MODEL_CONFIG = {
  en: {
    id: 'Xenova/opus-mt-en-es',
    label: 'Inglés profesional',
    dtype: 'q8',
  },
  multi: {
    id: 'Xenova/m2m100_418M',
    label: 'Multilingüe profesional',
    dtype: 'q8',
  },
};

const pipelines = new Map();
const loadingPipelines = new Map();
let activeModelKey = null;

function bridge(method, ...args) {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge[method] === 'function') {
      window.AndroidBridge[method](...args);
    }
  } catch (_) {
    // Android puede haber cerrado la vista mientras terminaba una tarea.
  }
}

function modelKeyForLanguage(language) {
  return language === 'en' ? 'en' : 'multi';
}

function progressReporter(requestId, modelKey) {
  const files = new Map();
  return (entry) => {
    if (!entry || typeof entry !== 'object') return;
    const file = String(entry.file || entry.name || entry.status || 'modelo');
    const loaded = Number(entry.loaded || 0);
    const total = Number(entry.total || 0);
    if (total > 0) files.set(file, { loaded: Math.min(loaded, total), total });

    let sumLoaded = 0;
    let sumTotal = 0;
    for (const value of files.values()) {
      sumLoaded += value.loaded;
      sumTotal += value.total;
    }

    let percent = 0;
    if (sumTotal > 0) {
      percent = Math.max(0, Math.min(100, Math.round((sumLoaded * 100) / sumTotal)));
    } else if (Number.isFinite(entry.progress)) {
      percent = Math.max(0, Math.min(100, Math.round(Number(entry.progress))));
    }

    bridge('onProgress', requestId, MODEL_CONFIG[modelKey].label, file, sumLoaded, sumTotal, percent);
  };
}

async function disposeLoadedPipelines(exceptKey = null) {
  for (const [key, instance] of pipelines.entries()) {
    if (key === exceptKey) continue;
    try {
      if (instance && typeof instance.dispose === 'function') await instance.dispose();
    } catch (_) {
      // La caché ya quedó escrita; liberar memoria es una optimización, no un requisito.
    }
    pipelines.delete(key);
  }
  if (exceptKey === null || activeModelKey !== exceptKey) activeModelKey = exceptKey;
}

async function getPipeline(modelKey, requestId) {
  if (pipelines.has(modelKey)) return pipelines.get(modelKey);
  if (loadingPipelines.has(modelKey)) return loadingPipelines.get(modelKey);

  await disposeLoadedPipelines(modelKey);
  const config = MODEL_CONFIG[modelKey];
  const promise = pipeline('translation', config.id, {
    device: 'wasm',
    dtype: config.dtype,
    progress_callback: progressReporter(requestId, modelKey),
  }).then((instance) => {
    pipelines.set(modelKey, instance);
    activeModelKey = modelKey;
    loadingPipelines.delete(modelKey);
    return instance;
  }).catch((error) => {
    loadingPipelines.delete(modelKey);
    throw error;
  });

  loadingPipelines.set(modelKey, promise);
  return promise;
}

window.zetaPrepare = async function zetaPrepare(language, requestId) {
  const modelKey = modelKeyForLanguage(language);
  try {
    await getPipeline(modelKey, requestId);
    await disposeLoadedPipelines(null);
    bridge('onPrepared', requestId, modelKey);
  } catch (error) {
    bridge('onError', requestId, String(error && error.message ? error.message : error));
  }
};

window.zetaTranslate = async function zetaTranslate(text, language, requestId) {
  const modelKey = modelKeyForLanguage(language);
  try {
    const translator = await getPipeline(modelKey, requestId);
    const clean = String(text || '').trim();
    if (!clean) throw new Error('Texto vacío');

    const options = {
      do_sample: false,
      num_beams: 3,
      max_new_tokens: 160,
      repetition_penalty: 1.08,
    };
    if (modelKey === 'multi') {
      options.src_lang = language;
      options.tgt_lang = 'es';
    }

    const output = await translator(clean, options);
    const translated = Array.isArray(output) && output.length > 0
      ? String(output[0].translation_text || '').trim()
      : '';
    if (!translated) throw new Error('El modelo no devolvió traducción');
    bridge('onTranslated', requestId, translated);
  } catch (error) {
    bridge('onError', requestId, String(error && error.message ? error.message : error));
  }
};

bridge('onReady');
