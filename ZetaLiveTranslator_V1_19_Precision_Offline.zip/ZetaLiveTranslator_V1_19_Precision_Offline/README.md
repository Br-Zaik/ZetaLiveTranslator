# Zeta Live Translator V1.19 — Precisión Offline

Versión enfocada en traducción offline de subtítulos hacia Español, estabilidad del overlay y descarga visible de modelos.

## Cambios principales

- Interfaz oscura gris grafito y compacta.
- Barra de progreso general de seis etapas.
- Progreso por archivo, porcentaje y megabytes para los paquetes profesionales cuando el servidor informa el tamaño.
- Cuatro modelos ligeros de respaldo: Inglés, Chino, Japonés y Coreano hacia Español.
- Motor específico Inglés → Español basado en OPUS-MT cuantizado.
- Motor multilingüe grande M2M100 para traducción directa de Chino, Japonés y Coreano → Español.
- Los modelos profesionales se descargan una vez y se guardan en el almacenamiento privado de la app.
- Si el motor profesional falla por memoria, incompatibilidad o caché, la sesión vuelve automáticamente a ML Kit y no repite el fallo en cada subtítulo.
- Auto prioriza Inglés, lo mantiene bloqueado mientras funcione y solo redetecta después de varios fallos.
- Al escoger un idioma manual, únicamente se ejecuta el OCR de ese idioma.
- Selección de las dos líneas inglesas más probables para evitar mezclar títulos, marcas de agua y subtítulos bilingües.
- Normalización de palabras expresivas como `gooood`, `noooo`, `pleaaase` y similares.
- Validación del resultado: si el motor profesional deja demasiado texto de origen, se usa el traductor de respaldo.
- Eliminado `FLAG_SECURE`: Zeta ya no marca sus ventanas como privadas ni bloquea capturas por sí mismo.
- El cuadro negro permanece visible durante el OCR y deja de parpadear.
- Solo el marco morado se oculta durante la captura.
- El cuadro negro queda pegado arriba o abajo del área morada, evita superponerse y sigue el selector al moverlo o girar la pantalla.
- La descarga no se interrumpe al rotar la pantalla principal.

## Uso

1. Abre la aplicación con una conexión estable.
2. Pulsa **Configurar todo**.
3. Concede notificaciones y permiso para mostrar sobre otras apps.
4. Espera a que terminen los cuatro modelos básicos y los dos paquetes profesionales.
5. Pulsa **Iniciar traductor** y confirma la captura de pantalla de Android.
6. En la barra flotante selecciona **Auto** o un idioma fijo.
7. Ajusta **Área** sobre el subtítulo original y activa **Vivo**.

## Almacenamiento y rendimiento

El motor incluido en el APK agrega aproximadamente 60–70 MB. Los modelos profesionales se descargan aparte y pueden superar 1 GB en conjunto. Conviene disponer de al menos 2 GB libres. El primer uso de cada motor puede tardar más porque debe cargar el modelo en memoria.

Los modelos grandes no garantizan una traducción perfecta. La calidad también depende del tamaño y nitidez del subtítulo, de que el cuadro incluya la frase completa y de la capacidad de memoria del dispositivo. La aplicación conserva ML Kit como respaldo para no quedar inutilizable en teléfonos que no soporten el motor grande.

## Modelos y licencias

- `Xenova/opus-mt-en-es`, derivado de Helsinki-NLP OPUS-MT.
- `Xenova/m2m100_418M`, derivado de Meta M2M100.
- Ejecución local con Transformers.js y ONNX Runtime Web.

Revisar las fichas y licencias de cada modelo antes de distribuir comercialmente la aplicación.

## Compilación

El repositorio incluye el motor web ya compilado en `app/src/main/assets/offline_engine`. El workflow de GitHub también puede reconstruirlo con Node 20 antes de generar el APK.
