# Cambios de Zeta Live Translator 1.28.0

Esta versión mejora de forma equilibrada **Inglés, Chino y Japonés → Español** para subtítulos de videos rápidos y continuos. Coreano continúa eliminado.

## Respuesta rápida y continua

- Intervalos LIVE aproximados: 300 ms en Inglés, 300 ms en Chino y 310 ms en Japonés.
- Auto permanece más conservador porque debe identificar el idioma.
- Si el video cambia mientras el OCR o la traducción anterior siguen activos, se guarda una captura pendiente y se procesa apenas termina la tarea actual.
- Nunca se inicia un segundo OCR simultáneo; esto evita colas, consumo excesivo de memoria y cierres, especialmente con los reconocedores asiáticos.
- La confirmación de estabilidad se solicita rápidamente y usa dos lecturas concordantes para reducir traducciones de subtítulos incompletos.
- Cada captura conserva el idioma con el que comenzó; cambiar de idioma invalida los resultados anteriores.

## OCR mejorado en los tres idiomas

- Primero se prueba el recorte original para responder rápido.
- Solo cuando la lectura parece vacía, pequeña o ruidosa se realiza una segunda pasada ampliada y con contraste.
- La mejora de imagen se adapta al tamaño del recorte y al idioma, con un límite aproximado de 1,8 megapíxeles para controlar memoria.
- Se elige la lectura más coherente sin mezclar dos OCR que discrepan.
- Se pueden unir hasta tres líneas cercanas del mismo subtítulo.
- Se conservan números y texto mixto útil como `Room 101`, `AI技术`, `3号` o `VIP会员`.

## Inglés

- Acepta palabras cortas como `Go`, `Run`, `Stop`, `Help`, `No`, `Why` y `Wait`.
- Protege contracciones y negaciones como `can't`, `don't`, `won't` e `isn't`.
- No considera iguales frases que cambian números o palabras críticas.
- Mejora la selección de líneas para evitar mezclar marcas de agua, texto chino u otros controles.

## Chino

- Admite chino simplificado y tradicional reconocido por ML Kit.
- Acepta expresiones de un solo carácter cuando se confirman entre capturas.
- Conserva letras y números que sí pertenecen al diálogo.
- Incluye respuestas directas para expresiones breves y frecuentes, mientras las frases completas siguen usando el modelo offline.

## Japonés

- Reconoce hiragana, katakana y kanji.
- Acepta expresiones cortas de uno o varios caracteres cuando son estables.
- En modo Japonés manual no ejecuta OCR chino ni inglés.
- Incluye respuestas directas para órdenes o preguntas breves frecuentes; las frases completas usan el modelo offline.

## Traducción y nombres propios

- El glosario puede proteger nombres o términos **dentro de una oración completa**, no solo cuando toda la línea coincide.
- Las reglas más largas se aplican antes que las cortas.
- El caché de traducción considera el contenido actual del glosario, evitando reutilizar una traducción vieja después de editarlo.
- Se rechazan resultados que siguen casi completamente en chino o japonés, pero se permiten nombres asiáticos dentro de una frase española real.

Ejemplos de glosario:

```text
魏无羡 => Wei Wuxian
蓝忘机 => Lan Wangji
五条悟 => Gojo Satoru
Save point => Punto de guardado
```

## Interfaz conservada

No se modificaron el punto rojo, el parpadeo LIVE, Ajustes, el botón Vivo ni el cuadro morado. Los subtítulos continúan con fondo transparente, letras blancas, contorno negro, sombra, tamaño ajustable y posición movible.
