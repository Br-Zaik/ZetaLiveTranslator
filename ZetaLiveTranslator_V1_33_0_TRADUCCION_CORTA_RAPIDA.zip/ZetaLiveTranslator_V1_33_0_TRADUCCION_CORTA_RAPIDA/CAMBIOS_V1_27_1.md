# Cambios de Zeta Live Translator 1.27.1

## Cierre ocasional al usar Chino

La causa más probable era la superposición de varias tareas asíncronas. Al pulsar **Trad.** de nuevo, una lectura anterior de ML Kit podía continuar reteniendo su bitmap mientras empezaba otra. El OCR chino requiere más memoria que el latino y podía provocar que Android cerrara el proceso en teléfonos modestos.

## Correcciones aplicadas

- Solo se permite una tarea OCR/traducción activa a la vez.
- Los toques repetidos no crean nuevas tareas; muestran que la captura anterior sigue procesándose.
- LIVE espera a que termine la lectura activa antes de capturar otra.
- La captura se recorta directamente desde el buffer de pantalla al cuadro morado.
- Se evita construir un bitmap completo de la pantalla para cada traducción.
- ImageReader usa dos buffers en lugar de tres.
- El OCR usa primero la imagen original y reserva la ampliación/contraste para un segundo intento.
- El procesamiento auxiliar se limita a aproximadamente 1,25 MP.
- Se capturan errores de memoria y fallos de inicialización de OCR/traducción.
- Los reconocedores y traductores se administran de forma segura durante el cierre del servicio.
- Versión actualizada a 1.27.1 (versionCode 25).

## Conservado

- Punto rojo y parpadeo LIVE.
- Botones y Ajustes.
- Cuadro morado seleccionable.
- Subtítulos transparentes con letras blancas, contorno negro y sombra.
- Inglés, Chino, Japonés y Auto; Coreano continúa eliminado.
