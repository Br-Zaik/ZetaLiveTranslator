# Zeta Live Translator v1.30.0

## Mejoras de interfaz y ajustes visuales
- Nuevo menú **Cuadro de captura** en la pantalla principal.
  - Cambiar color del borde.
  - Cambiar grosor del borde.
  - Añadir relleno interior suave.
  - Restablecer estilo por defecto.
- Nuevo menú **Apariencia de subtítulos**.
  - Cambiar tamaño.
  - Cambiar color del texto.
  - Cambiar grosor del contorno.
  - Cambiar alineación.
  - Restablecer estilo por defecto.
- Nuevo menú **Barra flotante**.
  - Elegir modo compacto o normal.
  - Ajustar transparencia.
  - Restablecer estilo por defecto.
- El cuadro de captura ahora aplica color, grosor y relleno configurables.
- Los subtítulos ahora respetan color, contorno y alineación configurables.
- La barra flotante ahora puede mostrarse con estilo compacto o normal.
- Se retiraron textos tipo "donghua" y "anime" de la interfaz para dejarla más neutra.

## Notas
- Los cambios visuales del overlay se aplican al volver a iniciar el traductor.
