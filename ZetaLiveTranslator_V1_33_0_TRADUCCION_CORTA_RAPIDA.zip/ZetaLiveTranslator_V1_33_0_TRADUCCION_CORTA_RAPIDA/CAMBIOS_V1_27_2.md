# Cambios de Zeta Live Translator 1.27.2

Versión enfocada en donghua y traducción continua Chino → Español.

## Rapidez sin saltarse la estabilidad

- Chino manual usa un intervalo LIVE de 330 ms; Auto conserva un intervalo más amplio porque puede ejecutar más OCR.
- Cuando la primera lectura necesita confirmación, la segunda captura se solicita casi inmediatamente.
- Sigue exigiendo dos lecturas compatibles: no se traduce una captura aislada como si fuera segura.
- El reconocedor OCR y el traductor del idioma elegido se preparan antes de la primera captura.

## Cambios de idioma seguros

- Al cambiar de idioma se invalida la captura anterior para que una lectura vieja no aparezca después con el modo nuevo.
- Si LIVE está activo, el nuevo idioma comienza a procesarse automáticamente.

## Mejor resultado en donghua

- Una traducción española ya no se descarta solo por conservar un nombre chino corto.
- Se siguen rechazando resultados que permanecen mayormente en chino o japonés.
- El glosario ahora funciona con Chino, Japonés e Inglés. Puede usarse para fijar nombres y términos de una serie, por ejemplo:

```text
魏无羡 => Wei Wuxian
蓝忘机 => Lan Wangji
宗门 => secta
```

El glosario solo actúa cuando coincide el texto completo; no reemplaza palabras dentro de cualquier frase.

## Conservado

- Punto rojo y parpadeo LIVE.
- Botones y Ajustes.
- Cuadro morado de selección.
- Subtítulos transparentes con letras, contorno y sombra.
- Eliminación completa de Coreano.
- Protección de negaciones, números y palabras cortas.
