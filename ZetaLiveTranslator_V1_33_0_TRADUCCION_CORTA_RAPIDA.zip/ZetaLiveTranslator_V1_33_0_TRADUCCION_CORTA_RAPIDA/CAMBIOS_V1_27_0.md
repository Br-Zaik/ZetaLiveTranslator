# Cambios de Zeta Live Translator 1.27.0

## Eliminado

- OCR coreano.
- Modelo y opción de traducción coreana.
- Botones, estados y dependencias coreanas.
- Fondo negro grande del subtítulo.
- Sustituciones automáticas peligrosas de jerga china/japonesa.
- Reinicio pegajoso del servicio de captura sin permiso recuperable.

## Corregido

- Inglés ya no aparece listo sin comprobar su modelo real.
- Preferencias antiguas no pueden inventar modelos instalados.
- Palabras inglesas cortas ya no se descartan por exigir dos palabras.
- Frases con negación o números diferentes no se tratan como repetidas.
- Caracteres chinos/japoneses cortos pueden confirmarse temporalmente.
- La app no elimina números ni combinaciones alfanuméricas útiles.
- Cada captura conserva el idioma con el que empezó.
- Los resultados atrasados se descartan y liberan correctamente.
- El subtítulo viejo desaparece cuando ya no hay texto.
- La captura responde a cambios de tamaño informados por Android.

## Mejorado

- Texto traducido con fondo transparente, contorno negro y sombra.
- Subtítulo arrastrable y con tamaño configurable.
- Menor escalado y contraste innecesarios.
- Procesamiento de bitmap fuera del hilo principal.
- Auto limitado a Inglés, Chino y Japonés.
- Pruebas automáticas para negaciones, números y similitud de frases.
