# Cambios de Zeta Live Translator 1.29.0

## Detectar idioma sin perder velocidad

- La opción **Auto** ahora se llama **Detectar**.
- Detectar prueba únicamente los modelos instalados: Inglés, Chino y Japonés.
- Una lectura muy clara bloquea el idioma en la primera captura.
- Una lectura dudosa necesita que el mismo idioma gane dos capturas cercanas.
- Después del bloqueo, la app deja de probar los otros OCR y utiliza la misma ruta rápida del modo manual.
- El botón muestra `Inglés✓`, `Chino✓` o `Japonés✓` cuando el idioma quedó fijado.
- El idioma no cambia aunque desaparezca el subtítulo o aparezca una línea difícil.
- Tocar el idioma con ✓ ejecuta **Detectar otra vez**.
- Mantener pulsado el botón permite pasar directamente a la selección manual.
- Si Detectar se reinicia mientras un OCR termina, el resultado antiguo se descarta antes de iniciar una detección nueva.
- Con un solo idioma instalado, la app entra directamente a ese idioma porque no hace falta detectar.

## Se conserva

- Punto rojo y parpadeo LIVE.
- Botón Vivo, Trad., Área y controles existentes.
- Cuadro morado.
- Subtítulos transparentes con contorno y sombra.
- Optimizaciones de Chino, Japonés e Inglés de la versión 1.28.0.
- Coreano eliminado.

## Pruebas añadidas

Se añadieron pruebas para:

- bloqueo inmediato con una candidata fuerte;
- bloqueo directo cuando existe un solo idioma instalado;
- confirmación de una candidata dudosa en dos capturas;
- reinicio de confirmación cuando gana otro idioma;
- caducidad de una detección antigua;
- reinicio manual de la detección.
