# Zeta Live Translator v1.32.0

## Funcionamiento sobre otras aplicaciones
- Se añadió una sección visible con el estado de:
  - permiso para mostrar sobre otras apps;
  - permiso de notificaciones;
  - optimización de batería.
- Nuevo botón **Abrir ajustes de batería** para que el usuario pueda seleccionar **Sin restricciones** o **No optimizar**, según el teléfono.
- El servicio de traducción queda declarado con `stopWithTask=false` para no detenerse solamente porque se retire la pantalla principal de recientes.
- La notificación permanente ahora abre Zeta al tocarla, se actualiza con el estado LIVE y está configurada como notificación de servicio.

## Estabilidad y memoria
- Se mantiene una sola captura/OCR/traducción activa a la vez.
- Las capturas demasiado grandes se reducen antes del OCR para evitar consumo innecesario de memoria.
- Cuando Android reporta memoria baja, Zeta activa temporalmente un modo de consumo reducido:
  - limita el tamaño de la imagen;
  - aumenta moderadamente el intervalo LIVE;
  - limpia capturas pendientes.
- Tras varias lecturas correctas, vuelve automáticamente al ritmo normal.
- Si el motor de lectura queda bloqueado durante demasiado tiempo, Zeta lo reconstruye y continúa sin cerrar la barra flotante ni perder la autorización de captura.

## Posiciones y experiencia visual
- Se guardan la posición del cuadro de captura, la barra flotante y el subtítulo.
- Las posiciones se adaptan cuando cambia la orientación o el tamaño de pantalla.
- Nuevo botón **Restablecer posiciones**.
- La interfaz mantiene su enfoque exclusivo:
  - Inglés, Chino o Japonés como entrada;
  - Español como salida fija;
  - sin voz, cuentas, nube ni inicio de sesión.

## Nota realista
Android todavía puede detener cualquier aplicación si el sistema se queda sin memoria o si el usuario fuerza su cierre. La exclusión de batería, el servicio en primer plano y la reducción de memoria disminuyen ese riesgo, pero no permiten prometer que una aplicación jamás será cerrada por el sistema.
