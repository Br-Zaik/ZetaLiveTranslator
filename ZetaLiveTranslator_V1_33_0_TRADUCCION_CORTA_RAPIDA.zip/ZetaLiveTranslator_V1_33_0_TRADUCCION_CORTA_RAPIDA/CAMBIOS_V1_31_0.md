# Zeta Live Translator v1.31.0

## Mejoras visuales y de enfoque
- La interfaz principal fue ordenada para verse más limpia y directa.
- Se añadió una tarjeta superior que deja claro el enfoque de la app:
  - entrada: inglés, chino y japonés
  - salida fija: español
- Se agrupó la personalización visual en una sección de **Apariencia**.
- Se eliminó la guía inicial automática para que la app abra de forma más limpia.
- Se cambió el texto general para dejar claro que la app está pensada para usuarios en español.

## Mejoras de diseño de pantalla principal
- Botón de permisos con redacción más clara.
- Botón de inicio con estilo más destacado.
- Tarjeta de idiomas renombrada a **Idiomas offline**.
- Se simplificó el bloque informativo final a un resumen más corto.

## Mejoras del overlay flotante
- Barra flotante con fondo más elegante, redondeado y con borde suave.
- Botones del overlay con estilo tipo píldora para verse más profesionales.
- Etiqueta **LIVE** más clara.
- Botón **Traducir** con texto completo.

## Mantiene
- Sin cuentas ni inicio de sesión.
- Sin reconocimiento de voz.
- Solo traducción de subtítulos o texto visible en pantalla.
- Traducción final al español.
