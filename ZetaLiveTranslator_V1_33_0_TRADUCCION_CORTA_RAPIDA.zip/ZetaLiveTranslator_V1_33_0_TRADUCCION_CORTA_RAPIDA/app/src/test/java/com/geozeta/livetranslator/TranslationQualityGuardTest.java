package com.geozeta.livetranslator;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TranslationQualityGuardTest {
    @Test public void rejectsMostlyChineseOutput() {
        assertTrue(TranslationQualityGuard.hasTooMuchCjkForSpanish("这是一个没有翻译的结果"));
    }

    @Test public void rejectsMostlyJapaneseOutput() {
        assertTrue(TranslationQualityGuard.hasTooMuchCjkForSpanish("これは翻訳されていません"));
    }

    @Test public void allowsSpanishWithShortChineseName() {
        assertFalse(TranslationQualityGuard.hasTooMuchCjkForSpanish("魏无羡 llegó a la montaña"));
    }

    @Test public void allowsSpanishWithLongerJapaneseName() {
        assertFalse(TranslationQualityGuard.hasTooMuchCjkForSpanish("Kamado 竈門炭治郎 llegó tarde"));
    }

    @Test public void rejectsANameWithoutActualSpanishSentence() {
        assertTrue(TranslationQualityGuard.hasTooMuchCjkForSpanish("Es 这是一个没有翻译"));
    }

    @Test public void allowsNormalSpanish() {
        assertFalse(TranslationQualityGuard.hasTooMuchCjkForSpanish("No puede ser, tenemos que irnos"));
    }
}
