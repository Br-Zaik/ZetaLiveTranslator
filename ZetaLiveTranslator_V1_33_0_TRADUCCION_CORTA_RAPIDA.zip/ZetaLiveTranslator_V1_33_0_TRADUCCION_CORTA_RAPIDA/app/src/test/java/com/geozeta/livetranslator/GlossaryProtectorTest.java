package com.geozeta.livetranslator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class GlossaryProtectorTest {
    @Test public void protectsChineseNameInsideSentence() {
        GlossaryProtector.Result result = GlossaryProtector.protect(
                "魏无羡回来了", "魏无羡 => Wei Wuxian", false);
        assertTrue(result.protectedText.contains("ZXQG0QXZ"));
        assertEquals("Wei Wuxian regresó", result.restore("ZXQG0QXZ regresó"));
    }

    @Test public void restoresTokenEvenWhenTranslatorAddsSpaces() {
        GlossaryProtector.Result result = GlossaryProtector.protect(
                "I saw Gojo", "Gojo => Gojo Satoru", true);
        assertEquals("Vi a Gojo Satoru", result.restore("Vi a Z X Q G 0 Q X Z"));
    }

    @Test public void longerRulesAreProtectedBeforeShorterRules() {
        GlossaryProtector.Result result = GlossaryProtector.protect(
                "蓝忘机来了", "蓝 => azul\n蓝忘机 => Lan Wangji", false);
        assertEquals("Lan Wangji llegó", result.restore("ZXQG0QXZ llegó"));
        assertFalse(result.protectedText.contains("azul"));
    }
    @Test public void shortEnglishRuleDoesNotChangePartOfLongerWord() {
        GlossaryProtector.Result result = GlossaryProtector.protect(
                "Go now, keep going", "Go => Ve", true);
        assertTrue(result.protectedText.startsWith("ZXQG0QXZ now"));
        assertTrue(result.protectedText.endsWith("keep going"));
        assertEquals("Ve ahora, sigue adelante", result.restore("ZXQG0QXZ ahora, sigue adelante"));
    }

}
