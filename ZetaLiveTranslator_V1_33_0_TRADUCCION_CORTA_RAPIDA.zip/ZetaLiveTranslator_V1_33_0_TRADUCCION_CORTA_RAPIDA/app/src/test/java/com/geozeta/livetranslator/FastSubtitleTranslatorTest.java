package com.geozeta.livetranslator;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class FastSubtitleTranslatorTest {
    @Test public void translatesShortEnglishCommandsInstantly() {
        assertEquals("Corre", FastSubtitleTranslator.translate("RUN!", "en"));
        assertEquals("No te muevas", FastSubtitleTranslator.translate("Don't move!", "en"));
        assertEquals("¿Qué pasó?", FastSubtitleTranslator.translate("What happened?", "en"));
    }

    @Test public void expandsCommonEnglishContractionsWithoutLosingNegation() {
        assertEquals("i am ready", FastSubtitleTranslator.normalizeEnglishForTest("I'm ready"));
        assertEquals("do not move", FastSubtitleTranslator.normalizeEnglishForTest("DON'T MOVE"));
        assertEquals("No entiendo", FastSubtitleTranslator.translate("I don't understand", "en"));
    }

    @Test public void leavesAmbiguousEnglishWordsToMainModel() {
        assertNull(FastSubtitleTranslator.translate("right", "en"));
        assertNull(FastSubtitleTranslator.translate("left", "en"));
        assertNull(FastSubtitleTranslator.translate("fire", "en"));
    }

    @Test public void translatesShortJapaneseDialogue() {
        assertEquals("Espera", FastSubtitleTranslator.translate("待って！", "ja"));
        assertEquals("¿Qué pasó?", FastSubtitleTranslator.translate("どうしたの？", "ja"));
        assertEquals("Tengo hambre", FastSubtitleTranslator.translate("お腹すいた", "ja"));
    }

    @Test public void usesJapaneseQuestionPunctuationForAmbiguousShortLine() {
        assertEquals("Estoy bien", FastSubtitleTranslator.translate("大丈夫。", "ja"));
        assertEquals("¿Estás bien?", FastSubtitleTranslator.translate("大丈夫？", "ja"));
    }

    @Test public void translatesSimplifiedAndTraditionalChinese() {
        assertEquals("No te preocupes", FastSubtitleTranslator.translate("别担心", "zh"));
        assertEquals("No te preocupes", FastSubtitleTranslator.translate("別擔心", "zh"));
        assertEquals("¿Qué pasó?", FastSubtitleTranslator.translate("發生什麼事了？", "zh"));
    }

    @Test public void leavesAmbiguousAsianSlangToMainModel() {
        assertNull(FastSubtitleTranslator.translate("やばい", "ja"));
        assertNull(FastSubtitleTranslator.translate("走", "zh"));
    }
}
