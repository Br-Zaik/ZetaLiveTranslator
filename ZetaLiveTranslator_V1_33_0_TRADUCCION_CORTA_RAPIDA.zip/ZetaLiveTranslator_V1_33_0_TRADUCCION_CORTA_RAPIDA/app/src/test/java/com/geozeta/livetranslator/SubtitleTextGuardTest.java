package com.geozeta.livetranslator;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class SubtitleTextGuardTest {
    @Test public void punctuationOnlyChangeIsEquivalent() {
        assertTrue(SubtitleTextGuard.areEquivalent("Hello, world!", "Hello world"));
    }

    @Test public void oneOcrCharacterMayBeEquivalentInLongSentence() {
        assertTrue(SubtitleTextGuard.areEquivalent("Where are you going", "Where are you goinq"));
    }

    @Test public void shortWordsAreNeverMergedBySimilarity() {
        assertFalse(SubtitleTextGuard.areEquivalent("No", "Go"));
        assertFalse(SubtitleTextGuard.areEquivalent("Run", "Fun"));
    }

    @Test public void contractionsAndNegationsChangeMeaning() {
        assertFalse(SubtitleTextGuard.areEquivalent("You can do it", "You can't do it"));
        assertFalse(SubtitleTextGuard.areEquivalent("You can do it", "You cant do it"));
        assertFalse(SubtitleTextGuard.areEquivalent("I do know", "I dont know"));
        assertFalse(SubtitleTextGuard.areEquivalent("He is alive", "He is not alive"));
        assertFalse(SubtitleTextGuard.areEquivalent("We should leave", "We should never leave"));
    }

    @Test public void numberChangesAreNotEquivalent() {
        assertFalse(SubtitleTextGuard.areEquivalent("Room 101", "Room 102"));
        assertFalse(SubtitleTextGuard.areEquivalent("Take 2 then 3", "Take 3 then 2"));
    }

    @Test public void chineseAndJapaneseNegationsAreProtected() {
        assertFalse(SubtitleTextGuard.areEquivalent("我喜欢你", "我不喜欢你"));
        assertFalse(SubtitleTextGuard.areEquivalent("行きます", "行きません"));
    }
}
