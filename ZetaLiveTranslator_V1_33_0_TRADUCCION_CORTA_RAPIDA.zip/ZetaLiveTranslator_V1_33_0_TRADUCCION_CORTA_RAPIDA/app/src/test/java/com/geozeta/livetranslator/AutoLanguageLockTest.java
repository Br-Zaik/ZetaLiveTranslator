package com.geozeta.livetranslator;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class AutoLanguageLockTest {
    @Test public void strongCandidateLocksImmediately() {
        AutoLanguageLock lock = new AutoLanguageLock();
        assertTrue(lock.shouldLock("zh", true, 3, 1000L));
    }

    @Test public void onlyInstalledLanguageLocksImmediately() {
        AutoLanguageLock lock = new AutoLanguageLock();
        assertTrue(lock.shouldLock("ja", false, 1, 1000L));
    }

    @Test public void uncertainCandidateNeedsTwoNearbyWins() {
        AutoLanguageLock lock = new AutoLanguageLock();
        assertFalse(lock.shouldLock("en", false, 3, 1000L));
        assertTrue(lock.shouldLock("en", false, 3, 1300L));
    }

    @Test public void differentWinnerRestartsConfirmation() {
        AutoLanguageLock lock = new AutoLanguageLock();
        assertFalse(lock.shouldLock("zh", false, 3, 1000L));
        assertFalse(lock.shouldLock("ja", false, 3, 1200L));
        assertTrue(lock.shouldLock("ja", false, 3, 1400L));
    }

    @Test public void staleWinnerDoesNotConfirm() {
        AutoLanguageLock lock = new AutoLanguageLock();
        assertFalse(lock.shouldLock("en", false, 3, 1000L));
        assertFalse(lock.shouldLock("en", false, 3, 4000L));
        assertTrue(lock.shouldLock("en", false, 3, 4200L));
    }

    @Test public void resetForcesFreshDetection() {
        AutoLanguageLock lock = new AutoLanguageLock();
        assertFalse(lock.shouldLock("zh", false, 3, 1000L));
        lock.reset();
        assertFalse(lock.shouldLock("zh", false, 3, 1200L));
    }
}
