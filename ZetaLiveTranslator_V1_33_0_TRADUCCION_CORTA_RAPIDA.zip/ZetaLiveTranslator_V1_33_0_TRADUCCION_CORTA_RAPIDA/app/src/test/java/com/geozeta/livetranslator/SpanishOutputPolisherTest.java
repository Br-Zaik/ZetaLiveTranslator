package com.geozeta.livetranslator;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class SpanishOutputPolisherTest {
    @Test public void cleansSpacesAndCapitalizes() {
        assertEquals("Hola, amigo", SpanishOutputPolisher.polish(" hola ,amigo ", "hello, friend"));
    }

    @Test public void restoresOpeningQuestionMarkFromSource() {
        assertEquals("¿Dónde estás?", SpanishOutputPolisher.polish("dónde estás?", "Where are you?"));
    }

    @Test public void restoresOpeningExclamationMarkFromSource() {
        assertEquals("¡Cuidado!", SpanishOutputPolisher.polish("cuidado!", "Watch out!"));
    }

    @Test public void doesNotDuplicateSpanishPunctuation() {
        assertEquals("¿De verdad?", SpanishOutputPolisher.polish("¿de verdad?", "Really?"));
        assertEquals("¡Ayuda!", SpanishOutputPolisher.polish("¡ayuda!", "Help!"));
    }
}
