package com.geozeta.livetranslator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OverlayTranslatorService extends Service {
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_DATA = "projection_data";

    private static final String CHANNEL_ID = "zeta_live_translator";
    private static final String TAG = "ZetaOverlay";
    private static final int NOTIFICATION_ID = 781;
    private static final long BUSY_TIMEOUT_MS = 12000L;
    private static final long ENGINE_HARD_TIMEOUT_MS = 24000L;
    private static final long LIVE_INTERVAL_CHINESE_MS = 300L;
    private static final long LIVE_INTERVAL_JAPANESE_MS = 310L;
    private static final long LIVE_INTERVAL_ENGLISH_MS = 300L;
    private static final long LIVE_INTERVAL_AUTO_MS = 470L;
    private static final long STABILITY_RETRY_MS = 80L;
    private static final int MAX_OCR_PIXELS = 1400000;
    private static final int LOW_MEMORY_MAX_OCR_PIXELS = 820000;
    private static final long LOW_MEMORY_MIN_INTERVAL_MS = 520L;
    private static final String KEY_LAST_LANGUAGE_MODE = "last_overlay_language_mode";

    private WindowManager windowManager;
    private boolean toolbarCompactMode = MainActivity.DEFAULT_TOOLBAR_COMPACT;
    private int toolbarBackgroundAlpha = MainActivity.DEFAULT_TOOLBAR_ALPHA;
    private Handler handler;
    private final ExecutorService captureExecutor = Executors.newSingleThreadExecutor();
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;
    private int captureWidth;
    private int captureHeight;

    private LinearLayout toolbar;
    private LinearLayout optionsRow;
    private TextView collapseBtn;
    private TextView areaBtn;
    private TextView liveIndicatorView;
    private TextView liveBtn;
    private TextView langBtn;
    private TextView statusView;
    private TextView subtitleView;
    private SelectorOverlayView selectorView;
    private WindowManager.LayoutParams toolbarParams;
    private WindowManager.LayoutParams subtitleParams;
    private WindowManager.LayoutParams selectorParams;
    private WindowManager.LayoutParams statusParams;

    private TranslatorEngine engine;
    private Runnable statusHideRunnable;
    private Rect selectorRect;
    private boolean selecting = false;
    private boolean live = false;
    private boolean busy = false;
    private boolean subtitleHidden = false;
    private boolean subtitleManuallyMoved = false;
    private boolean toolbarCollapsed = false;
    private boolean destroyed = false;
    private boolean captureViewsHidden = false;
    private boolean indicatorBlinkOn = true;
    private int toolbarVisibilityBeforeCapture = View.VISIBLE;
    private int selectorVisibilityBeforeCapture = View.VISIBLE;
    private int statusVisibilityBeforeCapture = View.GONE;
    private int subtitleVisibilityBeforeCapture = View.GONE;
    private String lastShownSubtitle = "";
    private long lastSubtitleTime = 0L;
    private long statusVisibleUntil = 0L;
    private int requestSerial = 0;
    private int activeRequestId = 0;
    private long busyStartedAt = 0L;
    private int captureFailureStreak = 0;
    private int emptyFrameStreak = 0;
    private volatile boolean engineTaskInFlight = false;
    private volatile long engineTaskStartedAt = 0L;
    private boolean liveTickPending = false;
    private boolean autoRedetectPending = false;
    private String announcedAutoMode = "";
    private volatile boolean lowMemoryMode = false;
    private int successfulFramesAfterMemoryPressure = 0;
    private int engineGeneration = 1;
    private int layoutResetCounterAtStart = 0;

    private final Runnable indicatorBlinkRunnable = new Runnable() {
        @Override public void run() {
            if (destroyed || liveIndicatorView == null) return;
            if (!live) {
                liveIndicatorView.setAlpha(1f);
                liveIndicatorView.setTextColor(Color.argb(170, 255, 255, 255));
                return;
            }
            indicatorBlinkOn = !indicatorBlinkOn;
            liveIndicatorView.setAlpha(indicatorBlinkOn ? 1f : 0.22f);
            liveIndicatorView.setTextColor(Color.rgb(255, 64, 64));
            handler.removeCallbacks(this);
            handler.postDelayed(this, 420L);
        }
    };

    // La estabilidad se decide antes de traducir, dentro de TranslatorEngine.
    // Aquí solo evitamos volver a mostrar la misma frase por ruido mínimo del OCR.
    private String currentSourceKey = "";

    // Detectar prueba Inglés, Chino o Japonés solo al inicio y luego bloquea el idioma.
    private int languageIndex = 0;
    private final String[] languageModes = new String[]{
            TranslatorEngine.MODE_AUTO,
            TranslatorEngine.MODE_ENGLISH,
            TranslatorEngine.MODE_CHINESE,
            TranslatorEngine.MODE_JAPANESE
    };

    private final Runnable liveRunnable = new Runnable() {
        @Override public void run() {
            if (!live || destroyed) return;
            if (busy || engineTaskInFlight) {
                // No inicia otro OCR, pero recuerda que el video ya avanzó.
                liveTickPending = true;
                handler.removeCallbacks(this);
                handler.postDelayed(this, 70L);
                return;
            }
            liveTickPending = false;
            translateOnce(false);
            handler.removeCallbacks(this);
            handler.postDelayed(this, liveIntervalForCurrentMode());
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        engine = new TranslatorEngine(getApplicationContext());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForeground(NOTIFICATION_ID, buildNotification("Traductor listo"));
        loadAppearancePreferences();
        readMetrics();
        layoutResetCounterAtStart = appPreferences().getInt(MainActivity.KEY_LAYOUT_RESET_COUNTER, 0);
        selectorRect = loadSavedSelectorRect();
        subtitleManuallyMoved = appPreferences().getBoolean(MainActivity.KEY_SUBTITLE_MOVED, false);
        chooseInitialLanguageMode();
        engine.preload(languageModes[languageIndex]);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (destroyed) return START_NOT_STICKY;
        if (intent == null) {
            if (mediaProjection == null) stopInvalidProjectionStart(startId);
            return START_NOT_STICKY;
        }
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (resultCode != 0 && data != null) {
            if (mediaProjection != null) {
                invalidateActiveRequest();
                releaseCaptureOnly();
                MediaProjection previousProjection = mediaProjection;
                mediaProjection = null;
                try { previousProjection.stop(); } catch (Exception ignored) { }
            }
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            MediaProjection newProjection = manager.getMediaProjection(resultCode, data);
            if (newProjection == null) {
                stopInvalidProjectionStart(startId);
                return START_NOT_STICKY;
            }
            mediaProjection = newProjection;
            newProjection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    if (!destroyed && mediaProjection == newProjection) stopSelf();
                }

                @Override public void onCapturedContentResize(int width, int height) {
                    if (destroyed || mediaProjection != newProjection || width <= 0 || height <= 0) return;
                    handler.post(() -> resizeCaptureSurface(width, height));
                }
            }, handler);
            setupInitialCapture();
            showToolbar();
        } else if (mediaProjection == null) {
            stopInvalidProjectionStart(startId);
        }
        return START_NOT_STICKY;
    }

    private void stopInvalidProjectionStart(int startId) {
        try { stopForeground(true); } catch (Exception ignored) { }
        stopSelf(startId);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void setupInitialCapture() {
        if (mediaProjection == null || destroyed) return;
        releaseCaptureOnly();
        readMetrics();
        captureWidth = screenWidth;
        captureHeight = screenHeight;
        imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ZetaLiveTranslatorScreen",
                captureWidth,
                captureHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
        );
    }

    /**
     * En una rotación no se vuelve a usar createVirtualDisplay con el mismo token.
     * Se conserva el VirtualDisplay y solo se cambia su tamaño y superficie.
     */
    private void resizeCaptureSurface() {
        resizeCaptureSurface(screenWidth, screenHeight);
    }

    private void resizeCaptureSurface(int width, int height) {
        if (mediaProjection == null || destroyed || width <= 0 || height <= 0) return;
        if (width == captureWidth && height == captureHeight && imageReader != null) return;
        ImageReader replacement = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        ImageReader previous = imageReader;
        try {
            if (virtualDisplay == null) {
                replacement.close();
                showStatus("Reinicia el traductor para recuperar la captura", 2200);
                return;
            }
            virtualDisplay.resize(width, height, screenDensity);
            virtualDisplay.setSurface(replacement.getSurface());
            imageReader = replacement;
            captureWidth = width;
            captureHeight = height;
            if (previous != null && previous != imageReader) previous.close();
        } catch (Exception e) {
            replacement.close();
            imageReader = previous;
            showStatus("No se pudo ajustar el tamaño de la captura", 1800);
        }
    }

    private void readMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.view.WindowMetrics wm = windowManager.getMaximumWindowMetrics();
            Rect bounds = wm.getBounds();
            screenWidth = bounds.width();
            screenHeight = bounds.height();
            screenDensity = getResources().getDisplayMetrics().densityDpi;
        } else {
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.densityDpi;
        }
    }

    private SharedPreferences appPreferences() {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    private boolean canPersistLayout() {
        return appPreferences().getInt(MainActivity.KEY_LAYOUT_RESET_COUNTER, 0) == layoutResetCounterAtStart;
    }

    private Rect loadSavedSelectorRect() {
        SharedPreferences prefs = appPreferences();
        if (!prefs.contains(MainActivity.KEY_SELECTOR_LEFT)
                || !prefs.contains(MainActivity.KEY_SELECTOR_TOP)
                || !prefs.contains(MainActivity.KEY_SELECTOR_RIGHT)
                || !prefs.contains(MainActivity.KEY_SELECTOR_BOTTOM)) {
            return defaultRect();
        }
        int oldWidth = Math.max(1, prefs.getInt(MainActivity.KEY_LAYOUT_SCREEN_W, screenWidth));
        int oldHeight = Math.max(1, prefs.getInt(MainActivity.KEY_LAYOUT_SCREEN_H, screenHeight));
        Rect saved = new Rect(
                scaleCoordinate(prefs.getInt(MainActivity.KEY_SELECTOR_LEFT, 0), oldWidth, screenWidth),
                scaleCoordinate(prefs.getInt(MainActivity.KEY_SELECTOR_TOP, 0), oldHeight, screenHeight),
                scaleCoordinate(prefs.getInt(MainActivity.KEY_SELECTOR_RIGHT, screenWidth), oldWidth, screenWidth),
                scaleCoordinate(prefs.getInt(MainActivity.KEY_SELECTOR_BOTTOM, screenHeight), oldHeight, screenHeight));
        return clampScreenRect(saved);
    }

    private int loadSavedX(String key, int defaultValue) {
        SharedPreferences prefs = appPreferences();
        if (!prefs.contains(key)) return defaultValue;
        int oldWidth = Math.max(1, prefs.getInt(MainActivity.KEY_LAYOUT_SCREEN_W, screenWidth));
        return scaleCoordinate(prefs.getInt(key, defaultValue), oldWidth, screenWidth);
    }

    private int loadSavedY(String key, int defaultValue) {
        SharedPreferences prefs = appPreferences();
        if (!prefs.contains(key)) return defaultValue;
        int oldHeight = Math.max(1, prefs.getInt(MainActivity.KEY_LAYOUT_SCREEN_H, screenHeight));
        return scaleCoordinate(prefs.getInt(key, defaultValue), oldHeight, screenHeight);
    }

    private void saveSelectorPosition() {
        saveAllLayoutPositions();
    }

    private void saveToolbarPosition() {
        saveAllLayoutPositions();
    }

    private void saveSubtitlePosition() {
        if (!canPersistLayout() || subtitleParams == null) return;
        subtitleManuallyMoved = true;
        saveAllLayoutPositions();
    }

    private void saveAllLayoutPositions() {
        if (!canPersistLayout()) return;
        SharedPreferences.Editor editor = appPreferences().edit()
                .putInt(MainActivity.KEY_LAYOUT_SCREEN_W, screenWidth)
                .putInt(MainActivity.KEY_LAYOUT_SCREEN_H, screenHeight);
        if (selectorRect != null) {
            editor.putInt(MainActivity.KEY_SELECTOR_LEFT, selectorRect.left)
                    .putInt(MainActivity.KEY_SELECTOR_TOP, selectorRect.top)
                    .putInt(MainActivity.KEY_SELECTOR_RIGHT, selectorRect.right)
                    .putInt(MainActivity.KEY_SELECTOR_BOTTOM, selectorRect.bottom);
        }
        if (toolbarParams != null) {
            editor.putInt(MainActivity.KEY_TOOLBAR_X, toolbarParams.x)
                    .putInt(MainActivity.KEY_TOOLBAR_Y, toolbarParams.y);
        }
        if (subtitleManuallyMoved && subtitleParams != null) {
            editor.putInt(MainActivity.KEY_SUBTITLE_X, subtitleParams.x)
                    .putInt(MainActivity.KEY_SUBTITLE_Y, subtitleParams.y)
                    .putBoolean(MainActivity.KEY_SUBTITLE_MOVED, true);
        }
        editor.apply();
    }

    private Rect defaultRect() {
        int w = Math.min(screenWidth - dp(24), Math.max(dp(260), (int) (screenWidth * 0.70f)));
        int h = Math.min(screenHeight - dp(32), Math.max(dp(70), (int) (screenHeight * 0.13f)));
        int left = Math.max(0, (screenWidth - w) / 2);
        int top = Math.max(0, (int) (screenHeight * 0.70f));
        return clampScreenRect(new Rect(left, top, left + w, top + h));
    }

    private void showToolbar() {
        if (toolbar != null || destroyed) return;
        loadAppearancePreferences();
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setGravity(Gravity.START);
        int horizontalPadding = toolbarCompactMode ? dp(3) : dp(5);
        int topPadding = toolbarCompactMode ? dp(2) : dp(4);
        int bottomPadding = toolbarCompactMode ? dp(3) : dp(5);
        toolbar.setPadding(horizontalPadding, topPadding, horizontalPadding, bottomPadding);
        toolbar.setBackground(toolbarBackground());

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(headerRow, new LinearLayout.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT));

        optionsRow = new LinearLayout(this);
        optionsRow.setOrientation(LinearLayout.HORIZONTAL);
        optionsRow.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(optionsRow, new LinearLayout.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT));

        collapseBtn = addButton(headerRow, "‹");
        liveIndicatorView = addIndicatorDot(headerRow);
        TextView closeBtn = addButton(headerRow, "×");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(18);
        closeBtn.setPadding(dp(12), dp(5), dp(12), dp(5));

        areaBtn = addButton(optionsRow, selecting ? "OK" : "Área");
        TextView translateBtn = addButton(optionsRow, "Traducir");
        liveBtn = addButton(optionsRow, "LIVE");
        TextView subtitleBtn = addButton(optionsRow, subtitleHidden ? "Mostrar" : "Ocultar");
        langBtn = addButton(optionsRow, currentLanguageButtonText());

        collapseBtn.setOnClickListener(v -> toggleToolbarCollapsed());
        areaBtn.setOnClickListener(v -> toggleSelector());
        translateBtn.setOnClickListener(v -> translateOnce(true));
        liveBtn.setOnClickListener(v -> toggleLive());
        subtitleBtn.setOnClickListener(v -> {
            subtitleHidden = !subtitleHidden;
            if (subtitleView != null) subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
            subtitleBtn.setText(subtitleHidden ? "Mostrar" : "Ocultar");
        });
        langBtn.setOnClickListener(v -> handleLanguageButtonTap());
        langBtn.setOnLongClickListener(v -> {
            cycleLanguage();
            return true;
        });
        closeBtn.setOnClickListener(v -> stopSelf());

        toolbarParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        toolbarParams.gravity = Gravity.TOP | Gravity.START;
        toolbarParams.x = loadSavedX(MainActivity.KEY_TOOLBAR_X, dp(8));
        toolbarParams.y = loadSavedY(MainActivity.KEY_TOOLBAR_Y, dp(38));
        toolbarParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        View.OnTouchListener toolbarDragListener = new View.OnTouchListener() {
            int startX;
            int startY;
            float touchX;
            float touchY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = toolbarParams.x;
                        startY = toolbarParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - touchX);
                        int dy = (int) (event.getRawY() - touchY);
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true;
                        toolbarParams.x = Math.max(0, Math.min(startX + dx, Math.max(0, screenWidth - dp(44))));
                        toolbarParams.y = Math.max(0, Math.min(startY + dy, Math.max(0, screenHeight - dp(44))));
                        safeUpdate(toolbar, toolbarParams);
                        updateStatusPosition();
                        return true;
                    case MotionEvent.ACTION_UP:
                        saveToolbarPosition();
                        if (!moved) v.performClick();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return false;
            }
        };
        toolbar.setOnTouchListener(toolbarDragListener);
        // La flecha funciona además como asa de arrastre; así no depende de tocar un espacio vacío.
        collapseBtn.setOnTouchListener(toolbarDragListener);
        safeAdd(toolbar, toolbarParams);
        // Como en la version original: el subtítulo no aparece hasta que exista
        // una traduccion real. No se muestra "Esperando subtitulo" sobre otras apps.
    }

    private void loadAppearancePreferences() {
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        toolbarCompactMode = prefs.getBoolean(MainActivity.KEY_TOOLBAR_COMPACT, MainActivity.DEFAULT_TOOLBAR_COMPACT);
        toolbarBackgroundAlpha = prefs.getInt(MainActivity.KEY_TOOLBAR_ALPHA, MainActivity.DEFAULT_TOOLBAR_ALPHA);
    }

    private void applySelectorAppearance() {
        if (selectorView == null) return;
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        int color = prefs.getInt(MainActivity.KEY_SELECTOR_COLOR, MainActivity.DEFAULT_SELECTOR_COLOR);
        int strokeDp = prefs.getInt(MainActivity.KEY_SELECTOR_STROKE_DP, MainActivity.DEFAULT_SELECTOR_STROKE_DP);
        int fillAlpha = prefs.getInt(MainActivity.KEY_SELECTOR_FILL_ALPHA, MainActivity.DEFAULT_SELECTOR_FILL_ALPHA);
        selectorView.setAppearance(color, strokeDp, fillAlpha);
    }

    private void applySubtitleAppearance() {
        if (subtitleView == null) return;
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        int savedTextSize = prefs.getInt(MainActivity.KEY_SUBTITLE_SIZE_SP, MainActivity.DEFAULT_SUBTITLE_SIZE_SP);
        int textColor = prefs.getInt(MainActivity.KEY_SUBTITLE_TEXT_COLOR, MainActivity.DEFAULT_SUBTITLE_TEXT_COLOR);
        int outlineDp = prefs.getInt(MainActivity.KEY_SUBTITLE_OUTLINE_DP, MainActivity.DEFAULT_SUBTITLE_OUTLINE_DP);
        int gravity = prefs.getInt(MainActivity.KEY_SUBTITLE_ALIGN, MainActivity.DEFAULT_SUBTITLE_ALIGN);
        subtitleView.setTextSize(savedTextSize);
        subtitleView.setGravity(gravity);
        if (subtitleView instanceof OutlinedTextView) {
            ((OutlinedTextView) subtitleView).setVisualStyle(textColor, Color.BLACK, outlineDp);
        } else {
            subtitleView.setTextColor(textColor);
        }
    }

    private void toggleToolbarCollapsed() {
        toolbarCollapsed = !toolbarCollapsed;
        if (toolbar == null || collapseBtn == null) return;
        collapseBtn.setText(toolbarCollapsed ? "›" : "‹");
        if (optionsRow != null) optionsRow.setVisibility(toolbarCollapsed ? View.GONE : View.VISIBLE);
        updateLiveIndicatorState();
        updateStatusPosition();
    }

    private TextView addButton(LinearLayout parent, String text) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextSize(toolbarCompactMode ? 11 : 12);
        b.setGravity(Gravity.CENTER);
        b.setPadding(toolbarCompactMode ? dp(7) : dp(9), toolbarCompactMode ? dp(5) : dp(6),
                toolbarCompactMode ? dp(7) : dp(9), toolbarCompactMode ? dp(5) : dp(6));
        b.setBackground(pillBackground());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(5);
        lp.bottomMargin = dp(3);
        parent.addView(b, lp);
        return b;
    }

    private GradientDrawable toolbarBackground() {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.argb(toolbarBackgroundAlpha, 17, 24, 39));
        drawable.setCornerRadius(dp(16));
        drawable.setStroke(dp(1), Color.argb(140, 120, 136, 160));
        return drawable;
    }

    private GradientDrawable pillBackground() {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.argb(52, 255, 255, 255));
        drawable.setCornerRadius(dp(12));
        drawable.setStroke(dp(1), Color.argb(80, 255, 255, 255));
        return drawable;
    }

    private TextView addIndicatorDot(LinearLayout parent) {
        TextView dot = new TextView(this);
        dot.setText("●");
        dot.setTextSize(14);
        dot.setTextColor(Color.argb(170, 255, 255, 255));
        dot.setGravity(Gravity.CENTER);
        dot.setPadding(dp(2), dp(0), dp(5), dp(0));
        dot.setBackgroundColor(Color.TRANSPARENT);
        parent.addView(dot, new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT));
        updateLiveIndicatorState();
        return dot;
    }

    private void updateLiveIndicatorState() {
        if (handler == null) return;
        handler.removeCallbacks(indicatorBlinkRunnable);
        if (liveIndicatorView == null) return;
        if (live) {
            indicatorBlinkOn = true;
            liveIndicatorView.setVisibility(View.VISIBLE);
            liveIndicatorView.setAlpha(1f);
            liveIndicatorView.setTextColor(Color.rgb(255, 64, 64));
            handler.post(indicatorBlinkRunnable);
        } else {
            liveIndicatorView.setVisibility(View.VISIBLE);
            liveIndicatorView.setAlpha(1f);
            liveIndicatorView.setTextColor(Color.argb(170, 255, 255, 255));
        }
    }

    private void toggleSelector() {
        if (selecting) {
            saveSelectorPosition();
            hideSelector();
            selecting = false;
            if (areaBtn != null) areaBtn.setText("Área");
            resetTranslationSwitchState(true);
            showStatus("Área guardada", 900);
        } else {
            engine.resetContextState();
            resetTranslationSwitchState(false);
            showSelector();
            selecting = true;
            if (areaBtn != null) areaBtn.setText("OK");
            showStatus("Ajusta y toca OK", 1200);
        }
    }

    private void showSelector() {
        if (selectorView != null || destroyed) return;
        selectorView = new SelectorOverlayView(this, selectorRect);
        applySelectorAppearance();
        selectorView.setOnRectChangedListener(rect -> {
            selectorRect = clampScreenRect(rect);
            if (subtitleView != null && subtitleParams != null && !subtitleManuallyMoved) {
                subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
                positionSubtitleNearSelector();
                safeUpdate(subtitleView, subtitleParams);
            }
        });
        selectorParams = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        selectorParams.gravity = Gravity.TOP | Gravity.START;
        selectorParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        safeAdd(selectorView, selectorParams);
        bringToolbarToFront();
    }

    private void bringToolbarToFront() {
        if (toolbar != null && toolbarParams != null) {
            safeRemove(toolbar);
            safeAdd(toolbar, toolbarParams);
        }
    }

    private void hideSelector() {
        if (selectorView != null) {
            safeRemove(selectorView);
            selectorView = null;
        }
    }

    private void toggleLive() {
        live = !live;
        handler.removeCallbacks(liveRunnable);
        if (live) {
            liveTickPending = false;
            if (selecting) toggleSelector();
            if (liveBtn != null) liveBtn.setText("Pausa");
            updateLiveIndicatorState();
            showStatus(isDetectMode() && !engine.isAutoLanguageLocked()
                    ? "En vivo: detectando idioma…" : "En vivo", 900);
            engine.resetStabilityState();
            engine.resetContextState();
            engine.preload(languageModes[languageIndex]);
            updateNotification("LIVE activo · " + languageLabel(effectiveLanguageMode()) + " → Español");
            handler.post(liveRunnable);
        } else {
            liveTickPending = false;
            if (liveBtn != null) liveBtn.setText("LIVE");
            updateLiveIndicatorState();
            invalidateActiveRequest();
            showStatus("Pausado", 700);
            updateNotification("Traductor pausado");
            engine.resetStabilityState();
        }
    }

    private void cycleLanguage() {
        invalidateActiveRequest();
        int installedCount = installedLanguageCount();
        if (installedCount <= 1) {
            chooseInitialLanguageMode();
        } else {
            int attempts = 0;
            do {
                languageIndex = (languageIndex + 1) % languageModes.length;
                attempts++;
            } while (attempts < languageModes.length
                    && !TranslatorEngine.MODE_AUTO.equals(languageModes[languageIndex])
                    && !isModeInstalled(languageModes[languageIndex]));
        }

        engine.resetAutoState();
        announcedAutoMode = "";
        autoRedetectPending = false;
        engine.resetStabilityState();
        engine.resetContextState();
        resetTranslationSwitchState(true);
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .edit().putString(KEY_LAST_LANGUAGE_MODE, languageModes[languageIndex]).apply();
        updateLanguageButton();
        engine.preload(languageModes[languageIndex]);
        if (isDetectMode()) {
            showStatus("Detectar idioma: pulsa LIVE o Traducir.", 1500);
        } else {
            showStatus("Idioma: " + languageLabel(languageModes[languageIndex]) + " → Español", 1300);
        }
        if (live) {
            handler.removeCallbacks(liveRunnable);
            handler.postDelayed(liveRunnable, 80L);
        }
    }

    private void chooseInitialLanguageMode() {
        String saved = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getString(KEY_LAST_LANGUAGE_MODE, "");
        if (saved != null && !saved.isEmpty()) {
            for (int i = 0; i < languageModes.length; i++) {
                if (!saved.equals(languageModes[i])) continue;
                if (TranslatorEngine.MODE_AUTO.equals(saved) && installedLanguageCount() > 1) {
                    languageIndex = i;
                    return;
                }
                if (!TranslatorEngine.MODE_AUTO.equals(saved) && isModeInstalled(saved)) {
                    languageIndex = i;
                    return;
                }
            }
        }

        int onlyIndex = -1;
        int count = 0;
        for (int i = 1; i < languageModes.length; i++) {
            if (isModeInstalled(languageModes[i])) {
                count++;
                onlyIndex = i;
            }
        }
        // Con un solo modelo no hace falta detectar. Con dos o tres, Detectar es el inicio útil.
        languageIndex = count == 1 ? onlyIndex : 0;
    }

    private int installedLanguageCount() {
        int count = 0;
        for (int i = 1; i < languageModes.length; i++) {
            if (isModeInstalled(languageModes[i])) count++;
        }
        return count;
    }

    private boolean isModeInstalled(String mode) {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.KEY_MODEL_PREFIX + mode, false);
    }

    private String languageLabel(String mode) {
        if (TranslatorEngine.MODE_AUTO.equals(mode)) return "Detectar";
        if (TranslatorEngine.MODE_CHINESE.equals(mode)) return "Chino";
        if (TranslatorEngine.MODE_ENGLISH.equals(mode)) return "Inglés";
        if (TranslatorEngine.MODE_JAPANESE.equals(mode)) return "Japonés";
        return "Detectar";
    }

    private String effectiveLanguageMode() {
        String mode = languageModes[Math.max(0, Math.min(languageIndex, languageModes.length - 1))];
        if (TranslatorEngine.MODE_AUTO.equals(mode) && engine != null) {
            String locked = engine.getLockedAutoMode();
            if (locked != null) return locked;
        }
        return mode;
    }

    private boolean isDetectMode() {
        return TranslatorEngine.MODE_AUTO.equals(
                languageModes[Math.max(0, Math.min(languageIndex, languageModes.length - 1))]);
    }

    private String currentLanguageButtonText() {
        if (!isDetectMode()) return languageLabel(languageModes[languageIndex]) + "→ES";
        String locked = engine == null ? null : engine.getLockedAutoMode();
        return locked == null ? "Detectar" : languageLabel(locked) + "✓";
    }

    private void updateLanguageButton() {
        if (langBtn != null) langBtn.setText(currentLanguageButtonText());
    }

    private void handleLanguageButtonTap() {
        if (isDetectMode() && engine.isAutoLanguageLocked()) {
            requestAutoRedetect();
            return;
        }
        cycleLanguage();
    }

    private void requestAutoRedetect() {
        if (!isDetectMode()) return;
        if (engineTaskInFlight) {
            autoRedetectPending = true;
            invalidateActiveRequest();
            showStatus("Detectar otra vez al terminar la lectura actual…", 1500);
            return;
        }
        applyAutoRedetect();
    }

    private void applyAutoRedetect() {
        autoRedetectPending = false;
        invalidateActiveRequest();
        engine.resetAutoState();
        engine.resetStabilityState();
        engine.resetContextState();
        announcedAutoMode = "";
        currentSourceKey = "";
        lastShownSubtitle = "";
        emptyFrameStreak = 0;
        if (subtitleView != null) subtitleView.setVisibility(View.GONE);
        updateLanguageButton();
        engine.preload(TranslatorEngine.MODE_AUTO);
        showStatus("Detectando idioma otra vez…", 1200);
        if (live) {
            handler.removeCallbacks(liveRunnable);
            handler.postDelayed(liveRunnable, 70L);
        } else {
            handler.postDelayed(() -> translateOnce(true), 70L);
        }
    }

    private void refreshAutoDetectionUi(boolean announce) {
        if (!isDetectMode()) return;
        String locked = engine.getLockedAutoMode();
        updateLanguageButton();
        if (locked == null || locked.equals(announcedAutoMode)) return;
        announcedAutoMode = locked;
        if (announce) {
            showStatus("Detectado: " + languageLabel(locked)
                    + ". Toca para detectar otra vez; mantén pulsado para elegir.", 2600);
        }
    }

    private void translateOnce(boolean userRequested) {
        if (destroyed) return;
        long now = System.currentTimeMillis();
        if (engineTaskInFlight) {
            if (!userRequested && live) liveTickPending = true;
            if (userRequested) {
                long elapsed = Math.max(0L, now - engineTaskStartedAt);
                if (elapsed > ENGINE_HARD_TIMEOUT_MS) {
                    showStatus("El OCR sigue ocupado. Pausa LIVE y vuelve a iniciar el traductor.", 2200);
                } else {
                    showStatus("Procesando la captura anterior…", 850);
                }
            }
            return;
        }
        if (busy) {
            if (!userRequested && live) liveTickPending = true;
            if (userRequested) showStatus("Preparando captura…", 700);
            return;
        }
        if (selecting && userRequested) toggleSelector();
        if (mediaProjection == null || imageReader == null) {
            showStatus("Falta permiso de captura de pantalla", 1600);
            return;
        }
        if (userRequested) {
            lastShownSubtitle = "";
            engine.resetStabilityState();
            engine.resetContextState();
            resetTranslationSwitchState(true);
        }
        busy = true;
        busyStartedAt = now;
        int requestId = ++requestSerial;
        activeRequestId = requestId;
        // En Vivo se confirma el texto OCR antes de traducir. La traducción manual
        // conserva respuesta inmediata para que el botón Trad. no parezca bloqueado.
        drainImages();
        hideAllForCleanCapture();
        handler.postDelayed(() -> captureAndTranslate(0, requestId, userRequested), 55);
        handler.postDelayed(() -> {
            if (destroyed || !busy || activeRequestId != requestId) return;
            if (engineTaskInFlight) {
                showStatus("El OCR todavía está procesando…", 1200);
                return;
            }
            invalidateActiveRequest();
            showStatus("Listo para reintentar", 700);
        }, BUSY_TIMEOUT_MS);
    }

    private void hideAllForCleanCapture() {
        if (captureViewsHidden) return;
        captureViewsHidden = true;
        if (toolbar != null) {
            toolbarVisibilityBeforeCapture = toolbar.getVisibility();
            if (viewIntersectsSelector(toolbar, toolbarParams)) toolbar.setVisibility(View.INVISIBLE);
        }
        if (selectorView != null) {
            selectorVisibilityBeforeCapture = selectorView.getVisibility();
            selectorView.setVisibility(View.INVISIBLE);
        }
        if (statusView != null) {
            statusVisibilityBeforeCapture = statusView.getVisibility();
            if (viewIntersectsSelector(statusView, statusParams)) statusView.setVisibility(View.INVISIBLE);
        }
        if (subtitleView != null) {
            subtitleVisibilityBeforeCapture = subtitleView.getVisibility();
            if (viewIntersectsSelector(subtitleView, subtitleParams)) subtitleView.setVisibility(View.INVISIBLE);
        }
    }

    private boolean viewIntersectsSelector(View view, WindowManager.LayoutParams params) {
        if (view == null || params == null || selectorRect == null || view.getVisibility() != View.VISIBLE) return false;
        int width = view.getWidth();
        int height = view.getHeight();
        if (width <= 0 && params.width > 0) width = params.width;
        if (height <= 0 && params.height > 0) height = params.height;
        if (width <= 0 || height <= 0) return false;
        Rect bounds = new Rect(params.x, params.y, params.x + width, params.y + height);
        return Rect.intersects(bounds, selectorRect);
    }

    private void restoreAfterCapture() {
        if (!captureViewsHidden) return;
        captureViewsHidden = false;
        if (toolbar != null) toolbar.setVisibility(toolbarVisibilityBeforeCapture);
        if (selectorView != null) selectorView.setVisibility(selectorVisibilityBeforeCapture);
        if (statusView != null) {
            boolean statusStillValid = statusVisibilityBeforeCapture == View.VISIBLE
                    && statusVisibleUntil > System.currentTimeMillis();
            statusView.setVisibility(statusStillValid ? View.VISIBLE : View.GONE);
        }
        if (subtitleView != null) {
            boolean shouldShow = subtitleVisibilityBeforeCapture == View.VISIBLE && !subtitleHidden;
            subtitleView.setVisibility(shouldShow ? View.VISIBLE : View.GONE);
        }
        updateLiveIndicatorState();
    }

    private void captureAndTranslate(int attempt, int requestId, boolean manualRequest) {
        if (destroyed) return;
        Image image = null;
        try {
            if (requestId != activeRequestId || imageReader == null) {
                restoreAfterCapture();
                return;
            }
            image = imageReader.acquireLatestImage();
            if (image == null) {
                if (attempt < 10) {
                    handler.postDelayed(() -> captureAndTranslate(attempt + 1, requestId, manualRequest), 45);
                } else {
                    restoreAfterCapture();
                    if (requestId == activeRequestId) busy = false;
                    runPendingLiveFrame(45L);
                    captureFailureStreak++;
                    if (captureFailureStreak >= 3) showStatus("La captura está tardando. Reintentando…", 1200);
                    if (captureFailureStreak >= 5) {
                        resizeCaptureSurface();
                        captureFailureStreak = 0;
                    }
                }
                return;
            }

            captureFailureStreak = 0;
            final Image capturedImage = image;
            image = null;
            final Rect selectedArea = new Rect(selectorRect);
            final int selectedScreenWidth = screenWidth;
            final int selectedScreenHeight = screenHeight;
            final String requestedMode = languageModes[languageIndex];
            restoreAfterCapture();
            try {
                captureExecutor.execute(() -> processCapturedImage(
                        capturedImage, selectedArea, selectedScreenWidth, selectedScreenHeight,
                        requestedMode, requestId, manualRequest));
            } catch (RuntimeException executorError) {
                try { capturedImage.close(); } catch (Exception ignored) { }
                throw executorError;
            }
        } catch (Exception e) {
            if (image != null) {
                try { image.close(); } catch (Exception ignored) { }
            }
            restoreAfterCapture();
            if (requestId == activeRequestId) busy = false;
            runPendingLiveFrame(70L);
            if (!destroyed) showStatus("Error captura: " + safeMessage(e), 2400);
        }
    }

    private void processCapturedImage(Image image, Rect selectedArea, int selectedScreenWidth,
                                      int selectedScreenHeight, String requestedMode,
                                      int requestId, boolean manualRequest) {
        Bitmap full = null;
        Bitmap crop = null;
        try {
            if (destroyed || requestId != activeRequestId) {
                if (image != null) image.close();
                return;
            }
            crop = imageToCroppedBitmap(image, selectedArea, selectedScreenWidth, selectedScreenHeight);
            image.close();
            image = null;
            crop = optimizeBitmapForOcr(crop);

            final Bitmap requestCrop = crop;
            crop = null;
            if (destroyed || requestId != activeRequestId) {
                recycleBitmap(requestCrop);
                return;
            }
            final boolean requireStableText = !manualRequest;
            try {
                engineTaskInFlight = true;
                engineTaskStartedAt = System.currentTimeMillis();
                final int requestEngineGeneration = engineGeneration;
                final long watchdogDelay = ENGINE_HARD_TIMEOUT_MS + 1200L;
                handler.postDelayed(() -> checkHungEngine(requestEngineGeneration, requestId), watchdogDelay);
                engine.process(requestCrop, requestedMode, requireStableText, new TranslatorEngine.Callback() {
                @Override public void onSuccess(String original, String translated, String sourceName) {
                    if (requestEngineGeneration != engineGeneration) {
                        recycleBitmap(requestCrop);
                        return;
                    }
                    engineTaskInFlight = false;
                    engineTaskStartedAt = 0L;
                    recycleBitmap(requestCrop);
                    handler.post(() -> {
                        if (destroyed) return;
                        if (autoRedetectPending) {
                            applyAutoRedetect();
                            return;
                        }
                        if (requestId != activeRequestId) return;
                        busy = false;
                        emptyFrameStreak = 0;
                        noteSuccessfulFrameAfterMemoryPressure();
                        refreshAutoDetectionUi(true);
                        handleTranslationResult(original, translated, sourceName, manualRequest);
                        runPendingLiveFrame(30L);
                    });
                }

                @Override public void onError(String message) {
                    if (requestEngineGeneration != engineGeneration) {
                        recycleBitmap(requestCrop);
                        return;
                    }
                    engineTaskInFlight = false;
                    engineTaskStartedAt = 0L;
                    recycleBitmap(requestCrop);
                    handler.post(() -> {
                        if (destroyed) return;
                        if (autoRedetectPending) {
                            applyAutoRedetect();
                            return;
                        }
                        if (requestId != activeRequestId) return;
                        busy = false;
                        refreshAutoDetectionUi(true);
                        String lower = message == null ? "" : message.toLowerCase(Locale.ROOT);
                        if (lower.contains("no se detect") || lower.contains("esperando texto claro")) {
                            engine.noteNoTextDetected();
                            handleNoTextFrame();
                        }
                        if (live && (lower.contains("esperando subtítulo estable")
                                || lower.contains("detectando idioma"))) {
                            liveTickPending = false;
                            handler.removeCallbacks(liveRunnable);
                            handler.postDelayed(liveRunnable,
                                    lower.contains("detectando idioma") ? 95L : STABILITY_RETRY_MS);
                        } else {
                            runPendingLiveFrame(35L);
                        }
                        if (!lower.contains("no se detect")
                                && !lower.contains("esperando subtítulo")
                                && !lower.contains("esperando texto claro")) {
                            showStatus(message, 1500);
                        }
                    });
                }
                });
            } catch (Exception processError) {
                engineTaskInFlight = false;
                engineTaskStartedAt = 0L;
                recycleBitmap(requestCrop);
                throw processError;
            } catch (OutOfMemoryError memoryError) {
                engineTaskInFlight = false;
                engineTaskStartedAt = 0L;
                recycleBitmap(requestCrop);
                throw memoryError;
            }
        } catch (OutOfMemoryError memoryError) {
            enterLowMemoryMode();
            if (image != null) {
                try { image.close(); } catch (Exception ignored) { }
            }
            recycleBitmap(full);
            recycleBitmap(crop);
            engineTaskInFlight = false;
            engineTaskStartedAt = 0L;
            handler.post(() -> {
                if (destroyed) return;
                if (autoRedetectPending) {
                    applyAutoRedetect();
                    return;
                }
                if (requestId == activeRequestId) busy = false;
                runPendingLiveFrame(90L);
                showStatus("Memoria insuficiente. Reduce el cuadro de captura y vuelve a intentar.", 2800);
            });
        } catch (Exception e) {
            if (image != null) {
                try { image.close(); } catch (Exception ignored) { }
            }
            recycleBitmap(full);
            recycleBitmap(crop);
            handler.post(() -> {
                if (destroyed) return;
                if (autoRedetectPending) {
                    applyAutoRedetect();
                    return;
                }
                if (requestId == activeRequestId) busy = false;
                runPendingLiveFrame(70L);
                showStatus("Error captura: " + safeMessage(e), 2400);
            });
        }
    }

    private void runPendingLiveFrame(long delayMs) {
        if (!live || destroyed || !liveTickPending) return;
        liveTickPending = false;
        handler.removeCallbacks(liveRunnable);
        handler.postDelayed(liveRunnable, Math.max(25L, delayMs));
    }

    private void handleNoTextFrame() {
        emptyFrameStreak++;
        if (emptyFrameStreak < 3 || subtitleView == null) return;
        if (System.currentTimeMillis() - lastSubtitleTime < 900L) return;
        subtitleView.setVisibility(View.GONE);
        currentSourceKey = "";
        lastShownSubtitle = "";
    }

    private Bitmap optimizeBitmapForOcr(Bitmap source) {
        if (source == null || source.isRecycled()) return source;
        int maxPixels = lowMemoryMode ? LOW_MEMORY_MAX_OCR_PIXELS : MAX_OCR_PIXELS;
        long pixels = (long) source.getWidth() * (long) source.getHeight();
        if (pixels <= maxPixels) return source;
        double scale = Math.sqrt(maxPixels / (double) pixels);
        int targetWidth = Math.max(2, (int) Math.round(source.getWidth() * scale));
        int targetHeight = Math.max(2, (int) Math.round(source.getHeight() * scale));
        try {
            Bitmap scaled = Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true);
            if (scaled != source) recycleBitmap(source);
            return scaled;
        } catch (OutOfMemoryError error) {
            enterLowMemoryMode();
            return source;
        }
    }

    private void enterLowMemoryMode() {
        lowMemoryMode = true;
        successfulFramesAfterMemoryPressure = 0;
        Runnable cleanup = () -> {
            if (destroyed) return;
            drainImages();
            if (engine != null) engine.resetContextState();
        };
        if (handler != null && Looper.myLooper() != handler.getLooper()) handler.post(cleanup);
        else cleanup.run();
    }

    private void noteSuccessfulFrameAfterMemoryPressure() {
        if (!lowMemoryMode) return;
        successfulFramesAfterMemoryPressure++;
        if (successfulFramesAfterMemoryPressure >= 24) {
            lowMemoryMode = false;
            successfulFramesAfterMemoryPressure = 0;
        }
    }

    private void checkHungEngine(int generation, int requestId) {
        if (destroyed || generation != engineGeneration || requestId != activeRequestId) return;
        if (!engineTaskInFlight || engineTaskStartedAt <= 0L) return;
        long elapsed = System.currentTimeMillis() - engineTaskStartedAt;
        if (elapsed < ENGINE_HARD_TIMEOUT_MS) return;

        boolean resumeLive = live;
        handler.removeCallbacks(liveRunnable);
        invalidateActiveRequest();
        engineGeneration++;
        engineTaskInFlight = false;
        engineTaskStartedAt = 0L;
        try { if (engine != null) engine.close(); } catch (Exception ignored) { }
        engine = new TranslatorEngine(getApplicationContext());
        engine.preload(languageModes[languageIndex]);
        enterLowMemoryMode();
        showStatus("La lectura tardó demasiado. Zeta recuperó el traductor automáticamente.", 2600);
        updateNotification("Traductor recuperado");
        if (resumeLive && !destroyed) {
            handler.postDelayed(liveRunnable, 650L);
        }
    }

    private long liveIntervalForCurrentMode() {
        String mode = languageModes[Math.max(0, Math.min(languageIndex, languageModes.length - 1))];
        if (TranslatorEngine.MODE_AUTO.equals(mode)) {
            String locked = engine.getLockedAutoMode();
            if (locked != null) mode = locked;
        }
        long interval;
        if (TranslatorEngine.MODE_CHINESE.equals(mode)) interval = LIVE_INTERVAL_CHINESE_MS;
        else if (TranslatorEngine.MODE_JAPANESE.equals(mode)) interval = LIVE_INTERVAL_JAPANESE_MS;
        else if (TranslatorEngine.MODE_ENGLISH.equals(mode)) interval = LIVE_INTERVAL_ENGLISH_MS;
        else interval = LIVE_INTERVAL_AUTO_MS;
        return lowMemoryMode ? Math.max(interval, LOW_MEMORY_MIN_INTERVAL_MS) : interval;
    }

    private void recycleBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try { bitmap.recycle(); } catch (Exception ignored) { }
        }
    }

    private void drainImages() {
        if (imageReader == null) return;
        Image old = null;
        try {
            while ((old = imageReader.acquireLatestImage()) != null) {
                old.close();
                old = null;
            }
        } catch (Exception ignored) {
            if (old != null) { try { old.close(); } catch (Exception ignored2) { } }
        }
    }

    private Bitmap imageToCroppedBitmap(Image image, Rect selectedArea,
                                               int sourceScreenWidth, int sourceScreenHeight) {
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        Rect cropRect = mapSelectorToBitmap(selectedArea, sourceScreenWidth, sourceScreenHeight,
                imageWidth, imageHeight);
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0) {
            throw new IllegalStateException("La captura no contiene píxeles.");
        }
        Image.Plane plane = planes[0];
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        if (pixelStride != 4) {
            return imageToCroppedBitmapFallback(image, cropRect);
        }

        int cropWidth = cropRect.width();
        int cropHeight = cropRect.height();
        ByteBuffer source = plane.getBuffer().duplicate();
        int baseOffset = source.position();
        ByteBuffer packed = ByteBuffer.allocateDirect(cropWidth * cropHeight * 4);
        byte[] row = new byte[cropWidth * 4];
        for (int y = 0; y < cropHeight; y++) {
            int sourceOffset = baseOffset + (cropRect.top + y) * rowStride + cropRect.left * pixelStride;
            if (sourceOffset < 0 || sourceOffset + row.length > source.limit()) {
                throw new IllegalStateException("El área seleccionada quedó fuera de la captura.");
            }
            source.position(sourceOffset);
            source.get(row, 0, row.length);
            packed.put(row);
        }
        packed.rewind();
        Bitmap cropped = Bitmap.createBitmap(cropWidth, cropHeight, Bitmap.Config.ARGB_8888);
        cropped.copyPixelsFromBuffer(packed);
        return cropped;
    }

    private Bitmap imageToCroppedBitmapFallback(Image image, Rect cropRect) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = Math.max(0, rowStride - pixelStride * imageWidth);
        int bitmapWidth = imageWidth + rowPadding / Math.max(1, pixelStride);
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, imageHeight, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(bitmap, cropRect.left, cropRect.top,
                cropRect.width(), cropRect.height());
        bitmap.recycle();
        return cropped;
    }

    private Rect mapSelectorToBitmap(Rect selectedArea, int sourceScreenWidth, int sourceScreenHeight,
                                     int bitmapWidth, int bitmapHeight) {
        float sx = sourceScreenWidth > 0 ? bitmapWidth / (float) sourceScreenWidth : 1f;
        float sy = sourceScreenHeight > 0 ? bitmapHeight / (float) sourceScreenHeight : 1f;
        Rect mapped = new Rect(
                Math.round(selectedArea.left * sx),
                Math.round(selectedArea.top * sy),
                Math.round(selectedArea.right * sx),
                Math.round(selectedArea.bottom * sy)
        );
        return clampCrop(mapped, bitmapWidth, bitmapHeight);
    }

    private Rect clampCrop(Rect r, int maxW, int maxH) {
        int left = Math.max(0, Math.min(r.left, maxW - 2));
        int top = Math.max(0, Math.min(r.top, maxH - 2));
        int right = Math.max(left + 2, Math.min(r.right, maxW));
        int bottom = Math.max(top + 2, Math.min(r.bottom, maxH));
        return new Rect(left, top, right, bottom);
    }

    private Rect clampScreenRect(Rect r) {
        int minW = Math.min(screenWidth, dp(120));
        int minH = Math.min(screenHeight, dp(44));
        int width = Math.max(minW, Math.min(r.width(), screenWidth));
        int height = Math.max(minH, Math.min(r.height(), screenHeight));
        int left = Math.max(0, Math.min(r.left, Math.max(0, screenWidth - width)));
        int top = Math.max(0, Math.min(r.top, Math.max(0, screenHeight - height)));
        return new Rect(left, top, left + width, top + height);
    }

    private void handleTranslationResult(String original, String translated, String sourceName, boolean manualRequest) {
        emptyFrameStreak = 0;
        String sourceKey = normalizeSourceKey(original);
        String cleanTranslation = makeSubtitleText(translated);
        if (sourceKey.length() == 0 || cleanTranslation.length() == 0) return;

        if (!manualRequest && areSourceKeysSimilar(currentSourceKey, sourceKey)) {
            return;
        }

        commitTranslation(sourceKey, cleanTranslation, sourceName);
    }

    private void commitTranslation(String sourceKey, String translated, String sourceName) {
        currentSourceKey = sourceKey;
        showSubtitle(translated, sourceName);
    }

    private void resetTranslationSwitchState(boolean resetCurrent) {
        if (resetCurrent) currentSourceKey = "";
    }

    private String normalizeSourceKey(String text) {
        return SubtitleTextGuard.normalize(text);
    }

    private boolean areSourceKeysSimilar(String a, String b) {
        return SubtitleTextGuard.areEquivalent(a, b);
    }

    private void ensureSubtitleOverlay() {
        if (destroyed) return;
        if (subtitleView == null) {
            subtitleView = new OutlinedTextView(this);
            subtitleView.setTextColor(Color.WHITE);
            subtitleView.setTextSize(MainActivity.DEFAULT_SUBTITLE_SIZE_SP);
            subtitleView.setGravity(Gravity.CENTER);
            subtitleView.setPadding(dp(8), dp(3), dp(8), dp(3));
            subtitleView.setShadowLayer(dp(2), 0, dp(1), Color.BLACK);
            subtitleView.setBackgroundColor(Color.TRANSPARENT);
            subtitleView.setIncludeFontPadding(false);
            subtitleView.setLineSpacing(0f, 1.05f);
            subtitleView.setMaxLines(3);
            subtitleView.setEllipsize(TextUtils.TruncateAt.END);
            subtitleView.setOnTouchListener(new View.OnTouchListener() {
                int startX;
                int startY;
                float touchX;
                float touchY;

                @Override public boolean onTouch(View v, MotionEvent event) {
                    if (subtitleParams == null) return false;
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            startX = subtitleParams.x;
                            startY = subtitleParams.y;
                            touchX = event.getRawX();
                            touchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            subtitleParams.x = startX + (int) (event.getRawX() - touchX);
                            subtitleParams.y = startY + (int) (event.getRawY() - touchY);
                            clampSubtitlePosition();
                            subtitleManuallyMoved = true;
                            safeUpdate(subtitleView, subtitleParams);
                            return true;
                        case MotionEvent.ACTION_UP:
                            saveSubtitlePosition();
                            return true;
                        case MotionEvent.ACTION_CANCEL:
                            return true;
                    }
                    return false;
                }
            });
        }
        applySubtitleAppearance();
        if (subtitleParams == null) {
            subtitleParams = overlayParams(selectorRect.width(), WindowManager.LayoutParams.WRAP_CONTENT);
            subtitleParams.gravity = Gravity.TOP | Gravity.START;
            subtitleParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            if (subtitleManuallyMoved) {
                subtitleParams.x = loadSavedX(MainActivity.KEY_SUBTITLE_X, selectorRect.left);
                subtitleParams.y = loadSavedY(MainActivity.KEY_SUBTITLE_Y, Math.max(dp(4), selectorRect.top - dp(58)));
            }
        }
        subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
        subtitleParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        if (!subtitleManuallyMoved) positionSubtitleNearSelector();
        clampSubtitlePosition();
        if (subtitleView.getParent() == null) safeAdd(subtitleView, subtitleParams);
        else safeUpdate(subtitleView, subtitleParams);
        subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
    }

    private void showSubtitle(String translated, String sourceName) {
        if (destroyed) return;
        hideSelector();
        selecting = false;
        if (areaBtn != null) areaBtn.setText("Área");

        String text = makeSubtitleText(translated);
        if (text.length() == 0) return;
        if (text.equals(lastShownSubtitle) && subtitleView != null) {
            lastSubtitleTime = System.currentTimeMillis();
            subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
            return;
        }
        lastShownSubtitle = text;
        lastSubtitleTime = System.currentTimeMillis();
        ensureSubtitleOverlay();
        subtitleView.setText(text);
        if (subtitleParams == null) {
            subtitleParams = overlayParams(selectorRect.width(), WindowManager.LayoutParams.WRAP_CONTENT);
            subtitleParams.gravity = Gravity.TOP | Gravity.START;
            subtitleParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }
        subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
        subtitleParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        if (!subtitleManuallyMoved) positionSubtitleNearSelector();
        clampSubtitlePosition();
        if (subtitleView.getParent() == null) {
            safeAdd(subtitleView, subtitleParams);
        } else {
            safeUpdate(subtitleView, subtitleParams);
        }
        subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
        if (!subtitleManuallyMoved) {
            handler.post(() -> {
                if (destroyed || subtitleView == null || subtitleParams == null) return;
                positionSubtitleNearSelector();
                safeUpdate(subtitleView, subtitleParams);
            });
        }
        updateNotification(sourceName + " → Español");
    }

    private void positionSubtitleNearSelector() {
        if (subtitleParams == null || selectorRect == null) return;
        int gap = dp(4);
        int measuredHeight = subtitleView == null ? 0 : Math.max(subtitleView.getHeight(), subtitleView.getMeasuredHeight());
        int boxHeight = measuredHeight > 0 ? measuredHeight : dp(58);
        int aboveY = selectorRect.top - boxHeight - gap;
        int belowY = selectorRect.bottom + gap;

        subtitleParams.x = selectorRect.left;
        if (aboveY >= dp(4)) {
            subtitleParams.y = aboveY;
        } else if (belowY + boxHeight <= screenHeight - dp(4)) {
            subtitleParams.y = belowY;
        } else {
            subtitleParams.y = Math.max(dp(4), Math.min(aboveY, screenHeight - boxHeight - dp(4)));
        }
        clampSubtitlePosition();
    }

    private void clampSubtitlePosition() {
        if (subtitleParams == null || selectorRect == null) return;
        int width = subtitleParams.width > 0 ? subtitleParams.width : Math.min(selectorRect.width(), screenWidth);
        int height = subtitleView == null ? dp(58) : Math.max(dp(44), Math.max(subtitleView.getHeight(), subtitleView.getMeasuredHeight()));
        subtitleParams.x = Math.max(0, Math.min(subtitleParams.x, Math.max(0, screenWidth - width)));
        subtitleParams.y = Math.max(0, Math.min(subtitleParams.y, Math.max(0, screenHeight - height)));

        // El usuario decide la posición; solo limitamos el subtítulo a los bordes de la pantalla.
    }

    private String makeSubtitleText(String text) {
        if (text == null) return "";
        return text.replace("\r", " ")
                .replace("\n", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private void showStatus(String text, long durationMs) {
        if (destroyed || text == null || text.trim().length() == 0) return;
        String lower = text.toLowerCase(Locale.ROOT);
        if (lower.contains("no se detect")
                || lower.contains("esperando subtítulo")
                || lower.contains("esperando texto claro")
                || lower.contains("deteccion cancelada")
                || lower.contains("detección cancelada")) return;

        if (statusView == null) {
            statusView = new TextView(this);
            statusView.setTextColor(Color.WHITE);
            statusView.setTextSize(11);
            statusView.setGravity(Gravity.CENTER);
            statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
            statusView.setBackgroundColor(Color.argb(175, 17, 24, 39));
            statusParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            statusParams.gravity = Gravity.TOP | Gravity.START;
            statusParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            updateStatusPosition();
            safeAdd(statusView, statusParams);
        } else {
            updateStatusPosition();
        }
        statusView.setText(text);
        statusView.setVisibility(View.VISIBLE);
        statusVisibleUntil = System.currentTimeMillis() + durationMs;
        if (statusHideRunnable != null) handler.removeCallbacks(statusHideRunnable);
        statusHideRunnable = () -> {
            statusVisibleUntil = 0L;
            if (!destroyed && statusView != null) statusView.setVisibility(View.GONE);
        };
        handler.postDelayed(statusHideRunnable, durationMs);
    }

    private void updateStatusPosition() {
        if (statusParams == null) return;
        statusParams.x = toolbarParams != null ? toolbarParams.x : dp(12);
        int toolbarHeight = toolbarCollapsed ? dp(38) : dp(72);
        statusParams.y = toolbarParams != null ? toolbarParams.y + toolbarHeight : dp(86);
        statusParams.x = Math.max(0, Math.min(statusParams.x, Math.max(0, screenWidth - dp(80))));
        statusParams.y = Math.max(0, Math.min(statusParams.y, Math.max(0, screenHeight - dp(36))));
        if (statusView != null && statusView.getParent() != null) safeUpdate(statusView, statusParams);
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width,
                height,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        return params;
    }

    private Notification buildNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Zeta Live Translator", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Mantiene la traducción activa sobre otras aplicaciones.");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            nm.createNotificationChannel(channel);
        }

        Intent openApp = new Intent(this, MainActivity.class);
        openApp.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 78, openApp, pendingFlags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_zeta)
                .setContentTitle("Zeta Live Translator")
                .setContentText(text)
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PRIVATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return builder.build();
    }

    private void updateNotification(String text) {
        if (destroyed) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void safeAdd(View view, WindowManager.LayoutParams params) {
        if (destroyed || view == null || params == null) return;
        try { windowManager.addView(view, params); } catch (Exception e) { Log.w(TAG, "No se pudo añadir una ventana flotante", e); }
    }

    private void safeUpdate(View view, WindowManager.LayoutParams params) {
        if (destroyed || view == null || params == null) return;
        try { windowManager.updateViewLayout(view, params); } catch (Exception e) { Log.w(TAG, "No se pudo actualizar una ventana flotante", e); }
    }

    private void safeRemove(View view) {
        if (view == null) return;
        try { windowManager.removeView(view); } catch (Exception e) { Log.w(TAG, "No se pudo retirar una ventana flotante", e); }
    }

    private void invalidateActiveRequest() {
        requestSerial++;
        activeRequestId = requestSerial;
        busy = false;
        liveTickPending = false;
        restoreAfterCapture();
    }

    private void releaseCaptureOnly() {
        if (virtualDisplay != null) {
            try { virtualDisplay.setSurface(null); } catch (Exception ignored) { }
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        captureWidth = 0;
        captureHeight = 0;
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (destroyed) return;
        boolean runningPressure = level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW
                || level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL;
        boolean severeBackgroundPressure = level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE;
        if (runningPressure || severeBackgroundPressure) {
            enterLowMemoryMode();
            if (handler != null) {
                handler.post(() -> showStatus("Android reportó poca memoria. Zeta redujo el consumo automáticamente.", 2300));
            }
        }
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (destroyed) return;
        enterLowMemoryMode();
        if (handler != null) {
            handler.post(() -> showStatus("Modo de memoria reducida activado.", 1800));
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (!destroyed) {
            updateNotification(live ? "LIVE activo · traducción a Español" : "Traductor disponible");
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        saveSelectorPosition();
        saveToolbarPosition();
        if (subtitleManuallyMoved) saveSubtitlePosition();
        destroyed = true;
        live = false;
        busy = false;
        engineTaskInFlight = false;
        engineTaskStartedAt = 0L;
        liveTickPending = false;
        requestSerial++;
        activeRequestId = requestSerial;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        captureExecutor.shutdownNow();
        if (engine != null) engine.close();
        if (toolbar != null) safeRemove(toolbar);
        if (selectorView != null) safeRemove(selectorView);
        if (subtitleView != null) safeRemove(subtitleView);
        if (statusView != null) safeRemove(statusView);
        releaseCaptureOnly();
        if (mediaProjection != null) {
            try { mediaProjection.stop(); } catch (Exception ignored) { }
            mediaProjection = null;
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (destroyed) return;
        final int oldWidth = Math.max(1, screenWidth);
        final int oldHeight = Math.max(1, screenHeight);
        final Rect oldSelector = selectorRect == null ? defaultRect() : new Rect(selectorRect);
        final int oldToolbarX = toolbarParams == null ? 0 : toolbarParams.x;
        final int oldToolbarY = toolbarParams == null ? 0 : toolbarParams.y;
        final int oldSubtitleX = subtitleParams == null ? 0 : subtitleParams.x;
        final int oldSubtitleY = subtitleParams == null ? 0 : subtitleParams.y;

        handler.removeCallbacks(liveRunnable);
        invalidateActiveRequest();
        handler.postDelayed(() -> {
            if (destroyed) return;
            readMetrics();
            selectorRect = scaleRect(oldSelector, oldWidth, oldHeight, screenWidth, screenHeight);
            selectorRect = clampScreenRect(selectorRect);
            if (selectorView != null) selectorView.setRect(selectorRect);

            if (toolbarParams != null) {
                toolbarParams.x = scaleCoordinate(oldToolbarX, oldWidth, screenWidth);
                toolbarParams.y = scaleCoordinate(oldToolbarY, oldHeight, screenHeight);
                toolbarParams.x = Math.max(0, Math.min(toolbarParams.x, Math.max(0, screenWidth - dp(44))));
                toolbarParams.y = Math.max(0, Math.min(toolbarParams.y, Math.max(0, screenHeight - dp(44))));
                safeUpdate(toolbar, toolbarParams);
            }

            if (subtitleParams != null) {
                subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
                if (subtitleManuallyMoved) {
                    subtitleParams.x = scaleCoordinate(oldSubtitleX, oldWidth, screenWidth);
                    subtitleParams.y = scaleCoordinate(oldSubtitleY, oldHeight, screenHeight);
                } else {
                    positionSubtitleNearSelector();
                }
                clampSubtitlePosition();
                safeUpdate(subtitleView, subtitleParams);
            }
            saveSelectorPosition();
            saveToolbarPosition();
            if (subtitleManuallyMoved) saveSubtitlePosition();
            updateStatusPosition();
            resizeCaptureSurface();
            engine.resetStabilityState();
            if (live) handler.postDelayed(liveRunnable, 350);
        }, 180);
    }

    private Rect scaleRect(Rect rect, int oldW, int oldH, int newW, int newH) {
        return new Rect(
                scaleCoordinate(rect.left, oldW, newW),
                scaleCoordinate(rect.top, oldH, newH),
                scaleCoordinate(rect.right, oldW, newW),
                scaleCoordinate(rect.bottom, oldH, newH)
        );
    }

    private int scaleCoordinate(int value, int oldSize, int newSize) {
        if (oldSize <= 0) return value;
        return Math.round((value / (float) oldSize) * newSize);
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) {
            return "desconocido";
        }
        return e.getMessage();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
