package com.geozeta.livetranslator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;

import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 501;
    private static final int REQ_NOTIFICATIONS = 502;

    public static final String PREFS = "zeta_live_translator";
    public static final String KEY_MODEL_PREFIX = "model_pair_ready_";
    public static final String KEY_SUBTITLE_SIZE_SP = "subtitle_size_sp";
    public static final String KEY_SELECTOR_COLOR = "selector_color";
    public static final String KEY_SELECTOR_STROKE_DP = "selector_stroke_dp";
    public static final String KEY_SELECTOR_FILL_ALPHA = "selector_fill_alpha";
    public static final String KEY_SUBTITLE_TEXT_COLOR = "subtitle_text_color";
    public static final String KEY_SUBTITLE_OUTLINE_DP = "subtitle_outline_dp";
    public static final String KEY_SUBTITLE_ALIGN = "subtitle_align";
    public static final String KEY_TOOLBAR_COMPACT = "toolbar_compact";
    public static final String KEY_TOOLBAR_ALPHA = "toolbar_alpha";
    public static final String KEY_LAYOUT_SCREEN_W = "layout_screen_w";
    public static final String KEY_LAYOUT_SCREEN_H = "layout_screen_h";
    public static final String KEY_SELECTOR_LEFT = "selector_left";
    public static final String KEY_SELECTOR_TOP = "selector_top";
    public static final String KEY_SELECTOR_RIGHT = "selector_right";
    public static final String KEY_SELECTOR_BOTTOM = "selector_bottom";
    public static final String KEY_TOOLBAR_X = "toolbar_x";
    public static final String KEY_TOOLBAR_Y = "toolbar_y";
    public static final String KEY_SUBTITLE_X = "subtitle_x";
    public static final String KEY_SUBTITLE_Y = "subtitle_y";
    public static final String KEY_SUBTITLE_MOVED = "subtitle_moved";
    public static final String KEY_LAYOUT_RESET_COUNTER = "layout_reset_counter";
    public static final int DEFAULT_SUBTITLE_SIZE_SP = 20;
    public static final int DEFAULT_SELECTOR_COLOR = 0xFF7C3AED;
    public static final int DEFAULT_SELECTOR_STROKE_DP = 2;
    public static final int DEFAULT_SELECTOR_FILL_ALPHA = 0;
    public static final int DEFAULT_SUBTITLE_TEXT_COLOR = 0xFFFFFFFF;
    public static final int DEFAULT_SUBTITLE_OUTLINE_DP = 2;
    public static final int DEFAULT_SUBTITLE_ALIGN = Gravity.CENTER;
    public static final boolean DEFAULT_TOOLBAR_COMPACT = false;
    public static final int DEFAULT_TOOLBAR_ALPHA = 220;

    private static final int BG = 0xFF0B0E13;
    private static final int SURFACE = 0xFF151A21;
    private static final int SURFACE_ALT = 0xFF1C232D;
    private static final int BORDER = 0xFF2C3542;
    private static final int TEXT = 0xFFF6F7F9;
    private static final int MUTED = 0xFFAAB4C3;
    private static final int ACCENT = 0xFF4F8CFF;
    private static final int SUCCESS = 0xFF31C48D;
    private static final int WARNING = 0xFFF0B429;
    private static final int ERROR = 0xFFF97066;

    private SharedPreferences prefs;
    private Button startButton;
    private Button permissionsButton;
    private TextView globalTitle;
    private TextView globalDetail;
    private TextView installedCount;
    private TextView overlayPermissionState;
    private TextView notificationPermissionState;
    private TextView batteryOptimizationState;
    private ProgressBar activeProgress;
    private TextView downloadStatusLine;
    private TextView downloadMetaLine;
    private Button downloadControlButton;
    private boolean receiverRegistered;

    private final String[] languageCodes = new String[]{
            TranslateLanguage.ENGLISH,
            TranslateLanguage.CHINESE,
            TranslateLanguage.JAPANESE
    };
    private final String[] languageNames = new String[]{
            "Inglés → Español",
            "Chino → Español",
            "Japonés → Español"
    };
    private final String[] languageNotes = new String[]{
            "Para subtítulos y texto visible en inglés.",
            "Para subtítulos y texto visible en chino.",
            "Para subtítulos y texto visible en japonés."
    };

    private final TextView[] stateBadges = new TextView[languageCodes.length];
    private final Button[] downloadButtons = new Button[languageCodes.length];
    private final RemoteModelManager remoteModelManager = RemoteModelManager.getInstance();

    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (DownloadModelService.ACTION_STATUS.equals(intent.getAction())) refreshUi();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        migrateLegacyModelState();
        buildUi();
        refreshUi();
        verifyActualModels();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(DownloadModelService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(downloadReceiver, filter);
        }
        receiverRegistered = true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
        refreshBackgroundStatus();
        verifyActualModels();
    }

    @Override
    protected void onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onStop();
    }

    private void showGlossaryDialog() {
        EditText input = new EditText(this);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setBackground(roundRect(SURFACE_ALT, BORDER, 12));
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        input.setMinLines(7);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setHint("Texto original => traducción preferida\nEjemplos:\n魏无羡 => Wei Wuxian\nGood morning => Buenos días");
        input.setText(prefs.getString(TranslatorEngine.KEY_CUSTOM_GLOSSARY, ""));

        FrameLayout container = new FrameLayout(this);
        int margin = dp(18);
        container.setPadding(margin, dp(6), margin, 0);
        container.addView(input, new FrameLayout.LayoutParams(-1, dp(260)));

        new AlertDialog.Builder(this)
                .setTitle("Glosario de correcciones")
                .setMessage("Funciona con Chino, Japonés e Inglés. Se aplica únicamente cuando el texto reconocido coincide completo, por lo que sirve para nombres o términos de una serie sin reemplazar palabras a ciegas ni ralentizar LIVE.")
                .setView(container)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    prefs.edit().putString(TranslatorEngine.KEY_CUSTOM_GLOSSARY, input.getText().toString()).apply();
                    toast("Glosario guardado.");
                })
                .setNeutralButton("Limpiar", (dialog, which) -> {
                    prefs.edit().remove(TranslatorEngine.KEY_CUSTOM_GLOSSARY).apply();
                    toast("Glosario eliminado.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showSubtitleSizeDialog() {
        final int[] sizes = new int[]{17, 20, 24, 28};
        final String[] labels = new String[]{"Pequeño (17)", "Mediano (20)", "Grande (24)", "Muy grande (28)"};
        int saved = prefs.getInt(KEY_SUBTITLE_SIZE_SP, DEFAULT_SUBTITLE_SIZE_SP);
        int selected = 1;
        for (int i = 0; i < sizes.length; i++) {
            if (sizes[i] == saved) {
                selected = i;
                break;
            }
        }
        final int initialSelection = selected;
        new AlertDialog.Builder(this)
                .setTitle("Tamaño del subtítulo")
                .setSingleChoiceItems(labels, initialSelection, (dialog, which) -> {
                    prefs.edit().putInt(KEY_SUBTITLE_SIZE_SP, sizes[which]).apply();
                    dialog.dismiss();
                    toast("Tamaño guardado. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showCaptureBoxDialog() {
        final String[] items = new String[]{"Color del borde", "Grosor del borde", "Relleno interior", "Restablecer estilo"};
        new AlertDialog.Builder(this)
                .setTitle("Cuadro de captura")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) showSelectorColorDialog();
                    else if (which == 1) showSelectorThicknessDialog();
                    else if (which == 2) showSelectorFillDialog();
                    else resetSelectorAppearance();
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void showSelectorColorDialog() {
        final int[] values = new int[]{0xFF7C3AED, 0xFFE11D48, 0xFF2563EB, 0xFF16A34A, 0xFFEAB308, 0xFFFFFFFF};
        final String[] labels = new String[]{"Morado", "Rojo", "Azul", "Verde", "Amarillo", "Blanco"};
        int selected = indexOf(values, prefs.getInt(KEY_SELECTOR_COLOR, DEFAULT_SELECTOR_COLOR));
        new AlertDialog.Builder(this)
                .setTitle("Color del cuadro")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    prefs.edit().putInt(KEY_SELECTOR_COLOR, values[which]).apply();
                    dialog.dismiss();
                    toast("Color guardado. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showSelectorThicknessDialog() {
        final int[] values = new int[]{2, 3, 4};
        final String[] labels = new String[]{"Fino", "Normal", "Grueso"};
        int selected = indexOf(values, prefs.getInt(KEY_SELECTOR_STROKE_DP, DEFAULT_SELECTOR_STROKE_DP));
        new AlertDialog.Builder(this)
                .setTitle("Grosor del cuadro")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    prefs.edit().putInt(KEY_SELECTOR_STROKE_DP, values[which]).apply();
                    dialog.dismiss();
                    toast("Grosor guardado. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showSelectorFillDialog() {
        final int[] values = new int[]{0, 26, 54};
        final String[] labels = new String[]{"Sin relleno", "Suave", "Medio"};
        int selected = indexOf(values, prefs.getInt(KEY_SELECTOR_FILL_ALPHA, DEFAULT_SELECTOR_FILL_ALPHA));
        new AlertDialog.Builder(this)
                .setTitle("Relleno del cuadro")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    prefs.edit().putInt(KEY_SELECTOR_FILL_ALPHA, values[which]).apply();
                    dialog.dismiss();
                    toast("Relleno guardado. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void resetSelectorAppearance() {
        prefs.edit()
                .putInt(KEY_SELECTOR_COLOR, DEFAULT_SELECTOR_COLOR)
                .putInt(KEY_SELECTOR_STROKE_DP, DEFAULT_SELECTOR_STROKE_DP)
                .putInt(KEY_SELECTOR_FILL_ALPHA, DEFAULT_SELECTOR_FILL_ALPHA)
                .apply();
        toast("Cuadro restablecido. Se aplicará al reiniciar el traductor.");
    }

    private void showSubtitleAppearanceDialog() {
        final String[] items = new String[]{"Tamaño", "Color del texto", "Grosor del contorno", "Alineación", "Restablecer estilo"};
        new AlertDialog.Builder(this)
                .setTitle("Apariencia de subtítulos")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) showSubtitleSizeDialog();
                    else if (which == 1) showSubtitleColorDialog();
                    else if (which == 2) showSubtitleOutlineDialog();
                    else if (which == 3) showSubtitleAlignmentDialog();
                    else resetSubtitleAppearance();
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void showSubtitleColorDialog() {
        final int[] values = new int[]{0xFFFFFFFF, 0xFFFFF176, 0xFFA5F3FC};
        final String[] labels = new String[]{"Blanco", "Amarillo suave", "Celeste"};
        int selected = indexOf(values, prefs.getInt(KEY_SUBTITLE_TEXT_COLOR, DEFAULT_SUBTITLE_TEXT_COLOR));
        new AlertDialog.Builder(this)
                .setTitle("Color del subtítulo")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    prefs.edit().putInt(KEY_SUBTITLE_TEXT_COLOR, values[which]).apply();
                    dialog.dismiss();
                    toast("Color guardado. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showSubtitleOutlineDialog() {
        final int[] values = new int[]{2, 3, 4};
        final String[] labels = new String[]{"Fino", "Normal", "Grueso"};
        int selected = indexOf(values, prefs.getInt(KEY_SUBTITLE_OUTLINE_DP, DEFAULT_SUBTITLE_OUTLINE_DP));
        new AlertDialog.Builder(this)
                .setTitle("Contorno del subtítulo")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    prefs.edit().putInt(KEY_SUBTITLE_OUTLINE_DP, values[which]).apply();
                    dialog.dismiss();
                    toast("Contorno guardado. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showSubtitleAlignmentDialog() {
        final int[] values = new int[]{Gravity.CENTER, Gravity.START | Gravity.CENTER_VERTICAL};
        final String[] labels = new String[]{"Centrado", "A la izquierda"};
        int selected = indexOf(values, prefs.getInt(KEY_SUBTITLE_ALIGN, DEFAULT_SUBTITLE_ALIGN));
        new AlertDialog.Builder(this)
                .setTitle("Alineación del subtítulo")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    prefs.edit().putInt(KEY_SUBTITLE_ALIGN, values[which]).apply();
                    dialog.dismiss();
                    toast("Alineación guardada. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void resetSubtitleAppearance() {
        prefs.edit()
                .putInt(KEY_SUBTITLE_SIZE_SP, DEFAULT_SUBTITLE_SIZE_SP)
                .putInt(KEY_SUBTITLE_TEXT_COLOR, DEFAULT_SUBTITLE_TEXT_COLOR)
                .putInt(KEY_SUBTITLE_OUTLINE_DP, DEFAULT_SUBTITLE_OUTLINE_DP)
                .putInt(KEY_SUBTITLE_ALIGN, DEFAULT_SUBTITLE_ALIGN)
                .apply();
        toast("Subtítulos restablecidos. Se aplicará al reiniciar el traductor.");
    }

    private void showToolbarAppearanceDialog() {
        final String[] items = new String[]{"Tamaño de la barra", "Transparencia de la barra", "Restablecer estilo"};
        new AlertDialog.Builder(this)
                .setTitle("Barra flotante")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) showToolbarSizeDialog();
                    else if (which == 1) showToolbarTransparencyDialog();
                    else resetToolbarAppearance();
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void showToolbarSizeDialog() {
        final boolean[] values = new boolean[]{true, false};
        final String[] labels = new String[]{"Compacta", "Normal"};
        boolean saved = prefs.getBoolean(KEY_TOOLBAR_COMPACT, DEFAULT_TOOLBAR_COMPACT);
        int selected = saved ? 0 : 1;
        new AlertDialog.Builder(this)
                .setTitle("Tamaño de la barra")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    prefs.edit().putBoolean(KEY_TOOLBAR_COMPACT, values[which]).apply();
                    dialog.dismiss();
                    toast("Tamaño guardado. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showToolbarTransparencyDialog() {
        final int[] values = new int[]{170, 220, 245};
        final String[] labels = new String[]{"Suave", "Normal", "Sólida"};
        int selected = indexOf(values, prefs.getInt(KEY_TOOLBAR_ALPHA, DEFAULT_TOOLBAR_ALPHA));
        new AlertDialog.Builder(this)
                .setTitle("Transparencia de la barra")
                .setSingleChoiceItems(labels, selected, (dialog, which) -> {
                    prefs.edit().putInt(KEY_TOOLBAR_ALPHA, values[which]).apply();
                    dialog.dismiss();
                    toast("Transparencia guardada. Se aplicará al reiniciar el traductor.");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void resetToolbarAppearance() {
        prefs.edit()
                .putBoolean(KEY_TOOLBAR_COMPACT, DEFAULT_TOOLBAR_COMPACT)
                .putInt(KEY_TOOLBAR_ALPHA, DEFAULT_TOOLBAR_ALPHA)
                .apply();
        toast("Barra restablecida. Se aplicará al reiniciar el traductor.");
    }

    private int indexOf(int[] values, int target) {
        for (int i = 0; i < values.length; i++) {
            if (values[i] == target) return i;
        }
        return 0;
    }

    private void migrateLegacyModelState() {
        SharedPreferences.Editor editor = prefs.edit();
        // Versiones antiguas marcaban todos los idiomas como instalados con una sola bandera.
        // Se invalida ese dato y se vuelve a comprobar cada modelo real con ML Kit.
        if (prefs.getBoolean("models_ready", false)) {
            for (String code : languageCodes) editor.putBoolean(modelKey(code), false);
            editor.remove("models_ready");
        }
        // Coreano fue retirado por completo en 1.27.0.
        editor.remove(modelKey("ko"));
        if ("ko".equals(prefs.getString(DownloadModelService.KEY_ACTIVE_CODE, ""))) {
            editor.putBoolean(DownloadModelService.KEY_ACTIVE, false)
                    .putString(DownloadModelService.KEY_STATE, DownloadModelService.STATE_IDLE)
                    .remove(DownloadModelService.KEY_ACTIVE_CODE)
                    .remove(DownloadModelService.KEY_ACTIVE_NAME);
        }
        editor.apply();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView eyebrow = label("TRADUCTOR OFFLINE ESTABLE", 11, ACCENT, true);
        eyebrow.setLetterSpacing(0.12f);
        root.addView(eyebrow);

        TextView title = label("Zeta Live Translator", 27, TEXT, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(5);
        root.addView(title, titleLp);

        TextView intro = label(
                "Traductor offline de subtítulos y texto visible en pantalla. Entrada: Chino, Japonés o Inglés. Salida: Español.",
                14, MUTED, false);
        intro.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = dp(7);
        root.addView(intro, introLp);

        LinearLayout heroCard = card();
        heroCard.addView(label("Configuración simple", 18, TEXT, true));
        TextView heroDetail = label("La app está pensada para usuarios en español y para traducir únicamente hacia español, sin inicio de sesión ni funciones extra.", 13, MUTED, false);
        heroDetail.setLineSpacing(0f, 1.12f);
        heroCard.addView(heroDetail, topMargin(7));

        LinearLayout chipsRow = new LinearLayout(this);
        chipsRow.setOrientation(LinearLayout.HORIZONTAL);
        chipsRow.setGravity(Gravity.START);
        chipsRow.addView(infoChip("Entrada: EN / ZH / JA", ACCENT));
        LinearLayout.LayoutParams chip2Lp = new LinearLayout.LayoutParams(-2, -2);
        chip2Lp.leftMargin = dp(8);
        chipsRow.addView(infoChip("Salida fija: Español", SUCCESS), chip2Lp);
        heroCard.addView(chipsRow, topMargin(12));
        root.addView(heroCard, topMargin(16));

        LinearLayout statusCard = card();
        globalTitle = label("Preparando estado", 19, TEXT, true);
        statusCard.addView(globalTitle);
        globalDetail = label("Comprobando permisos y modelos instalados.", 13, MUTED, false);
        LinearLayout.LayoutParams globalDetailLp = new LinearLayout.LayoutParams(-1, -2);
        globalDetailLp.topMargin = dp(7);
        statusCard.addView(globalDetail, globalDetailLp);
        installedCount = badge("0 idiomas listos", WARNING);
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(-2, -2);
        countLp.topMargin = dp(13);
        statusCard.addView(installedCount, countLp);
        root.addView(statusCard, topMargin(16));

        LinearLayout backgroundCard = card();
        backgroundCard.addView(label("Funcionamiento sobre otras apps", 19, TEXT, true));
        TextView backgroundHint = label("Estos ajustes ayudan a mantener la barra y LIVE activos mientras usas Google, Chrome, reproductores u otras aplicaciones.", 13, MUTED, false);
        backgroundHint.setLineSpacing(0f, 1.12f);
        backgroundCard.addView(backgroundHint, topMargin(7));

        overlayPermissionState = label("Comprobando permiso de superposición…", 13, MUTED, true);
        backgroundCard.addView(overlayPermissionState, topMargin(13));
        notificationPermissionState = label("Comprobando notificaciones…", 13, MUTED, true);
        backgroundCard.addView(notificationPermissionState, topMargin(8));
        batteryOptimizationState = label("Comprobando batería…", 13, MUTED, true);
        backgroundCard.addView(batteryOptimizationState, topMargin(8));

        permissionsButton = primaryButton("Preparar permisos");
        permissionsButton.setOnClickListener(v -> beginPermissionFlow());
        backgroundCard.addView(permissionsButton, topMargin(13));

        Button batteryButton = secondaryButton("Abrir ajustes de batería");
        batteryButton.setOnClickListener(v -> openBatterySettings());
        backgroundCard.addView(batteryButton, topMargin(9));
        root.addView(backgroundCard, topMargin(16));

        startButton = accentOutlineButton("Iniciar traductor");
        startButton.setOnClickListener(v -> startCaptureFlow());
        root.addView(startButton, topMargin(10));

        LinearLayout appearanceCard = card();
        appearanceCard.addView(label("Apariencia", 19, TEXT, true));
        TextView appearanceHint = label("Ajusta solo lo visual: cuadro de captura, subtítulos y barra flotante.", 13, MUTED, false);
        appearanceCard.addView(appearanceHint, topMargin(6));

        Button selectorStyleButton = secondaryButton("Cuadro de captura");
        selectorStyleButton.setOnClickListener(v -> showCaptureBoxDialog());
        appearanceCard.addView(selectorStyleButton, topMargin(12));

        Button subtitleStyleButton = secondaryButton("Apariencia de subtítulos");
        subtitleStyleButton.setOnClickListener(v -> showSubtitleAppearanceDialog());
        appearanceCard.addView(subtitleStyleButton, topMargin(10));

        Button toolbarStyleButton = secondaryButton("Barra flotante");
        toolbarStyleButton.setOnClickListener(v -> showToolbarAppearanceDialog());
        appearanceCard.addView(toolbarStyleButton, topMargin(10));

        Button resetPositionsButton = secondaryButton("Restablecer posiciones");
        resetPositionsButton.setOnClickListener(v -> resetOverlayPositions());
        appearanceCard.addView(resetPositionsButton, topMargin(10));

        Button glossaryButton = secondaryButton("Glosario de correcciones");
        glossaryButton.setOnClickListener(v -> showGlossaryDialog());
        appearanceCard.addView(glossaryButton, topMargin(10));
        root.addView(appearanceCard, topMargin(16));

        LinearLayout modelsCard = card();
        modelsCard.addView(label("Idiomas offline", 19, TEXT, true));
        TextView modelsHint = label(
                "Descarga solo los idiomas que realmente vas a usar. Cada idioma queda listo para traducir únicamente hacia español.",
                13, MUTED, false);
        modelsHint.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
        hintLp.topMargin = dp(7);
        modelsCard.addView(modelsHint, hintLp);

        activeProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        activeProgress.setIndeterminate(true);
        activeProgress.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
        activeProgress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(5));
        progressLp.topMargin = dp(14);
        modelsCard.addView(activeProgress, progressLp);

        downloadStatusLine = label("Sin descarga activa", 13, TEXT, true);
        downloadStatusLine.setVisibility(View.GONE);
        LinearLayout.LayoutParams downloadStatusLp = new LinearLayout.LayoutParams(-1, -2);
        downloadStatusLp.topMargin = dp(11);
        modelsCard.addView(downloadStatusLine, downloadStatusLp);

        downloadMetaLine = label("", 12, MUTED, false);
        downloadMetaLine.setVisibility(View.GONE);
        LinearLayout.LayoutParams downloadMetaLp = new LinearLayout.LayoutParams(-1, -2);
        downloadMetaLp.topMargin = dp(5);
        modelsCard.addView(downloadMetaLine, downloadMetaLp);

        downloadControlButton = smallButton("Detener seguimiento");
        downloadControlButton.setVisibility(View.GONE);
        downloadControlButton.setOnClickListener(v -> handleDownloadControl());
        LinearLayout.LayoutParams downloadControlLp = new LinearLayout.LayoutParams(-1, dp(44));
        downloadControlLp.topMargin = dp(10);
        modelsCard.addView(downloadControlButton, downloadControlLp);

        for (int i = 0; i < languageCodes.length; i++) {
            modelsCard.addView(buildLanguageRow(i), topMargin(i == 0 ? 15 : 12));
        }
        root.addView(modelsCard, topMargin(16));

        LinearLayout behaviorCard = card();
        behaviorCard.addView(label("Resumen rápido", 19, TEXT, true));
        addBullet(behaviorCard, "La traducción siempre sale en español.");
        addBullet(behaviorCard, "Detectar idioma se usa solo al inicio y luego bloquea el idioma para mantener la velocidad.");
        addBullet(behaviorCard, "Puedes personalizar el cuadro, los subtítulos y la barra flotante sin tocar la lógica principal.");
        addBullet(behaviorCard, "El subtítulo sigue mostrándose sin cuadro negro grande para no tapar el video.");
        root.addView(behaviorCard, topMargin(16));

        setContentView(scroll);
    }

    private LinearLayout buildLanguageRow(int index) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        row.setBackground(roundRect(SURFACE_ALT, BORDER, 14));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = label(languageNames[index], 16, TEXT, true);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));

        stateBadges[index] = badge("No instalado", WARNING);
        top.addView(stateBadges[index]);
        row.addView(top);

        TextView note = label(languageNotes[index], 12, MUTED, false);
        note.setLineSpacing(0f, 1.1f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(7);
        row.addView(note, noteLp);

        downloadButtons[index] = smallButton(index == 0 ? "Descargar Inglés" : "Descargar");
        final int languageIndex = index;
        downloadButtons[index].setOnClickListener(v -> downloadLanguage(languageIndex));
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1, dp(46));
        buttonLp.topMargin = dp(11);
        row.addView(downloadButtons[index], buttonLp);
        return row;
    }

    private void refreshBackgroundStatus() {
        if (overlayPermissionState == null || notificationPermissionState == null || batteryOptimizationState == null) return;
        boolean overlayReady = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        boolean notificationsReady = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        boolean batteryReady = isIgnoringBatteryOptimizations();

        overlayPermissionState.setText((overlayReady ? "✓ " : "• ") + "Mostrar sobre otras apps: " + (overlayReady ? "Listo" : "Pendiente"));
        overlayPermissionState.setTextColor(overlayReady ? SUCCESS : WARNING);
        notificationPermissionState.setText((notificationsReady ? "✓ " : "• ") + "Notificación del servicio: " + (notificationsReady ? "Lista" : "Pendiente"));
        notificationPermissionState.setTextColor(notificationsReady ? SUCCESS : WARNING);
        batteryOptimizationState.setText((batteryReady ? "✓ " : "• ") + "Batería: " + (batteryReady ? "Sin restricciones" : "Optimizada por Android"));
        batteryOptimizationState.setTextColor(batteryReady ? SUCCESS : WARNING);
    }

    private boolean isIgnoringBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        return powerManager != null && powerManager.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void openBatterySettings() {
        new AlertDialog.Builder(this)
                .setTitle("Evitar cierres por batería")
                .setMessage("Busca Zeta Live Translator y selecciona Sin restricciones o No optimizar. El nombre puede cambiar según la marca del teléfono. Esto ayuda a que LIVE continúe sobre otras aplicaciones, pero Android todavía puede cerrar cualquier app si falta memoria.")
                .setPositiveButton("Abrir ajustes", (dialog, which) -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                        startActivity(intent);
                    } catch (Exception firstError) {
                        try {
                            Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + getPackageName()));
                            startActivity(fallback);
                        } catch (Exception ignored) {
                            toast("No se pudo abrir el ajuste de batería.");
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void resetOverlayPositions() {
        int resetCounter = prefs.getInt(KEY_LAYOUT_RESET_COUNTER, 0) + 1;
        prefs.edit()
                .putInt(KEY_LAYOUT_RESET_COUNTER, resetCounter)
                .remove(KEY_LAYOUT_SCREEN_W)
                .remove(KEY_LAYOUT_SCREEN_H)
                .remove(KEY_SELECTOR_LEFT)
                .remove(KEY_SELECTOR_TOP)
                .remove(KEY_SELECTOR_RIGHT)
                .remove(KEY_SELECTOR_BOTTOM)
                .remove(KEY_TOOLBAR_X)
                .remove(KEY_TOOLBAR_Y)
                .remove(KEY_SUBTITLE_X)
                .remove(KEY_SUBTITLE_Y)
                .remove(KEY_SUBTITLE_MOVED)
                .apply();
        toast("Posiciones restablecidas. Se aplicará al volver a iniciar el traductor.");
    }

    private void beginPermissionFlow() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        toast("Permisos principales listos.");
        refreshUi();
    }

    private void downloadLanguage(int index) {
        if (isDownloadActive()) {
            toast("Ya hay una descarga en curso.");
            return;
        }
        if (isModelReady(languageCodes[index])) {
            toast(languageNames[index] + " ya está listo.");
            return;
        }
        if (!isNetworkAvailable()) {
            updateGlobal("Sin conexión", "Conéctate a internet y vuelve a tocar Descargar.");
            return;
        }
        if (!hasEnoughStorage()) {
            updateGlobal("Espacio insuficiente", "Libera al menos 150 MB y vuelve a intentarlo.");
            toast("No hay espacio libre suficiente.");
            return;
        }

        prefs.edit()
                .putBoolean(DownloadModelService.KEY_ACTIVE, true)
                .putInt(DownloadModelService.KEY_ACTIVE_INDEX, index)
                .putString(DownloadModelService.KEY_ACTIVE_CODE, languageCodes[index])
                .putString(DownloadModelService.KEY_ACTIVE_NAME, languageNames[index])
                .putString(DownloadModelService.KEY_STATE, DownloadModelService.STATE_CHECKING)
                .putString(DownloadModelService.KEY_MESSAGE, "Iniciando comprobación…")
                .putLong(DownloadModelService.KEY_STARTED_AT, System.currentTimeMillis())
                .putInt(DownloadModelService.KEY_STAGE, 0)
                .putInt(DownloadModelService.KEY_STAGE_TOTAL, 2)
                .putString(DownloadModelService.KEY_CONNECTION, connectionLabel())
                .apply();

        Intent service = new Intent(this, DownloadModelService.class);
        service.setAction(DownloadModelService.ACTION_START);
        service.putExtra(DownloadModelService.EXTRA_INDEX, index);
        service.putExtra(DownloadModelService.EXTRA_CODE, languageCodes[index]);
        service.putExtra(DownloadModelService.EXTRA_NAME, languageNames[index]);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);
        refreshUi();
    }

    private void startCaptureFlow() {
        if (installedModels() == 0) {
            updateGlobal("Falta un idioma", "Descarga por lo menos Inglés → Español antes de iniciar.");
            toast("Descarga por lo menos un idioma.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            updateGlobal("Falta permiso", "Activa “Mostrar sobre otras apps” para usar la barra flotante.");
            beginPermissionFlow();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, OverlayTranslatorService.class);
            service.putExtra(OverlayTranslatorService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(OverlayTranslatorService.EXTRA_DATA, data);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
            updateGlobal("Traductor iniciado", "Ajusta el cuadro de captura y pulsa Traducir o LIVE.");
            moveTaskToBack(true);
        } else {
            updateGlobal("Captura cancelada", "Android no concedió el permiso de captura.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                refreshUi();
            }
        }
    }

    private void refreshUi() {
        refreshBackgroundStatus();
        int installed = installedModels();
        boolean overlayReady = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        boolean downloadActive = isDownloadActive();
        int activeIndex = prefs.getInt(DownloadModelService.KEY_ACTIVE_INDEX, -1);
        String downloadState = prefs.getString(DownloadModelService.KEY_STATE, DownloadModelService.STATE_IDLE);
        String downloadName = prefs.getString(DownloadModelService.KEY_ACTIVE_NAME, "");
        String downloadMessage = prefs.getString(DownloadModelService.KEY_MESSAGE, "");
        int stage = prefs.getInt(DownloadModelService.KEY_STAGE, 0);
        int stageTotal = prefs.getInt(DownloadModelService.KEY_STAGE_TOTAL, 0);
        String connection = prefs.getString(DownloadModelService.KEY_CONNECTION, connectionLabel());
        long startedAt = prefs.getLong(DownloadModelService.KEY_STARTED_AT, 0L);
        long elapsed = startedAt > 0L ? Math.max(0L, System.currentTimeMillis() - startedAt) : 0L;

        installedCount.setText(installed + (installed == 1 ? " idioma listo" : " idiomas listos"));
        styleBadge(installedCount, installed > 0 ? SUCCESS : WARNING);

        for (int i = 0; i < languageCodes.length; i++) {
            boolean ready = isModelReady(languageCodes[i]);
            boolean downloading = downloadActive && activeIndex == i;
            stateBadges[i].setText(ready ? "Listo" : (downloading ? stateLabel(downloadState) : "No instalado"));
            styleBadge(stateBadges[i], ready ? SUCCESS : (downloading ? ACCENT : WARNING));
            downloadButtons[i].setText(ready ? "Instalado" : (downloading ? "En proceso…" : (i == 0 ? "Descargar Inglés" : "Descargar")));
            downloadButtons[i].setEnabled(!downloadActive && !ready);
            downloadButtons[i].setAlpha(downloadButtons[i].isEnabled() ? 1f : 0.55f);
        }

        boolean showDownloadPanel = downloadActive
                || DownloadModelService.STATE_ERROR.equals(downloadState)
                || DownloadModelService.STATE_STOPPED.equals(downloadState)
                || DownloadModelService.STATE_READY.equals(downloadState);
        activeProgress.setVisibility(downloadActive ? View.VISIBLE : View.GONE);
        downloadStatusLine.setVisibility(showDownloadPanel ? View.VISIBLE : View.GONE);
        downloadMetaLine.setVisibility(showDownloadPanel ? View.VISIBLE : View.GONE);
        downloadControlButton.setVisibility((downloadActive
                || DownloadModelService.STATE_ERROR.equals(downloadState)
                || DownloadModelService.STATE_STOPPED.equals(downloadState)) ? View.VISIBLE : View.GONE);

        if (showDownloadPanel) {
            String title = downloadName.isEmpty() ? "Descarga de modelo" : downloadName;
            downloadStatusLine.setText(stateLabel(downloadState) + " · " + title);
            String stageText = stageTotal > 0 ? "Etapa " + Math.min(stage + (downloadActive ? 1 : 0), stageTotal) + " de " + stageTotal : "Preparando";
            downloadMetaLine.setText(stageText + "  ·  " + formatElapsed(elapsed) + "  ·  " + connection + "\n" + downloadMessage);
            downloadControlButton.setText(downloadActive ? "Detener seguimiento" : "Reintentar");
        }

        startButton.setEnabled(installed > 0 && overlayReady && !downloadActive);
        startButton.setAlpha(startButton.isEnabled() ? 1f : 0.5f);
        permissionsButton.setText(overlayReady ? "Permisos listos" : "Preparar permisos");

        if (downloadActive) {
            updateGlobal(stateLabel(downloadState) + " " + downloadName,
                    downloadMessage + " Tiempo: " + formatElapsed(elapsed) + ". Conexión: " + connection + ".");
        } else if (DownloadModelService.STATE_ERROR.equals(downloadState)) {
            updateGlobal("Falló la descarga", downloadMessage);
        } else if (DownloadModelService.STATE_STOPPED.equals(downloadState)) {
            updateGlobal("Seguimiento detenido", downloadMessage);
        } else if (DownloadModelService.STATE_READY.equals(downloadState)) {
            updateGlobal("Modelo instalado", downloadMessage);
        } else if (installed == 0) {
            updateGlobal("Descarga un idioma", "Empieza por Inglés → Español o instala directamente el idioma que más uses.");
        } else if (!overlayReady) {
            updateGlobal("Falta un permiso", "Activa “Mostrar sobre otras apps”. Tus modelos ya están guardados.");
        } else {
            updateGlobal("Listo para traducir", "Tienes " + installed + " idioma(s) instalado(s). Puedes iniciar ahora.");
        }
    }

    private int installedModels() {
        int count = 0;
        for (String code : languageCodes) if (isModelReady(code)) count++;
        return count;
    }

    private boolean isModelReady(String source) {
        return prefs.getBoolean(modelKey(source), false);
    }

    private String modelKey(String source) {
        return KEY_MODEL_PREFIX + source;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }


    private boolean hasEnoughStorage() {
        try {
            return getFilesDir().getUsableSpace() >= 150L * 1024L * 1024L;
        } catch (Exception ignored) {
            return true;
        }
    }

    private void handleDownloadControl() {
        String currentState = prefs.getString(DownloadModelService.KEY_STATE, DownloadModelService.STATE_IDLE);
        if (isDownloadActive()) {
            Intent stop = new Intent(this, DownloadModelService.class);
            stop.setAction(DownloadModelService.ACTION_STOP);
            startService(stop);
            return;
        }
        if (DownloadModelService.STATE_ERROR.equals(currentState)
                || DownloadModelService.STATE_STOPPED.equals(currentState)) {
            int index = prefs.getInt(DownloadModelService.KEY_ACTIVE_INDEX, -1);
            if (index >= 0 && index < languageCodes.length) downloadLanguage(index);
        }
    }

    private boolean isDownloadActive() {
        return prefs.getBoolean(DownloadModelService.KEY_ACTIVE, false);
    }

    private String stateLabel(String state) {
        if (DownloadModelService.STATE_CHECKING.equals(state)) return "Comprobando";
        if (DownloadModelService.STATE_DOWNLOADING.equals(state)) return "Descargando";
        if (DownloadModelService.STATE_VERIFYING.equals(state)) return "Verificando";
        if (DownloadModelService.STATE_READY.equals(state)) return "Listo";
        if (DownloadModelService.STATE_ERROR.equals(state)) return "Error";
        if (DownloadModelService.STATE_STOPPED.equals(state)) return "Detenido";
        return "Preparando";
    }

    private String connectionLabel() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return "Sin conexión";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return "Sin conexión";
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "Sin conexión";
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) return "Red sin internet";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi‑Fi";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Datos móviles";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            return "Internet disponible";
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null || !info.isConnected()) return "Sin conexión";
        return info.getType() == ConnectivityManager.TYPE_WIFI ? "Wi‑Fi" : "Datos móviles";
    }

    private String formatElapsed(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        return String.format(Locale.US, "%02d:%02d", totalSeconds / 60L, totalSeconds % 60L);
    }

    private void verifyActualModels() {
        verifyPairAt(0);
    }

    private void verifyPairAt(int index) {
        if (index >= languageCodes.length) {
            refreshUi();
            return;
        }
        verifyRemoteModel(TranslateLanguage.SPANISH, spanishReady -> {
            if (!spanishReady) {
                prefs.edit().putBoolean(modelKey(languageCodes[index]), false).apply();
                verifyPairAt(index + 1);
                return;
            }
            verifyRemoteModel(languageCodes[index], sourceReady -> {
                prefs.edit().putBoolean(modelKey(languageCodes[index]), sourceReady).apply();
                verifyPairAt(index + 1);
            });
        });
    }

    private void verifyRemoteModel(String languageCode, ModelCheckCallback callback) {
        TranslateRemoteModel model = new TranslateRemoteModel.Builder(languageCode).build();
        remoteModelManager.isModelDownloaded(model)
                .addOnSuccessListener(result -> callback.onResult(Boolean.TRUE.equals(result)))
                .addOnFailureListener(error -> callback.onResult(false));
    }

    private interface ModelCheckCallback {
        void onResult(boolean ready);
    }

    private void updateGlobal(String title, String detail) {
        globalTitle.setText(title);
        globalDetail.setText(detail);
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(17), dp(17), dp(17));
        card.setBackground(roundRect(SURFACE, BORDER, 18));
        return card;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private TextView badge(String value, int color) {
        TextView view = label(value, 12, color, true);
        view.setPadding(dp(10), dp(6), dp(10), dp(6));
        styleBadge(view, color);
        return view;
    }

    private void styleBadge(TextView view, int color) {
        int translucent;
        if (color == SUCCESS) translucent = 0x222FC58D;
        else if (color == ACCENT) translucent = 0x224F8CFF;
        else if (color == ERROR) translucent = 0x22F97066;
        else translucent = 0x22F0B429;
        view.setTextColor(color);
        view.setBackground(roundRect(translucent, color, 999));
    }

    private TextView infoChip(String value, int color) {
        TextView chip = label(value, 12, color, true);
        chip.setPadding(dp(10), dp(6), dp(10), dp(6));
        chip.setBackground(roundRect((color == SUCCESS ? 0x1E31C48D : 0x1E4F8CFF), color, 999));
        return chip;
    }

    private Button primaryButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(16);
        b.setTextColor(0xFFFFFFFF);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(roundRect(ACCENT, ACCENT, 16));
        return b;
    }

    private Button accentOutlineButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(16);
        b.setTextColor(TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(roundRect(0xFF1B2430, ACCENT, 16));
        return b;
    }

    private Button secondaryButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(16);
        b.setTextColor(TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(roundRect(SURFACE_ALT, BORDER, 16));
        return b;
    }

    private Button smallButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(14);
        b.setTextColor(TEXT);
        b.setAllCaps(false);
        b.setBackground(roundRect(0xFF263142, BORDER, 13));
        return b;
    }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams topMargin(int margin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(margin);
        return lp;
    }

    private void addBullet(LinearLayout parent, String text) {
        TextView bullet = label("• " + text, 13, MUTED, false);
        bullet.setLineSpacing(0f, 1.12f);
        parent.addView(bullet, topMargin(9));
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
