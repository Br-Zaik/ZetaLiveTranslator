package com.geozeta.livetranslator;

/**
 * Confirma una deteccion automatica sin dejar que el idioma cambie durante el video.
 * Una candidata fuerte se bloquea de inmediato; una candidata dudosa debe ganar dos
 * capturas cercanas. La clase no depende de Android para poder probar esta regla.
 */
final class AutoLanguageLock {
    private static final long CONFIRM_WINDOW_MS = 2600L;

    private String pendingMode = "";
    private int consecutiveWins = 0;
    private long lastWinAt = 0L;

    synchronized boolean shouldLock(String mode, boolean strongCandidate,
                                    int installedLanguageCount, long nowMs) {
        if (mode == null || mode.trim().isEmpty()) return false;
        if (installedLanguageCount <= 1 || strongCandidate) {
            reset();
            return true;
        }

        boolean sameRecentMode = mode.equals(pendingMode)
                && nowMs >= lastWinAt
                && nowMs - lastWinAt <= CONFIRM_WINDOW_MS;
        if (sameRecentMode) {
            consecutiveWins++;
        } else {
            pendingMode = mode;
            consecutiveWins = 1;
        }
        lastWinAt = nowMs;

        if (consecutiveWins >= 2) {
            reset();
            return true;
        }
        return false;
    }

    synchronized void reset() {
        pendingMode = "";
        consecutiveWins = 0;
        lastWinAt = 0L;
    }
}
