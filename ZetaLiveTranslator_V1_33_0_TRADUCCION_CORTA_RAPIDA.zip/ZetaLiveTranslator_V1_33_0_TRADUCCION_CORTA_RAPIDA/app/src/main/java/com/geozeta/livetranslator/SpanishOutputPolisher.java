package com.geozeta.livetranslator;

import java.util.Locale;

/** Ajustes tipográficos seguros para que el resultado offline se lea como español natural. */
final class SpanishOutputPolisher {
    private SpanishOutputPolisher() { }

    static String polish(String translated, String original) {
        if (translated == null) return "";
        String text = translated.replace('\r', ' ').replace('\n', ' ')
                .replaceAll("\\s+", " ")
                .replaceAll("\\s+([,.;:!?])", "$1")
                .replaceAll("([¿¡])\\s+", "$1")
                .replaceAll("([,;:])(?=\\S)", "$1 ")
                .replaceAll("[?]{2,}", "?")
                .replaceAll("[!]{2,}", "!")
                .trim();
        if (text.isEmpty()) return text;

        boolean sourceQuestion = containsQuestion(original);
        boolean sourceExclamation = containsExclamation(original);
        if ((sourceQuestion || text.endsWith("?")) && !text.startsWith("¿")) {
            text = "¿" + text;
        }
        if ((sourceExclamation || text.endsWith("!")) && !text.startsWith("¡")) {
            text = "¡" + text;
        }

        int letterIndex = firstLetterIndex(text);
        if (letterIndex >= 0) {
            String first = text.substring(letterIndex, letterIndex + 1).toUpperCase(Locale.ROOT);
            text = text.substring(0, letterIndex) + first + text.substring(letterIndex + 1);
        }
        return text;
    }

    private static boolean containsQuestion(String source) {
        return source != null && (source.indexOf('?') >= 0 || source.indexOf('？') >= 0);
    }

    private static boolean containsExclamation(String source) {
        return source != null && (source.indexOf('!') >= 0 || source.indexOf('！') >= 0);
    }

    private static int firstLetterIndex(String text) {
        for (int i = 0; i < text.length(); i++) {
            if (Character.isLetter(text.charAt(i))) return i;
        }
        return -1;
    }
}
