package com.geozeta.livetranslator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Checks whether an alleged Spanish result stayed mostly in the source script. */
public final class TranslationQualityGuard {
    private static final Pattern LATIN_WORD = Pattern.compile("[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]{2,}");

    private TranslationQualityGuard() { }

    public static boolean hasTooMuchCjkForSpanish(String text) {
        if (text == null || text.trim().isEmpty()) return true;
        int cjk = 0;
        int latin = 0;
        int longestCjkRun = 0;
        int currentCjkRun = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (isCjk(c)) {
                cjk++;
                currentCjkRun++;
                longestCjkRun = Math.max(longestCjkRun, currentCjkRun);
            } else {
                currentCjkRun = 0;
                if (isLatin(c)) latin++;
            }
        }
        if (cjk <= 3) return false;

        int latinWords = 0;
        Matcher matcher = LATIN_WORD.matcher(text);
        while (matcher.find()) latinWords++;

        // Un nombre asiático puede conservarse dentro de una frase española. Se permite una
        // o dos secuencias cortas cuando ya hay suficiente texto latino alrededor.
        if (latinWords >= 2 && latin >= 6 && cjk <= 10 && longestCjkRun <= 7) return false;

        int letters = cjk + latin;
        if (letters == 0) return true;
        float cjkRatio = cjk / (float) letters;
        return latinWords == 0 || latin < 4 || cjkRatio > 0.48f || longestCjkRun > 10;
    }

    private static boolean isCjk(char c) {
        return (c >= '\u3400' && c <= '\u9FFF') || (c >= '\u3040' && c <= '\u30FF');
    }

    private static boolean isLatin(char c) {
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
                || "ÁÉÍÓÚÜÑáéíóúüñ".indexOf(c) >= 0;
    }
}
