package com.geozeta.livetranslator;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Strict duplicate guard. It never merges subtitles when negation or numbers change. */
final class SubtitleTextGuard {
    private static final Pattern NUMBER_PATTERN = Pattern.compile("\\d+");
    private static final String[] NEGATION_WORDS = new String[]{
            " no ", " not ", " never ", " none ", " nobody ", " nothing ",
            " neither ", " nor ", " without ", " cannot "
    };
    private static final String[] CJK_NEGATIONS = new String[]{
            "不", "没", "沒有", "没有", "無", "无", "別", "别", "未", "非", "勿", "莫",
            "ない", "ません", "じゃない", "ではない", "なく", "なかった"
    };

    private SubtitleTextGuard() { }

    static String normalize(String text) {
        if (text == null) return "";
        String value = text.toLowerCase(Locale.ROOT).replace('’', '\'');
        // El OCR suele perder el apóstrofo. Se protegen también cant/dont/isnt, etc.
        value = value.replaceAll("\\bwon't\\b|\\bwont\\b", "will not")
                .replaceAll("\\bcan't\\b|\\bcant\\b", "can not")
                .replaceAll("\\bshan't\\b|\\bshant\\b", "shall not")
                .replaceAll("\\bain't\\b|\\baint\\b", "is not")
                .replaceAll("\\bdon't\\b|\\bdont\\b", "do not")
                .replaceAll("\\bdoesn't\\b|\\bdoesnt\\b", "does not")
                .replaceAll("\\bdidn't\\b|\\bdidnt\\b", "did not")
                .replaceAll("\\bisn't\\b|\\bisnt\\b", "is not")
                .replaceAll("\\baren't\\b|\\barent\\b", "are not")
                .replaceAll("\\bwasn't\\b|\\bwasnt\\b", "was not")
                .replaceAll("\\bweren't\\b|\\bwerent\\b", "were not")
                .replaceAll("\\bshouldn't\\b|\\bshouldnt\\b", "should not")
                .replaceAll("\\bcouldn't\\b|\\bcouldnt\\b", "could not")
                .replaceAll("\\bwouldn't\\b|\\bwouldnt\\b", "would not")
                .replaceAll("\\bhasn't\\b|\\bhasnt\\b", "has not")
                .replaceAll("\\bhaven't\\b|\\bhavent\\b", "have not")
                .replaceAll("\\bhadn't\\b|\\bhadnt\\b", "had not")
                .replaceAll("\\bmustn't\\b|\\bmustnt\\b", "must not")
                .replaceAll("\\bneedn't\\b|\\bneednt\\b", "need not")
                .replaceAll("\\b([a-z]+)n't\\b", "$1 not");
        return value.replaceAll("[^\\p{L}\\p{N}]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    static boolean areEquivalent(String first, String second) {
        String a = normalize(first);
        String b = normalize(second);
        if (a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b)) return true;
        if (meaningSignatureChanged(a, b)) return false;

        int max = Math.max(a.length(), b.length());
        int min = Math.min(a.length(), b.length());
        if (min >= 12 && (a.contains(b) || b.contains(a)) && min >= Math.round(max * 0.94f)) {
            return true;
        }
        return max >= 12
                && Math.abs(a.length() - b.length()) <= 1
                && levenshteinDistance(a, b) <= 1;
    }

    private static boolean meaningSignatureChanged(String a, String b) {
        String paddedA = " " + a + " ";
        String paddedB = " " + b + " ";
        for (String word : NEGATION_WORDS) {
            if (paddedA.contains(word) != paddedB.contains(word)) return true;
        }
        for (String term : CJK_NEGATIONS) {
            if (a.contains(term) != b.contains(term)) return true;
        }
        return !numbers(a).equals(numbers(b));
    }

    private static List<String> numbers(String value) {
        List<String> out = new ArrayList<>();
        Matcher matcher = NUMBER_PATTERN.matcher(value);
        while (matcher.find()) out.add(matcher.group());
        return out;
    }

    private static int levenshteinDistance(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[b.length()];
    }
}
