package com.geozeta.livetranslator;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;

import com.google.mlkit.common.MlKitException;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TranslatorEngine {
    public static final String MODE_AUTO = "auto";
    public static final String MODE_CHINESE = TranslateLanguage.CHINESE;
    public static final String MODE_ENGLISH = TranslateLanguage.ENGLISH;
    public static final String MODE_JAPANESE = TranslateLanguage.JAPANESE;

    public interface Callback {
        void onSuccess(String original, String translated, String sourceName);
        void onError(String message);
    }

    private final Pattern cjkPattern = Pattern.compile("[\\u3400-\\u9FFF\\u3040-\\u30FF]");
    private final Pattern chinesePattern = Pattern.compile("[\\u3400-\\u9FFF]");
    private final Pattern japanesePattern = Pattern.compile("[\\u3040-\\u30FF]");
    private final Pattern latinPattern = Pattern.compile("[A-Za-z]");
    private final Pattern expressiveWordPattern = Pattern.compile("[A-Za-z]{2,}");
    private static final int AUTO_ENGLISH_ACCEPT_SCORE = 120;
    private static final int AUTO_CJK_ACCEPT_SCORE = 18;
    public static final String KEY_CUSTOM_GLOSSARY = "custom_glossary_en_es";
    private final Context appContext;
    private final SharedPreferences preferences;
    private final Set<String> englishVocabulary = new HashSet<>();
    // En modo Detectar, lastAutoMode se convierte en un bloqueo explicito.
    // No cambia durante el video hasta que el usuario solicita detectar otra vez.
    private volatile String lastAutoMode = null;
    private volatile int autoDetectionGeneration = 0;
    private final AutoLanguageLock autoLanguageLock = new AutoLanguageLock();
    private final List<StableReading> recentStableReadings = new ArrayList<>();
    private String stableWindowMode = "";
    private String lastAcceptedStableKey = "";
    private String lastAcceptedStableMode = "";
    private int consecutiveEmptyFrames = 0;
    private static final int STABILITY_WINDOW_SIZE = 3;
    private static final long STABILITY_WINDOW_MS = 2200L;
    // Espera un poco mas antes de aceptar el subtitulo: evita traducir frases a medio aparecer.
    private static final long STABILITY_MIN_CONFIRM_CHINESE_MS = 150L;
    private static final long STABILITY_MIN_CONFIRM_JAPANESE_MS = 170L;
    private static final long STABILITY_MIN_CONFIRM_ENGLISH_MS = 180L;
    private final Map<String, TextRecognizer> recognizers = new ConcurrentHashMap<>();
    private final Map<String, Translator> translators = new ConcurrentHashMap<>();
    private volatile boolean closed = false;
    private final Map<String, String> translationCache = new LinkedHashMap<String, String>(160, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > 320;
        }
    };
    private static final Set<String> EXPRESSIVE_DICTIONARY = new HashSet<>(Arrays.asList(
            "a", "ah", "am", "are", "awesome", "bad", "beautiful", "better", "book", "boom",
            "bye", "call", "calm", "can", "come", "cool", "damn", "do", "done", "fine", "food",
            "go", "good", "great", "happy", "help", "hello", "hey", "home", "honey", "hope", "how",
            "i", "know", "later", "leave", "like", "little", "look", "love", "man", "maybe", "me",
            "mom", "more", "need", "never", "nice", "no", "not", "now", "of", "oh", "okay", "one",
            "please", "really", "right", "run", "sad", "see", "she", "shit", "so", "sorry", "stop",
            "sure", "thank", "thanks", "that", "the", "there", "think", "this", "time", "too", "very",
            "wait", "want", "we", "well", "what", "why", "wow", "yeah", "yes", "you"
    ));

    public TranslatorEngine(Context context) {
        appContext = context.getApplicationContext();
        preferences = appContext.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        loadEnglishVocabulary();
    }

    public synchronized void resetAutoState() {
        autoDetectionGeneration++;
        lastAutoMode = null;
        autoLanguageLock.reset();
    }

    public synchronized boolean isAutoLanguageLocked() {
        return lastAutoMode != null && isModelReady(lastAutoMode);
    }

    public synchronized String getLockedAutoMode() {
        return isAutoLanguageLocked() ? lastAutoMode : null;
    }

    public void resetStabilityState() {
        recentStableReadings.clear();
        stableWindowMode = "";
        lastAcceptedStableKey = "";
        lastAcceptedStableMode = "";
        consecutiveEmptyFrames = 0;
    }

    public void noteNoTextDetected() {
        recentStableReadings.clear();
        consecutiveEmptyFrames++;
        // Dos fotogramas sin subtítulo indican que la línea anterior ya desapareció.
        // Así una frase idéntica puede volver a mostrarse más adelante en el video.
        if (consecutiveEmptyFrames >= 2) {
            lastAcceptedStableKey = "";
            lastAcceptedStableMode = "";
            // No se desbloquea el idioma detectado cuando desaparece un subtitulo.
            // Solo se descarta una confirmacion inicial incompleta.
            synchronized (this) {
                if (lastAutoMode == null) autoLanguageLock.reset();
            }
        }
    }

    public void resetContextState() {
        // Compatibilidad: el contexto automático fue eliminado en la versión 1.26.
    }

    /**
     * Prepara los clientes del idioma seleccionado antes de la primera captura. No descarga
     * modelos ni inicia OCR: solo evita parte del retraso de creación al empezar LIVE.
     */
    public void preload(String mode) {
        if (closed || mode == null) return;
        if (MODE_AUTO.equals(mode)) {
            // En teléfonos con poca RAM no se cargan tres OCR a la vez. Se prepara el último
            // idioma detectado o el primero instalado; los demás se crean solo si Detectar los necesita.
            String warmMode = lastAutoMode != null && isModelReady(lastAutoMode)
                    ? lastAutoMode : firstInstalledAutoMode();
            if (warmMode != null) preload(warmMode);
            return;
        }
        if (!isModelReady(mode)) return;
        try {
            getRecognizer(mode);
            getTranslator(mode);
        } catch (RuntimeException ignored) {
            // El procesamiento normal mostrará un error útil si el cliente no puede iniciarse.
        }
    }

    public void process(Bitmap crop, String mode, Callback callback) {
        process(crop, mode, false, callback);
    }

    public void process(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (closed) {
            callback.onError("El traductor ya fue cerrado.");
            return;
        }
        if (crop == null || crop.isRecycled()) {
            callback.onError("No se pudo leer el recorte.");
            return;
        }
        try {
            if (MODE_AUTO.equals(mode)) {
                processAuto(crop, requireStable, callback);
            } else {
                processFixed(crop, mode, requireStable, callback);
            }
        } catch (OutOfMemoryError memoryError) {
            callback.onError("Memoria insuficiente para procesar esta captura. Reduce el cuadro de captura.");
        } catch (RuntimeException runtimeError) {
            callback.onError("No se pudo iniciar el OCR: " + safeMessage(runtimeError));
        }
    }

    private void processFixed(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (!isModelReady(mode)) {
            callback.onError("Descarga " + readable(mode) + " → Español antes de usar este idioma.");
            return;
        }

        // Primera lectura sobre la imagen real. Si el texto parece parcial, pequeño o ruidoso,
        // se ejecuta una segunda lectura mejorada y se conserva la candidata más completa.
        recognize(crop, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String first = cleanOcrResult(result, mode, imageWidth, imageHeight);
                if (!shouldRunEnhancedPass(first, mode, crop.getWidth(), crop.getHeight())) {
                    finishFixedOcr(first, mode, requireStable, callback);
                    return;
                }

                Bitmap enhanced = prepareForOcr(crop, mode);
                if (enhanced == null || enhanced == crop || enhanced.isRecycled()) {
                    finishFixedOcr(first, mode, requireStable, callback);
                    return;
                }
                recognize(enhanced, mode, new OcrCallback() {
                    @Override public void onResult(Text secondResult, int enhancedWidth, int enhancedHeight) {
                        String second = cleanOcrResult(secondResult, mode, enhancedWidth, enhancedHeight);
                        if (!enhanced.isRecycled()) enhanced.recycle();
                        finishFixedOcr(chooseBetterOcrText(first, second, mode), mode, requireStable, callback);
                    }

                    @Override public void onError(String ignored) {
                        if (!enhanced.isRecycled()) enhanced.recycle();
                        finishFixedOcr(first, mode, requireStable, callback);
                    }
                });
            }

            @Override public void onError(String firstError) {
                Bitmap enhanced = prepareForOcr(crop, mode);
                if (enhanced == null || enhanced == crop || enhanced.isRecycled()) {
                    callback.onError(firstError);
                    return;
                }
                recognize(enhanced, mode, new OcrCallback() {
                    @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                        String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                        if (!enhanced.isRecycled()) enhanced.recycle();
                        finishFixedOcr(cleaned, mode, requireStable, callback);
                    }

                    @Override public void onError(String secondError) {
                        if (!enhanced.isRecycled()) enhanced.recycle();
                        callback.onError(secondError);
                    }
                });
            }
        });
    }

    private void finishFixedOcr(String cleaned, String mode, boolean requireStable, Callback callback) {
        if (cleaned == null || cleaned.trim().isEmpty()) {
            callback.onError("No se detectó texto dentro del cuadro.");
            return;
        }
        translateWhenStable(cleaned, mode, requireStable, callback);
    }

    private boolean shouldRunEnhancedPass(String text, String mode, int width, int height) {
        if (text == null || text.trim().isEmpty()) return true;
        String clean = text.trim();
        if (Math.min(width, height) < 90) return true;
        if (MODE_ENGLISH.equals(mode)) {
            int words = countEnglishWords(clean);
            int vocabulary = countVocabularyWords(clean);
            // Expresiones cortas válidas no deben pagar una segunda lectura innecesaria.
            if (words == 1 && vocabulary == 1) return false;
            return scoreEnglishLine(clean) < 105
                    || countSuspiciousCharacters(clean) > 0
                    || (words <= 3 && !clean.matches(".*[.!?…][\"']?$"));
        }
        int script = scriptCountForMode(clean, mode);
        if (script <= 1) return true;
        return stableReadingScore(clean, mode) < 58
                || countSuspiciousCharactersForMode(clean) > 0;
    }

    private String chooseBetterOcrText(String first, String second, String mode) {
        String a = first == null ? "" : first.trim();
        String b = second == null ? "" : second.trim();
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        int scoreA = stableReadingScore(a, mode);
        int scoreB = stableReadingScore(b, mode);
        if (SubtitleTextGuard.areEquivalent(a, b)) {
            if (scoreA != scoreB) return scoreB > scoreA ? b : a;
            return b.length() >= a.length() ? b : a;
        }
        // Si las dos pasadas discrepan, no se mezclan. LIVE decidirá por repetición entre frames.
        return scoreB > scoreA + 8 ? b : a;
    }

    private void processAuto(Bitmap crop, boolean requireStable, Callback callback) {
        final String lockedMode;
        final int generation;
        synchronized (this) {
            lockedMode = lastAutoMode != null && isModelReady(lastAutoMode) ? lastAutoMode : null;
            generation = autoDetectionGeneration;
        }

        // Una vez detectado, Detectar deja de probar idiomas y usa exactamente la misma
        // ruta rapida que el modo manual hasta que el usuario pulse Detectar otra vez.
        if (lockedMode != null) {
            processFixed(crop, lockedMode, requireStable, callback);
            return;
        }

        List<String> installed = installedAutoModes();
        if (installed.isEmpty()) {
            callback.onError("Descarga por lo menos un idioma antes de usar Detectar.");
            return;
        }

        if (installed.size() == 1) {
            String onlyMode = installed.get(0);
            synchronized (this) {
                if (generation != autoDetectionGeneration) {
                    callback.onError("Deteccion cancelada.");
                    return;
                }
                lastAutoMode = onlyMode;
                autoLanguageLock.reset();
            }
            processFixed(crop, onlyMode, requireStable, callback);
            return;
        }

        Bitmap prepared = prepareForOcr(crop, MODE_AUTO);
        List<Candidate> candidates = new ArrayList<>();
        String[] modes = installed.toArray(new String[0]);
        recognizeAutoAt(crop, prepared, modes, 0, candidates, () -> {
            if (prepared != crop && prepared != null && !prepared.isRecycled()) prepared.recycle();
            synchronized (this) {
                if (generation != autoDetectionGeneration) {
                    callback.onError("Deteccion cancelada.");
                    return;
                }
            }

            Candidate best = chooseBest(candidates);
            if (best == null || !isAutoCandidateAcceptable(best.cleaned, best.sourceLanguage, best.score)) {
                callback.onError("No se detecto un idioma claro dentro del cuadro.");
                return;
            }

            int runnerUpScore = runnerUpScore(candidates, best);
            int margin = best.score - runnerUpScore;
            boolean strong = isStrongAutoCandidate(best, margin);
            boolean lockNow;
            synchronized (this) {
                if (generation != autoDetectionGeneration) {
                    callback.onError("Deteccion cancelada.");
                    return;
                }
                lockNow = autoLanguageLock.shouldLock(
                        best.sourceLanguage, strong, installed.size(), System.currentTimeMillis());
                if (lockNow) lastAutoMode = best.sourceLanguage;
            }

            if (!lockNow) {
                callback.onError("Detectando idioma: confirma otra captura.");
                return;
            }

            translateWhenStable(best.cleaned, best.sourceLanguage, requireStable, callback);
        });
    }

    private boolean isAutoCandidateAcceptable(String text, String mode, int score) {
        if (text == null || text.trim().isEmpty()) return false;
        if (MODE_ENGLISH.equals(mode)) return score >= AUTO_ENGLISH_ACCEPT_SCORE;
        int scriptCount = scriptCountForMode(text, mode);
        if (scriptCount == 1) return score >= 5;
        return score >= AUTO_CJK_ACCEPT_SCORE;
    }

    private int runnerUpScore(List<Candidate> candidates, Candidate best) {
        int score = Integer.MIN_VALUE / 4;
        for (Candidate candidate : candidates) {
            if (candidate == best) continue;
            if (candidate.score > score) score = candidate.score;
        }
        return score == Integer.MIN_VALUE / 4 ? 0 : score;
    }

    private boolean isStrongAutoCandidate(Candidate best, int margin) {
        if (best == null) return false;
        if (MODE_ENGLISH.equals(best.sourceLanguage)) {
            return best.score >= 240 && margin >= 35;
        }

        int han = countMatches(chinesePattern, best.cleaned);
        int kana = countMatches(japanesePattern, best.cleaned);
        if (MODE_JAPANESE.equals(best.sourceLanguage) && kana > 0) {
            return best.score >= 40 && margin >= 12;
        }
        if (MODE_CHINESE.equals(best.sourceLanguage) && kana == 0 && han >= 3) {
            return best.score >= 50 && margin >= 24;
        }
        return best.score >= 80 && margin >= 30;
    }

    private int scriptCountForMode(String text, String mode) {
        if (text == null) return 0;
        if (MODE_CHINESE.equals(mode)) return countMatches(chinesePattern, text);
        return countMatches(chinesePattern, text) + countMatches(japanesePattern, text);
    }

    private List<String> installedAutoModes() {
        List<String> modes = new ArrayList<>();
        // Inglés siempre es la primera opción cuando está instalado.
        if (isModelReady(MODE_ENGLISH)) modes.add(MODE_ENGLISH);
        if (isModelReady(MODE_CHINESE)) modes.add(MODE_CHINESE);
        if (isModelReady(MODE_JAPANESE)) modes.add(MODE_JAPANESE);
        return modes;
    }

    private String firstInstalledAutoMode() {
        List<String> modes = installedAutoModes();
        return modes.isEmpty() ? null : modes.get(0);
    }

    private boolean isModelReady(String sourceLanguage) {
        if (TranslateLanguage.SPANISH.equals(sourceLanguage)) return true;
        return preferences.getBoolean(MainActivity.KEY_MODEL_PREFIX + sourceLanguage, false);
    }

    private void recognizeAutoAt(Bitmap original, Bitmap prepared, String[] modes, int index,
                                 List<Candidate> out, Runnable done) {
        if (index >= modes.length) {
            done.run();
            return;
        }
        String mode = modes[index];
        Bitmap bitmap = MODE_ENGLISH.equals(mode) ? original : prepared;
        recognize(bitmap, mode, new OcrCallback() {
            @Override public void onResult(Text result, int imageWidth, int imageHeight) {
                String cleaned = cleanOcrResult(result, mode, imageWidth, imageHeight);
                int score = scoreCandidate(cleaned, mode);
                if (!cleaned.trim().isEmpty()) out.add(new Candidate(cleaned, mode, score));
                recognizeAutoAt(original, prepared, modes, index + 1, out, done);
            }

            @Override public void onError(String error) {
                recognizeAutoAt(original, prepared, modes, index + 1, out, done);
            }
        });
    }

    private Candidate chooseBest(List<Candidate> candidates) {
        Candidate best = null;
        for (Candidate candidate : candidates) {
            if (best == null || candidate.score > best.score) {
                best = candidate;
                continue;
            }
            if (lastAutoMode != null && candidate.sourceLanguage.equals(lastAutoMode)
                    && candidate.score >= best.score - 12) {
                best = candidate;
            }
        }
        return best;
    }

    private int scoreCandidate(String text, String mode) {
        if (text == null) return 0;
        String t = text.trim();
        if (t.length() == 0) return 0;
        int score = Math.min(t.length(), 160);
        int cjk = countMatches(cjkPattern, t);
        int chinese = countMatches(chinesePattern, t);
        int japanese = countMatches(japanesePattern, t);
        int latin = countMatches(latinPattern, t);
        int lineCount = countUsefulLines(t);
        if (lineCount > 1) score += Math.min(90, lineCount * 22);

        if (MODE_ENGLISH.equals(mode)) {
            if (isBadEnglishFalsePositive(t)) return -9999;
            score += latin * 3;
            if (isGoodEnglishLine(t)) score += 170 + scoreEnglishLine(t);
            if (countEnglishWords(t) <= 2 && commonEnglishWordScore(t) == 0) score -= 90;
            if (isLikelySpanishLine(t)) score -= 180;
            if (cjk > 0) score -= cjk * 2;
        } else if (MODE_CHINESE.equals(mode)) {
            score += chinese * 8;
            if (japanese > 0) score -= 16;
            if (japanese == 0 && chinese > 0 && MODE_CHINESE.equals(lastAutoMode)) score += 24;
        } else if (MODE_JAPANESE.equals(mode)) {
            score += japanese * 10 + chinese * 4;
            if (japanese == 0 && chinese > 0 && MODE_JAPANESE.equals(lastAutoMode)) score += 46;
        }
        return score;
    }

    private int countMatches(Pattern pattern, String text) {
        int count = 0;
        java.util.regex.Matcher m = pattern.matcher(text);
        while (m.find()) count++;
        return count;
    }

    private int countUsefulLines(String text) {
        if (text == null) return 0;
        String[] parts = text.replace("\r", "").split("\n");
        int count = 0;
        for (String p : parts) {
            if (p != null && p.trim().length() >= 2) count++;
        }
        return count;
    }

    private static class Candidate {
        final String cleaned;
        final String sourceLanguage;
        final int score;
        Candidate(String cleaned, String sourceLanguage, int score) {
            this.cleaned = cleaned;
            this.sourceLanguage = sourceLanguage;
            this.score = score;
        }
    }

    private static class StableReading {
        final String text;
        final String key;
        final String mode;
        final long timestamp;

        StableReading(String text, String key, String mode, long timestamp) {
            this.text = text;
            this.key = key;
            this.mode = mode;
            this.timestamp = timestamp;
        }
    }

    private Bitmap prepareForOcr(Bitmap crop, String mode) {
        if (crop == null || crop.isRecycled()) return crop;
        int width = crop.getWidth();
        int height = crop.getHeight();
        if (width <= 0 || height <= 0) return crop;

        Bitmap scaled = null;
        Bitmap enhanced = null;
        try {
            int shortSide = Math.min(width, height);
            float scale;
            if (shortSide < 70) scale = 2.25f;
            else if (shortSide < 100) scale = 1.95f;
            else if (shortSide < 145) scale = 1.65f;
            else if (width < 620) scale = 1.45f;
            else scale = 1.20f;
            if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode)) scale += 0.10f;

            // Una sola imagen auxiliar de hasta ~1,8 MP: mejora letras pequeñas sin acumular RAM.
            double maxPixels = 1_800_000d;
            double proposedPixels = width * (double) height * scale * scale;
            if (proposedPixels > maxPixels) {
                scale = (float) Math.max(1d, Math.sqrt(maxPixels / (width * (double) height)));
            }
            int newW = Math.max(width, Math.round(width * scale));
            int newH = Math.max(height, Math.round(height * scale));

            scaled = Bitmap.createScaledBitmap(crop, newW, newH, true);
            enhanced = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(enhanced);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            float contrast = MODE_ENGLISH.equals(mode) ? 1.36f : 1.43f;
            if (MODE_AUTO.equals(mode)) contrast = 1.40f;
            float translate = (-0.5f * contrast + 0.5f) * 255f;
            ColorMatrix contrastMatrix = new ColorMatrix(new float[]{
                    contrast, 0, 0, 0, translate,
                    0, contrast, 0, 0, translate,
                    0, 0, contrast, 0, translate,
                    0, 0, 0, 1, 0
            });
            ColorMatrix saturationMatrix = new ColorMatrix();
            saturationMatrix.setSaturation(0.18f);
            saturationMatrix.postConcat(contrastMatrix);
            paint.setColorFilter(new ColorMatrixColorFilter(saturationMatrix));
            canvas.drawBitmap(scaled, 0, 0, paint);
            if (scaled != crop && !scaled.isRecycled()) scaled.recycle();
            return enhanced;
        } catch (OutOfMemoryError memoryError) {
            if (enhanced != null && !enhanced.isRecycled()) enhanced.recycle();
            if (scaled != null && scaled != crop && !scaled.isRecycled()) scaled.recycle();
            return crop;
        }
    }

    private interface OcrCallback {
        void onResult(Text result, int imageWidth, int imageHeight);
        void onError(String error);
    }

    private void recognize(Bitmap crop, String mode, OcrCallback cb) {
        if (closed) {
            cb.onError("El traductor ya fue cerrado.");
            return;
        }
        try {
            TextRecognizer recognizer = getRecognizer(mode);
            InputImage image = InputImage.fromBitmap(crop, 0);
            int width = crop.getWidth();
            int height = crop.getHeight();
            recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        if (closed) cb.onError("El traductor ya fue cerrado.");
                        else cb.onResult(result, width, height);
                    })
                    .addOnFailureListener(e -> cb.onError("Error OCR: " + safeMessage(e)));
        } catch (OutOfMemoryError memoryError) {
            cb.onError("Memoria insuficiente para iniciar el OCR de " + readable(mode) + ".");
        } catch (RuntimeException runtimeError) {
            cb.onError("Error OCR: " + safeMessage(runtimeError));
        }
    }

    private synchronized TextRecognizer getRecognizer(String mode) {
        if (closed) throw new IllegalStateException("Traductor cerrado");
        String key = mode == null ? MODE_ENGLISH : mode;
        TextRecognizer existing = recognizers.get(key);
        if (existing != null) return existing;
        TextRecognizer created;
        if (MODE_CHINESE.equals(key)) {
            created = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        } else if (MODE_JAPANESE.equals(key)) {
            created = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        } else {
            created = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        }
        recognizers.put(key, created);
        return created;
    }

    private void translateWhenStable(String text, String sourceLanguage, boolean requireStable, Callback callback) {
        if (!requireStable) {
            translate(text, sourceLanguage, callback);
            return;
        }

        String stableText = selectStableText(text, sourceLanguage);
        if (stableText == null || stableText.trim().isEmpty()) {
            callback.onError("Esperando subtítulo estable.");
            return;
        }

        String acceptedKey = lastAcceptedStableKey;
        String acceptedMode = lastAcceptedStableMode;
        translate(stableText, sourceLanguage, new Callback() {
            @Override public void onSuccess(String original, String translated, String sourceName) {
                callback.onSuccess(original, translated, sourceName);
            }

            @Override public void onError(String message) {
                // Si el modelo falla, permite reintentar el mismo subtítulo en la siguiente captura.
                if (acceptedKey.equals(lastAcceptedStableKey)
                        && acceptedMode.equals(lastAcceptedStableMode)) {
                    lastAcceptedStableKey = "";
                    lastAcceptedStableMode = "";
                }
                callback.onError(message);
            }
        });
    }

    /**
     * Confirma el OCR por consenso: al menos dos de las últimas tres lecturas deben
     * representar el mismo subtítulo. Nunca fuerza una frase inestable por tiempo;
     * mientras no exista consenso, LIVE conserva la traducción anterior.
     */
    private String selectStableText(String text, String sourceLanguage) {
        String cleaned = normalizeBeforeTranslate(text, sourceLanguage);
        String normalized = normalizeKeyForLanguage(cleaned, sourceLanguage);
        if (normalized.isEmpty()) return null;

        String mode = sourceLanguage == null ? "" : sourceLanguage;
        long now = System.currentTimeMillis();
        consecutiveEmptyFrames = 0;

        if (mode.equals(lastAcceptedStableMode)
                && isSameAcceptedSubtitle(lastAcceptedStableKey, normalized)) {
            recentStableReadings.clear();
            stableWindowMode = mode;
            return null;
        }

        if (!mode.equals(stableWindowMode)) {
            recentStableReadings.clear();
            stableWindowMode = mode;
        }

        for (int i = recentStableReadings.size() - 1; i >= 0; i--) {
            if (now - recentStableReadings.get(i).timestamp > STABILITY_WINDOW_MS) {
                recentStableReadings.remove(i);
            }
        }

        recentStableReadings.add(new StableReading(cleaned, normalized, mode, now));
        while (recentStableReadings.size() > STABILITY_WINDOW_SIZE) {
            recentStableReadings.remove(0);
        }

        StableReading best = null;
        int bestMatches = 0;
        for (StableReading candidate : recentStableReadings) {
            int matches = 0;
            for (StableReading other : recentStableReadings) {
                if (areConsensusSimilar(candidate.key, other.key)) matches++;
            }
            if (matches > bestMatches
                    || (matches == bestMatches && isBetterStableReading(candidate, best))) {
                bestMatches = matches;
                best = candidate;
            }
        }

        if (best == null || bestMatches < 2) return null;

        long oldestMatchAt = now;
        StableReading bestReading = null;
        for (StableReading sample : recentStableReadings) {
            if (!areConsensusSimilar(best.key, sample.key)) continue;
            oldestMatchAt = Math.min(oldestMatchAt, sample.timestamp);
            if (isBetterStableReading(sample, bestReading)) bestReading = sample;
        }

        if (now - oldestMatchAt < stabilityMinConfirmMs(mode) || bestReading == null) return null;

        lastAcceptedStableKey = bestReading.key;
        lastAcceptedStableMode = mode;
        recentStableReadings.clear();
        stableWindowMode = mode;
        return bestReading.text;
    }

    private boolean isBetterStableReading(StableReading candidate, StableReading currentBest) {
        if (candidate == null) return false;
        if (currentBest == null) return true;
        int candidateScore = stableReadingScore(candidate.text, candidate.mode);
        int currentScore = stableReadingScore(currentBest.text, currentBest.mode);
        if (candidateScore != currentScore) return candidateScore > currentScore;
        return candidate.timestamp > currentBest.timestamp;
    }

    private int stableReadingScore(String text, String mode) {
        if (text == null) return Integer.MIN_VALUE;
        String clean = text.trim();
        int score = clean.length();
        if (MODE_ENGLISH.equals(mode)) {
            int words = clean.isEmpty() ? 0 : clean.split("\\s+").length;
            int vocabularyWords = countVocabularyWords(clean);
            score += Math.min(words, 16) * 6;
            score += Math.min(vocabularyWords, 16) * 7;
            score -= Math.max(0, words - vocabularyWords - 2) * 3;
            if (clean.matches(".*[.!?…][\"']?$")) score += 12;
            if (clean.matches(".*\\b(I|you|he|she|we|they|it)\\b.*")) score += 5;
            score -= countSuspiciousCharacters(clean) * 15;
            return score;
        }
        int han = countMatches(chinesePattern, clean);
        int kana = countMatches(japanesePattern, clean);
        if (MODE_CHINESE.equals(mode)) {
            score += han * 9 - kana * 12;
        } else if (MODE_JAPANESE.equals(mode)) {
            score += kana * 10 + han * 5;
        }
        if (clean.matches(".*[。！？!?…」』]$")) score += 10;
        score -= countSuspiciousCharactersForMode(clean) * 8;
        return score;
    }

    private long stabilityMinConfirmMs(String mode) {
        if (MODE_CHINESE.equals(mode)) return STABILITY_MIN_CONFIRM_CHINESE_MS;
        if (MODE_JAPANESE.equals(mode)) return STABILITY_MIN_CONFIRM_JAPANESE_MS;
        return STABILITY_MIN_CONFIRM_ENGLISH_MS;
    }

    private int countSuspiciousCharacters(String text) {
        if (text == null) return 0;
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c)
                    || "'.,?!:;-–—…".indexOf(c) >= 0) continue;
            count++;
        }
        return count;
    }

    private int countSuspiciousCharactersForMode(String text) {
        if (text == null) return 0;
        int count = 0;
        String allowed = "'.,?!:;-–—…，。！？：；、・〜～「」『』（）【】《》〈〉…·";
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c) || allowed.indexOf(c) >= 0) continue;
            count++;
        }
        return count;
    }

    private boolean areConsensusSimilar(String a, String b) {
        // Las palabras cortas requieren coincidencia exacta. Esto evita confirmar
        // por error pares con significado distinto como "No"/"Go" o "can"/"can't".
        return SubtitleTextGuard.areEquivalent(a, b);
    }

    private boolean isSameAcceptedSubtitle(String accepted, String current) {
        return SubtitleTextGuard.areEquivalent(accepted, current);
    }

    private void translate(String text, String sourceLanguage, Callback callback) {
        String src = sourceLanguage;
        if (MODE_AUTO.equals(src)) src = guessFromCharacters(text);
        if (src == null) src = TranslateLanguage.ENGLISH;

        String cleanForTranslate = normalizeBeforeTranslate(text, src);
        String glossaryMatch = exactGlossaryTranslation(cleanForTranslate, src);
        if (glossaryMatch != null) {
            callback.onSuccess(cleanForTranslate, glossaryMatch, readable(src));
            return;
        }
        String fastTranslation = FastSubtitleTranslator.translate(cleanForTranslate, src);
        if (fastTranslation != null && !fastTranslation.trim().isEmpty()) {
            callback.onSuccess(cleanForTranslate, fastTranslation, readable(src));
            return;
        }
        // LIVE traduce cada subtítulo de forma independiente. No se mezcla con líneas anteriores.
        String glossaryState = preferences.getString(KEY_CUSTOM_GLOSSARY, "");
        String cacheKey = src + "|g" + (glossaryState == null ? 0 : glossaryState.hashCode())
                + "|" + normalizeKeyForLanguage(cleanForTranslate, src);
        if (translationCache.containsKey(cacheKey)) {
            String cached = translationCache.get(cacheKey);
            callback.onSuccess(cleanForTranslate, cached, readable(src));
            return;
        }

        if (TranslateLanguage.SPANISH.equals(src)) {
            callback.onSuccess(cleanForTranslate, cleanForTranslate, "Español");
            return;
        }

        translateWithMlKit(cleanForTranslate, src, cacheKey, callback);
    }

    private void translateWithMlKit(String input, String sourceLanguage,
                                    String cacheKey, Callback callback) {
        if (!isModelReady(sourceLanguage)) {
            callback.onError("Descarga " + readable(sourceLanguage) + " → Español antes de traducir.");
            return;
        }

        String storedGlossary = preferences.getString(KEY_CUSTOM_GLOSSARY, "");
        GlossaryProtector.Result protectedInput = GlossaryProtector.protect(
                input, storedGlossary, TranslateLanguage.ENGLISH.equals(sourceLanguage));
        Translator translator = getTranslator(sourceLanguage);
        translateDirect(translator, input, protectedInput, sourceLanguage, cacheKey, callback);
    }

    private void translateDirect(Translator translator, String originalInput,
                                 GlossaryProtector.Result protectedInput,
                                 String sourceLanguage, String cacheKey, Callback callback) {
        if (closed) {
            callback.onError("El traductor ya fue cerrado.");
            return;
        }
        try {
            translator.translate(protectedInput.protectedText)
                    .addOnSuccessListener(translated -> {
                        if (closed) callback.onError("El traductor ya fue cerrado.");
                        else finishTranslation(originalInput, protectedInput, sourceLanguage,
                                cacheKey, translated, callback);
                    })
                    .addOnFailureListener(e -> handleTranslationFailure(e, sourceLanguage, callback));
        } catch (OutOfMemoryError memoryError) {
            callback.onError("Memoria insuficiente para traducir desde " + readable(sourceLanguage) + ".");
        } catch (RuntimeException runtimeError) {
            callback.onError("Error al traducir: " + safeMessage(runtimeError));
        }
    }

    private void handleTranslationFailure(Exception error, String sourceLanguage, Callback callback) {
        if (error instanceof MlKitException
                && ((MlKitException) error).getErrorCode() == MlKitException.NOT_FOUND) {
            preferences.edit().putBoolean(MainActivity.KEY_MODEL_PREFIX + sourceLanguage, false).apply();
            callback.onError("Falta el modelo real de " + readable(sourceLanguage)
                    + ". Vuelve a la app y descárgalo otra vez.");
            return;
        }
        callback.onError("Error al traducir: " + safeMessage(error));
    }

    private void finishTranslation(String input, GlossaryProtector.Result protectedInput,
                                   String sourceLanguage, String cacheKey,
                                   String translated, Callback callback) {
        String restored = protectedInput == null ? translated : protectedInput.restore(translated);
        String polished = SpanishOutputPolisher.polish(restored, input);
        if (isSuspiciousResult(input, polished, sourceLanguage)
                && TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String fallback = FastSubtitleTranslator.translate(input, sourceLanguage);
            if (fallback != null && fallback.trim().length() > 0) polished = fallback;
        }
        // No mostramos el original ni una mezcla evidente como si fuera una traducción terminada.
        // En modo Vivo el cuadro conserva la última traducción fiable hasta la siguiente lectura válida.
        if (isSuspiciousResult(input, polished, sourceLanguage)) {
            callback.onError("No se obtuvo una traducción suficientemente confiable.");
            return;
        }
        if (cacheKey != null) translationCache.put(cacheKey, polished);
        callback.onSuccess(input, polished, readable(sourceLanguage));
    }

    private boolean isSuspiciousResult(String original, String translated, String sourceLanguage) {
        if (translated == null || translated.trim().isEmpty()) return true;
        if (looksUntranslated(original, translated)) return true;
        if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)) {
            return TranslationQualityGuard.hasTooMuchCjkForSpanish(translated);
        }
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            int strongEnglish = countStrongEnglishWords(translated);
            int spanishSignals = countSpanishSignals(translated);
            return strongEnglish >= 2 && spanishSignals == 0;
        }
        return false;
    }

    private int countStrongEnglishWords(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "the","this","that","these","those","you","your","yours","he","she","they",
                "we","our","where","when","why","what","who","how","with","from","have","has",
                "had","will","would","could","should","were","was","are","does","did","doing",
                "think","know","want","need","good","right","please","sorry","home"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }

    private int countSpanishSignals(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "el","la","los","las","un","una","que","de","del","en","por","para","con",
                "como","qué","dónde","cuando","porque","estoy","está","son","eres","tengo","tiene",
                "quiero","puedo","casa","bien","gracias","pero","muy","ya","aquí","allí"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }


    private synchronized Translator getTranslator(String sourceLanguage) {
        if (closed) throw new IllegalStateException("Traductor cerrado");
        Translator existing = translators.get(sourceLanguage);
        if (existing != null) return existing;
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguage)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        Translator created = Translation.getClient(options);
        translators.put(sourceLanguage, created);
        return created;
    }

    private String normalizeBeforeTranslate(String text, String sourceLanguage) {
        if (text == null) return "";
        String t = joinOcrLines(text, sourceLanguage);
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            t = repairEnglishOcr(t);
            t = normalizeExpressiveEnglish(t);
        } else if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)) {
            t = sanitizeAsianDelimitersAndCues(t, sourceLanguage);
            t = normalizeAsianOcrText(t, sourceLanguage);
            t = normalizeAsianColloquialisms(t, sourceLanguage);
        }
        return t;
    }

    private String joinOcrLines(String text, String sourceLanguage) {
        if (text == null) return "";
        String[] lines = text.replace("\r", "").split("\n");
        StringBuilder out = new StringBuilder();
        Set<String> seen = new HashSet<>();
        boolean compactCjk = TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage);
        for (String line : lines) {
            String s = line == null ? "" : line.trim();
            if (s.length() == 0) continue;
            String key = normalizeKeyForLanguage(s, sourceLanguage);
            if (key.length() > 0 && !seen.add(key)) continue;
            if (out.length() > 0 && !compactCjk) out.append(' ');
            out.append(s);
        }
        String joined = out.toString().replaceAll("[\t ]+", " ").trim();
        if (compactCjk) joined = joined.replaceAll("\\s+", "");
        return joined;
    }

    private String repairEnglishOcr(String text) {
        if (text == null) return "";
        String t = sanitizeSubtitleDelimitersAndCues(text.trim());
        t = stripCjkFromEnglish(t);
        t = t.replaceAll("(?<=[a-z])(?=[A-Z])", " ");
        t = t.replace('’', '\'');

        // Solo se conservan correcciones de confusiones OCR muy seguras. Las sustituciones
        // gramaticales agresivas se eliminaron porque podían cambiar palabras correctas.
        t = t.replaceAll("(?i)\\bschoo1\\b", "school");
        t = t.replaceAll("(?i)\\bmornlng\\b", "morning");
        t = t.replaceAll("(?i)\\bfinisbed\\b", "finished");
        t = t.replaceAll("(?i)\\bleam\\b", "learn");
        t = t.replaceAll("(?i)\\btomorow\\b", "tomorrow");
        t = t.replaceAll("(?i)\\bexacty\\b", "exactly");

        // Reparaciones de inicio muy limitadas y de alta confianza observadas en subtítulos.
        t = t.replaceFirst("(?i)^[tl|]?decause\\b", "Because");
        t = t.replaceFirst("(?i)^[tl|]?because\\b", "Because");
        t = t.replaceFirst("(?i)^f?it['’]?s\\s+evening\\b", "It's evening");
        t = t.replaceFirst(
                "(?i)^[i1|]?so\\s+[l1|i]\\s+(?=(continued|walked|went|was|am|have|had|can|could|would|should|did|do|saw|heard|thought|knew|kept|started|decided|just)\\b)",
                "So I ");

        t = t.replaceAll("[.]{2,}", " ");
        t = t.replaceAll("[^A-Za-z0-9'.,?!:;\\- ]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    /**
     * Quita únicamente los delimitadores visuales del subtítulo. Si el contenido entre
     * corchetes o paréntesis es una indicación sonora breve, se elimina completo; si es
     * una frase normal, conserva el contenido y solo retira los signos.
     */
    private String sanitizeSubtitleDelimitersAndCues(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String t = text.replace('［', '[').replace('］', ']')
                .replace('（', '(').replace('）', ')')
                .replace('｛', '{').replace('｝', '}');
        t = replaceBracketSegments(t, Pattern.compile("\\[([^\\[\\]]{1,80})\\]"));
        t = replaceBracketSegments(t, Pattern.compile("\\(([^()]{1,80})\\)"));
        t = replaceBracketSegments(t, Pattern.compile("\\{([^{}]{1,80})\\}"));
        // Elimina signos sueltos restantes, sin borrar las palabras que contenían.
        t = t.replaceAll("[\\[\\](){}]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String replaceBracketSegments(String text, Pattern pattern) {
        Matcher matcher = pattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
            String replacement = isSubtitleStageCue(inner) ? " " : " " + inner + " ";
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private boolean isSubtitleStageCue(String text) {
        if (text == null) return false;
        String cue = text.toLowerCase(Locale.ROOT)
                .replace('’', '\'')
                .replaceAll("[^a-z' ]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
        if (cue.isEmpty()) return true;
        int words = cue.split(" ").length;
        if (words > 5) return false;
        if (cue.matches("(soft |dramatic |background |upbeat |sad |tense )?music( playing| continues| fades)?")) return true;
        if (cue.matches("applause|laughter|laughs?|laughing|sighs?|sighing|gasps?|gasping|groans?|groaning|whispers?|whispering|screams?|screaming|cries|crying|sobs?|sobbing|chuckles?|chuckling|breathing|panting|footsteps|silence|inaudible")) return true;
        return cue.matches("(door|phone|bell|alarm|thunder|rain|wind|knock|knocking|gunshot|explosion)( opens?| closes?| rings?| sounds?| continues?| fades?| stops?)?");
    }

    private String normalizeAsianOcrText(String text, String mode) {
        if (text == null) return "";
        String t = text.replace('　', ' ').trim();
        t = t.replaceAll("^[—―ー-\\s]+", "");
        t = t.replaceAll("[·•･ㆍ]+", " ");
        t = t.replaceAll("([。！？!?，,、…])\\1+", "$1");
        t = t.replaceAll("\\s+", "");

        // Conserva letras y números: pueden pertenecer al diálogo (AI技术, 3号, VIP会员).
        return t.trim();
    }

    private String sanitizeAsianDelimitersAndCues(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return "";
        String t = text.replace('［', '[').replace('］', ']')
                .replace('（', '(').replace('）', ')')
                .replace('｛', '{').replace('｝', '}');
        t = replaceAsianBracketSegments(t, Pattern.compile("\\[([^\\[\\]]{1,80})\\]"), mode);
        t = replaceAsianBracketSegments(t, Pattern.compile("\\(([^()]{1,80})\\)"), mode);
        t = replaceAsianBracketSegments(t, Pattern.compile("\\{([^{}]{1,80})\\}"), mode);
        t = t.replaceAll("[\\[\\](){}]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String replaceAsianBracketSegments(String text, Pattern pattern, String mode) {
        Matcher matcher = pattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String inner = matcher.group(1) == null ? "" : matcher.group(1).trim();
            String replacement = isAsianStageCue(inner, mode) ? " " : " " + inner + " ";
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private boolean isAsianStageCue(String text, String mode) {
        if (text == null) return false;
        String cue = text.replaceAll("\\s+", "").trim();
        if (cue.isEmpty()) return true;
        if (MODE_JAPANESE.equals(mode)) {
            return cue.matches("音楽|笑い|笑い声|拍手|ため息|泣き声|足音|雨音|風の音|雷|悲鳴|息切れ|聞き取れない");
        }
        if (MODE_CHINESE.equals(mode)) {
            return cue.matches("音乐|笑|笑声|掌声|叹气|哭声|脚步声|雨声|风声|雷声|尖叫|喘息|听不清");
        }
        return false;
    }

    private String normalizeAsianColloquialisms(String text, String mode) {
        // No sustituimos jerga polisémica antes de traducir. Términos como やばい,
        // 牛逼 o 卧槽 cambian según el contexto y una sustitución fija puede invertir el tono.
        return text == null ? "" : text.trim();
    }

    private String normalizeExpressiveEnglish(String text) {
        if (text == null || text.length() == 0) return "";
        Matcher matcher = expressiveWordPattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String original = matcher.group();
            String replacement = normalizeExpressiveWord(original);
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private String normalizeExpressiveWord(String word) {
        if (word == null || word.length() < 3 || !hasRunOfThree(word)) return word;
        String lower = word.toLowerCase(Locale.ROOT);
        String maxTwo = collapseRuns(lower, 2);
        String selected = EXPRESSIVE_DICTIONARY.contains(maxTwo) ? maxTwo : findDictionaryVariant(maxTwo, 0, new StringBuilder());
        if (selected == null) selected = maxTwo;
        if (word.equals(word.toUpperCase(Locale.ROOT))) return selected.toUpperCase(Locale.ROOT);
        if (Character.isUpperCase(word.charAt(0))) {
            return Character.toUpperCase(selected.charAt(0)) + selected.substring(1);
        }
        return selected;
    }

    private boolean hasRunOfThree(String word) {
        int run = 1;
        for (int i = 1; i < word.length(); i++) {
            if (Character.toLowerCase(word.charAt(i)) == Character.toLowerCase(word.charAt(i - 1))) {
                run++;
                if (run >= 3) return true;
            } else {
                run = 1;
            }
        }
        return false;
    }

    private String collapseRuns(String word, int maxRun) {
        StringBuilder out = new StringBuilder(word.length());
        char previous = 0;
        int run = 0;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c == previous) {
                run++;
            } else {
                previous = c;
                run = 1;
            }
            if (run <= maxRun) out.append(c);
        }
        return out.toString();
    }

    private String findDictionaryVariant(String word, int index, StringBuilder built) {
        if (index >= word.length()) {
            String candidate = built.toString();
            return EXPRESSIVE_DICTIONARY.contains(candidate) ? candidate : null;
        }
        char c = word.charAt(index);
        int end = index + 1;
        while (end < word.length() && word.charAt(end) == c) end++;
        int runLength = end - index;
        int originalLength = built.length();

        for (int i = 0; i < runLength; i++) built.append(c);
        String keep = findDictionaryVariant(word, end, built);
        if (keep != null) return keep;
        built.setLength(originalLength);

        if (runLength == 2) {
            built.append(c);
            String reduced = findDictionaryVariant(word, end, built);
            if (reduced != null) return reduced;
            built.setLength(originalLength);
        }
        return null;
    }

    private String stripCjkFromEnglish(String text) {
        if (text == null) return "";
        String t = text;
        // Quita traducciones chinas/japonesas entre paréntesis para no contaminar el inglés.
        t = t.replaceAll("\\([^)]*[\\u3400-\\u9FFF\\u3040-\\u30FF][^)]*\\)", " ");
        t = t.replaceAll("[\\u3400-\\u9FFF\\u3040-\\u30FF]+", " ");
        return t;
    }

    private String cleanEnglishLine(String line) {
        if (line == null) return "";
        String s = normalizeExpressiveEnglish(repairEnglishOcr(line));
        s = s.replaceAll("^[^A-Za-z0-9]+", "");
        s = s.replaceAll("[^A-Za-z0-9.?!']+$", "");
        s = s.replaceAll("\\s+", " ").trim();
        return trimEnglishOcrNoise(s);
    }

    /**
     * Recorta basura corta que el OCR latino inventa al intentar leer caracteres chinos.
     * Es una operacion local y rapida: no espera otra captura ni consulta otro modelo.
     */
    private String trimEnglishOcrNoise(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String[] tokens = text.trim().split("\\s+");
        int start = 0;
        int end = tokens.length;
        while (start < end && isSuspiciousOcrToken(tokens[start])) start++;
        while (end > start && isSuspiciousOcrToken(tokens[end - 1])) end--;
        if (start >= end) return "";

        StringBuilder out = new StringBuilder();
        int badRun = 0;
        int goodCount = 0;
        for (int i = start; i < end; i++) {
            String token = tokens[i];
            boolean bad = isSuspiciousOcrToken(token);
            if (bad) {
                badRun++;
                if (goodCount >= 2 && badRun >= 2) break;
            } else {
                badRun = 0;
                goodCount++;
            }
            if (out.length() > 0) out.append(' ');
            out.append(token);
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    private boolean isSuspiciousOcrToken(String token) {
        if (token == null) return true;
        String raw = token.replaceAll("^[^A-Za-z0-9']+|[^A-Za-z0-9']+$", "");
        if (raw.isEmpty()) return true;
        if (raw.matches("\\d{1,6}([:./-]\\d{1,6})?")) return false;
        String lower = raw.toLowerCase(Locale.ROOT).replace("'", "");
        if (lower.equals("a") || lower.equals("i")) return false;
        if (isVocabularyWord(lower)) return false;
        String contractions = " im ive ill id youre hes shes theyre were dont didnt doesnt cant wont isnt arent wasnt werent thats whats wheres whos lets ";
        if (contractions.contains(" " + lower + " ")) return false;
        if (raw.matches("[A-Za-z]+\\d+[A-Za-z0-9]*") || raw.matches("\\d+[A-Za-z]+[A-Za-z0-9]*")) {
            return raw.length() <= 1;
        }
        if (lower.length() <= 2) return true;
        if (lower.length() >= 4 && !lower.matches(".*[aeiouy].*")) return true;
        return raw.equals(raw.toUpperCase(Locale.ROOT)) && raw.length() <= 3;
    }

    private boolean isGoodEnglishLine(String s) {
        if (s == null) return false;
        String key = normalizeKey(s);
        if (key.isEmpty()) return false;
        int words = countEnglishWords(s);
        int vocabulary = countVocabularyWords(s);
        boolean sentenceMark = s.matches(".*[?!. ,'].*");
        if (words == 1 && vocabulary == 1) return true;
        if (words >= 6 && (vocabulary > 0 || sentenceMark)) return true;
        if (words >= 2 && vocabulary > 0) return true;
        return key.equals("at home") || key.equals("thank you");
    }

    private int scoreEnglishLine(String s) {
        if (s == null) return -9999;
        int words = countEnglishWords(s);
        int vocabulary = countVocabularyWords(s);
        int score = Math.min(s.length(), 120) + words * 14 + vocabulary * 28;
        if (s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",")) score += 14;
        if (words == 1 && vocabulary == 1) score += 42;
        if (words <= 2 && vocabulary == 0) score -= 80;
        if (isLikelySpanishLine(s)) score -= 180;
        return score;
    }

    private boolean isBadEnglishFalsePositive(String s) {
        if (s == null) return true;
        String key = normalizeKey(s);
        if (key.isEmpty()) return true;
        int words = countEnglishWords(s);
        int vocabulary = countVocabularyWords(s);
        if (words == 1 && vocabulary == 1) return false;
        boolean hasSentenceMark = s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",") || s.contains("'");
        boolean looksLikeTitle = words <= 3 && vocabulary == 0 && !s.matches(".*[a-z].*[a-z].*");
        boolean tooShortWithoutContext = words <= 2 && vocabulary == 0;
        return looksLikeTitle || (tooShortWithoutContext && !hasSentenceMark);
    }

    private int commonEnglishWordScore(String s) {
        return countVocabularyWords(s);
    }

    private int countVocabularyWords(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        Matcher matcher = Pattern.compile("[A-Za-z']+").matcher(text.toLowerCase(Locale.ROOT));
        int count = 0;
        while (matcher.find()) {
            String word = matcher.group().replace("'", "");
            if (isVocabularyWord(word)) count++;
        }
        return count;
    }

    private boolean isVocabularyWord(String word) {
        if (word == null || word.isEmpty()) return false;
        if (word.equals("i") || word.equals("a")) return true;
        if (word.length() < 2) return false;
        if (englishVocabulary.contains(word)) return true;
        if (word.endsWith("s") && word.length() > 3 && englishVocabulary.contains(word.substring(0, word.length() - 1))) return true;
        if (word.endsWith("ed") && word.length() > 4) {
            String root = word.substring(0, word.length() - 2);
            if (englishVocabulary.contains(root) || englishVocabulary.contains(root + "e")) return true;
        }
        if (word.endsWith("ing") && word.length() > 5) {
            String root = word.substring(0, word.length() - 3);
            if (englishVocabulary.contains(root) || englishVocabulary.contains(root + "e")) return true;
        }
        return false;
    }

    private void loadEnglishVocabulary() {
        englishVocabulary.addAll(EXPRESSIVE_DICTIONARY);
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                appContext.getAssets().open("english_ocr_vocabulary.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String word = line.trim().toLowerCase(Locale.ROOT);
                if (!word.isEmpty()) englishVocabulary.add(word);
            }
        } catch (Exception ignored) {
            // La app sigue funcionando con el vocabulario básico incorporado.
        }
    }

    private boolean isLikelySpanishLine(String s) {
        if (s == null) return false;
        String k = normalizeKey(s);
        return s.contains("¿") || s.contains("¡")
                || k.contains(" que ")
                || k.startsWith("que ")
                || k.contains(" donde ")
                || k.contains(" dónde ")
                || k.contains(" esta ")
                || k.contains(" está ")
                || k.contains(" ropa")
                || k.contains(" mama")
                || k.contains(" mamá")
                || k.contains(" nada")
                || k.contains(" casa")
                || k.contains(" fing");
    }

    private int countEnglishWords(String s) {
        if (s == null) return 0;
        Matcher matcher = Pattern.compile("[A-Za-z']+").matcher(s);
        int count = 0;
        while (matcher.find()) {
            String word = matcher.group().replace("'", "");
            if (!word.isEmpty()) count++;
        }
        return count;
    }

    private String cleanCjkLine(String line, String mode) {
        if (line == null) return "";
        String s = line.replace('　', ' ').trim();
        s = sanitizeAsianDelimitersAndCues(s, mode);
        if (MODE_CHINESE.equals(mode)) {
            s = s.replaceAll("[\u3040-\u30FF]+", " ");
        }
        s = s.replaceAll("\\s+", " ").trim();
        return hasEnoughScriptForMode(s, mode) ? s : "";
    }

    private boolean hasEnoughScriptForMode(String text, String mode) {
        if (text == null || text.trim().isEmpty()) return false;
        int han = countMatches(chinesePattern, text);
        int kana = countMatches(japanesePattern, text);
        // Una expresión de un solo carácter puede ser un subtítulo válido.
        // En Vivo se confirma entre capturas para evitar ruido aislado.
        if (MODE_CHINESE.equals(mode)) return han >= 1;
        if (MODE_JAPANESE.equals(mode)) return kana >= 1 || han >= 1;
        return false;
    }

    private boolean looksUntranslated(String original, String translated) {
        if (original == null || translated == null) return false;
        String a = normalizeKey(original);
        String b = normalizeKey(translated);
        if (a.length() == 0 || b.length() == 0) return false;
        return a.equals(b) || (b.contains(a) && b.length() <= a.length() + 4);
    }

    private String exactGlossaryTranslation(String sourceText, String sourceLanguage) {
        String stored = preferences.getString(KEY_CUSTOM_GLOSSARY, "");
        if (stored == null || stored.trim().isEmpty()) return null;
        String sourceKey = normalizeKeyForLanguage(sourceText, sourceLanguage);
        for (String line : stored.replace("\r", "").split("\n")) {
            String entry = line.trim();
            if (entry.isEmpty() || entry.startsWith("#")) continue;
            int split = entry.indexOf("=>");
            if (split < 0) split = entry.indexOf('=');
            if (split <= 0) continue;
            String source = entry.substring(0, split).trim();
            String target = entry.substring(split + (entry.startsWith("=>", split) ? 2 : 1)).trim();
            if (!target.isEmpty()
                    && normalizeKeyForLanguage(source, sourceLanguage).equals(sourceKey)) return target;
        }
        return null;
    }

    private String normalizeKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9áéíóúñü]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String normalizeKeyForLanguage(String text, String mode) {
        if (text == null) return "";
        if (MODE_ENGLISH.equals(mode) || TranslateLanguage.SPANISH.equals(mode) || mode == null) {
            return normalizeKey(text);
        }
        return text.toLowerCase(Locale.ROOT)
                .replace('　', ' ')
                .replaceAll("[\\[\\](){}［］（）｛｝]", " ")
                .replaceAll("[^\\p{L}\\p{N}]+", "")
                .trim();
    }

    private String cleanOcrResult(Text result, String mode, int imageWidth, int imageHeight) {
        if (result == null) return "";
        if (MODE_ENGLISH.equals(mode)) {
            // En inglés no volvemos al bloque completo cuando el análisis por líneas rechaza el texto.
            // Ese retroceso era precisamente lo que reintroducía basura china, marcas de agua y tokens rotos.
            return cleanEnglishFromLayout(result, imageWidth, imageHeight);
        }
        if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode)) {
            return cleanAsianFromLayout(result, mode, imageWidth, imageHeight);
        }
        return cleanText(result.getText(), mode);
    }

    private static class AsianLineCandidate {
        final String text;
        final Rect box;
        final int score;

        AsianLineCandidate(String text, Rect box, int score) {
            this.text = text;
            this.box = box;
            this.score = score;
        }
    }

    private String cleanAsianFromLayout(Text result, String mode, int imageWidth, int imageHeight) {
        List<AsianLineCandidate> candidates = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String raw = line.getText();
                if (raw == null || raw.trim().isEmpty()) continue;
                String lower = raw.toLowerCase(Locale.ROOT);
                if (isWatermarkOrUi(raw, lower)) continue;
                String cleaned = cleanCjkLine(raw, mode);
                if (cleaned.isEmpty()) continue;
                int score = scoreAsianLine(cleaned, mode);
                Rect box = line.getBoundingBox();
                if (box == null) box = new Rect(0, 0, imageWidth, Math.max(1, imageHeight));
                float widthRatio = imageWidth > 0 ? box.width() / (float) imageWidth : 0f;
                float centerY = imageHeight > 0 ? box.centerY() / (float) imageHeight : 0.5f;
                if (widthRatio >= 0.35f) score += 30;
                else if (widthRatio >= 0.18f) score += 14;
                if (centerY >= 0.30f) score += 8;
                candidates.add(new AsianLineCandidate(cleaned, box, score));
            }
        }
        if (candidates.isEmpty()) return "";
        candidates.sort((a, b) -> {
            int top = Integer.compare(a.box.top, b.box.top);
            return top != 0 ? top : Integer.compare(a.box.left, b.box.left);
        });

        int bestStart = -1;
        int bestEnd = -1;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            int groupScore = 0;
            for (int j = i; j < candidates.size() && j < i + 3; j++) {
                if (j > i && !asianLinesBelongTogether(candidates.get(j - 1), candidates.get(j), imageWidth)) break;
                groupScore += candidates.get(j).score;
                if (j > i) groupScore += j == i + 1 ? 28 : 18;
                if (groupScore > bestScore) {
                    bestScore = groupScore;
                    bestStart = i;
                    bestEnd = j;
                }
            }
        }
        if (bestStart < 0) return "";
        StringBuilder combinedBuilder = new StringBuilder();
        for (int i = bestStart; i <= bestEnd; i++) combinedBuilder.append(candidates.get(i).text);
        String combined = sanitizeAsianDelimitersAndCues(combinedBuilder.toString(), mode);
        return hasEnoughScriptForMode(combined, mode) ? combined.trim() : "";
    }

    private int scoreAsianLine(String text, String mode) {
        int han = countMatches(chinesePattern, text);
        int kana = countMatches(japanesePattern, text);
        int score = Math.min(120, text.length() * 2);
        if (MODE_CHINESE.equals(mode)) score += han * 10 - kana * 14;
        else if (MODE_JAPANESE.equals(mode)) score += kana * 11 + han * 6;
        if (text.matches(".*[。！？!?…」』]$")) score += 10;
        return score;
    }

    private boolean asianLinesBelongTogether(AsianLineCandidate a, AsianLineCandidate b, int imageWidth) {
        if (a == null || b == null) return false;
        int heightA = Math.max(1, a.box.height());
        int heightB = Math.max(1, b.box.height());
        float heightRatio = Math.max(heightA, heightB) / (float) Math.min(heightA, heightB);
        if (heightRatio > 1.8f) return false;
        int gap = b.box.top - a.box.bottom;
        int maxHeight = Math.max(heightA, heightB);
        if (gap < -maxHeight / 3 || gap > Math.round(maxHeight * 1.5f)) return false;
        int overlap = Math.max(0, Math.min(a.box.right, b.box.right) - Math.max(a.box.left, b.box.left));
        int minWidth = Math.max(1, Math.min(a.box.width(), b.box.width()));
        float overlapRatio = overlap / (float) minWidth;
        int centerDistance = Math.abs(a.box.centerX() - b.box.centerX());
        return overlapRatio >= 0.28f || centerDistance <= Math.max(48, imageWidth / 8);
    }

    private static class EnglishLineCandidate {
        final String text;
        final Rect box;
        final int score;

        EnglishLineCandidate(String text, Rect box, int score) {
            this.text = text;
            this.box = box;
            this.score = score;
        }
    }

    /**
     * Selecciona el subtítulo inglés usando texto y posición. Esto evita mezclar la línea china,
     * marcas de agua y fragmentos aislados que antes terminaban dentro de la traducción.
     */
    private String cleanEnglishFromLayout(Text result, int imageWidth, int imageHeight) {
        List<EnglishLineCandidate> candidates = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String raw = line.getText();
                if (raw == null || raw.trim().isEmpty()) continue;
                String lower = raw.toLowerCase(Locale.ROOT);
                if (isWatermarkOrUi(raw, lower)) continue;

                int originalLatin = countMatches(latinPattern, raw);
                int originalCjk = countMatches(cjkPattern, raw);
                String cleaned = cleanEnglishLine(raw);
                if (cleaned.isEmpty() || isLikelySpanishLine(cleaned) || isBadEnglishFalsePositive(cleaned)) continue;

                int words = countEnglishWords(cleaned);
                int vocabularyWords = countVocabularyWords(cleaned);
                if (words < 1 || vocabularyWords == 0 && words < 2) continue;
                if (originalLatin < 1) continue;
                if (originalCjk > originalLatin * 2 && words < 4) continue;

                Rect box = line.getBoundingBox();
                if (box == null) box = new Rect(0, 0, imageWidth, Math.max(1, imageHeight));
                int score = scoreEnglishLine(cleaned);
                float widthRatio = imageWidth > 0 ? box.width() / (float) imageWidth : 0f;
                float centerY = imageHeight > 0 ? box.centerY() / (float) imageHeight : 0.5f;
                if (widthRatio >= 0.35f) score += 32;
                else if (widthRatio >= 0.18f) score += 14;
                if (centerY >= 0.35f) score += 10;
                score += Math.min(36, vocabularyWords * 7);
                if (originalCjk > 0) score -= Math.min(20, originalCjk / 2);
                candidates.add(new EnglishLineCandidate(cleaned, box, score));
            }
        }

        if (candidates.isEmpty()) return "";
        candidates.sort((a, b) -> {
            int top = Integer.compare(a.box.top, b.box.top);
            return top != 0 ? top : Integer.compare(a.box.left, b.box.left);
        });

        int bestStart = -1;
        int bestEnd = -1;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            int groupScore = 0;
            for (int j = i; j < candidates.size() && j < i + 3; j++) {
                if (j > i && !linesBelongTogether(candidates.get(j - 1), candidates.get(j), imageWidth, imageHeight)) break;
                groupScore += candidates.get(j).score;
                if (j > i) groupScore += j == i + 1 ? 34 : 20;
                if (groupScore > bestScore) {
                    bestScore = groupScore;
                    bestStart = i;
                    bestEnd = j;
                }
            }
        }

        if (bestStart < 0 || bestScore < 35) return "";
        StringBuilder combinedBuilder = new StringBuilder();
        for (int i = bestStart; i <= bestEnd; i++) {
            if (combinedBuilder.length() > 0) combinedBuilder.append(' ');
            combinedBuilder.append(candidates.get(i).text);
        }
        String combined = trimEnglishOcrNoise(combinedBuilder.toString().replaceAll("\\s+", " ").trim());
        return isGoodEnglishLine(combined) ? combined : "";
    }

    private boolean linesBelongTogether(EnglishLineCandidate a, EnglishLineCandidate b,
                                        int imageWidth, int imageHeight) {
        if (a == null || b == null) return false;
        int heightA = Math.max(1, a.box.height());
        int heightB = Math.max(1, b.box.height());
        float heightRatio = Math.max(heightA, heightB) / (float) Math.min(heightA, heightB);
        if (heightRatio > 1.8f) return false;
        int gap = b.box.top - a.box.bottom;
        int maxHeight = Math.max(heightA, heightB);
        if (gap < -maxHeight / 3 || gap > Math.round(maxHeight * 1.5f)) return false;

        int overlap = Math.max(0, Math.min(a.box.right, b.box.right) - Math.max(a.box.left, b.box.left));
        int minWidth = Math.max(1, Math.min(a.box.width(), b.box.width()));
        float overlapRatio = overlap / (float) minWidth;
        int centerDistance = Math.abs(a.box.centerX() - b.box.centerX());
        boolean horizontallyRelated = overlapRatio >= 0.28f
                || centerDistance <= Math.max(48, imageWidth / 8);
        if (!horizontallyRelated) return false;

        String ka = normalizeKey(a.text);
        String kb = normalizeKey(b.text);
        if (ka.equals(kb)) return false;
        return countEnglishWords(a.text) + countEnglishWords(b.text) >= 2;
    }

    private String cleanText(String raw, String mode) {
        if (raw == null) return "";
        String[] lines = raw.replace("\r", "").split("\n");
        StringBuilder cjk = new StringBuilder();
        StringBuilder all = new StringBuilder();
        List<String> englishLines = new ArrayList<>();

        for (String line : lines) {
            String s = line.trim();
            if (s.length() == 0) continue;
            String lower = s.toLowerCase(Locale.ROOT);
            if (isWatermarkOrUi(s, lower)) continue;

            if (MODE_ENGLISH.equals(mode)) {
                String e = cleanEnglishLine(s);
                if (e.length() == 0) continue;

                // Antes se elegía solo la “mejor” línea y por eso se perdían líneas de subtítulos largos.
                // Ahora se conservan todas las líneas útiles dentro del cuadro OCR.
                if (!isLikelySpanishLine(e) && !isBadEnglishFalsePositive(e)) {
                    if (isGoodEnglishLine(e) || commonEnglishWordScore(e) > 0) {
                        englishLines.add(e);
                    }
                }
                continue;
            }

            if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode)) {
                String onlyCjk = cleanCjkLine(s, mode);
                if (cjkPattern.matcher(onlyCjk).find()) {
                    cjk.append(onlyCjk).append('\n');
                    continue;
                }
            }
            all.append(s).append('\n');
        }

        // Inglés: conserva como máximo las dos líneas más probables del subtítulo y respeta su orden.
        if (MODE_ENGLISH.equals(mode) && !englishLines.isEmpty()) {
            return selectBestEnglishLines(englishLines);
        }
        // CJK: devolver todas las líneas chinas/japonesas detectadas.
        if ((MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode)) && cjk.length() > 0) {
            return cjk.toString().trim();
        }
        return all.toString().trim();
    }

    private String selectBestEnglishLines(List<String> lines) {
        if (lines == null || lines.isEmpty()) return "";
        int bestStart = 0;
        int bestEnd = 0;
        int bestScore = scoreEnglishLine(lines.get(0));

        for (int i = 0; i < lines.size(); i++) {
            int single = scoreEnglishLine(lines.get(i));
            if (single > bestScore) {
                bestScore = single;
                bestStart = i;
                bestEnd = i;
            }
            if (i + 1 < lines.size()) {
                int pair = single + scoreEnglishLine(lines.get(i + 1)) + 18;
                if (pair > bestScore) {
                    bestScore = pair;
                    bestStart = i;
                    bestEnd = i + 1;
                }
            }
        }

        StringBuilder out = new StringBuilder();
        for (int i = bestStart; i <= bestEnd; i++) {
            if (out.length() > 0) out.append(' ');
            out.append(lines.get(i));
        }
        return trimEnglishOcrNoise(out.toString().replaceAll("\\s+", " ").trim());
    }

    private boolean isWatermarkOrUi(String s, String lower) {
        return lower.contains("video eagle")
                || lower.contains("tencent")
                || lower.contains("zeta live translator")
                || lower.contains("ocr solo")
                || lower.contains("order by")
                || lower.contains("date added")
                || lower.contains("date published")
                || lower.contains("popular:")
                || lower.contains("mother language")
                || lower.contains("spanish order")
                || lower.contains("auto") && lower.contains("español")
                || lower.contains("chino") && lower.contains("es")
                || lower.contains("inglés") && lower.contains("es")
                || lower.contains("japonés") && lower.contains("es")
                || lower.equals("área")
                || lower.equals("trad.")
                || lower.equals("vivo")
                || lower.equals("pausa")
                || lower.equals("ok")
                || s.contains("腾讯视频")
                || s.contains("出品")
                || s.contains("云曦星空")
                || s.contains("AI专属");
    }

    private String guessFromCharacters(String text) {
        if (text == null) return null;
        if (japanesePattern.matcher(text).find()) return TranslateLanguage.JAPANESE;
        if (chinesePattern.matcher(text).find()) return TranslateLanguage.CHINESE;
        if (latinPattern.matcher(text).find()) return TranslateLanguage.ENGLISH;
        return null;
    }

    public synchronized void close() {
        if (closed) return;
        closed = true;
        for (TextRecognizer recognizer : new ArrayList<>(recognizers.values())) {
            try { recognizer.close(); } catch (Exception ignored) { }
        }
        recognizers.clear();
        for (Translator translator : new ArrayList<>(translators.values())) {
            try { translator.close(); } catch (Exception ignored) { }
        }
        translators.clear();
        translationCache.clear();
        resetStabilityState();
        resetContextState();
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) return "desconocido";
        return e.getMessage();
    }

    public String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.SPANISH.equals(code)) return "Español";
        return code == null ? "Detectar" : code;
    }
}
