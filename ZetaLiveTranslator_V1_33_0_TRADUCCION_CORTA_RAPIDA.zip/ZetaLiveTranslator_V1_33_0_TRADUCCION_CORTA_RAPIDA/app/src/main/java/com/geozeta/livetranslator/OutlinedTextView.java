package com.geozeta.livetranslator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.TextView;

/** Subtitle text with a real black outline and no opaque rectangle behind it. */
public class OutlinedTextView extends TextView {
    private float outlineWidth;
    private boolean drawingOutline;
    private int fillColor = Color.WHITE;
    private int outlineColor = Color.BLACK;

    public OutlinedTextView(Context context) {
        super(context);
        init();
    }

    public OutlinedTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        outlineWidth = Math.max(3f, getResources().getDisplayMetrics().density * 2.2f);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        setTextColor(fillColor);
    }

    public void setVisualStyle(int textColor, int strokeColor, int outlineDp) {
        fillColor = textColor;
        outlineColor = strokeColor;
        outlineWidth = Math.max(2f, getResources().getDisplayMetrics().density * outlineDp);
        setTextColor(fillColor);
        invalidate();
    }

    @Override
    public void invalidate() {
        // setTextColor() invalidates the view. During the two-pass draw that would
        // otherwise schedule an unnecessary redraw on every frame.
        if (!drawingOutline) super.invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = getPaint();
        Paint.Style previousStyle = paint.getStyle();
        Paint.Join previousJoin = paint.getStrokeJoin();
        float previousStroke = paint.getStrokeWidth();
        int previousColor = getCurrentTextColor();
        drawingOutline = true;
        try {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(outlineWidth);
            paint.setStrokeJoin(Paint.Join.ROUND);
            setTextColor(outlineColor);
            super.onDraw(canvas);

            paint.setStyle(Paint.Style.FILL);
            paint.setStrokeWidth(previousStroke);
            setTextColor(fillColor);
            super.onDraw(canvas);
        } finally {
            paint.setStyle(previousStyle);
            paint.setStrokeJoin(previousJoin);
            paint.setStrokeWidth(previousStroke);
            setTextColor(previousColor);
            drawingOutline = false;
        }
    }
}
