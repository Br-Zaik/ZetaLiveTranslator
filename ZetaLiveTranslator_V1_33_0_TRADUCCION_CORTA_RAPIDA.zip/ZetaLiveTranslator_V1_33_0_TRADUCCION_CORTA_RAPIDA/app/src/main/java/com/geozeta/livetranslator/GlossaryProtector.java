package com.geozeta.livetranslator;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Protects glossary terms while an offline translation model processes the sentence. */
final class GlossaryProtector {
    private GlossaryProtector() { }

    static Result protect(String input, String storedRules, boolean caseInsensitive) {
        if (input == null) input = "";
        if (storedRules == null || storedRules.trim().isEmpty()) return new Result(input, new LinkedHashMap<>());

        List<Rule> rules = parseRules(storedRules);
        rules.sort(Comparator.comparingInt((Rule rule) -> rule.source.length()).reversed());
        String protectedText = input;
        LinkedHashMap<String, String> replacements = new LinkedHashMap<>();
        int index = 0;
        for (Rule rule : rules) {
            String token = "ZXQG" + index + "QXZ";
            String replaced = replaceLiteral(protectedText, rule.source, token, caseInsensitive);
            if (!replaced.equals(protectedText)) {
                protectedText = replaced;
                replacements.put(token, rule.target);
                index++;
            }
        }
        return new Result(protectedText, replacements);
    }

    private static List<Rule> parseRules(String storedRules) {
        List<Rule> out = new ArrayList<>();
        for (String rawLine : storedRules.replace("\r", "").split("\n")) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int split = line.indexOf("=>");
            int delimiterLength = 2;
            if (split < 0) {
                split = line.indexOf('=');
                delimiterLength = 1;
            }
            if (split <= 0) continue;
            String source = line.substring(0, split).trim();
            String target = line.substring(split + delimiterLength).trim();
            if (source.isEmpty() || target.isEmpty()) continue;
            out.add(new Rule(source, target));
        }
        return out;
    }

    private static String replaceLiteral(String input, String source, String replacement, boolean caseInsensitive) {
        int flags = caseInsensitive ? Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE : 0;
        String expression = Pattern.quote(source);
        // En inglés una regla corta no debe modificar el interior de otra palabra:
        // "Go" no puede alterar "going" y "he" no puede alterar "the".
        if (caseInsensitive && !source.isEmpty()) {
            int first = source.codePointAt(0);
            int last = source.codePointBefore(source.length());
            if (Character.isLetterOrDigit(first)) expression = "(?<![\\p{L}\\p{N}])" + expression;
            if (Character.isLetterOrDigit(last)) expression = expression + "(?![\\p{L}\\p{N}])";
        }
        Pattern pattern = Pattern.compile(expression, flags);
        return pattern.matcher(input).replaceAll(Matcher.quoteReplacement(replacement));
    }

    private static String flexibleTokenPattern(String token) {
        StringBuilder pattern = new StringBuilder("(?i)");
        for (int i = 0; i < token.length(); i++) {
            if (i > 0) pattern.append("[\\s._-]*");
            pattern.append(Pattern.quote(String.valueOf(token.charAt(i))));
        }
        return pattern.toString();
    }

    static final class Result {
        final String protectedText;
        private final LinkedHashMap<String, String> replacements;

        Result(String protectedText, LinkedHashMap<String, String> replacements) {
            this.protectedText = protectedText == null ? "" : protectedText;
            this.replacements = replacements;
        }

        boolean hasReplacements() {
            return !replacements.isEmpty();
        }

        String restore(String translated) {
            String out = translated == null ? "" : translated;
            for (Map.Entry<String, String> entry : replacements.entrySet()) {
                out = out.replaceAll(flexibleTokenPattern(entry.getKey()), Matcher.quoteReplacement(entry.getValue()));
            }
            return out.replaceAll("\\s+([,.;:!?])", "$1").replaceAll("\\s+", " ").trim();
        }

        Map<String, String> replacementsForTest() {
            return new LinkedHashMap<>(replacements);
        }
    }

    private static final class Rule {
        final String source;
        final String target;

        Rule(String source, String target) {
            this.source = source;
            this.target = target;
        }
    }
}
