package com.geozeta.livetranslator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DownloadModelService extends Service {
    public static final String ACTION_START = "com.geozeta.livetranslator.START_MODEL_DOWNLOAD";
    public static final String ACTION_STOP = "com.geozeta.livetranslator.STOP_MODEL_DOWNLOAD";
    public static final String ACTION_STATUS = "com.geozeta.livetranslator.MODEL_DOWNLOAD_STATUS";

    public static final String EXTRA_INDEX = "language_index";
    public static final String EXTRA_CODE = "language_code";
    public static final String EXTRA_NAME = "language_name";
    public static final String EXTRA_STATE = "download_state";
    public static final String EXTRA_MESSAGE = "download_message";
    public static final String EXTRA_ELAPSED = "download_elapsed";
    public static final String EXTRA_STAGE = "download_stage";
    public static final String EXTRA_STAGE_TOTAL = "download_stage_total";
    public static final String EXTRA_CONNECTION = "download_connection";

    public static final String STATE_IDLE = "idle";
    public static final String STATE_CHECKING = "checking";
    public static final String STATE_DOWNLOADING = "downloading";
    public static final String STATE_VERIFYING = "verifying";
    public static final String STATE_READY = "ready";
    public static final String STATE_ERROR = "error";
    public static final String STATE_STOPPED = "stopped";

    public static final String KEY_ACTIVE = "download_active";
    public static final String KEY_ACTIVE_INDEX = "download_active_index";
    public static final String KEY_ACTIVE_CODE = "download_active_code";
    public static final String KEY_ACTIVE_NAME = "download_active_name";
    public static final String KEY_STATE = "download_state";
    public static final String KEY_MESSAGE = "download_message";
    public static final String KEY_STARTED_AT = "download_started_at";
    public static final String KEY_STAGE = "download_stage";
    public static final String KEY_STAGE_TOTAL = "download_stage_total";
    public static final String KEY_CONNECTION = "download_connection";

    private static final String CHANNEL_ID = "zeta_model_downloads";
    private static final int NOTIFICATION_ID = 912;
    private static final long SLOW_WARNING_MS = 180_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final RemoteModelManager modelManager = RemoteModelManager.getInstance();

    private SharedPreferences prefs;
    private NotificationManager notificationManager;
    private boolean active;
    private int requestToken;
    private int languageIndex = -1;
    private String languageCode = "";
    private String languageName = "";
    private String state = STATE_IDLE;
    private String message = "";
    private String connection = "Sin conexión";
    private long startedElapsed;
    private long startedWall;
    private int stage;
    private int stageTotal;
    private int lastNotificationSecond = -1;
    private boolean pollInFlight;
    private List<String> requiredModels = new ArrayList<>();

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (!active) return;
            String previousConnection = connection;
            connection = connectionLabel();
            long elapsed = elapsedMs();
            if (("Sin conexión".equals(connection) || "Red sin internet".equals(connection))
                    && STATE_DOWNLOADING.equals(state)) {
                message = "Descarga en espera: recupera una conexión estable para continuar.";
            } else if (("Sin conexión".equals(previousConnection) || "Red sin internet".equals(previousConnection))
                    && STATE_DOWNLOADING.equals(state)) {
                message = "Conexión recuperada. ML Kit continúa la descarga.";
            }
            if (elapsed >= SLOW_WARNING_MS && STATE_DOWNLOADING.equals(state)
                    && !"Sin conexión".equals(connection) && !"Red sin internet".equals(connection)) {
                message = "La descarga sigue pendiente. Verifica espacio libre y Servicios de Google Play.";
            }
            saveState();
            sendStatus();
            int currentSecond = (int) (elapsed / 1000L);
            if (currentSecond != lastNotificationSecond && currentSecond % 5 == 0) {
                lastNotificationSecond = currentSecond;
                notificationManager.notify(NOTIFICATION_ID, buildNotification(false));
            }
            if (currentSecond > 0 && currentSecond % 10 == 0 && !pollInFlight) {
                pollInstallation(requestToken);
            }
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            if (prefs.getBoolean(KEY_ACTIVE, false)) return recoverDownload();
            return START_NOT_STICKY;
        }
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopMonitoring();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) return START_NOT_STICKY;
        if (active) {
            sendStatus();
            return START_STICKY;
        }

        languageIndex = intent.getIntExtra(EXTRA_INDEX, -1);
        languageCode = safe(intent.getStringExtra(EXTRA_CODE));
        languageName = safe(intent.getStringExtra(EXTRA_NAME));
        if (languageIndex < 0 || languageCode.isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }

        active = true;
        requestToken++;
        startedElapsed = SystemClock.elapsedRealtime();
        startedWall = System.currentTimeMillis();
        stage = 0;
        requiredModels = requiredModels(languageCode);
        stageTotal = requiredModels.size();
        connection = connectionLabel();
        state = STATE_CHECKING;
        message = "Comprobando qué componentes ya están instalados…";
        saveState();
        startForeground(NOTIFICATION_ID, buildNotification(false));
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        sendStatus();
        processStage(0, requestToken);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int recoverDownload() {
        languageIndex = prefs.getInt(KEY_ACTIVE_INDEX, -1);
        languageCode = safe(prefs.getString(KEY_ACTIVE_CODE, ""));
        languageName = safe(prefs.getString(KEY_ACTIVE_NAME, ""));
        if (languageIndex < 0 || languageCode.isEmpty()) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply();
            return START_NOT_STICKY;
        }
        active = true;
        requestToken++;
        startedWall = prefs.getLong(KEY_STARTED_AT, System.currentTimeMillis());
        long previousElapsed = Math.max(0L, System.currentTimeMillis() - startedWall);
        startedElapsed = Math.max(0L, SystemClock.elapsedRealtime() - previousElapsed);
        stage = prefs.getInt(KEY_STAGE, 0);
        requiredModels = requiredModels(languageCode);
        stageTotal = requiredModels.size();
        state = STATE_CHECKING;
        connection = connectionLabel();
        message = "Recuperando la comprobación de descarga…";
        saveState();
        startForeground(NOTIFICATION_ID, buildNotification(false));
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        sendStatus();
        processStage(0, requestToken);
        return START_STICKY;
    }

    private List<String> requiredModels(String sourceLanguage) {
        List<String> models = new ArrayList<>();
        if (sourceLanguage != null && !sourceLanguage.isEmpty()) models.add(sourceLanguage);
        if (!TranslateLanguage.SPANISH.equals(sourceLanguage)) models.add(TranslateLanguage.SPANISH);
        return models;
    }

    private void processStage(int position, int token) {
        if (!isCurrent(token)) return;
        if (position >= requiredModels.size()) {
            verifyStage(0, token);
            return;
        }

        String modelLanguage = requiredModels.get(position);
        TranslateRemoteModel remoteModel = new TranslateRemoteModel.Builder(modelLanguage).build();
        state = STATE_CHECKING;
        message = "Comprobando componente " + (position + 1) + " de " + stageTotal + ": " + readable(modelLanguage) + ".";
        saveAndPublish();

        modelManager.isModelDownloaded(remoteModel)
                .addOnSuccessListener(downloaded -> {
                    if (!isCurrent(token)) return;
                    if (Boolean.TRUE.equals(downloaded)) {
                        stage = position + 1;
                        message = readable(modelLanguage) + " ya estaba instalado.";
                        saveAndPublish();
                        processStage(position + 1, token);
                    } else {
                        downloadStage(position, remoteModel, modelLanguage, token);
                    }
                })
                .addOnFailureListener(error -> fail("No se pudo comprobar el modelo: " + cleanError(error), token));
    }

    private void downloadStage(int position, TranslateRemoteModel remoteModel, String modelLanguage, int token) {
        if (!isCurrent(token)) return;
        state = STATE_DOWNLOADING;
        message = connection.startsWith("Sin")
                ? "Esperando conexión para descargar " + readable(modelLanguage) + "."
                : "ML Kit está descargando " + readable(modelLanguage) + ".";
        saveAndPublish();

        DownloadConditions conditions = new DownloadConditions.Builder().build();
        modelManager.download(remoteModel, conditions)
                .addOnSuccessListener(unused -> {
                    if (!isCurrent(token)) return;
                    stage = position + 1;
                    state = STATE_CHECKING;
                    message = readable(modelLanguage) + " descargado. Continuando…";
                    saveAndPublish();
                    processStage(position + 1, token);
                })
                .addOnFailureListener(error -> fail("Falló " + readable(modelLanguage) + ": " + cleanError(error), token));
    }

    private void pollInstallation(int token) {
        if (!isCurrent(token) || requiredModels.isEmpty()) return;
        pollInFlight = true;
        pollModelAt(0, token);
    }

    private void pollModelAt(int position, int token) {
        if (!isCurrent(token)) {
            pollInFlight = false;
            return;
        }
        if (position >= requiredModels.size()) {
            pollInFlight = false;
            finishSuccess(token);
            return;
        }
        TranslateRemoteModel model = new TranslateRemoteModel.Builder(requiredModels.get(position)).build();
        modelManager.isModelDownloaded(model)
                .addOnSuccessListener(downloaded -> {
                    if (!isCurrent(token)) {
                        pollInFlight = false;
                        return;
                    }
                    if (Boolean.TRUE.equals(downloaded)) pollModelAt(position + 1, token);
                    else pollInFlight = false;
                })
                .addOnFailureListener(error -> pollInFlight = false);
    }

    private void verifyStage(int position, int token) {
        if (!isCurrent(token)) return;
        if (position >= requiredModels.size()) {
            finishSuccess(token);
            return;
        }

        state = STATE_VERIFYING;
        message = "Verificando instalación " + (position + 1) + " de " + stageTotal + "…";
        saveAndPublish();
        String modelLanguage = requiredModels.get(position);
        TranslateRemoteModel remoteModel = new TranslateRemoteModel.Builder(modelLanguage).build();
        modelManager.isModelDownloaded(remoteModel)
                .addOnSuccessListener(downloaded -> {
                    if (!isCurrent(token)) return;
                    if (Boolean.TRUE.equals(downloaded)) verifyStage(position + 1, token);
                    else fail("ML Kit terminó, pero no confirmó el componente " + readable(modelLanguage) + ". Pulsa Reintentar.", token);
                })
                .addOnFailureListener(error -> fail("No se pudo verificar la instalación: " + cleanError(error), token));
    }

    private void finishSuccess(int token) {
        if (!isCurrent(token)) return;
        prefs.edit().putBoolean(MainActivity.KEY_MODEL_PREFIX + languageCode, true).apply();
        active = false;
        state = STATE_READY;
        stage = stageTotal;
        message = languageName + " quedó verificado y listo para funcionar sin conexión.";
        saveState();
        sendStatus();
        handler.removeCallbacks(ticker);
        notificationManager.notify(NOTIFICATION_ID, buildNotification(true));
        stopForeground(false);
        stopSelf();
    }

    private void fail(String reason, int token) {
        if (!isCurrent(token)) return;
        active = false;
        state = STATE_ERROR;
        message = reason;
        saveState();
        sendStatus();
        handler.removeCallbacks(ticker);
        notificationManager.notify(NOTIFICATION_ID, buildNotification(true));
        stopForeground(false);
        stopSelf();
    }

    private void stopMonitoring() {
        if (!active && !prefs.getBoolean(KEY_ACTIVE, false)) {
            stopSelf();
            return;
        }
        requestToken++;
        active = false;
        state = STATE_STOPPED;
        message = "Seguimiento detenido. ML Kit puede finalizar internamente; pulsa Reintentar para comprobarlo.";
        connection = connectionLabel();
        saveState();
        sendStatus();
        handler.removeCallbacks(ticker);
        stopForeground(true);
        stopSelf();
    }

    private boolean isCurrent(int token) {
        return active && token == requestToken;
    }

    private void saveAndPublish() {
        saveState();
        sendStatus();
        notificationManager.notify(NOTIFICATION_ID, buildNotification(false));
    }

    private void saveState() {
        prefs.edit()
                .putBoolean(KEY_ACTIVE, active)
                .putInt(KEY_ACTIVE_INDEX, languageIndex)
                .putString(KEY_ACTIVE_CODE, languageCode)
                .putString(KEY_ACTIVE_NAME, languageName)
                .putString(KEY_STATE, state)
                .putString(KEY_MESSAGE, message)
                .putLong(KEY_STARTED_AT, startedWall)
                .putInt(KEY_STAGE, stage)
                .putInt(KEY_STAGE_TOTAL, stageTotal)
                .putString(KEY_CONNECTION, connection)
                .apply();
    }

    private void sendStatus() {
        Intent update = new Intent(ACTION_STATUS);
        update.setPackage(getPackageName());
        update.putExtra(EXTRA_INDEX, languageIndex);
        update.putExtra(EXTRA_CODE, languageCode);
        update.putExtra(EXTRA_NAME, languageName);
        update.putExtra(EXTRA_STATE, state);
        update.putExtra(EXTRA_MESSAGE, message);
        update.putExtra(EXTRA_ELAPSED, elapsedMs());
        update.putExtra(EXTRA_STAGE, stage);
        update.putExtra(EXTRA_STAGE_TOTAL, stageTotal);
        update.putExtra(EXTRA_CONNECTION, connection);
        sendBroadcast(update);
    }

    private Notification buildNotification(boolean finished) {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this, 0, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(com.geozeta.livetranslator.R.drawable.ic_stat_zeta)
                .setContentTitle(notificationTitle())
                .setContentText(notificationText())
                .setContentIntent(openPending)
                .setOnlyAlertOnce(true)
                .setOngoing(!finished)
                .setCategory(Notification.CATEGORY_PROGRESS);

        if (!finished) {
            Intent stopIntent = new Intent(this, DownloadModelService.class);
            stopIntent.setAction(ACTION_STOP);
            PendingIntent stopPending = PendingIntent.getService(
                    this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(0, "Detener", stopPending);
        } else {
            builder.setAutoCancel(true);
        }
        return builder.build();
    }

    private String notificationTitle() {
        if (STATE_READY.equals(state)) return "Modelo listo";
        if (STATE_ERROR.equals(state)) return "Falló la descarga";
        if (STATE_STOPPED.equals(state)) return "Seguimiento detenido";
        return "Preparando " + languageName;
    }

    private String notificationText() {
        String stageText = stageTotal > 0 ? "Etapa " + Math.min(stage + 1, stageTotal) + "/" + stageTotal : "Preparando";
        return stageText + " · " + formatElapsed(elapsedMs()) + " · " + connection;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Descargas de idiomas", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Estado de descarga e instalación de modelos offline");
        notificationManager.createNotificationChannel(channel);
    }

    private long elapsedMs() {
        if (startedElapsed <= 0L) return 0L;
        return Math.max(0L, SystemClock.elapsedRealtime() - startedElapsed);
    }

    private String connectionLabel() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return "Sin conexión";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return "Sin conexión";
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "Sin conexión";
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) return "Red sin internet";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi‑Fi";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Datos móviles";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            return "Internet disponible";
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null || !info.isConnected()) return "Sin conexión";
        return info.getType() == ConnectivityManager.TYPE_WIFI ? "Wi‑Fi" : "Datos móviles";
    }

    private String readable(String code) {
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.SPANISH.equals(code)) return "Español";
        return code;
    }

    private String cleanError(Exception error) {
        if (error == null || error.getMessage() == null || error.getMessage().trim().isEmpty()) {
            return "error desconocido";
        }
        return error.getMessage().trim();
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    private String formatElapsed(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(ticker);
        if (active) {
            active = false;
            state = STATE_ERROR;
            message = "Android detuvo el servicio de descarga. Pulsa Reintentar para comprobar o continuar.";
            saveState();
            sendStatus();
        }
        super.onDestroy();
    }
}
