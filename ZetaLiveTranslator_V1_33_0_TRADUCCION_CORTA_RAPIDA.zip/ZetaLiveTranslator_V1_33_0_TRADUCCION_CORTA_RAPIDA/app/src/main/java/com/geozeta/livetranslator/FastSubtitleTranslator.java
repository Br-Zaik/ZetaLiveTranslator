package com.geozeta.livetranslator;

import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Traducciones instantáneas para expresiones cortas y frecuentes de subtítulos.
 *
 * <p>Esta capa no sustituye al modelo offline. Solo resuelve frases breves de alta confianza,
 * donde un modelo neuronal suele perder contexto o devolver una traducción demasiado literal.
 * Las entradas ambiguas se dejan al modelo principal.</p>
 */
final class FastSubtitleTranslator {
    private static final String ENGLISH = "en";
    private static final String CHINESE = "zh";
    private static final String JAPANESE = "ja";

    private static final Map<String, String> ENGLISH_TO_SPANISH;
    private static final Map<String, String> JAPANESE_TO_SPANISH;
    private static final Map<String, String> CHINESE_TO_SPANISH;

    static {
        Map<String, String> en = new HashMap<>();
        addEnglish(en, "I", "Yo");
        addEnglish(en, "yes", "Sí");
        addEnglish(en, "yeah", "Sí");
        addEnglish(en, "yep", "Sí");
        addEnglish(en, "no", "No");
        addEnglish(en, "nope", "No");
        addEnglish(en, "okay", "Está bien");
        addEnglish(en, "ok", "Está bien");
        addEnglish(en, "alright", "Está bien");
        addEnglish(en, "all right", "Está bien");
        addEnglish(en, "fine", "Está bien");
        addEnglish(en, "sure", "Claro");
        addEnglish(en, "of course", "Por supuesto");
        addEnglish(en, "maybe", "Quizá");
        addEnglish(en, "perhaps", "Quizá");
        addEnglish(en, "really", "¿En serio?");
        addEnglish(en, "seriously", "¿En serio?");
        addEnglish(en, "impossible", "Imposible");
        addEnglish(en, "perfect", "Perfecto");
        addEnglish(en, "amazing", "Increíble");
        addEnglish(en, "awesome", "Genial");
        addEnglish(en, "great", "Genial");
        addEnglish(en, "terrible", "Terrible");
        addEnglish(en, "danger", "Peligro");
        addEnglish(en, "ready", "Listo");
        addEnglish(en, "done", "Listo");
        addEnglish(en, "finished", "Terminado");
        addEnglish(en, "alive", "Vivo");
        addEnglish(en, "dead", "Muerto");
        addEnglish(en, "now", "Ahora");
        addEnglish(en, "today", "Hoy");
        addEnglish(en, "tomorrow", "Mañana");
        addEnglish(en, "yesterday", "Ayer");
        addEnglish(en, "here", "Aquí");
        addEnglish(en, "there", "Ahí");
        addEnglish(en, "inside", "Adentro");
        addEnglish(en, "outside", "Afuera");

        addEnglish(en, "stop", "Detente");
        addEnglish(en, "stop it", "Detente");
        addEnglish(en, "run", "Corre");
        addEnglish(en, "help", "¡Ayuda!");
        addEnglish(en, "help me", "Ayúdame");
        addEnglish(en, "save me", "Sálvame");
        addEnglish(en, "wait", "Espera");
        addEnglish(en, "hold on", "Espera");
        addEnglish(en, "wait a minute", "Espera un momento");
        addEnglish(en, "one moment", "Un momento");
        addEnglish(en, "wait for me", "Espérame");
        addEnglish(en, "wait here", "Espera aquí");
        addEnglish(en, "go", "Ve");
        addEnglish(en, "go away", "Vete");
        addEnglish(en, "go home", "Vete a casa");
        addEnglish(en, "come", "Ven");
        addEnglish(en, "come here", "Ven aquí");
        addEnglish(en, "come on", "Vamos");
        addEnglish(en, "let's go", "Vamos");
        addEnglish(en, "let us go", "Déjanos ir");
        addEnglish(en, "let me go", "Déjame ir");
        addEnglish(en, "follow me", "Sígueme");
        addEnglish(en, "look", "Mira");
        addEnglish(en, "look at me", "Mírame");
        addEnglish(en, "listen", "Escucha");
        addEnglish(en, "listen to me", "Escúchame");
        addEnglish(en, "tell me", "Dime");
        addEnglish(en, "show me", "Muéstrame");
        addEnglish(en, "trust me", "Confía en mí");
        addEnglish(en, "believe me", "Créeme");
        addEnglish(en, "move", "Muévete");
        addEnglish(en, "don't move", "No te muevas");
        addEnglish(en, "do not move", "No te muevas");
        addEnglish(en, "duck", "Agáchate");
        addEnglish(en, "hide", "Escóndete");
        addEnglish(en, "stay", "Quédate");
        addEnglish(en, "stay here", "Quédate aquí");
        addEnglish(en, "leave", "Vete");
        addEnglish(en, "leave me alone", "Déjame en paz");
        addEnglish(en, "get out", "Sal de aquí");
        addEnglish(en, "shut up", "Cállate");
        addEnglish(en, "be quiet", "Silencio");
        addEnglish(en, "quiet", "Silencio");
        addEnglish(en, "jump", "Salta");
        addEnglish(en, "hurry", "Date prisa");
        addEnglish(en, "hurry up", "Date prisa");
        addEnglish(en, "careful", "Ten cuidado");
        addEnglish(en, "be careful", "Ten cuidado");
        addEnglish(en, "watch out", "¡Cuidado!");
        addEnglish(en, "don't touch me", "No me toques");
        addEnglish(en, "do not touch me", "No me toques");
        addEnglish(en, "don't worry", "No te preocupes");
        addEnglish(en, "do not worry", "No te preocupes");
        addEnglish(en, "don't cry", "No llores");
        addEnglish(en, "do not cry", "No llores");
        addEnglish(en, "don't go", "No te vayas");
        addEnglish(en, "do not go", "No te vayas");
        addEnglish(en, "don't leave", "No te vayas");
        addEnglish(en, "do not leave", "No te vayas");

        addEnglish(en, "hello", "Hola");
        addEnglish(en, "hi", "Hola");
        addEnglish(en, "hey", "Hola");
        addEnglish(en, "good morning", "Buenos días");
        addEnglish(en, "good afternoon", "Buenas tardes");
        addEnglish(en, "good evening", "Buenas noches");
        addEnglish(en, "good night", "Buenas noches");
        addEnglish(en, "goodbye", "Adiós");
        addEnglish(en, "bye", "Adiós");
        addEnglish(en, "see you", "Nos vemos");
        addEnglish(en, "see you later", "Hasta luego");
        addEnglish(en, "welcome", "Bienvenido");
        addEnglish(en, "welcome back", "Bienvenido de nuevo");
        addEnglish(en, "good luck", "Buena suerte");
        addEnglish(en, "take care", "Cuídate");
        addEnglish(en, "please", "Por favor");
        addEnglish(en, "thanks", "Gracias");
        addEnglish(en, "thank you", "Gracias");
        addEnglish(en, "thank you very much", "Muchas gracias");
        addEnglish(en, "you're welcome", "De nada");
        addEnglish(en, "you are welcome", "De nada");
        addEnglish(en, "sorry", "Lo siento");
        addEnglish(en, "I'm sorry", "Lo siento");
        addEnglish(en, "I am sorry", "Lo siento");
        addEnglish(en, "excuse me", "Disculpe");
        addEnglish(en, "forgive me", "Perdóname");

        addEnglish(en, "what", "¿Qué?");
        addEnglish(en, "why", "¿Por qué?");
        addEnglish(en, "who", "¿Quién?");
        addEnglish(en, "where", "¿Dónde?");
        addEnglish(en, "when", "¿Cuándo?");
        addEnglish(en, "how", "¿Cómo?");
        addEnglish(en, "which", "¿Cuál?");
        addEnglish(en, "whose", "¿De quién?");
        addEnglish(en, "how much", "¿Cuánto?");
        addEnglish(en, "how many", "¿Cuántos?");
        addEnglish(en, "what now", "¿Y ahora qué?");
        addEnglish(en, "why me", "¿Por qué yo?");
        addEnglish(en, "who are you", "¿Quién eres?");
        addEnglish(en, "where are you", "¿Dónde estás?");
        addEnglish(en, "where am I", "¿Dónde estoy?");
        addEnglish(en, "what happened", "¿Qué pasó?");
        addEnglish(en, "what's wrong", "¿Qué pasa?");
        addEnglish(en, "what is wrong", "¿Qué pasa?");
        addEnglish(en, "what are you doing", "¿Qué estás haciendo?");
        addEnglish(en, "what are you saying", "¿Qué estás diciendo?");
        addEnglish(en, "what do you want", "¿Qué quieres?");
        addEnglish(en, "are you okay", "¿Estás bien?");
        addEnglish(en, "are you all right", "¿Estás bien?");
        addEnglish(en, "are you sure", "¿Estás seguro?");

        addEnglish(en, "I know", "Lo sé");
        addEnglish(en, "I don't know", "No lo sé");
        addEnglish(en, "I do not know", "No lo sé");
        addEnglish(en, "I understand", "Entiendo");
        addEnglish(en, "I don't understand", "No entiendo");
        addEnglish(en, "I do not understand", "No entiendo");
        addEnglish(en, "I remember", "Lo recuerdo");
        addEnglish(en, "I forgot", "Lo olvidé");
        addEnglish(en, "I believe you", "Te creo");
        addEnglish(en, "I trust you", "Confío en ti");
        addEnglish(en, "I love you", "Te amo");
        addEnglish(en, "I miss you", "Te extraño");
        addEnglish(en, "I hate you", "Te odio");
        addEnglish(en, "I need you", "Te necesito");
        addEnglish(en, "I want you", "Te quiero");
        addEnglish(en, "I am okay", "Estoy bien");
        addEnglish(en, "I'm okay", "Estoy bien");
        addEnglish(en, "I am fine", "Estoy bien");
        addEnglish(en, "I'm fine", "Estoy bien");
        addEnglish(en, "I am ready", "Estoy listo");
        addEnglish(en, "I'm ready", "Estoy listo");
        addEnglish(en, "I am tired", "Estoy cansado");
        addEnglish(en, "I'm tired", "Estoy cansado");
        addEnglish(en, "I am hungry", "Tengo hambre");
        addEnglish(en, "I'm hungry", "Tengo hambre");
        addEnglish(en, "I am thirsty", "Tengo sed");
        addEnglish(en, "I'm thirsty", "Tengo sed");
        addEnglish(en, "I am scared", "Tengo miedo");
        addEnglish(en, "I'm scared", "Tengo miedo");
        addEnglish(en, "I am coming", "Ya voy");
        addEnglish(en, "I'm coming", "Ya voy");
        addEnglish(en, "I have to go", "Tengo que irme");
        addEnglish(en, "we have to go", "Tenemos que irnos");
        addEnglish(en, "I am at home", "Estoy en casa");
        addEnglish(en, "I'm at home", "Estoy en casa");
        addEnglish(en, "I am at school", "Estoy en la escuela");
        addEnglish(en, "I am at work", "Estoy en el trabajo");
        addEnglish(en, "I am sure", "Estoy seguro");
        addEnglish(en, "I'm sure", "Estoy seguro");

        addEnglish(en, "that's right", "Así es");
        addEnglish(en, "that is right", "Así es");
        addEnglish(en, "you're right", "Tienes razón");
        addEnglish(en, "you are right", "Tienes razón");
        addEnglish(en, "not bad", "No está mal");
        addEnglish(en, "good job", "Buen trabajo");
        addEnglish(en, "well done", "Bien hecho");
        addEnglish(en, "no problem", "No hay problema");
        addEnglish(en, "no way", "De ninguna manera");
        addEnglish(en, "never mind", "No importa");
        addEnglish(en, "forget it", "Olvídalo");
        addEnglish(en, "it doesn't matter", "No importa");
        addEnglish(en, "it does not matter", "No importa");
        addEnglish(en, "it's okay", "Está bien");
        addEnglish(en, "it is okay", "Está bien");
        addEnglish(en, "that's enough", "Ya basta");
        addEnglish(en, "that is enough", "Ya basta");
        addEnglish(en, "enough", "Basta");
        addEnglish(en, "let's do it", "Hagámoslo");
        addEnglish(en, "let us do it", "Hagámoslo");
        ENGLISH_TO_SPANISH = Collections.unmodifiableMap(en);

        Map<String, String> ja = new HashMap<>();
        addAsian(ja, "はい", "Sí");
        addAsian(ja, "うん", "Sí");
        addAsian(ja, "ええ", "Sí");
        addAsian(ja, "いいえ", "No");
        addAsian(ja, "いや", "No");
        addAsian(ja, "だめ", "No");
        addAsian(ja, "ダメ", "No");
        addAsian(ja, "無理", "Imposible");
        addAsian(ja, "そう", "Así es");
        addAsian(ja, "そうだ", "Así es");
        addAsian(ja, "そうです", "Así es");
        addAsian(ja, "そうか", "Ya veo");
        addAsian(ja, "なるほど", "Ya veo");
        addAsian(ja, "わかった", "Entendido");
        addAsian(ja, "分かった", "Entendido");
        addAsian(ja, "わかりました", "Entendido");
        addAsian(ja, "分かりました", "Entendido");
        addAsian(ja, "わからない", "No entiendo");
        addAsian(ja, "分からない", "No entiendo");
        addAsian(ja, "知らない", "No lo sé");
        addAsian(ja, "知ってる", "Lo sé");
        addAsian(ja, "本当", "¿En serio?");
        addAsian(ja, "本当に", "¿En serio?");
        addAsian(ja, "本当ですか", "¿De verdad?");
        addAsian(ja, "マジ", "¿En serio?");
        addAsian(ja, "マジで", "¿En serio?");
        addAsian(ja, "まじで", "¿En serio?");
        addAsian(ja, "嘘", "Mentira");
        addAsian(ja, "嘘だ", "Es mentira");
        addAsian(ja, "嘘でしょ", "No puede ser");
        addAsian(ja, "まさか", "No puede ser");
        addAsian(ja, "すごい", "Increíble");
        addAsian(ja, "すげえ", "Increíble");
        addAsian(ja, "かわいい", "Qué lindo");
        addAsian(ja, "かっこいい", "Qué genial");
        addAsian(ja, "よかった", "Qué alivio");
        addAsian(ja, "残念", "Qué pena");
        addAsian(ja, "最悪", "Es lo peor");
        addAsian(ja, "最高", "Es lo mejor");
        addAsian(ja, "大変", "Esto es grave");
        addAsian(ja, "大変だ", "Esto es grave");

        addAsian(ja, "こんにちは", "Hola");
        addAsian(ja, "ありがとう", "Gracias");
        addAsian(ja, "ありがとうございます", "Gracias");
        addAsian(ja, "おはよう", "Buenos días");
        addAsian(ja, "おはようございます", "Buenos días");
        addAsian(ja, "こんばんは", "Buenas noches");
        addAsian(ja, "おやすみ", "Buenas noches");
        addAsian(ja, "おやすみなさい", "Buenas noches");
        addAsian(ja, "さようなら", "Adiós");
        addAsian(ja, "またね", "Nos vemos");
        addAsian(ja, "じゃあね", "Nos vemos");
        addAsian(ja, "ただいま", "Ya llegué");
        addAsian(ja, "おかえり", "Bienvenido a casa");
        addAsian(ja, "ごめん", "Lo siento");
        addAsian(ja, "ごめんなさい", "Lo siento");
        addAsian(ja, "すみません", "Disculpe");
        addAsian(ja, "お願い", "Por favor");
        addAsian(ja, "お願いします", "Por favor");
        addAsian(ja, "許して", "Perdóname");
        addAsian(ja, "いただきます", "Buen provecho");
        addAsian(ja, "ごちそうさま", "Gracias por la comida");

        addAsian(ja, "助けて", "¡Ayúdame!");
        addAsian(ja, "助けろ", "¡Ayúdame!");
        addAsian(ja, "危ない", "¡Cuidado!");
        addAsian(ja, "気をつけて", "Ten cuidado");
        addAsian(ja, "やめて", "¡Detente!");
        addAsian(ja, "やめろ", "¡Detente!");
        addAsian(ja, "もうやめて", "Ya basta");
        addAsian(ja, "もういい", "Ya basta");
        addAsian(ja, "待って", "Espera");
        addAsian(ja, "待て", "Espera");
        addAsian(ja, "ちょっと", "Un momento");
        addAsian(ja, "早く", "Date prisa");
        addAsian(ja, "急げ", "Date prisa");
        addAsian(ja, "行け", "Ve");
        addAsian(ja, "行って", "Vete");
        addAsian(ja, "行こう", "Vamos");
        addAsian(ja, "来い", "Ven");
        addAsian(ja, "来て", "Ven");
        addAsian(ja, "逃げろ", "Huye");
        addAsian(ja, "逃げて", "Huye");
        addAsian(ja, "走れ", "Corre");
        addAsian(ja, "帰ろう", "Volvamos a casa");
        addAsian(ja, "静かに", "Silencio");
        addAsian(ja, "黙れ", "Cállate");
        addAsian(ja, "うるさい", "Cállate");
        addAsian(ja, "頑張って", "Ánimo");
        addAsian(ja, "信じて", "Confía en mí");
        addAsian(ja, "任せて", "Déjamelo a mí");
        addAsian(ja, "任せろ", "Déjamelo a mí");

        addAsian(ja, "誰", "¿Quién?");
        addAsian(ja, "何", "¿Qué?");
        addAsian(ja, "なに", "¿Qué?");
        addAsian(ja, "どこ", "¿Dónde?");
        addAsian(ja, "いつ", "¿Cuándo?");
        addAsian(ja, "なぜ", "¿Por qué?");
        addAsian(ja, "どうして", "¿Por qué?");
        addAsian(ja, "どうしてだ", "¿Por qué?");
        addAsian(ja, "なんで", "¿Por qué?");
        addAsian(ja, "どうした", "¿Qué pasó?");
        addAsian(ja, "どうしたの", "¿Qué pasó?");
        addAsian(ja, "何してる", "¿Qué haces?");
        addAsian(ja, "どこにいる", "¿Dónde estás?");
        addAsian(ja, "何があった", "¿Qué pasó?");

        addAsian(ja, "痛い", "Duele");
        addAsian(ja, "怖い", "Tengo miedo");
        addAsian(ja, "眠い", "Tengo sueño");
        addAsian(ja, "お腹すいた", "Tengo hambre");
        addAsian(ja, "喉渇いた", "Tengo sed");
        addAsian(ja, "寒い", "Hace frío");
        addAsian(ja, "暑い", "Hace calor");
        addAsian(ja, "熱い", "Está caliente");
        addAsian(ja, "愛してる", "Te amo");
        addAsian(ja, "大好き", "Te quiero mucho");
        addAsian(ja, "嫌い", "No me gustas");
        addAsian(ja, "会いたい", "Quiero verte");
        addAsian(ja, "行きたい", "Quiero ir");
        addAsian(ja, "帰りたい", "Quiero volver a casa");
        addAsian(ja, "死ぬ", "Voy a morir");
        addAsian(ja, "死ね", "Muérete");
        addAsian(ja, "殺す", "Te mataré");
        JAPANESE_TO_SPANISH = Collections.unmodifiableMap(ja);

        Map<String, String> zh = new HashMap<>();
        addAsian(zh, "对", "Sí");
        addAsian(zh, "對", "Sí");
        addAsian(zh, "对的", "Así es");
        addAsian(zh, "對的", "Así es");
        addAsian(zh, "没错", "Así es");
        addAsian(zh, "沒錯", "Así es");
        addAsian(zh, "不是", "No");
        addAsian(zh, "不", "No");
        addAsian(zh, "不要", "No lo hagas");
        addAsian(zh, "别", "No lo hagas");
        addAsian(zh, "別", "No lo hagas");
        addAsian(zh, "好的", "De acuerdo");
        addAsian(zh, "好", "Está bien");
        addAsian(zh, "行", "Está bien");
        addAsian(zh, "可以", "Está bien");
        addAsian(zh, "不行", "No se puede");
        addAsian(zh, "没事", "No pasa nada");
        addAsian(zh, "沒事", "No pasa nada");
        addAsian(zh, "没关系", "No pasa nada");
        addAsian(zh, "沒關係", "No pasa nada");
        addAsian(zh, "没问题", "No hay problema");
        addAsian(zh, "沒問題", "No hay problema");
        addAsian(zh, "当然", "Por supuesto");
        addAsian(zh, "當然", "Por supuesto");
        addAsian(zh, "真的", "De verdad");
        addAsian(zh, "真的吗", "¿De verdad?");
        addAsian(zh, "真的嗎", "¿De verdad?");
        addAsian(zh, "不会吧", "No puede ser");
        addAsian(zh, "不會吧", "No puede ser");
        addAsian(zh, "怎么可能", "¿Cómo es posible?");
        addAsian(zh, "怎麼可能", "¿Cómo es posible?");
        addAsian(zh, "天啊", "Dios mío");
        addAsian(zh, "我的天", "Dios mío");
        addAsian(zh, "太好了", "Qué bien");
        addAsian(zh, "厉害", "Increíble");
        addAsian(zh, "厲害", "Increíble");
        addAsian(zh, "真棒", "Genial");
        addAsian(zh, "糟了", "Oh, no");
        addAsian(zh, "危险", "Peligro");
        addAsian(zh, "危險", "Peligro");
        addAsian(zh, "算了", "Olvídalo");
        addAsian(zh, "够了", "Ya basta");
        addAsian(zh, "夠了", "Ya basta");
        addAsian(zh, "没办法", "No hay forma");
        addAsian(zh, "沒辦法", "No hay forma");

        addAsian(zh, "你好", "Hola");
        addAsian(zh, "谢谢", "Gracias");
        addAsian(zh, "謝謝", "Gracias");
        addAsian(zh, "多谢", "Gracias");
        addAsian(zh, "多謝", "Gracias");
        addAsian(zh, "不客气", "De nada");
        addAsian(zh, "不客氣", "De nada");
        addAsian(zh, "不用谢", "De nada");
        addAsian(zh, "不用謝", "De nada");
        addAsian(zh, "早上好", "Buenos días");
        addAsian(zh, "晚上好", "Buenas noches");
        addAsian(zh, "晚安", "Buenas noches");
        addAsian(zh, "对不起", "Lo siento");
        addAsian(zh, "對不起", "Lo siento");
        addAsian(zh, "抱歉", "Lo siento");
        addAsian(zh, "请", "Por favor");
        addAsian(zh, "請", "Por favor");
        addAsian(zh, "拜托", "Por favor");
        addAsian(zh, "拜託", "Por favor");
        addAsian(zh, "再见", "Adiós");
        addAsian(zh, "再見", "Adiós");
        addAsian(zh, "回头见", "Nos vemos");
        addAsian(zh, "回頭見", "Nos vemos");

        addAsian(zh, "救命", "¡Ayuda!");
        addAsian(zh, "救我", "Ayúdame");
        addAsian(zh, "帮我", "Ayúdame");
        addAsian(zh, "幫我", "Ayúdame");
        addAsian(zh, "小心", "¡Cuidado!");
        addAsian(zh, "住手", "¡Detente!");
        addAsian(zh, "停", "Detente");
        addAsian(zh, "等等", "Espera");
        addAsian(zh, "等一下", "Espera un momento");
        addAsian(zh, "等我", "Espérame");
        addAsian(zh, "等等我", "Espérame");
        addAsian(zh, "快点", "Date prisa");
        addAsian(zh, "快點", "Date prisa");
        addAsian(zh, "快走", "Vete rápido");
        addAsian(zh, "快跑", "Corre");
        addAsian(zh, "快逃", "Huye");
        addAsian(zh, "来", "Ven");
        addAsian(zh, "來", "Ven");
        addAsian(zh, "过来", "Ven aquí");
        addAsian(zh, "過來", "Ven aquí");
        addAsian(zh, "回来", "Vuelve");
        addAsian(zh, "回來", "Vuelve");
        addAsian(zh, "出去", "Sal");
        addAsian(zh, "滚", "Vete");
        addAsian(zh, "滾", "Vete");
        addAsian(zh, "走吧", "Vámonos");
        addAsian(zh, "我们走", "Vámonos");
        addAsian(zh, "我們走", "Vámonos");
        addAsian(zh, "跟我走", "Ven conmigo");
        addAsian(zh, "跟我来", "Sígueme");
        addAsian(zh, "跟我來", "Sígueme");
        addAsian(zh, "别动", "No te muevas");
        addAsian(zh, "別動", "No te muevas");
        addAsian(zh, "别碰我", "No me toques");
        addAsian(zh, "別碰我", "No me toques");
        addAsian(zh, "放开我", "Suéltame");
        addAsian(zh, "放開我", "Suéltame");
        addAsian(zh, "让我走", "Déjame ir");
        addAsian(zh, "讓我走", "Déjame ir");
        addAsian(zh, "离开我", "Déjame en paz");
        addAsian(zh, "離開我", "Déjame en paz");
        addAsian(zh, "闭嘴", "Cállate");
        addAsian(zh, "閉嘴", "Cállate");
        addAsian(zh, "安静", "Silencio");
        addAsian(zh, "安靜", "Silencio");
        addAsian(zh, "加油", "Ánimo");
        addAsian(zh, "别担心", "No te preocupes");
        addAsian(zh, "別擔心", "No te preocupes");
        addAsian(zh, "别哭", "No llores");
        addAsian(zh, "別哭", "No llores");
        addAsian(zh, "别怕", "No tengas miedo");
        addAsian(zh, "別怕", "No tengas miedo");
        addAsian(zh, "听我说", "Escúchame");
        addAsian(zh, "聽我說", "Escúchame");
        addAsian(zh, "看着我", "Mírame");
        addAsian(zh, "看著我", "Mírame");
        addAsian(zh, "相信我", "Confía en mí");

        addAsian(zh, "为什么", "¿Por qué?");
        addAsian(zh, "為什麼", "¿Por qué?");
        addAsian(zh, "什么", "¿Qué?");
        addAsian(zh, "什麼", "¿Qué?");
        addAsian(zh, "谁", "¿Quién?");
        addAsian(zh, "誰", "¿Quién?");
        addAsian(zh, "哪里", "¿Dónde?");
        addAsian(zh, "哪裡", "¿Dónde?");
        addAsian(zh, "哪儿", "¿Dónde?");
        addAsian(zh, "哪兒", "¿Dónde?");
        addAsian(zh, "什么时候", "¿Cuándo?");
        addAsian(zh, "什麼時候", "¿Cuándo?");
        addAsian(zh, "怎么", "¿Cómo?");
        addAsian(zh, "怎麼", "¿Cómo?");
        addAsian(zh, "怎么了", "¿Qué pasa?");
        addAsian(zh, "怎麼了", "¿Qué pasa?");
        addAsian(zh, "怎么回事", "¿Qué pasó?");
        addAsian(zh, "怎麼回事", "¿Qué pasó?");
        addAsian(zh, "发生什么事了", "¿Qué pasó?");
        addAsian(zh, "發生什麼事了", "¿Qué pasó?");
        addAsian(zh, "你好吗", "¿Cómo estás?");
        addAsian(zh, "你好嗎", "¿Cómo estás?");
        addAsian(zh, "你没事吧", "¿Estás bien?");
        addAsian(zh, "你沒事吧", "¿Estás bien?");

        addAsian(zh, "我没事", "Estoy bien");
        addAsian(zh, "我沒事", "Estoy bien");
        addAsian(zh, "我知道", "Lo sé");
        addAsian(zh, "我不知道", "No lo sé");
        addAsian(zh, "我明白", "Entiendo");
        addAsian(zh, "我不明白", "No entiendo");
        addAsian(zh, "我懂了", "Entendido");
        addAsian(zh, "我爱你", "Te amo");
        addAsian(zh, "我愛你", "Te amo");
        addAsian(zh, "我想你", "Te extraño");
        addAsian(zh, "我喜欢你", "Me gustas");
        addAsian(zh, "我喜歡你", "Me gustas");
        addAsian(zh, "我恨你", "Te odio");
        addAsian(zh, "我相信你", "Confío en ti");
        addAsian(zh, "我不相信", "No lo creo");
        addAsian(zh, "我要回家", "Quiero ir a casa");
        addAsian(zh, "回家", "Vuelve a casa");
        addAsian(zh, "我饿了", "Tengo hambre");
        addAsian(zh, "我餓了", "Tengo hambre");
        addAsian(zh, "我渴了", "Tengo sed");
        addAsian(zh, "我累了", "Estoy cansado");
        addAsian(zh, "我害怕", "Tengo miedo");
        addAsian(zh, "疼", "Duele");
        addAsian(zh, "痛", "Duele");
        addAsian(zh, "冷", "Hace frío");
        addAsian(zh, "热", "Hace calor");
        addAsian(zh, "熱", "Hace calor");
        addAsian(zh, "好了", "Listo");
        addAsian(zh, "完成了", "Terminado");
        addAsian(zh, "准备好了吗", "¿Estás listo?");
        addAsian(zh, "準備好了嗎", "¿Estás listo?");
        addAsian(zh, "准备好了", "Estoy listo");
        addAsian(zh, "準備好了", "Estoy listo");
        CHINESE_TO_SPANISH = Collections.unmodifiableMap(zh);
    }

    private FastSubtitleTranslator() { }

    static String translate(String input, String sourceLanguage) {
        if (input == null || input.trim().isEmpty() || sourceLanguage == null) return null;
        if (ENGLISH.equals(sourceLanguage)) {
            return ENGLISH_TO_SPANISH.get(normalizeEnglish(input));
        }
        if (JAPANESE.equals(sourceLanguage)) {
            String key = normalizeAsian(input);
            if ("大丈夫".equals(key)) return isQuestion(input) ? "¿Estás bien?" : "Estoy bien";
            return JAPANESE_TO_SPANISH.get(key);
        }
        if (CHINESE.equals(sourceLanguage)) {
            String key = normalizeAsian(input);
            if ("真的".equals(key)) {
                return isQuestion(input) ? "¿De verdad?" : "De verdad";
            }
            return CHINESE_TO_SPANISH.get(key);
        }
        return null;
    }

    static String normalizeEnglishForTest(String input) {
        return normalizeEnglish(input);
    }

    private static void addEnglish(Map<String, String> map, String source, String target) {
        map.put(normalizeEnglish(source), target);
    }

    private static void addAsian(Map<String, String> map, String source, String target) {
        map.put(normalizeAsian(source), target);
    }

    private static String normalizeEnglish(String input) {
        String value = input == null ? "" : input.toLowerCase(Locale.ROOT)
                .replace('’', '\'')
                .replace('‘', '\'')
                .replace('`', '\'');
        value = value.replaceAll("\\bi['’]?m\\b", "i am");
        value = value.replaceAll("\\byou['’]?re\\b", "you are");
        value = value.replaceAll("\\bwe['’]?re\\b", "we are");
        value = value.replaceAll("\\bthey['’]?re\\b", "they are");
        value = value.replaceAll("\\bhe['’]?s\\b", "he is");
        value = value.replaceAll("\\bshe['’]?s\\b", "she is");
        value = value.replaceAll("\\bit['’]?s\\b", "it is");
        value = value.replaceAll("\\bthat['’]?s\\b", "that is");
        value = value.replaceAll("\\bwhat['’]?s\\b", "what is");
        value = value.replaceAll("\\bdon['’]?t\\b|\\bdont\\b", "do not");
        value = value.replaceAll("\\bdoesn['’]?t\\b|\\bdoesnt\\b", "does not");
        value = value.replaceAll("\\bdidn['’]?t\\b|\\bdidnt\\b", "did not");
        value = value.replaceAll("\\bcan['’]?t\\b|\\bcant\\b", "cannot");
        value = value.replaceAll("\\bwon['’]?t\\b|\\bwont\\b", "will not");
        value = value.replaceAll("\\bisn['’]?t\\b|\\bisnt\\b", "is not");
        value = value.replaceAll("\\baren['’]?t\\b|\\barent\\b", "are not");
        value = value.replaceAll("\\bwasn['’]?t\\b|\\bwasnt\\b", "was not");
        value = value.replaceAll("\\bweren['’]?t\\b|\\bwerent\\b", "were not");
        value = value.replaceAll("[^a-z0-9]+", " ");
        return value.replaceAll("\\s+", " ").trim();
    }

    private static String normalizeAsian(String input) {
        if (input == null) return "";
        return input.toLowerCase(Locale.ROOT)
                .replace('　', ' ')
                .replaceAll("[^\\p{L}\\p{N}]+", "")
                .trim();
    }

    private static boolean isQuestion(String input) {
        if (input == null) return false;
        String trimmed = input.trim();
        return trimmed.contains("?") || trimmed.contains("？")
                || trimmed.endsWith("吗") || trimmed.endsWith("嗎")
                || trimmed.endsWith("か");
    }
}
