# Cambios V1.33.0 — traducción corta rápida

## Mejora principal

Se añadió una capa local e instantánea para expresiones cortas y frecuentes de subtítulos en:

- Inglés → Español
- Chino simplificado y tradicional → Español
- Japonés → Español

Esta capa se ejecuta antes del modelo offline únicamente cuando existe una traducción de alta confianza. Las frases largas y las palabras ambiguas continúan en ML Kit para evitar imponer significados incorrectos.

## Precisión

- Más de 500 entradas y variantes breves entre los tres idiomas.
- Mejor manejo de preguntas, órdenes, saludos, despedidas, respuestas, emociones y frases de emergencia.
- Normalización de contracciones y negaciones inglesas sin confundir `can` con `can't` ni eliminar el sentido negativo.
- Distinción por signo de pregunta en expresiones japonesas cortas como `大丈夫`.
- Variantes frecuentes de chino simplificado y tradicional.
- Palabras polisémicas como `right`, `fire`, `やばい` y `走` no se fuerzan mediante reglas fijas.

## Español de salida

- Limpieza de espacios antes de signos.
- Recuperación segura de `¿` y `¡` cuando el original es interrogativo o exclamativo.
- Capitalización inicial sin cambiar el contenido traducido.

## Partes no modificadas

No se modificaron la interfaz, el cuadro morado, LIVE, ajustes, OCR, segundo plano, notificación, selección de idioma ni frecuencia de captura.
