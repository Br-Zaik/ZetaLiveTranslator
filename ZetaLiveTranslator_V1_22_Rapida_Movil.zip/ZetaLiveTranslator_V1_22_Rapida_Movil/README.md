# Zeta Live Translator 1.22 - Rapida y movil

Esta version recupera el comportamiento rapido de las primeras versiones y mantiene el cuadro negro libre para moverlo con el dedo.

## Cambios realizados

- Traduccion en vivo sin esperar dos lecturas antes de mostrar un resultado.
- Intervalo Vivo reducido a 650 ms.
- Una sola pasada de traduccion: se quito el segundo intento con contexto que aumentaba la demora.
- El cuadro negro puede colocarse libremente en cualquier parte de la pantalla.
- Al mover o redimensionar el cuadro morado, el cuadro negro ya no pierde la posicion elegida manualmente.
- El cuadro negro solo se limita a los bordes de la pantalla; no se expulsa del area morada.
- Reintentos de captura mas rapidos y tolerantes.
- Un fotograma perdido ya no muestra inmediatamente el aviso de error.
- Recuperacion automatica de la superficie si la captura falla repetidamente.
- Limpieza rapida del OCR ingles antes de traducir.
- Eliminacion de restos cortos y aleatorios como `FN`, `3f`, `EAE`, `bt` o `Brdrr`.
- Correcciones generales de OCR como `EXACTY -> exactly`, `finisbed -> finished`, `leam -> learn` y `schoo1 -> school`.
- Normalizacion de palabras alargadas como `gooood`, `noooo` o `pleaaase`.
- En subtitulos de dos lineas solo se unen lineas contiguas para evitar mezclar texto no relacionado.
- Auto sigue priorizando Ingles y el modo manual usa solamente el idioma elegido.
- Zeta sigue sin utilizar `FLAG_SECURE`, por lo que no bloquea capturas por si mismo.

## Uso recomendado

1. Descarga el idioma que vas a utilizar.
2. Inicia el traductor y acepta la captura.
3. Selecciona Ingles -> ES cuando el video ya incluye subtitulos ingleses.
4. Ajusta el cuadro morado solamente alrededor del subtitulo original.
5. Mueve el cuadro negro a la posicion que prefieras.
6. Activa Vivo.

## Limitacion real

Si colocas el cuadro negro directamente encima del texto original dentro del cuadro morado, el OCR puede leer el propio texto de Zeta porque esa ventana tapa los pixeles del video. La aplicacion ya no fuerza su posicion, por lo que conviene colocarlo donde no cubra el subtitulo original.

Una aplicacion externa con DRM puede seguir bloqueando capturas aunque Zeta no utilice `FLAG_SECURE`.
