package com.geozeta.livetranslator;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TranslatorEngine {
    public static final String MODE_AUTO = "auto";
    public static final String MODE_CHINESE = TranslateLanguage.CHINESE;
    public static final String MODE_ENGLISH = TranslateLanguage.ENGLISH;
    public static final String MODE_JAPANESE = TranslateLanguage.JAPANESE;
    public static final String MODE_KOREAN = TranslateLanguage.KOREAN;

    public interface Callback {
        void onSuccess(String original, String translated, String sourceName);
        void onError(String message);
    }

    private final Pattern cjkPattern = Pattern.compile("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]");
    private final Pattern chinesePattern = Pattern.compile("[\\u3400-\\u9FFF]");
    private final Pattern japanesePattern = Pattern.compile("[\\u3040-\\u30FF]");
    private final Pattern koreanPattern = Pattern.compile("[\\uAC00-\\uD7AF]");
    private final Pattern latinPattern = Pattern.compile("[A-Za-z]");
    private final Pattern expressiveWordPattern = Pattern.compile("[A-Za-z]{2,}");
    private static final int AUTO_UNLOCK_FAILURES = 3;
    private static final int AUTO_ENGLISH_ACCEPT_SCORE = 120;
    private static final int AUTO_CJK_ACCEPT_SCORE = 55;
    private final SharedPreferences preferences;
    private int autoFailureCount = 0;
    private String lastAutoMode = null;
    private String pendingStableKey = "";
    private String pendingStableMode = "";
    private int pendingStableMatches = 0;
    private long pendingStableSince = 0L;
    private String lastSourceText = "";
    private String lastSourceLanguage = "";
    private long lastSourceAt = 0L;
    private static final String CONTEXT_MARKER = "ZXQ9173";
    private final Map<String, TextRecognizer> recognizers = new HashMap<>();
    private final Map<String, Translator> translators = new HashMap<>();
    private final Map<String, String> translationCache = new LinkedHashMap<String, String>(160, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
            return size() > 160;
        }
    };
    private static final Set<String> EXPRESSIVE_DICTIONARY = new HashSet<>(Arrays.asList(
            "a", "ah", "am", "are", "awesome", "bad", "beautiful", "better", "book", "boom",
            "bye", "call", "calm", "can", "come", "cool", "damn", "do", "done", "fine", "food",
            "go", "good", "great", "happy", "help", "hello", "hey", "home", "honey", "hope", "how",
            "i", "know", "later", "leave", "like", "little", "look", "love", "man", "maybe", "me",
            "mom", "more", "need", "never", "nice", "no", "not", "now", "of", "oh", "okay", "one",
            "please", "really", "right", "run", "sad", "see", "she", "shit", "so", "sorry", "stop",
            "sure", "thank", "thanks", "that", "the", "there", "think", "this", "time", "too", "very",
            "wait", "want", "we", "well", "what", "why", "wow", "yeah", "yes", "you"
    ));

    public TranslatorEngine(Context context) {
        Context appContext = context.getApplicationContext();
        preferences = appContext.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
    }

    public void resetAutoState() {
        lastAutoMode = null;
        autoFailureCount = 0;
    }

    public void resetStabilityState() {
        pendingStableKey = "";
        pendingStableMode = "";
        pendingStableMatches = 0;
        pendingStableSince = 0L;
    }

    public void resetContextState() {
        lastSourceText = "";
        lastSourceLanguage = "";
        lastSourceAt = 0L;
    }

    public void process(Bitmap crop, String mode, Callback callback) {
        process(crop, mode, false, callback);
    }

    public void process(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (crop == null || crop.isRecycled()) {
            callback.onError("No se pudo leer el recorte.");
            return;
        }
        if (MODE_AUTO.equals(mode)) {
            processAuto(crop, requireStable, callback);
        } else {
            processFixed(crop, mode, requireStable, callback);
        }
    }

    private void processFixed(Bitmap crop, String mode, boolean requireStable, Callback callback) {
        if (!isModelReady(mode)) {
            callback.onError("Descarga " + readable(mode) + " → Español antes de usar este idioma.");
            return;
        }
        Bitmap prepared = prepareForOcr(crop);
        recognize(prepared, mode, new OcrCallback() {
            @Override public void onText(String raw) {
                String cleaned = cleanText(raw, mode);
                if (cleaned.trim().length() < 1 && prepared != crop) {
                    prepared.recycle();
                    recognize(crop, mode, new OcrCallback() {
                        @Override public void onText(String raw2) {
                            String cleaned2 = cleanText(raw2, mode);
                            if (cleaned2.trim().length() < 1) {
                                callback.onError("No se detectó texto dentro del cuadro.");
                                return;
                            }
                            translateWhenStable(cleaned2, mode, requireStable, callback);
                        }
                        @Override public void onError(String error) { callback.onError(error); }
                    });
                    return;
                }
                if (prepared != crop) prepared.recycle();
                if (cleaned.trim().length() < 1) {
                    callback.onError("No se detectó texto dentro del cuadro.");
                    return;
                }
                translateWhenStable(cleaned, mode, requireStable, callback);
            }

            @Override public void onError(String error) {
                if (prepared != crop) prepared.recycle();
                callback.onError(error);
            }
        });
    }

    private void processAuto(Bitmap crop, boolean requireStable, Callback callback) {
        String preferred = firstInstalledAutoMode();
        if (preferred == null) {
            callback.onError("Descarga por lo menos un idioma antes de usar Auto.");
            return;
        }
        Bitmap prepared = prepareForOcr(crop);
        String primaryMode = lastAutoMode != null && isModelReady(lastAutoMode) ? lastAutoMode : preferred;
        recognize(prepared, primaryMode, new OcrCallback() {
            @Override public void onText(String raw) {
                String cleaned = cleanText(raw, primaryMode);
                int score = scoreCandidate(cleaned, primaryMode);
                if (isAutoCandidateAcceptable(cleaned, primaryMode, score)) {
                    if (prepared != crop) prepared.recycle();
                    lastAutoMode = primaryMode;
                    autoFailureCount = 0;
                    translateWhenStable(cleaned, primaryMode, requireStable, callback);
                    return;
                }
                autoFailureCount++;
                if (lastAutoMode != null && autoFailureCount < AUTO_UNLOCK_FAILURES) {
                    if (prepared != crop) prepared.recycle();
                    callback.onError("Esperando texto claro en " + readable(primaryMode) + ".");
                    return;
                }
                scanAutoFallback(prepared, crop, primaryMode, requireStable, callback);
            }

            @Override public void onError(String error) {
                autoFailureCount++;
                if (lastAutoMode != null && autoFailureCount < AUTO_UNLOCK_FAILURES) {
                    if (prepared != crop) prepared.recycle();
                    callback.onError("Esperando texto claro en " + readable(primaryMode) + ".");
                    return;
                }
                scanAutoFallback(prepared, crop, primaryMode, requireStable, callback);
            }
        });
    }

    private void scanAutoFallback(Bitmap prepared, Bitmap original, String alreadyTried,
                                  boolean requireStable, Callback callback) {
        String[] modes = fallbackModes(alreadyTried);
        List<Candidate> candidates = new ArrayList<>();
        recognizeAutoAt(prepared, modes, 0, candidates, () -> {
            Candidate best = chooseBest(candidates);
            if (prepared != original) prepared.recycle();
            if (best != null && isAutoCandidateAcceptable(best.cleaned, best.sourceLanguage, best.score)) {
                lastAutoMode = best.sourceLanguage;
                autoFailureCount = 0;
                translateWhenStable(best.cleaned, best.sourceLanguage, requireStable, callback);
                return;
            }

            List<Candidate> originalCandidates = new ArrayList<>();
            recognizeAutoAt(original, autoModesOrder(), 0, originalCandidates, () -> {
                Candidate bestOriginal = chooseBest(originalCandidates);
                if (bestOriginal == null || !isAutoCandidateAcceptable(
                        bestOriginal.cleaned, bestOriginal.sourceLanguage, bestOriginal.score)) {
                    callback.onError("No se detectó texto claro dentro del cuadro.");
                    return;
                }
                lastAutoMode = bestOriginal.sourceLanguage;
                autoFailureCount = 0;
                translateWhenStable(bestOriginal.cleaned, bestOriginal.sourceLanguage, requireStable, callback);
            });
        });
    }

    private boolean isAutoCandidateAcceptable(String text, String mode, int score) {
        if (text == null || text.trim().isEmpty()) return false;
        if (MODE_ENGLISH.equals(mode)) return score >= AUTO_ENGLISH_ACCEPT_SCORE;
        return score >= AUTO_CJK_ACCEPT_SCORE;
    }

    private String[] fallbackModes(String alreadyTried) {
        List<String> installed = installedAutoModes();
        installed.remove(alreadyTried);
        return installed.toArray(new String[0]);
    }

    private String[] autoModesOrder() {
        return installedAutoModes().toArray(new String[0]);
    }

    private List<String> installedAutoModes() {
        List<String> modes = new ArrayList<>();
        // Inglés siempre es la primera opción cuando está instalado.
        if (isModelReady(MODE_ENGLISH)) modes.add(MODE_ENGLISH);
        if (isModelReady(MODE_CHINESE)) modes.add(MODE_CHINESE);
        if (isModelReady(MODE_JAPANESE)) modes.add(MODE_JAPANESE);
        if (isModelReady(MODE_KOREAN)) modes.add(MODE_KOREAN);
        return modes;
    }

    private String firstInstalledAutoMode() {
        List<String> modes = installedAutoModes();
        return modes.isEmpty() ? null : modes.get(0);
    }

    private boolean isModelReady(String sourceLanguage) {
        if (TranslateLanguage.SPANISH.equals(sourceLanguage)) return true;
        return preferences.getBoolean(MainActivity.KEY_MODEL_PREFIX + sourceLanguage, false);
    }

    private void recognizeAutoAt(Bitmap bitmap, String[] modes, int index, List<Candidate> out, Runnable done) {
        if (index >= modes.length) {
            done.run();
            return;
        }
        String mode = modes[index];
        recognize(bitmap, mode, new OcrCallback() {
            @Override public void onText(String raw) {
                String cleaned = cleanText(raw, mode);
                int score = scoreCandidate(cleaned, mode);
                if (cleaned.trim().length() > 0) out.add(new Candidate(cleaned, mode, score));
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }

            @Override public void onError(String error) {
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }
        });
    }

    private Candidate chooseBest(List<Candidate> candidates) {
        Candidate best = null;
        for (Candidate candidate : candidates) {
            if (best == null || candidate.score > best.score) best = candidate;
        }
        return best;
    }

    private int scoreCandidate(String text, String mode) {
        if (text == null) return 0;
        String t = text.trim();
        if (t.length() == 0) return 0;
        int score = Math.min(t.length(), 160);
        int cjk = countMatches(cjkPattern, t);
        int chinese = countMatches(chinesePattern, t);
        int japanese = countMatches(japanesePattern, t);
        int korean = countMatches(koreanPattern, t);
        int latin = countMatches(latinPattern, t);
        int lineCount = countUsefulLines(t);
        if (lineCount > 1) score += Math.min(90, lineCount * 22);

        if (MODE_ENGLISH.equals(mode)) {
            if (isBadEnglishFalsePositive(t)) return -9999;
            score += latin * 3;
            if (isGoodEnglishLine(t)) score += 170 + scoreEnglishLine(t);
            if (countEnglishWords(t) <= 2 && commonEnglishWordScore(t) == 0) score -= 90;
            if (isLikelySpanishLine(t)) score -= 180;
            if (cjk > 0) score -= cjk * 2;
        } else if (MODE_CHINESE.equals(mode)) {
            score += chinese * 7;
            if (japanese > 0 || korean > 0) score -= 10;
        } else if (MODE_JAPANESE.equals(mode)) {
            score += japanese * 8 + chinese * 2;
        } else if (MODE_KOREAN.equals(mode)) {
            score += korean * 8;
        }
        return score;
    }

    private int countMatches(Pattern pattern, String text) {
        int count = 0;
        java.util.regex.Matcher m = pattern.matcher(text);
        while (m.find()) count++;
        return count;
    }

    private int countUsefulLines(String text) {
        if (text == null) return 0;
        String[] parts = text.replace("\r", "").split("\n");
        int count = 0;
        for (String p : parts) {
            if (p != null && p.trim().length() >= 2) count++;
        }
        return count;
    }

    private static class Candidate {
        final String cleaned;
        final String sourceLanguage;
        final int score;
        Candidate(String cleaned, String sourceLanguage, int score) {
            this.cleaned = cleaned;
            this.sourceLanguage = sourceLanguage;
            this.score = score;
        }
    }

    private Bitmap prepareForOcr(Bitmap crop) {
        if (crop == null || crop.isRecycled()) return crop;
        int width = crop.getWidth();
        int height = crop.getHeight();
        if (width <= 0 || height <= 0) return crop;

        // Escala el recorte para que el OCR lea mejor subtítulos pequeños.
        float scale = 1.0f;
        if (width < 900) scale = 1.75f;
        if (width < 620) scale = 2.25f;
        if (width < 430) scale = 2.7f;
        int newW = Math.max(width, Math.round(width * scale));
        int newH = Math.max(height, Math.round(height * scale));

        Bitmap scaled = Bitmap.createScaledBitmap(crop, newW, newH, true);
        Bitmap enhanced = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(enhanced);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float contrast = 1.48f;
        float translate = (-0.5f * contrast + 0.5f) * 255f;
        ColorMatrix matrix = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        canvas.drawBitmap(scaled, 0, 0, paint);
        if (scaled != crop) scaled.recycle();
        return enhanced;
    }

    private interface OcrCallback {
        void onText(String text);
        void onError(String error);
    }

    private void recognize(Bitmap crop, String mode, OcrCallback cb) {
        TextRecognizer recognizer = getRecognizer(mode);
        InputImage image = InputImage.fromBitmap(crop, 0);
        recognizer.process(image)
                .addOnSuccessListener(result -> cb.onText(result.getText()))
                .addOnFailureListener(e -> cb.onError("Error OCR: " + safeMessage(e)));
    }

    private TextRecognizer getRecognizer(String mode) {
        String key = mode == null ? MODE_ENGLISH : mode;
        TextRecognizer existing = recognizers.get(key);
        if (existing != null) return existing;
        TextRecognizer created;
        if (MODE_CHINESE.equals(key)) {
            created = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        } else if (MODE_JAPANESE.equals(key)) {
            created = TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        } else if (MODE_KOREAN.equals(key)) {
            created = TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        } else {
            created = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        }
        recognizers.put(key, created);
        return created;
    }

    private void translateWhenStable(String text, String sourceLanguage, boolean requireStable, Callback callback) {
        if (requireStable && !acceptStableText(text, sourceLanguage)) {
            callback.onError("Esperando subtítulo estable.");
            return;
        }
        translate(text, sourceLanguage, callback);
    }

    private boolean acceptStableText(String text, String sourceLanguage) {
        String normalized = normalizeKey(normalizeBeforeTranslate(text, sourceLanguage));
        if (normalized.length() == 0) return false;
        long now = System.currentTimeMillis();
        boolean sameMode = sourceLanguage != null && sourceLanguage.equals(pendingStableMode);
        boolean recent = now - pendingStableSince <= 3000L;
        if (sameMode && recent && areSimilarSubtitles(pendingStableKey, normalized)) {
            pendingStableMatches++;
            pendingStableKey = normalized;
        } else {
            pendingStableMode = sourceLanguage == null ? "" : sourceLanguage;
            pendingStableKey = normalized;
            pendingStableMatches = 1;
            pendingStableSince = now;
        }
        return pendingStableMatches >= 2 && now - pendingStableSince >= 350L;
    }

    private boolean areSimilarSubtitles(String a, String b) {
        if (a == null || b == null || a.length() == 0 || b.length() == 0) return false;
        if (a.equals(b)) return true;
        int max = Math.max(a.length(), b.length());
        int min = Math.min(a.length(), b.length());
        if (max - min <= Math.max(2, max / 8) && (a.contains(b) || b.contains(a))) return true;
        return levenshteinDistance(a, b) <= Math.max(1, max / 12);
    }

    private int levenshteinDistance(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[b.length()];
    }

    private void detectLanguageThenTranslate(String text, Callback callback) {
        String guessed = guessFromCharacters(text);
        if (guessed != null) {
            translate(text, guessed, callback);
            return;
        }

        LanguageIdentifier identifier = LanguageIdentification.getClient();
        identifier.identifyLanguage(text)
                .addOnSuccessListener(languageCode -> {
                    identifier.close();
                    String src = mapLanguage(languageCode);
                    if (src == null || "und".equals(languageCode)) src = TranslateLanguage.ENGLISH;
                    translate(text, src, callback);
                })
                .addOnFailureListener(e -> {
                    identifier.close();
                    translate(text, TranslateLanguage.ENGLISH, callback);
                });
    }

    private void translate(String text, String sourceLanguage, Callback callback) {
        String src = sourceLanguage;
        if (MODE_AUTO.equals(src)) src = guessFromCharacters(text);
        if (src == null) src = TranslateLanguage.ENGLISH;

        String cleanForTranslate = normalizeBeforeTranslate(text, src);
        // La traduccion en vivo usa una sola pasada. El contexto duplicaba llamadas y retrasaba la salida.
        String context = null;
        String cacheKey = src + "|" + normalizeKey(cleanForTranslate);
        if (translationCache.containsKey(cacheKey)) {
            String cached = translationCache.get(cacheKey);
            rememberSource(cleanForTranslate, src);
            callback.onSuccess(cleanForTranslate, cached, readable(src));
            return;
        }

        if (TranslateLanguage.SPANISH.equals(src)) {
            rememberSource(cleanForTranslate, src);
            callback.onSuccess(cleanForTranslate, cleanForTranslate, "Español");
            return;
        }

        translateWithMlKit(cleanForTranslate, src, context, cacheKey, callback);
    }

    private void translateWithMlKit(String input, String sourceLanguage, String context,
                                    String cacheKey, Callback callback) {
        if (!isModelReady(sourceLanguage)) {
            callback.onError("Descarga " + readable(sourceLanguage) + " → Español antes de traducir.");
            return;
        }

        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String direct = fallbackEnglishToSpanish(input);
            if (direct != null && !direct.trim().isEmpty()) {
                translationCache.put(cacheKey, direct);
                rememberSource(input, sourceLanguage);
                callback.onSuccess(input, direct, readable(sourceLanguage));
                return;
            }
        }

        Translator translator = getTranslator(sourceLanguage);
        if (context != null) {
            String contextualInput = context + "\n" + CONTEXT_MARKER + "\n" + input;
            translator.translate(contextualInput)
                    .addOnSuccessListener(translated -> {
                        String extracted = extractContextTranslation(translated, input);
                        if (extracted != null) {
                            finishTranslation(input, sourceLanguage, cacheKey, extracted, callback);
                        } else {
                            translateDirect(translator, input, sourceLanguage, cacheKey, callback);
                        }
                    })
                    .addOnFailureListener(e -> translateDirect(
                            translator, input, sourceLanguage, cacheKey, callback));
        } else {
            translateDirect(translator, input, sourceLanguage, cacheKey, callback);
        }
    }

    private void translateDirect(Translator translator, String input, String sourceLanguage,
                                 String cacheKey, Callback callback) {
        translator.translate(input)
                .addOnSuccessListener(translated -> finishTranslation(
                        input, sourceLanguage, cacheKey, translated, callback))
                .addOnFailureListener(e -> callback.onError("Error al traducir: " + safeMessage(e)));
    }

    private void finishTranslation(String input, String sourceLanguage, String cacheKey, String translated, Callback callback) {
        String polished = polishSpanish(translated);
        if (isSuspiciousResult(input, polished, sourceLanguage)
                && TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            String fallback = fallbackEnglishToSpanish(input);
            if (fallback != null && fallback.trim().length() > 0) polished = fallback;
        }
        // No mostramos el original ni una mezcla evidente como si fuera una traducción terminada.
        // En modo Vivo el cuadro conserva la última traducción fiable hasta la siguiente lectura válida.
        if (isSuspiciousResult(input, polished, sourceLanguage)) {
            callback.onError("No se obtuvo una traducción suficientemente confiable.");
            return;
        }
        translationCache.put(cacheKey, polished);
        rememberSource(input, sourceLanguage);
        callback.onSuccess(input, polished, readable(sourceLanguage));
    }

    private boolean isSuspiciousResult(String original, String translated, String sourceLanguage) {
        if (translated == null || translated.trim().isEmpty()) return true;
        if (looksUntranslated(original, translated)) return true;
        if (TranslateLanguage.CHINESE.equals(sourceLanguage)
                || TranslateLanguage.JAPANESE.equals(sourceLanguage)
                || TranslateLanguage.KOREAN.equals(sourceLanguage)) {
            return countMatches(cjkPattern, translated) > 2;
        }
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            int strongEnglish = countStrongEnglishWords(translated);
            int spanishSignals = countSpanishSignals(translated);
            return strongEnglish >= 2 && spanishSignals == 0;
        }
        return false;
    }

    private int countStrongEnglishWords(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "the","this","that","these","those","you","your","yours","he","she","they",
                "we","our","where","when","why","what","who","how","with","from","have","has",
                "had","will","would","could","should","were","was","are","does","did","doing",
                "think","know","want","need","good","right","please","sorry","home"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }

    private int countSpanishSignals(String text) {
        if (text == null) return 0;
        String key = " " + normalizeKey(text) + " ";
        String[] words = new String[]{
                "el","la","los","las","un","una","que","de","del","en","por","para","con",
                "como","qué","dónde","cuando","porque","estoy","está","son","eres","tengo","tiene",
                "quiero","puedo","casa","bien","gracias","pero","muy","ya","aquí","allí"
        };
        int count = 0;
        for (String word : words) if (key.contains(" " + word + " ")) count++;
        return count;
    }

    private String eligibleContext(String current, String sourceLanguage) {
        if (current == null || current.trim().length() == 0) return null;
        if (lastSourceText.length() == 0 || lastSourceLanguage.length() == 0) return null;
        if (!lastSourceLanguage.equals(sourceLanguage)) return null;
        if (System.currentTimeMillis() - lastSourceAt > 9000L) return null;
        if (normalizeKey(lastSourceText).equals(normalizeKey(current))) return null;
        int wordCount = current.trim().split("\\s+").length;
        if (wordCount > 7 || current.length() > 90 || lastSourceText.length() > 180) return null;
        return lastSourceText;
    }

    private String extractContextTranslation(String translated, String currentInput) {
        if (translated == null) return null;
        String upper = translated.toUpperCase(Locale.ROOT);
        int marker = upper.indexOf(CONTEXT_MARKER);
        if (marker < 0) return null;
        String current = translated.substring(marker + CONTEXT_MARKER.length())
                .replaceFirst("^[\\s:;,.!?\\-–—]+", "")
                .trim();
        if (current.length() == 0) return null;
        int maxReasonable = Math.max(80, currentInput.length() * 5);
        if (current.length() > maxReasonable) return null;
        return current;
    }

    private void rememberSource(String text, String sourceLanguage) {
        if (text == null || text.trim().length() == 0 || sourceLanguage == null) return;
        lastSourceText = text.trim();
        lastSourceLanguage = sourceLanguage;
        lastSourceAt = System.currentTimeMillis();
    }

    private Translator getTranslator(String sourceLanguage) {
        Translator existing = translators.get(sourceLanguage);
        if (existing != null) return existing;
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguage)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        Translator created = Translation.getClient(options);
        translators.put(sourceLanguage, created);
        return created;
    }

    private String normalizeBeforeTranslate(String text, String sourceLanguage) {
        if (text == null) return "";
        String t = joinOcrLines(text);
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            t = repairEnglishOcr(t);
            t = normalizeExpressiveEnglish(t);
        }
        return t;
    }

    private String joinOcrLines(String text) {
        if (text == null) return "";
        String[] lines = text.replace("\r", "").split("\n");
        StringBuilder out = new StringBuilder();
        Set<String> seen = new HashSet<>();
        for (String line : lines) {
            String s = line == null ? "" : line.trim();
            if (s.length() == 0) continue;
            String key = normalizeKey(s);
            if (key.length() > 0 && !seen.add(key)) continue;
            if (out.length() > 0) out.append(' ');
            out.append(s);
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    private String repairEnglishOcr(String text) {
        if (text == null) return "";
        String t = text.trim();
        t = stripCjkFromEnglish(t);
        // Une subtítulos con OCR pegado: "athome" debe llegar al traductor como "at home".
        t = t.replaceAll("(?<=[a-z])(?=[A-Z])", " ");
        t = t.replace('’', '\'');
        t = t.replaceAll("(?i)\\bdothes\\b", "clothes");
        t = t.replaceAll("(?i)\\bclathes\\b", "clothes");
        t = t.replaceAll("(?i)\\bexacty\\b", "exactly");
        t = t.replaceAll("(?i)\\bfinisbed\\b", "finished");
        t = t.replaceAll("(?i)\\bleam\\b", "learn");
        t = t.replaceAll("(?i)\\bschoo1\\b", "school");
        t = t.replaceAll("(?i)\\bputyour\\b", "put your");
        t = t.replaceAll("(?i)\\byourclothes\\b", "your clothes");
        t = t.replaceAll("(?i)\\bathome\\b", "at home");
        t = t.replaceAll("(?i)\\batschool\\b", "at school");
        t = t.replaceAll("(?i)\\batwork\\b", "at work");
        t = t.replaceAll("(?i)\\binthe\\b", "in the");
        t = t.replaceAll("(?i)\\bonthe\\b", "on the");
        t = t.replaceAll("(?i)\\bofthe\\b", "of the");
        t = t.replaceAll("(?i)\\btothe\\b", "to the");
        t = t.replaceAll("(?i)\\bforthe\\b", "for the");
        t = t.replaceAll("(?i)\\bfromthe\\b", "from the");
        t = t.replaceAll("(?i)\\bwiththe\\b", "with the");
        t = t.replaceAll("(?i)\\bandthe\\b", "and the");
        t = t.replaceAll("(?i)\\bisnot\\b", "is not");
        t = t.replaceAll("(?i)\\barenot\\b", "are not");
        t = t.replaceAll("(?i)\\bdonot\\b", "do not");
        t = t.replaceAll("(?i)\\bdidnt\\b", "did not");
        t = t.replaceAll("(?i)\\bdoesnt\\b", "does not");
        t = t.replaceAll("(?i)\\bdont\\b", "do not");
        t = t.replaceAll("(?i)\\bcant\\b", "can not");
        t = t.replaceAll("(?i)\\bcannot\\b", "can not");
        t = t.replaceAll("(?i)\\bwont\\b", "will not");
        t = t.replaceAll("(?i)\\bl'm\\b", "I'm");
        t = t.replaceAll("(?i)^l\\s+(?=(love|am|do|did|have|will|can|was|need|want|think|know)\\b)", "I " );
        t = t.replaceAll("(?i)\\bim\\b", "I am");
        t = t.replaceAll("(?i)\\byoure\\b", "you are");
        t = t.replaceAll("(?i)\\bhes\\b", "he is");
        t = t.replaceAll("(?i)\\bshes\\b", "she is");
        t = t.replaceAll("(?i)\\btheyre\\b", "they are");
        t = t.replaceAll("(?i)\\bwheres\\b", "where is");
        t = t.replaceAll("(?i)\\bwhere s\\b", "where is");
        t = t.replaceAll("(?i)\\bwhat s\\b", "what is");
        t = t.replaceAll("(?i)\\bwho s\\b", "who is");
        t = t.replaceAll("[.]{2,}", " ");
        t = t.replaceAll("[^A-Za-z0-9'.,?!:;\\- ]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String normalizeExpressiveEnglish(String text) {
        if (text == null || text.length() == 0) return "";
        Matcher matcher = expressiveWordPattern.matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String original = matcher.group();
            String replacement = normalizeExpressiveWord(original);
            matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private String normalizeExpressiveWord(String word) {
        if (word == null || word.length() < 3 || !hasRunOfThree(word)) return word;
        String lower = word.toLowerCase(Locale.ROOT);
        String maxTwo = collapseRuns(lower, 2);
        String selected = EXPRESSIVE_DICTIONARY.contains(maxTwo) ? maxTwo : findDictionaryVariant(maxTwo, 0, new StringBuilder());
        if (selected == null) selected = maxTwo;
        if (word.equals(word.toUpperCase(Locale.ROOT))) return selected.toUpperCase(Locale.ROOT);
        if (Character.isUpperCase(word.charAt(0))) {
            return Character.toUpperCase(selected.charAt(0)) + selected.substring(1);
        }
        return selected;
    }

    private boolean hasRunOfThree(String word) {
        int run = 1;
        for (int i = 1; i < word.length(); i++) {
            if (Character.toLowerCase(word.charAt(i)) == Character.toLowerCase(word.charAt(i - 1))) {
                run++;
                if (run >= 3) return true;
            } else {
                run = 1;
            }
        }
        return false;
    }

    private String collapseRuns(String word, int maxRun) {
        StringBuilder out = new StringBuilder(word.length());
        char previous = 0;
        int run = 0;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (c == previous) {
                run++;
            } else {
                previous = c;
                run = 1;
            }
            if (run <= maxRun) out.append(c);
        }
        return out.toString();
    }

    private String findDictionaryVariant(String word, int index, StringBuilder built) {
        if (index >= word.length()) {
            String candidate = built.toString();
            return EXPRESSIVE_DICTIONARY.contains(candidate) ? candidate : null;
        }
        char c = word.charAt(index);
        int end = index + 1;
        while (end < word.length() && word.charAt(end) == c) end++;
        int runLength = end - index;
        int originalLength = built.length();

        for (int i = 0; i < runLength; i++) built.append(c);
        String keep = findDictionaryVariant(word, end, built);
        if (keep != null) return keep;
        built.setLength(originalLength);

        if (runLength == 2) {
            built.append(c);
            String reduced = findDictionaryVariant(word, end, built);
            if (reduced != null) return reduced;
            built.setLength(originalLength);
        }
        return null;
    }

    private String stripCjkFromEnglish(String text) {
        if (text == null) return "";
        String t = text;
        // Quita traducciones chinas/japonesas/coreanas entre paréntesis para no contaminar el inglés.
        t = t.replaceAll("\\([^)]*[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF][^)]*\\)", " ");
        t = t.replaceAll("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]+", " ");
        return t;
    }

    private String cleanEnglishLine(String line) {
        if (line == null) return "";
        String s = normalizeExpressiveEnglish(repairEnglishOcr(line));
        s = s.replaceAll("^[^A-Za-z0-9]+", "");
        s = s.replaceAll("[^A-Za-z0-9.?!']+$", "");
        s = s.replaceAll("\\s+", " ").trim();
        return trimEnglishOcrNoise(s);
    }

    /**
     * Recorta basura corta que el OCR latino inventa al intentar leer caracteres chinos.
     * Es una operacion local y rapida: no espera otra captura ni consulta otro modelo.
     */
    private String trimEnglishOcrNoise(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String[] tokens = text.trim().split("\\s+");
        int start = 0;
        int end = tokens.length;
        while (start < end && isSuspiciousOcrToken(tokens[start])) start++;
        while (end > start && isSuspiciousOcrToken(tokens[end - 1])) end--;
        if (start >= end) return "";

        StringBuilder out = new StringBuilder();
        int badRun = 0;
        int goodCount = 0;
        for (int i = start; i < end; i++) {
            String token = tokens[i];
            boolean bad = isSuspiciousOcrToken(token);
            if (bad) {
                badRun++;
                if (goodCount >= 2 && badRun >= 2) break;
            } else {
                badRun = 0;
                goodCount++;
            }
            if (out.length() > 0) out.append(' ');
            out.append(token);
        }
        return out.toString().replaceAll("\\s+", " ").trim();
    }

    private boolean isSuspiciousOcrToken(String token) {
        if (token == null) return true;
        String raw = token.replaceAll("^[^A-Za-z0-9']+|[^A-Za-z0-9']+$", "");
        if (raw.isEmpty()) return true;
        if (raw.matches(".*\\d.*")) return true;
        String lower = raw.toLowerCase(Locale.ROOT).replace("'", "");
        if (lower.equals("a") || lower.equals("i")) return false;
        String commonShort = " ok hi yes no go why who how hey wow bye not the you me my we us he she her him our your his its mr ms dr ";
        if (commonShort.contains(" " + lower + " ")) return false;
        String contractions = " im ive ill id youre hes shes theyre were dont didnt doesnt cant wont isnt arent wasnt werent thats whats wheres whos lets ";
        if (contractions.contains(" " + lower + " ")) return false;
        if (lower.length() <= 2) {
            String allowed = " am an as at be by do go he if in is it me my no of oh on or so to up us we ";
            return !allowed.contains(" " + lower + " ");
        }
        if (lower.length() >= 4 && !lower.matches(".*[aeiouy].*")) return true;
        return raw.equals(raw.toUpperCase(Locale.ROOT)) && raw.length() <= 3;
    }

    private boolean isGoodEnglishLine(String s) {
        if (s == null) return false;
        String key = normalizeKey(s);
        if (key.length() < 2) return false;
        int words = countEnglishWords(s);
        if (words >= 2) return true;
        return commonEnglishWordScore(s) > 0 || key.equals("at home") || key.equals("thank you");
    }

    private int scoreEnglishLine(String s) {
        if (s == null) return -9999;
        String k = normalizeKey(s);
        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        int score = Math.min(s.length(), 120) + words * 14 + common * 26;
        if (s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",")) score += 14;
        if (words <= 2 && common == 0) score -= 80;
        if (isLikelySpanishLine(s)) score -= 180;
        return score;
    }

    private boolean isBadEnglishFalsePositive(String s) {
        if (s == null) return true;
        String k = normalizeKey(s);
        if (k.length() == 0) return true;

        int words = countEnglishWords(s);
        int common = commonEnglishWordScore(s);
        boolean hasSentenceMark = s.contains("?") || s.contains("!") || s.contains(".") || s.contains(",") || s.contains("'");
        boolean looksLikeTitle = words <= 3 && common == 0 && !s.matches(".*[a-z].*[a-z].*");
        boolean tooShortWithoutContext = words <= 2 && common == 0;
        return looksLikeTitle || (tooShortWithoutContext && !hasSentenceMark);
    }

    private int commonEnglishWordScore(String s) {
        String k = normalizeKey(s);
        if (k.length() == 0) return 0;
        String[] common = new String[]{
                "i","you","he","she","we","they","the","a","an","is","are","am","was","were",
                "do","does","did","not","dont","know","what","where","when","why","how",
                "mom","mother","father","home","clothes","put","on","in","at","to","for",
                "your","my","me","anything","good","great","yes","yeah","no","so","please",
                "cool","really","very","okay","ok","wow","hello","hey","sorry","stop","wait","right","fine",
                "finished","finish","work","learn","learned","school","almost","done","even","give","student",
                "status","introduced","here","bathroom","still","already","never","again","today","tomorrow"
        };
        int count = 0;
        for (String w : common) {
            if (k.equals(w) || k.contains(" " + w + " ") || k.startsWith(w + " ") || k.endsWith(" " + w)) count++;
        }
        return count;
    }

    private boolean isLikelySpanishLine(String s) {
        if (s == null) return false;
        String k = normalizeKey(s);
        return s.contains("¿") || s.contains("¡")
                || k.contains(" que ")
                || k.startsWith("que ")
                || k.contains(" donde ")
                || k.contains(" dónde ")
                || k.contains(" esta ")
                || k.contains(" está ")
                || k.contains(" ropa")
                || k.contains(" mama")
                || k.contains(" mamá")
                || k.contains(" nada")
                || k.contains(" casa")
                || k.contains(" fing");
    }

    private int countEnglishWords(String s) {
        if (s == null) return 0;
        java.util.regex.Matcher m = Pattern.compile("[A-Za-z]{2,}").matcher(s);
        int count = 0;
        while (m.find()) count++;
        return count;
    }

    private String cleanCjkLine(String line) {
        if (line == null) return "";
        String s = line;
        // Si hay inglés + CJK en una misma línea, conserva la parte CJK para OCR chino/japonés/coreano.
        s = s.replaceAll("[A-Za-z0-9][A-Za-z0-9'.,?!:;\\- ]+", " ");
        s = s.replaceAll("[()\\[\\]{}]", " ");
        s = s.replaceAll("\\s+", " ").trim();
        return s;
    }

    private boolean looksUntranslated(String original, String translated) {
        if (original == null || translated == null) return false;
        String a = normalizeKey(original);
        String b = normalizeKey(translated);
        if (a.length() == 0 || b.length() == 0) return false;
        return a.equals(b) || (b.contains(a) && b.length() <= a.length() + 4);
    }

    private String fallbackEnglishToSpanish(String text) {
        String k = normalizeKey(text);
        if (k.equals("at home")) return "En casa";
        if (k.equals("i am at home")) return "Estoy en casa";
        if (k.equals("i m at home")) return "Estoy en casa";
        if (k.equals("i am at school")) return "Estoy en la escuela";
        if (k.equals("i am at work")) return "Estoy en el trabajo";
        if (k.equals("good morning")) return "Buenos días";
        if (k.equals("good night")) return "Buenas noches";
        if (k.equals("thank you")) return "Gracias";
        if (k.equals("what are you doing")) return "¿Qué estás haciendo?";
        if (k.equals("where are you")) return "¿Dónde estás?";
        return null;
    }

    private String normalizeKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9áéíóúñü]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String cleanText(String raw, String mode) {
        if (raw == null) return "";
        String[] lines = raw.replace("\r", "").split("\n");
        StringBuilder cjk = new StringBuilder();
        StringBuilder all = new StringBuilder();
        List<String> englishLines = new ArrayList<>();

        for (String line : lines) {
            String s = line.trim();
            if (s.length() == 0) continue;
            String lower = s.toLowerCase(Locale.ROOT);
            if (isWatermarkOrUi(s, lower)) continue;

            if (MODE_ENGLISH.equals(mode)) {
                String e = cleanEnglishLine(s);
                if (e.length() == 0) continue;

                // Antes se elegía solo la “mejor” línea y por eso se perdían líneas de subtítulos largos.
                // Ahora se conservan todas las líneas útiles dentro del cuadro OCR.
                if (!isLikelySpanishLine(e) && !isBadEnglishFalsePositive(e)) {
                    if (isGoodEnglishLine(e) || commonEnglishWordScore(e) > 0) {
                        englishLines.add(e);
                    }
                }
                continue;
            }

            if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) {
                String onlyCjk = cleanCjkLine(s);
                if (cjkPattern.matcher(onlyCjk).find()) {
                    cjk.append(onlyCjk).append('\n');
                    continue;
                }
            }
            all.append(s).append('\n');
        }

        // Inglés: conserva como máximo las dos líneas más probables del subtítulo y respeta su orden.
        if (MODE_ENGLISH.equals(mode) && !englishLines.isEmpty()) {
            return selectBestEnglishLines(englishLines);
        }
        // CJK: devolver todas las líneas chinas/japonesas/coreanas detectadas.
        if ((MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) && cjk.length() > 0) {
            return cjk.toString().trim();
        }
        return all.toString().trim();
    }

    private String selectBestEnglishLines(List<String> lines) {
        if (lines == null || lines.isEmpty()) return "";
        int bestStart = 0;
        int bestEnd = 0;
        int bestScore = scoreEnglishLine(lines.get(0));

        for (int i = 0; i < lines.size(); i++) {
            int single = scoreEnglishLine(lines.get(i));
            if (single > bestScore) {
                bestScore = single;
                bestStart = i;
                bestEnd = i;
            }
            if (i + 1 < lines.size()) {
                int pair = single + scoreEnglishLine(lines.get(i + 1)) + 18;
                if (pair > bestScore) {
                    bestScore = pair;
                    bestStart = i;
                    bestEnd = i + 1;
                }
            }
        }

        StringBuilder out = new StringBuilder();
        for (int i = bestStart; i <= bestEnd; i++) {
            if (out.length() > 0) out.append(' ');
            out.append(lines.get(i));
        }
        return trimEnglishOcrNoise(out.toString().replaceAll("\\s+", " ").trim());
    }

    private boolean isWatermarkOrUi(String s, String lower) {
        return lower.contains("video eagle")
                || lower.contains("tencent")
                || lower.contains("zeta live translator")
                || lower.contains("ocr solo")
                || lower.contains("order by")
                || lower.contains("date added")
                || lower.contains("date published")
                || lower.contains("popular:")
                || lower.contains("mother language")
                || lower.contains("spanish order")
                || lower.contains("auto") && lower.contains("español")
                || lower.contains("chino") && lower.contains("es")
                || lower.contains("inglés") && lower.contains("es")
                || lower.contains("japonés") && lower.contains("es")
                || lower.contains("coreano") && lower.contains("es")
                || lower.equals("área")
                || lower.equals("trad.")
                || lower.equals("vivo")
                || lower.equals("pausa")
                || lower.equals("ok")
                || s.contains("腾讯视频")
                || s.contains("出品")
                || s.contains("云曦星空")
                || s.contains("AI专属");
    }

    private String polishSpanish(String translated) {
        if (translated == null) return "";
        String t = translated.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
        if (t.length() == 0) return t;
        return t.substring(0, 1).toUpperCase(Locale.ROOT) + t.substring(1);
    }

    private String guessFromCharacters(String text) {
        if (text == null) return null;
        if (koreanPattern.matcher(text).find()) return TranslateLanguage.KOREAN;
        if (japanesePattern.matcher(text).find()) return TranslateLanguage.JAPANESE;
        if (chinesePattern.matcher(text).find()) return TranslateLanguage.CHINESE;
        if (latinPattern.matcher(text).find()) return TranslateLanguage.ENGLISH;
        return null;
    }

    private String mapLanguage(String languageCode) {
        if (languageCode == null) return null;
        if (languageCode.startsWith("zh")) return TranslateLanguage.CHINESE;
        if (languageCode.startsWith("en")) return TranslateLanguage.ENGLISH;
        if (languageCode.startsWith("ja")) return TranslateLanguage.JAPANESE;
        if (languageCode.startsWith("ko")) return TranslateLanguage.KOREAN;
        if (languageCode.startsWith("es")) return TranslateLanguage.SPANISH;
        return null;
    }

    public void close() {
        for (TextRecognizer recognizer : recognizers.values()) {
            try { recognizer.close(); } catch (Exception ignored) { }
        }
        recognizers.clear();
        for (Translator translator : translators.values()) {
            try { translator.close(); } catch (Exception ignored) { }
        }
        translators.clear();
        translationCache.clear();
        resetStabilityState();
        resetContextState();
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) return "desconocido";
        return e.getMessage();
    }

    public String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        if (TranslateLanguage.SPANISH.equals(code)) return "Español";
        return code == null ? "Auto" : code;
    }
}
