package com.geozeta.livetranslator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 501;
    private static final int REQ_NOTIFICATIONS = 502;

    public static final String PREFS = "zeta_live_translator";
    public static final String KEY_MODEL_PREFIX = "model_pair_ready_";
    private static final String KEY_FIRST_RUN = "first_run_v21";

    private static final int BG = 0xFF0B0E13;
    private static final int SURFACE = 0xFF151A21;
    private static final int SURFACE_ALT = 0xFF1C232D;
    private static final int BORDER = 0xFF2C3542;
    private static final int TEXT = 0xFFF6F7F9;
    private static final int MUTED = 0xFFAAB4C3;
    private static final int ACCENT = 0xFF4F8CFF;
    private static final int SUCCESS = 0xFF31C48D;
    private static final int WARNING = 0xFFF0B429;
    private static final int ERROR = 0xFFF97066;

    private SharedPreferences prefs;
    private Button startButton;
    private Button permissionsButton;
    private TextView globalTitle;
    private TextView globalDetail;
    private TextView installedCount;
    private ProgressBar activeProgress;
    private TextView downloadStatusLine;
    private TextView downloadMetaLine;
    private Button downloadControlButton;
    private boolean receiverRegistered;

    private final String[] languageCodes = new String[]{
            TranslateLanguage.ENGLISH,
            TranslateLanguage.CHINESE,
            TranslateLanguage.JAPANESE,
            TranslateLanguage.KOREAN
    };
    private final String[] languageNames = new String[]{
            "Inglés → Español",
            "Chino → Español",
            "Japonés → Español",
            "Coreano → Español"
    };
    private final String[] languageNotes = new String[]{
            "Recomendado para comenzar y para subtítulos bilingües.",
            "Descárgalo solo cuando vayas a traducir chino.",
            "Descárgalo solo cuando vayas a traducir japonés.",
            "Descárgalo solo cuando vayas a traducir coreano."
    };

    private final TextView[] stateBadges = new TextView[4];
    private final Button[] downloadButtons = new Button[4];
    private final RemoteModelManager remoteModelManager = RemoteModelManager.getInstance();

    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (DownloadModelService.ACTION_STATUS.equals(intent.getAction())) refreshUi();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        migrateLegacyModelState();
        buildUi();
        refreshUi();
        verifyActualModels();
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(DownloadModelService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(downloadReceiver, filter);
        }
        receiverRegistered = true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
        verifyActualModels();
        if (!prefs.getBoolean(KEY_FIRST_RUN, false)) {
            prefs.edit().putBoolean(KEY_FIRST_RUN, true).apply();
            findViewById(android.R.id.content).post(this::showFirstRunDialog);
        }
    }

    @Override
    protected void onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        super.onStop();
    }

    private void migrateLegacyModelState() {
        if (!prefs.getBoolean("models_ready", false)) return;
        SharedPreferences.Editor editor = prefs.edit();
        for (String code : languageCodes) editor.putBoolean(modelKey(code), true);
        editor.apply();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView eyebrow = label("TRADUCTOR OFFLINE ESTABLE", 11, ACCENT, true);
        eyebrow.setLetterSpacing(0.12f);
        root.addView(eyebrow);

        TextView title = label("Zeta Live Translator", 27, TEXT, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(5);
        root.addView(title, titleLp);

        TextView intro = label(
                "Descarga únicamente el idioma que vas a usar. La app funciona desde el primer modelo instalado y nunca carga varios traductores grandes a la vez.",
                14, MUTED, false);
        intro.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = dp(7);
        root.addView(intro, introLp);

        LinearLayout statusCard = card();
        globalTitle = label("Preparando estado", 19, TEXT, true);
        statusCard.addView(globalTitle);
        globalDetail = label("Comprobando permisos y modelos instalados.", 13, MUTED, false);
        LinearLayout.LayoutParams globalDetailLp = new LinearLayout.LayoutParams(-1, -2);
        globalDetailLp.topMargin = dp(7);
        statusCard.addView(globalDetail, globalDetailLp);
        installedCount = badge("0 idiomas listos", WARNING);
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(-2, -2);
        countLp.topMargin = dp(13);
        statusCard.addView(installedCount, countLp);
        root.addView(statusCard, topMargin(16));

        permissionsButton = primaryButton("Revisar permisos");
        permissionsButton.setOnClickListener(v -> beginPermissionFlow());
        root.addView(permissionsButton, topMargin(14));

        startButton = secondaryButton("Iniciar traductor");
        startButton.setOnClickListener(v -> startCaptureFlow());
        root.addView(startButton, topMargin(10));

        LinearLayout modelsCard = card();
        modelsCard.addView(label("Modelos por idioma", 19, TEXT, true));
        TextView modelsHint = label(
                "ML Kit no informa bytes ni porcentaje. Por eso se muestran tiempo, conexión, etapa real y verificación final, sin inventar progreso.",
                13, MUTED, false);
        modelsHint.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
        hintLp.topMargin = dp(7);
        modelsCard.addView(modelsHint, hintLp);

        activeProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        activeProgress.setIndeterminate(true);
        activeProgress.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
        activeProgress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(5));
        progressLp.topMargin = dp(14);
        modelsCard.addView(activeProgress, progressLp);

        downloadStatusLine = label("Sin descarga activa", 13, TEXT, true);
        downloadStatusLine.setVisibility(View.GONE);
        LinearLayout.LayoutParams downloadStatusLp = new LinearLayout.LayoutParams(-1, -2);
        downloadStatusLp.topMargin = dp(11);
        modelsCard.addView(downloadStatusLine, downloadStatusLp);

        downloadMetaLine = label("", 12, MUTED, false);
        downloadMetaLine.setVisibility(View.GONE);
        LinearLayout.LayoutParams downloadMetaLp = new LinearLayout.LayoutParams(-1, -2);
        downloadMetaLp.topMargin = dp(5);
        modelsCard.addView(downloadMetaLine, downloadMetaLp);

        downloadControlButton = smallButton("Detener seguimiento");
        downloadControlButton.setVisibility(View.GONE);
        downloadControlButton.setOnClickListener(v -> handleDownloadControl());
        LinearLayout.LayoutParams downloadControlLp = new LinearLayout.LayoutParams(-1, dp(44));
        downloadControlLp.topMargin = dp(10);
        modelsCard.addView(downloadControlButton, downloadControlLp);

        for (int i = 0; i < languageCodes.length; i++) {
            modelsCard.addView(buildLanguageRow(i), topMargin(i == 0 ? 15 : 12));
        }
        root.addView(modelsCard, topMargin(16));

        LinearLayout behaviorCard = card();
        behaviorCard.addView(label("Funcionamiento", 19, TEXT, true));
        addBullet(behaviorCard, "Si instalas solo Inglés, puedes probar inmediatamente Inglés o Auto.");
        addBullet(behaviorCard, "Auto prioriza Inglés y solo considera idiomas instalados.");
        addBullet(behaviorCard, "La selección manual procesa únicamente el idioma elegido.");
        addBullet(behaviorCard, "El cuadro negro aparece desde el inicio con “Esperando subtítulo…”.");
        addBullet(behaviorCard, "Zeta ya no marca sus ventanas como contenido privado.");
        root.addView(behaviorCard, topMargin(16));

        setContentView(scroll);
    }

    private LinearLayout buildLanguageRow(int index) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        row.setBackground(roundRect(SURFACE_ALT, BORDER, 14));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = label(languageNames[index], 16, TEXT, true);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));

        stateBadges[index] = badge("No instalado", WARNING);
        top.addView(stateBadges[index]);
        row.addView(top);

        TextView note = label(languageNotes[index], 12, MUTED, false);
        note.setLineSpacing(0f, 1.1f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(7);
        row.addView(note, noteLp);

        downloadButtons[index] = smallButton(index == 0 ? "Descargar Inglés" : "Descargar");
        final int languageIndex = index;
        downloadButtons[index].setOnClickListener(v -> downloadLanguage(languageIndex));
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1, dp(46));
        buttonLp.topMargin = dp(11);
        row.addView(downloadButtons[index], buttonLp);
        return row;
    }

    private void showFirstRunDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Empieza por Inglés")
                .setMessage("Concede los permisos y descarga únicamente Inglés → Español. Podrás probar el traductor sin esperar los otros idiomas.")
                .setPositiveButton("Revisar permisos", (dialog, which) -> beginPermissionFlow())
                .setNegativeButton("Ahora no", null)
                .show();
    }

    private void beginPermissionFlow() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        toast("Permisos principales listos.");
        refreshUi();
    }

    private void downloadLanguage(int index) {
        if (isDownloadActive()) {
            toast("Ya hay una descarga en curso.");
            return;
        }
        if (isModelReady(languageCodes[index])) {
            toast(languageNames[index] + " ya está listo.");
            return;
        }
        if (!isNetworkAvailable()) {
            updateGlobal("Sin conexión", "Conéctate a internet y vuelve a tocar Descargar.");
            return;
        }
        if (!hasEnoughStorage()) {
            updateGlobal("Espacio insuficiente", "Libera al menos 150 MB y vuelve a intentarlo.");
            toast("No hay espacio libre suficiente.");
            return;
        }

        prefs.edit()
                .putBoolean(DownloadModelService.KEY_ACTIVE, true)
                .putInt(DownloadModelService.KEY_ACTIVE_INDEX, index)
                .putString(DownloadModelService.KEY_ACTIVE_CODE, languageCodes[index])
                .putString(DownloadModelService.KEY_ACTIVE_NAME, languageNames[index])
                .putString(DownloadModelService.KEY_STATE, DownloadModelService.STATE_CHECKING)
                .putString(DownloadModelService.KEY_MESSAGE, "Iniciando comprobación…")
                .putLong(DownloadModelService.KEY_STARTED_AT, System.currentTimeMillis())
                .putInt(DownloadModelService.KEY_STAGE, 0)
                .putInt(DownloadModelService.KEY_STAGE_TOTAL, TranslateLanguage.ENGLISH.equals(languageCodes[index]) ? 1 : 2)
                .putString(DownloadModelService.KEY_CONNECTION, connectionLabel())
                .apply();

        Intent service = new Intent(this, DownloadModelService.class);
        service.setAction(DownloadModelService.ACTION_START);
        service.putExtra(DownloadModelService.EXTRA_INDEX, index);
        service.putExtra(DownloadModelService.EXTRA_CODE, languageCodes[index]);
        service.putExtra(DownloadModelService.EXTRA_NAME, languageNames[index]);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);
        refreshUi();
    }

    private void startCaptureFlow() {
        if (installedModels() == 0) {
            updateGlobal("Falta un idioma", "Descarga por lo menos Inglés → Español antes de iniciar.");
            toast("Descarga por lo menos un idioma.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            updateGlobal("Falta permiso", "Activa “Mostrar sobre otras apps” para usar la barra flotante.");
            beginPermissionFlow();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, OverlayTranslatorService.class);
            service.putExtra(OverlayTranslatorService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(OverlayTranslatorService.EXTRA_DATA, data);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
            updateGlobal("Traductor iniciado", "Ajusta el cuadro morado y pulsa Trad. o Vivo.");
            moveTaskToBack(true);
        } else {
            updateGlobal("Captura cancelada", "Android no concedió el permiso de captura.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                refreshUi();
            }
        }
    }

    private void refreshUi() {
        int installed = installedModels();
        boolean overlayReady = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        boolean downloadActive = isDownloadActive();
        int activeIndex = prefs.getInt(DownloadModelService.KEY_ACTIVE_INDEX, -1);
        String downloadState = prefs.getString(DownloadModelService.KEY_STATE, DownloadModelService.STATE_IDLE);
        String downloadName = prefs.getString(DownloadModelService.KEY_ACTIVE_NAME, "");
        String downloadMessage = prefs.getString(DownloadModelService.KEY_MESSAGE, "");
        int stage = prefs.getInt(DownloadModelService.KEY_STAGE, 0);
        int stageTotal = prefs.getInt(DownloadModelService.KEY_STAGE_TOTAL, 0);
        String connection = prefs.getString(DownloadModelService.KEY_CONNECTION, connectionLabel());
        long startedAt = prefs.getLong(DownloadModelService.KEY_STARTED_AT, 0L);
        long elapsed = startedAt > 0L ? Math.max(0L, System.currentTimeMillis() - startedAt) : 0L;

        installedCount.setText(installed + (installed == 1 ? " idioma listo" : " idiomas listos"));
        styleBadge(installedCount, installed > 0 ? SUCCESS : WARNING);

        for (int i = 0; i < languageCodes.length; i++) {
            boolean ready = isModelReady(languageCodes[i]);
            boolean downloading = downloadActive && activeIndex == i;
            stateBadges[i].setText(ready ? "Listo" : (downloading ? stateLabel(downloadState) : "No instalado"));
            styleBadge(stateBadges[i], ready ? SUCCESS : (downloading ? ACCENT : WARNING));
            downloadButtons[i].setText(ready ? "Instalado" : (downloading ? "En proceso…" : (i == 0 ? "Descargar Inglés" : "Descargar")));
            downloadButtons[i].setEnabled(!downloadActive && !ready);
            downloadButtons[i].setAlpha(downloadButtons[i].isEnabled() ? 1f : 0.55f);
        }

        boolean showDownloadPanel = downloadActive
                || DownloadModelService.STATE_ERROR.equals(downloadState)
                || DownloadModelService.STATE_STOPPED.equals(downloadState)
                || DownloadModelService.STATE_READY.equals(downloadState);
        activeProgress.setVisibility(downloadActive ? View.VISIBLE : View.GONE);
        downloadStatusLine.setVisibility(showDownloadPanel ? View.VISIBLE : View.GONE);
        downloadMetaLine.setVisibility(showDownloadPanel ? View.VISIBLE : View.GONE);
        downloadControlButton.setVisibility((downloadActive
                || DownloadModelService.STATE_ERROR.equals(downloadState)
                || DownloadModelService.STATE_STOPPED.equals(downloadState)) ? View.VISIBLE : View.GONE);

        if (showDownloadPanel) {
            String title = downloadName.isEmpty() ? "Descarga de modelo" : downloadName;
            downloadStatusLine.setText(stateLabel(downloadState) + " · " + title);
            String stageText = stageTotal > 0 ? "Etapa " + Math.min(stage + (downloadActive ? 1 : 0), stageTotal) + " de " + stageTotal : "Preparando";
            downloadMetaLine.setText(stageText + "  ·  " + formatElapsed(elapsed) + "  ·  " + connection + "\n" + downloadMessage);
            downloadControlButton.setText(downloadActive ? "Detener seguimiento" : "Reintentar");
        }

        startButton.setEnabled(installed > 0 && overlayReady && !downloadActive);
        startButton.setAlpha(startButton.isEnabled() ? 1f : 0.5f);
        permissionsButton.setText(overlayReady ? "Permisos listos" : "Revisar permisos");

        if (downloadActive) {
            updateGlobal(stateLabel(downloadState) + " " + downloadName,
                    downloadMessage + " Tiempo: " + formatElapsed(elapsed) + ". Conexión: " + connection + ".");
        } else if (DownloadModelService.STATE_ERROR.equals(downloadState)) {
            updateGlobal("Falló la descarga", downloadMessage);
        } else if (DownloadModelService.STATE_STOPPED.equals(downloadState)) {
            updateGlobal("Seguimiento detenido", downloadMessage);
        } else if (DownloadModelService.STATE_READY.equals(downloadState)) {
            updateGlobal("Modelo instalado", downloadMessage);
        } else if (installed == 0) {
            updateGlobal("Descarga un idioma", "Empieza por Inglés → Español para probar la app sin esperar los demás.");
        } else if (!overlayReady) {
            updateGlobal("Falta un permiso", "Activa “Mostrar sobre otras apps”. Tus modelos ya están guardados.");
        } else {
            updateGlobal("Listo para traducir", "Tienes " + installed + " idioma(s) instalado(s). Puedes iniciar ahora.");
        }
    }

    private int installedModels() {
        int count = 0;
        for (String code : languageCodes) if (isModelReady(code)) count++;
        return count;
    }

    private boolean isModelReady(String source) {
        return prefs.getBoolean(modelKey(source), false);
    }

    private String modelKey(String source) {
        return KEY_MODEL_PREFIX + source;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }


    private boolean hasEnoughStorage() {
        try {
            return getFilesDir().getUsableSpace() >= 150L * 1024L * 1024L;
        } catch (Exception ignored) {
            return true;
        }
    }

    private void handleDownloadControl() {
        String currentState = prefs.getString(DownloadModelService.KEY_STATE, DownloadModelService.STATE_IDLE);
        if (isDownloadActive()) {
            Intent stop = new Intent(this, DownloadModelService.class);
            stop.setAction(DownloadModelService.ACTION_STOP);
            startService(stop);
            return;
        }
        if (DownloadModelService.STATE_ERROR.equals(currentState)
                || DownloadModelService.STATE_STOPPED.equals(currentState)) {
            int index = prefs.getInt(DownloadModelService.KEY_ACTIVE_INDEX, -1);
            if (index >= 0 && index < languageCodes.length) downloadLanguage(index);
        }
    }

    private boolean isDownloadActive() {
        return prefs.getBoolean(DownloadModelService.KEY_ACTIVE, false);
    }

    private String stateLabel(String state) {
        if (DownloadModelService.STATE_CHECKING.equals(state)) return "Comprobando";
        if (DownloadModelService.STATE_DOWNLOADING.equals(state)) return "Descargando";
        if (DownloadModelService.STATE_VERIFYING.equals(state)) return "Verificando";
        if (DownloadModelService.STATE_READY.equals(state)) return "Listo";
        if (DownloadModelService.STATE_ERROR.equals(state)) return "Error";
        if (DownloadModelService.STATE_STOPPED.equals(state)) return "Detenido";
        return "Preparando";
    }

    private String connectionLabel() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return "Sin conexión";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return "Sin conexión";
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "Sin conexión";
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) return "Red sin internet";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi‑Fi";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Datos móviles";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            return "Internet disponible";
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null || !info.isConnected()) return "Sin conexión";
        return info.getType() == ConnectivityManager.TYPE_WIFI ? "Wi‑Fi" : "Datos móviles";
    }

    private String formatElapsed(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        return String.format(Locale.US, "%02d:%02d", totalSeconds / 60L, totalSeconds % 60L);
    }

    private void verifyActualModels() {
        verifyPairAt(0);
    }

    private void verifyPairAt(int index) {
        if (index >= languageCodes.length) {
            refreshUi();
            return;
        }
        verifyRemoteModel(TranslateLanguage.SPANISH, spanishReady -> {
            if (!spanishReady) {
                prefs.edit().putBoolean(modelKey(languageCodes[index]), false).apply();
                verifyPairAt(index + 1);
                return;
            }
            if (TranslateLanguage.ENGLISH.equals(languageCodes[index])) {
                prefs.edit().putBoolean(modelKey(languageCodes[index]), true).apply();
                verifyPairAt(index + 1);
                return;
            }
            verifyRemoteModel(languageCodes[index], sourceReady -> {
                prefs.edit().putBoolean(modelKey(languageCodes[index]), sourceReady).apply();
                verifyPairAt(index + 1);
            });
        });
    }

    private void verifyRemoteModel(String languageCode, ModelCheckCallback callback) {
        TranslateRemoteModel model = new TranslateRemoteModel.Builder(languageCode).build();
        remoteModelManager.isModelDownloaded(model)
                .addOnSuccessListener(result -> callback.onResult(Boolean.TRUE.equals(result)))
                .addOnFailureListener(error -> callback.onResult(false));
    }

    private interface ModelCheckCallback {
        void onResult(boolean ready);
    }

    private void updateGlobal(String title, String detail) {
        globalTitle.setText(title);
        globalDetail.setText(detail);
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(17), dp(17), dp(17));
        card.setBackground(roundRect(SURFACE, BORDER, 18));
        return card;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private TextView badge(String value, int color) {
        TextView view = label(value, 12, color, true);
        view.setPadding(dp(10), dp(6), dp(10), dp(6));
        styleBadge(view, color);
        return view;
    }

    private void styleBadge(TextView view, int color) {
        int translucent;
        if (color == SUCCESS) translucent = 0x222FC58D;
        else if (color == ACCENT) translucent = 0x224F8CFF;
        else if (color == ERROR) translucent = 0x22F97066;
        else translucent = 0x22F0B429;
        view.setTextColor(color);
        view.setBackground(roundRect(translucent, color, 999));
    }

    private Button primaryButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(16);
        b.setTextColor(0xFFFFFFFF);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(roundRect(ACCENT, ACCENT, 16));
        return b;
    }

    private Button secondaryButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(16);
        b.setTextColor(TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(roundRect(SURFACE_ALT, BORDER, 16));
        return b;
    }

    private Button smallButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(14);
        b.setTextColor(TEXT);
        b.setAllCaps(false);
        b.setBackground(roundRect(0xFF263142, BORDER, 13));
        return b;
    }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams topMargin(int margin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(margin);
        return lp;
    }

    private void addBullet(LinearLayout parent, String text) {
        TextView bullet = label("• " + text, 13, MUTED, false);
        bullet.setLineSpacing(0f, 1.12f);
        parent.addView(bullet, topMargin(9));
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
