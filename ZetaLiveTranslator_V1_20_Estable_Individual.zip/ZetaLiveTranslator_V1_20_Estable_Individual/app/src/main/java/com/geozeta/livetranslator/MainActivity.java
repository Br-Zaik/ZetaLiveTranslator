package com.geozeta.livetranslator;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 501;
    private static final int REQ_NOTIFICATIONS = 502;

    public static final String PREFS = "zeta_live_translator";
    public static final String KEY_MODEL_PREFIX = "model_pair_ready_";
    private static final String KEY_FIRST_RUN = "first_run_v20";

    private static final int BG = 0xFF0B0E13;
    private static final int SURFACE = 0xFF151A21;
    private static final int SURFACE_ALT = 0xFF1C232D;
    private static final int BORDER = 0xFF2C3542;
    private static final int TEXT = 0xFFF6F7F9;
    private static final int MUTED = 0xFFAAB4C3;
    private static final int ACCENT = 0xFF4F8CFF;
    private static final int SUCCESS = 0xFF31C48D;
    private static final int WARNING = 0xFFF0B429;
    private static final int ERROR = 0xFFF97066;

    private SharedPreferences prefs;
    private Button startButton;
    private Button permissionsButton;
    private TextView globalTitle;
    private TextView globalDetail;
    private TextView installedCount;
    private ProgressBar activeProgress;

    private final String[] languageCodes = new String[]{
            TranslateLanguage.ENGLISH,
            TranslateLanguage.CHINESE,
            TranslateLanguage.JAPANESE,
            TranslateLanguage.KOREAN
    };
    private final String[] languageNames = new String[]{
            "Inglés → Español",
            "Chino → Español",
            "Japonés → Español",
            "Coreano → Español"
    };
    private final String[] languageNotes = new String[]{
            "Recomendado para comenzar y para subtítulos bilingües.",
            "Descárgalo solo cuando vayas a traducir chino.",
            "Descárgalo solo cuando vayas a traducir japonés.",
            "Descárgalo solo cuando vayas a traducir coreano."
    };

    private final TextView[] stateBadges = new TextView[4];
    private final Button[] downloadButtons = new Button[4];
    private Translator activeTranslator;
    private int activeDownloadIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        migrateLegacyModelState();
        buildUi();
        refreshUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
        if (!prefs.getBoolean(KEY_FIRST_RUN, false)) {
            prefs.edit().putBoolean(KEY_FIRST_RUN, true).apply();
            findViewById(android.R.id.content).post(this::showFirstRunDialog);
        }
    }

    @Override
    protected void onDestroy() {
        closeActiveTranslator();
        super.onDestroy();
    }

    private void migrateLegacyModelState() {
        if (!prefs.getBoolean("models_ready", false)) return;
        SharedPreferences.Editor editor = prefs.edit();
        for (String code : languageCodes) editor.putBoolean(modelKey(code), true);
        editor.apply();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView eyebrow = label("TRADUCTOR OFFLINE ESTABLE", 11, ACCENT, true);
        eyebrow.setLetterSpacing(0.12f);
        root.addView(eyebrow);

        TextView title = label("Zeta Live Translator", 27, TEXT, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(5);
        root.addView(title, titleLp);

        TextView intro = label(
                "Descarga únicamente el idioma que vas a usar. La app funciona desde el primer modelo instalado y nunca carga varios traductores grandes a la vez.",
                14, MUTED, false);
        intro.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = dp(7);
        root.addView(intro, introLp);

        LinearLayout statusCard = card();
        globalTitle = label("Preparando estado", 19, TEXT, true);
        statusCard.addView(globalTitle);
        globalDetail = label("Comprobando permisos y modelos instalados.", 13, MUTED, false);
        LinearLayout.LayoutParams globalDetailLp = new LinearLayout.LayoutParams(-1, -2);
        globalDetailLp.topMargin = dp(7);
        statusCard.addView(globalDetail, globalDetailLp);
        installedCount = badge("0 idiomas listos", WARNING);
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(-2, -2);
        countLp.topMargin = dp(13);
        statusCard.addView(installedCount, countLp);
        root.addView(statusCard, topMargin(16));

        permissionsButton = primaryButton("Revisar permisos");
        permissionsButton.setOnClickListener(v -> beginPermissionFlow());
        root.addView(permissionsButton, topMargin(14));

        startButton = secondaryButton("Iniciar traductor");
        startButton.setOnClickListener(v -> startCaptureFlow());
        root.addView(startButton, topMargin(10));

        LinearLayout modelsCard = card();
        modelsCard.addView(label("Modelos por idioma", 19, TEXT, true));
        TextView modelsHint = label(
                "No existe un porcentaje real de bytes porque ML Kit no lo proporciona. Cada fila cambia de Descargando a Listo cuando el modelo queda instalado de verdad.",
                13, MUTED, false);
        modelsHint.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
        hintLp.topMargin = dp(7);
        modelsCard.addView(modelsHint, hintLp);

        activeProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        activeProgress.setIndeterminate(true);
        activeProgress.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
        activeProgress.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, dp(5));
        progressLp.topMargin = dp(14);
        modelsCard.addView(activeProgress, progressLp);

        for (int i = 0; i < languageCodes.length; i++) {
            modelsCard.addView(buildLanguageRow(i), topMargin(i == 0 ? 15 : 12));
        }
        root.addView(modelsCard, topMargin(16));

        LinearLayout behaviorCard = card();
        behaviorCard.addView(label("Funcionamiento", 19, TEXT, true));
        addBullet(behaviorCard, "Si instalas solo Inglés, puedes probar inmediatamente Inglés o Auto.");
        addBullet(behaviorCard, "Auto prioriza Inglés y solo considera idiomas instalados.");
        addBullet(behaviorCard, "La selección manual procesa únicamente el idioma elegido.");
        addBullet(behaviorCard, "El cuadro negro aparece desde el inicio con “Esperando subtítulo…”.");
        addBullet(behaviorCard, "Zeta ya no marca sus ventanas como contenido privado.");
        root.addView(behaviorCard, topMargin(16));

        setContentView(scroll);
    }

    private LinearLayout buildLanguageRow(int index) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        row.setBackground(roundRect(SURFACE_ALT, BORDER, 14));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView name = label(languageNames[index], 16, TEXT, true);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));

        stateBadges[index] = badge("No instalado", WARNING);
        top.addView(stateBadges[index]);
        row.addView(top);

        TextView note = label(languageNotes[index], 12, MUTED, false);
        note.setLineSpacing(0f, 1.1f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(7);
        row.addView(note, noteLp);

        downloadButtons[index] = smallButton(index == 0 ? "Descargar Inglés" : "Descargar");
        final int languageIndex = index;
        downloadButtons[index].setOnClickListener(v -> downloadLanguage(languageIndex));
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1, dp(46));
        buttonLp.topMargin = dp(11);
        row.addView(downloadButtons[index], buttonLp);
        return row;
    }

    private void showFirstRunDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Empieza por Inglés")
                .setMessage("Concede los permisos y descarga únicamente Inglés → Español. Podrás probar el traductor sin esperar los otros idiomas.")
                .setPositiveButton("Revisar permisos", (dialog, which) -> beginPermissionFlow())
                .setNegativeButton("Ahora no", null)
                .show();
    }

    private void beginPermissionFlow() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        toast("Permisos principales listos.");
        refreshUi();
    }

    private void downloadLanguage(int index) {
        if (activeDownloadIndex >= 0) {
            toast("Espera a que termine la descarga actual.");
            return;
        }
        if (isModelReady(languageCodes[index])) {
            toast(languageNames[index] + " ya está listo.");
            return;
        }
        if (!isNetworkAvailable()) {
            updateGlobal("Sin conexión", "Conéctate a internet y vuelve a tocar Descargar.");
            return;
        }

        activeDownloadIndex = index;
        activeProgress.setVisibility(View.VISIBLE);
        updateGlobal("Descargando " + languageNames[index],
                "Mantén la app abierta. El estado cambiará a Listo cuando ML Kit confirme la instalación.");
        refreshUi();

        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(languageCodes[index])
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        activeTranslator = Translation.getClient(options);
        Translator taskTranslator = activeTranslator;
        taskTranslator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(unused -> {
                    prefs.edit().putBoolean(modelKey(languageCodes[index]), true).apply();
                    closeActiveTranslator();
                    activeDownloadIndex = -1;
                    activeProgress.setVisibility(View.GONE);
                    refreshUi();
                    updateGlobal("Modelo instalado", languageNames[index] + " está listo para usarse sin conexión.");
                    toast(languageNames[index] + " listo.");
                })
                .addOnFailureListener(error -> {
                    closeActiveTranslator();
                    activeDownloadIndex = -1;
                    activeProgress.setVisibility(View.GONE);
                    String message = isNetworkAvailable()
                            ? "No se pudo instalar. Revisa Servicios de Google Play, espacio libre e internet."
                            : "La conexión se perdió durante la descarga.";
                    refreshUi();
                    updateGlobal("Falló la descarga", message);
                });
    }

    private void startCaptureFlow() {
        if (installedModels() == 0) {
            updateGlobal("Falta un idioma", "Descarga por lo menos Inglés → Español antes de iniciar.");
            toast("Descarga por lo menos un idioma.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            updateGlobal("Falta permiso", "Activa “Mostrar sobre otras apps” para usar la barra flotante.");
            beginPermissionFlow();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent service = new Intent(this, OverlayTranslatorService.class);
            service.putExtra(OverlayTranslatorService.EXTRA_RESULT_CODE, resultCode);
            service.putExtra(OverlayTranslatorService.EXTRA_DATA, data);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
            else startService(service);
            updateGlobal("Traductor iniciado", "Ajusta el cuadro morado y pulsa Trad. o Vivo.");
            moveTaskToBack(true);
        } else {
            updateGlobal("Captura cancelada", "Android no concedió el permiso de captura.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } else {
                refreshUi();
            }
        }
    }

    private void refreshUi() {
        int installed = installedModels();
        boolean overlayReady = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
        installedCount.setText(installed + (installed == 1 ? " idioma listo" : " idiomas listos"));
        styleBadge(installedCount, installed > 0 ? SUCCESS : WARNING);

        for (int i = 0; i < languageCodes.length; i++) {
            boolean ready = isModelReady(languageCodes[i]);
            boolean downloading = activeDownloadIndex == i;
            stateBadges[i].setText(ready ? "Listo" : (downloading ? "Descargando" : "No instalado"));
            styleBadge(stateBadges[i], ready ? SUCCESS : (downloading ? ACCENT : WARNING));
            downloadButtons[i].setText(ready ? "Instalado" : (downloading ? "Descargando…" : (i == 0 ? "Descargar Inglés" : "Descargar")));
            downloadButtons[i].setEnabled(activeDownloadIndex < 0 && !ready);
            downloadButtons[i].setAlpha(downloadButtons[i].isEnabled() ? 1f : 0.55f);
        }

        startButton.setEnabled(installed > 0 && overlayReady && activeDownloadIndex < 0);
        startButton.setAlpha(startButton.isEnabled() ? 1f : 0.5f);
        permissionsButton.setText(overlayReady ? "Permisos listos" : "Revisar permisos");

        if (activeDownloadIndex < 0) {
            if (installed == 0) updateGlobal("Descarga un idioma", "Empieza por Inglés → Español para probar la app sin esperar los demás.");
            else if (!overlayReady) updateGlobal("Falta un permiso", "Activa “Mostrar sobre otras apps”. Tus modelos ya están guardados.");
            else updateGlobal("Listo para traducir", "Tienes " + installed + " idioma(s) instalado(s). Puedes iniciar ahora.");
        }
    }

    private int installedModels() {
        int count = 0;
        for (String code : languageCodes) if (isModelReady(code)) count++;
        return count;
    }

    private boolean isModelReady(String source) {
        return prefs.getBoolean(modelKey(source), false);
    }

    private String modelKey(String source) {
        return KEY_MODEL_PREFIX + source;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network network = cm.getActiveNetwork();
            if (network == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        }
        android.net.NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void closeActiveTranslator() {
        if (activeTranslator != null) {
            try { activeTranslator.close(); } catch (Exception ignored) { }
            activeTranslator = null;
        }
    }

    private void updateGlobal(String title, String detail) {
        globalTitle.setText(title);
        globalDetail.setText(detail);
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(17), dp(17), dp(17));
        card.setBackground(roundRect(SURFACE, BORDER, 18));
        return card;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private TextView badge(String value, int color) {
        TextView view = label(value, 12, color, true);
        view.setPadding(dp(10), dp(6), dp(10), dp(6));
        styleBadge(view, color);
        return view;
    }

    private void styleBadge(TextView view, int color) {
        int translucent;
        if (color == SUCCESS) translucent = 0x222FC58D;
        else if (color == ACCENT) translucent = 0x224F8CFF;
        else if (color == ERROR) translucent = 0x22F97066;
        else translucent = 0x22F0B429;
        view.setTextColor(color);
        view.setBackground(roundRect(translucent, color, 999));
    }

    private Button primaryButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(16);
        b.setTextColor(0xFFFFFFFF);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(roundRect(ACCENT, ACCENT, 16));
        return b;
    }

    private Button secondaryButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(16);
        b.setTextColor(TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(roundRect(SURFACE_ALT, BORDER, 16));
        return b;
    }

    private Button smallButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(14);
        b.setTextColor(TEXT);
        b.setAllCaps(false);
        b.setBackground(roundRect(0xFF263142, BORDER, 13));
        return b;
    }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams topMargin(int margin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(margin);
        return lp;
    }

    private void addBullet(LinearLayout parent, String text) {
        TextView bullet = label("• " + text, 13, MUTED, false);
        bullet.setLineSpacing(0f, 1.12f);
        parent.addView(bullet, topMargin(9));
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
