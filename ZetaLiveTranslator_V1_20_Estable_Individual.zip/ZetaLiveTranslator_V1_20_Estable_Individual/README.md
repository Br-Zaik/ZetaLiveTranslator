# Zeta Live Translator 1.20 - Estable por idioma

Esta versión reemplaza la arquitectura inestable de la 1.19. El motor grande ejecutado dentro de WebView fue eliminado porque podía cerrar la aplicación al finalizar la descarga o al reservar memoria.

## Cambios principales

- Descarga manual e independiente para Inglés, Chino, Japonés y Coreano hacia Español.
- La aplicación funciona desde el primer idioma instalado; no exige 4 de 4 ni 6 de 6.
- Inglés aparece primero y es el paquete recomendado para probar.
- Auto prioriza Inglés y solo prueba idiomas instalados.
- Un idioma seleccionado manualmente usa únicamente ese OCR y ese traductor.
- No se cargan varios traductores grandes al mismo tiempo.
- Se eliminó el WebView, Transformers.js, ONNX Runtime Web y el paquete multilingüe que causaba cierres.
- El cuadro negro se crea al iniciar y muestra "Esperando subtítulo...".
- El cuadro negro permanece visible durante la captura y no parpadea.
- La traducción se coloca arriba o abajo del área morada, evitando entrar en el recorte OCR.
- No se usa FLAG_SECURE; Zeta no bloquea capturas por sí mismo.
- La limpieza OCR conserva la prioridad al Inglés, elimina CJK de líneas inglesas y normaliza palabras alargadas como `gooood`.
- La traducción usa contexto corto, caché y validación para evitar mostrar el original como una traducción terminada.

## Descarga y progreso

ML Kit no entrega porcentaje de bytes. Por eso esta versión no muestra porcentajes inventados. Cada idioma tiene estados reales:

- No instalado
- Descargando
- Listo
- Falló

Cuando cambia a **Listo**, ML Kit confirmó que el modelo quedó disponible.

## Flujo recomendado

1. Instala la app.
2. Revisa los permisos.
3. Descarga solo `Inglés -> Español`.
4. Pulsa `Iniciar traductor`.
5. Selecciona Inglés o Auto.
6. Ajusta el área morada y usa Trad. o Vivo.
7. Descarga los demás idiomas únicamente cuando los necesites.

## Limitaciones honestas

Esta versión prioriza estabilidad y usa los modelos offline de ML Kit. No incluye todavía un modelo neuronal grande nativo de cientos de MB. Integrar uno correctamente exige un motor Android nativo, tokenizador compatible, archivos verificables y pruebas de memoria en dispositivos reales. La 1.19 simuló esa capacidad mediante WebView y no fue estable, por lo que fue retirada en lugar de mantener una función que cerraba la aplicación.

Una aplicación externa con DRM puede seguir bloqueando capturas aunque Zeta ya no use FLAG_SECURE.
