package com.geozeta.livetranslator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

public class OverlayTranslatorService extends Service {
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_DATA = "projection_data";

    private static final String CHANNEL_ID = "zeta_live_translator";
    private static final int NOTIFICATION_ID = 781;
    private static final long BUSY_TIMEOUT_MS = 12000L;
    private static final long LIVE_CAPTURE_DELAY_MS = 20L;
    private static final long SUBTITLE_GAP_HIDE_MS = 700L; // Conservado solo por compatibilidad; LIVE ya no oculta la última traducción.

    private WindowManager windowManager;
    private Handler handler;
    private ExecutorService captureExecutor;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;

    private LinearLayout toolbar;
    private LinearLayout optionsRow;
    private TextView collapseBtn;
    private TextView areaBtn;
    private TextView liveIndicatorView;
    private TextView liveBtn;
    private TextView langBtn;
    private TextView statusView;
    private TextView subtitleView;
    private SelectorOverlayView selectorView;
    private WindowManager.LayoutParams toolbarParams;
    private WindowManager.LayoutParams subtitleParams;
    private WindowManager.LayoutParams selectorParams;
    private WindowManager.LayoutParams statusParams;

    private TranslatorEngine engine;
    private Runnable statusHideRunnable;
    private Rect selectorRect;
    private boolean selecting = false;
    private boolean live = false;
    private boolean busy = false;
    private boolean subtitleHidden = false;
    private boolean subtitleManuallyMoved = false;
    private boolean toolbarCollapsed = false;
    private volatile boolean destroyed = false;
    private boolean captureViewsHidden = false;
    private boolean indicatorBlinkOn = true;
    private int toolbarVisibilityBeforeCapture = View.VISIBLE;
    private int selectorVisibilityBeforeCapture = View.VISIBLE;
    private int statusVisibilityBeforeCapture = View.GONE;
    private int subtitleVisibilityBeforeCapture = View.GONE;
    private boolean subtitleHiddenForCapture = false;
    private String lastShownSubtitle = "";
    private long lastSubtitleTime = 0L;
    private long statusVisibleUntil = 0L;
    private int requestSerial = 0;
    private volatile int activeRequestId = 0;
    private volatile int busyRequestId = 0;
    private long busyStartedAt = 0L;
    private long lastBusyNoticeAt = 0L;
    private int captureFailureStreak = 0;
    private volatile boolean captureWorkerActive = false;
    private boolean priorityCapturePending = false;
    private boolean subtitleAutoPositionInitialized = false;
    private long currentSourceCommittedAt = 0L;
    private String currentSourceMode = "";

    // OCR y traducción trabajan en carriles separados. Solo hay un OCR y una traducción
    // simultáneos. Las frases aceptadas se traducen en orden para que un subtítulo corto
    // no desaparezca de la cola solo porque el siguiente llegó antes de terminar ML Kit.
    private boolean translationBusy = false;
    private long translationGeneration = 0L;
    private String translatingSourceKey = "";
    private final ArrayDeque<TranslationJob> translationQueue = new ArrayDeque<>();
    private String lastFailedTranslationKey = "";
    private long lastFailedTranslationAt = 0L;

    private static final class TranslationJob {
        final String original;
        final String sourceMode;
        final String sourceName;
        final String sourceKey;
        final boolean manualRequest;
        final long generation;
        final long enqueuedAt;

        TranslationJob(String original, String sourceMode, String sourceName,
                       String sourceKey, boolean manualRequest, long generation) {
            this.original = original;
            this.sourceMode = sourceMode;
            this.sourceName = sourceName;
            this.sourceKey = sourceKey;
            this.manualRequest = manualRequest;
            this.generation = generation;
            this.enqueuedAt = System.currentTimeMillis();
        }
    }

    private final Runnable indicatorBlinkRunnable = new Runnable() {
        @Override public void run() {
            if (destroyed || liveIndicatorView == null) return;
            if (!live) {
                liveIndicatorView.setAlpha(1f);
                liveIndicatorView.setTextColor(Color.argb(170, 255, 255, 255));
                return;
            }
            indicatorBlinkOn = !indicatorBlinkOn;
            liveIndicatorView.setAlpha(indicatorBlinkOn ? 1f : 0.22f);
            liveIndicatorView.setTextColor(Color.rgb(255, 64, 64));
            handler.removeCallbacks(this);
            handler.postDelayed(this, 420L);
        }
    };

    // La estabilidad se decide antes de traducir, dentro de TranslatorEngine.
    // Aquí solo evitamos volver a mostrar la misma frase por ruido mínimo del OCR.
    private String currentSourceKey = "";

    // Auto lee Inglés, Chino, Japonés o Coreano y traduce a Español.
    private int languageIndex = 0;
    private final String[] languageModes = new String[]{
            TranslatorEngine.MODE_AUTO,
            TranslatorEngine.MODE_ENGLISH,
            TranslatorEngine.MODE_CHINESE,
            TranslatorEngine.MODE_JAPANESE,
            TranslatorEngine.MODE_KOREAN
    };

    private final Runnable liveRunnable = new Runnable() {
        @Override public void run() {
            if (!live || destroyed) return;
            // La siguiente captura se agenda al terminar el OCR anterior, no al terminar
            // la traducción. Así no se crea una cola de fotogramas ni una espera fija larga.
            translateOnce(false);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        captureExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "ZetaCaptureWorker");
            thread.setPriority(Thread.NORM_PRIORITY - 1);
            return thread;
        });
        engine = new TranslatorEngine(getApplicationContext());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForeground(NOTIFICATION_ID, buildNotification("Traductor listo"));
        readMetrics();
        selectorRect = defaultRect();
        chooseInitialLanguageMode();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || destroyed) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (resultCode != 0 && data != null) {
            if (mediaProjection != null) {
                invalidateActiveRequest();
                releaseCaptureOnly();
                MediaProjection previousProjection = mediaProjection;
                mediaProjection = null;
                try { previousProjection.stop(); } catch (Exception ignored) { }
            }
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            MediaProjection newProjection = manager.getMediaProjection(resultCode, data);
            mediaProjection = newProjection;
            newProjection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    if (!destroyed && mediaProjection == newProjection) stopSelf();
                }
            }, handler);
            setupInitialCapture();
            showToolbar();
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void setupInitialCapture() {
        if (mediaProjection == null || destroyed) return;
        releaseCaptureOnly();
        readMetrics();
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ZetaLiveTranslatorScreen",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
        );
    }

    /**
     * En una rotación no se vuelve a usar createVirtualDisplay con el mismo token.
     * Se conserva el VirtualDisplay y solo se cambia su tamaño y superficie.
     */
    private void resizeCaptureSurface() {
        if (mediaProjection == null || destroyed) return;
        ImageReader replacement = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        ImageReader previous = imageReader;
        try {
            if (virtualDisplay == null) {
                replacement.close();
                showStatus("Reinicia el traductor para recuperar la captura", 2200);
                return;
            }
            virtualDisplay.resize(screenWidth, screenHeight, screenDensity);
            virtualDisplay.setSurface(replacement.getSurface());
            imageReader = replacement;
            if (previous != null && previous != imageReader) previous.close();
        } catch (Exception e) {
            replacement.close();
            imageReader = previous;
            showStatus("No se pudo ajustar la captura tras girar", 1800);
        }
    }

    private void readMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.view.WindowMetrics wm = windowManager.getMaximumWindowMetrics();
            Rect bounds = wm.getBounds();
            screenWidth = bounds.width();
            screenHeight = bounds.height();
            screenDensity = getResources().getDisplayMetrics().densityDpi;
        } else {
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.densityDpi;
        }
    }

    private Rect defaultRect() {
        int w = Math.min(screenWidth - dp(24), Math.max(dp(260), (int) (screenWidth * 0.70f)));
        int h = Math.min(screenHeight - dp(32), Math.max(dp(70), (int) (screenHeight * 0.13f)));
        int left = Math.max(0, (screenWidth - w) / 2);
        int top = Math.max(0, (int) (screenHeight * 0.70f));
        return clampScreenRect(new Rect(left, top, left + w, top + h));
    }

    private void showToolbar() {
        if (toolbar != null || destroyed) return;
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setGravity(Gravity.START);
        toolbar.setPadding(dp(4), dp(3), dp(4), dp(4));
        toolbar.setBackgroundColor(Color.argb(220, 17, 24, 39));

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(headerRow, new LinearLayout.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT));

        optionsRow = new LinearLayout(this);
        optionsRow.setOrientation(LinearLayout.HORIZONTAL);
        optionsRow.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(optionsRow, new LinearLayout.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT));

        collapseBtn = addButton(headerRow, "‹");
        liveIndicatorView = addIndicatorDot(headerRow);
        TextView closeBtn = addButton(headerRow, "×");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(18);
        closeBtn.setPadding(dp(12), dp(5), dp(12), dp(5));

        areaBtn = addButton(optionsRow, selecting ? "OK" : "Área");
        TextView translateBtn = addButton(optionsRow, "Trad.");
        liveBtn = addButton(optionsRow, "Vivo");
        TextView subtitleBtn = addButton(optionsRow, "Ocultar");
        langBtn = addButton(optionsRow, languageLabel(languageModes[languageIndex]) + "→ES");

        collapseBtn.setOnClickListener(v -> toggleToolbarCollapsed());
        areaBtn.setOnClickListener(v -> toggleSelector());
        translateBtn.setOnClickListener(v -> translateOnce(true));
        liveBtn.setOnClickListener(v -> toggleLive());
        subtitleBtn.setOnClickListener(v -> {
            subtitleHidden = !subtitleHidden;
            if (subtitleView != null) subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
            subtitleBtn.setText(subtitleHidden ? "Mostrar" : "Ocultar");
        });
        langBtn.setOnClickListener(v -> cycleLanguage());
        closeBtn.setOnClickListener(v -> stopSelf());

        toolbarParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        toolbarParams.gravity = Gravity.TOP | Gravity.START;
        toolbarParams.x = dp(8);
        toolbarParams.y = dp(38);
        toolbarParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        View.OnTouchListener toolbarDragListener = new View.OnTouchListener() {
            int startX;
            int startY;
            float touchX;
            float touchY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = toolbarParams.x;
                        startY = toolbarParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - touchX);
                        int dy = (int) (event.getRawY() - touchY);
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true;
                        toolbarParams.x = Math.max(0, Math.min(startX + dx, Math.max(0, screenWidth - dp(44))));
                        toolbarParams.y = Math.max(0, Math.min(startY + dy, Math.max(0, screenHeight - dp(44))));
                        safeUpdate(toolbar, toolbarParams);
                        updateStatusPosition();
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) v.performClick();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return false;
            }
        };
        toolbar.setOnTouchListener(toolbarDragListener);
        // La flecha funciona además como asa de arrastre; así no depende de tocar un espacio vacío.
        collapseBtn.setOnTouchListener(toolbarDragListener);
        safeAdd(toolbar, toolbarParams);
        // Como en la version original: el cuadro negro no aparece hasta que exista
        // una traduccion real. No se muestra "Esperando subtitulo" sobre otras apps.
    }

    private void toggleToolbarCollapsed() {
        toolbarCollapsed = !toolbarCollapsed;
        if (toolbar == null || collapseBtn == null) return;
        collapseBtn.setText(toolbarCollapsed ? "›" : "‹");
        if (optionsRow != null) optionsRow.setVisibility(toolbarCollapsed ? View.GONE : View.VISIBLE);
        updateLiveIndicatorState();
        updateStatusPosition();
    }

    private TextView addButton(LinearLayout parent, String text) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(7), dp(6), dp(7), dp(6));
        b.setBackgroundColor(Color.TRANSPARENT);
        parent.addView(b, new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT));
        return b;
    }

    private TextView addIndicatorDot(LinearLayout parent) {
        TextView dot = new TextView(this);
        dot.setText("●");
        dot.setTextSize(14);
        dot.setTextColor(Color.argb(170, 255, 255, 255));
        dot.setGravity(Gravity.CENTER);
        dot.setPadding(dp(2), dp(0), dp(5), dp(0));
        dot.setBackgroundColor(Color.TRANSPARENT);
        parent.addView(dot, new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT));
        updateLiveIndicatorState();
        return dot;
    }

    private void updateLiveIndicatorState() {
        if (handler == null) return;
        handler.removeCallbacks(indicatorBlinkRunnable);
        if (liveIndicatorView == null) return;
        if (live) {
            indicatorBlinkOn = true;
            liveIndicatorView.setVisibility(View.VISIBLE);
            liveIndicatorView.setAlpha(1f);
            liveIndicatorView.setTextColor(Color.rgb(255, 64, 64));
            handler.post(indicatorBlinkRunnable);
        } else {
            liveIndicatorView.setVisibility(View.VISIBLE);
            liveIndicatorView.setAlpha(1f);
            liveIndicatorView.setTextColor(Color.argb(170, 255, 255, 255));
        }
    }

    private void toggleSelector() {
        if (selecting) {
            hideSelector();
            selecting = false;
            if (areaBtn != null) areaBtn.setText("Área");
            resetTranslationSwitchState(true);
            showStatus("Área guardada", 900);
        } else {
            engine.resetContextState();
            resetTranslationSwitchState(false);
            showSelector();
            selecting = true;
            if (areaBtn != null) areaBtn.setText("OK");
            showStatus("Ajusta y toca OK", 1200);
        }
    }

    private void showSelector() {
        if (selectorView != null || destroyed) return;
        selectorView = new SelectorOverlayView(this, selectorRect);
        selectorView.setOnRectChangedListener(rect -> {
            selectorRect = clampScreenRect(rect);
            if (subtitleView != null && subtitleParams != null && !subtitleManuallyMoved) {
                subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
                positionSubtitleNearSelector();
                subtitleAutoPositionInitialized = true;
                safeUpdate(subtitleView, subtitleParams);
            }
        });
        selectorParams = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        selectorParams.gravity = Gravity.TOP | Gravity.START;
        selectorParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        safeAdd(selectorView, selectorParams);
        bringToolbarToFront();
    }

    private void bringToolbarToFront() {
        if (toolbar != null && toolbarParams != null) {
            safeRemove(toolbar);
            safeAdd(toolbar, toolbarParams);
        }
    }

    private void hideSelector() {
        if (selectorView != null) {
            safeRemove(selectorView);
            selectorView = null;
        }
    }

    private void toggleLive() {
        live = !live;
        handler.removeCallbacks(liveRunnable);
        if (live) {
            if (selecting) toggleSelector();
            if (liveBtn != null) liveBtn.setText("Pausa");
            updateLiveIndicatorState();
            showStatus("En vivo", 700);
            engine.resetStabilityState();
            engine.resetContextState();
            engine.warmUpMode(languageModes[languageIndex]);
            handler.postDelayed(liveRunnable, 35L);
        } else {
            if (liveBtn != null) liveBtn.setText("Vivo");
            updateLiveIndicatorState();
            priorityCapturePending = false;
            invalidateActiveRequest();
            invalidateTranslationQueue();
            showStatus("Pausado", 700);
            engine.resetStabilityState();
        }
    }

    private void cycleLanguage() {
        int installedCount = installedLanguageCount();
        if (installedCount <= 1) {
            chooseInitialLanguageMode();
        } else {
            int attempts = 0;
            do {
                languageIndex = (languageIndex + 1) % languageModes.length;
                attempts++;
            } while (attempts < languageModes.length
                    && !TranslatorEngine.MODE_AUTO.equals(languageModes[languageIndex])
                    && !isModeInstalled(languageModes[languageIndex]));
        }

        // El idioma elegido por el usuario tiene prioridad absoluta desde este instante.
        // El OCR/traductor anterior puede terminar internamente, pero su requestId/generación
        // ya no pueden modificar el cuadro ni volver a entrar en la cola.
        priorityCapturePending = live;
        if (busy) {
            // ML Kit no permite cancelar con seguridad una lectura ya iniciada.
            invalidateActiveRequest();
        }
        engine.resetAutoState();
        engine.resetStabilityState();
        engine.resetContextState();
        invalidateTranslationQueue();
        resetTranslationSwitchState(true);
        if (langBtn != null) langBtn.setText(languageLabel(languageModes[languageIndex]) + "→ES");
        if (!busy) {
            engine.warmUpMode(languageModes[languageIndex]);
            if (live) {
                handler.removeCallbacks(liveRunnable);
                priorityCapturePending = false;
                handler.post(liveRunnable);
            }
        }
        showStatus("Idioma: " + languageLabel(languageModes[languageIndex]) + " → Español", 1300);
    }

    private void chooseInitialLanguageMode() {
        // Inglés fijo es la opción inicial para LIVE: evita que Auto pruebe OCR/modelos
        // innecesarios y reduce errores cuando los videos están en inglés.
        if (isModeInstalled(TranslatorEngine.MODE_ENGLISH)) {
            languageIndex = 1;
            return;
        }

        int onlyIndex = -1;
        int count = 0;
        for (int i = 1; i < languageModes.length; i++) {
            if (isModeInstalled(languageModes[i])) {
                count++;
                onlyIndex = i;
            }
        }
        languageIndex = count == 1 ? onlyIndex : 0;
    }

    private int installedLanguageCount() {
        int count = 0;
        for (int i = 1; i < languageModes.length; i++) {
            if (isModeInstalled(languageModes[i])) count++;
        }
        return count;
    }

    private boolean isModeInstalled(String mode) {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.KEY_MODEL_PREFIX + mode, false);
    }

    private String languageLabel(String mode) {
        if (TranslatorEngine.MODE_AUTO.equals(mode)) return "Auto";
        if (TranslatorEngine.MODE_CHINESE.equals(mode)) return "Chino";
        if (TranslatorEngine.MODE_ENGLISH.equals(mode)) return "Inglés";
        if (TranslatorEngine.MODE_JAPANESE.equals(mode)) return "Japonés";
        if (TranslatorEngine.MODE_KOREAN.equals(mode)) return "Coreano";
        return "Auto";
    }

    private void translateOnce(boolean userRequested) {
        if (destroyed) return;
        long now = System.currentTimeMillis();
        if (busy) {
            // ML Kit no ofrece cancelación segura de una lectura OCR ya iniciada.
            // Nunca abrimos otra lectura ni cerramos el recognizer mientras la anterior sigue viva.
            if (userRequested) {
                showStatus("Terminando lectura anterior…", 650);
            } else if (now - busyStartedAt > BUSY_TIMEOUT_MS
                    && now - lastBusyNoticeAt > BUSY_TIMEOUT_MS) {
                lastBusyNoticeAt = now;
                showStatus("OCR tardando; esperando sin reiniciarlo…", 900);
            }
            return;
        }
        if (selecting && userRequested) toggleSelector();
        if (mediaProjection == null || imageReader == null) {
            showStatus("Falta permiso de captura de pantalla", 1600);
            return;
        }
        if (userRequested) {
            lastShownSubtitle = "";
            engine.resetAutoState();
            engine.resetStabilityState();
            engine.resetContextState();
            resetTranslationSwitchState(true);
        }
        busy = true;
        busyStartedAt = now;
        lastBusyNoticeAt = 0L;
        int requestId = ++requestSerial;
        activeRequestId = requestId;
        busyRequestId = requestId;
        drainImages();
        hideAllForCleanCapture();
        handler.postDelayed(() -> captureAndTranslate(0, requestId, userRequested), 22L);
        handler.postDelayed(() -> {
            if (!destroyed && busy && busyRequestId == requestId) {
                lastBusyNoticeAt = System.currentTimeMillis();
                showStatus("OCR tardando; esperando sin reiniciarlo…", 900);
            }
        }, BUSY_TIMEOUT_MS);
    }

    private void hideAllForCleanCapture() {
        if (captureViewsHidden) return;
        captureViewsHidden = true;
        // La barra superior permanece estable para que sea facil tocar las opciones.
        // El indicador rojo comunica que LIVE sigue activo sin hacer parpadear toda la barra.
        if (toolbar != null) {
            toolbarVisibilityBeforeCapture = toolbar.getVisibility();
        }
        if (selectorView != null) {
            selectorVisibilityBeforeCapture = selectorView.getVisibility();
            selectorView.setVisibility(View.INVISIBLE);
        }
        if (statusView != null) {
            statusVisibilityBeforeCapture = statusView.getVisibility();
            statusView.setVisibility(View.INVISIBLE);
        }
        // El subtítulo traducido NO se oculta durante cada captura: ocultarlo 20-30 ms
        // repetidamente producía el pequeño parpadeo/tic visible en LIVE. TranslatorEngine
        // conoce el texto que Zeta está mostrando y lo descarta si vuelve a aparecer en OCR.
        // Así la UI permanece estable incluso si el usuario mueve el cuadro cerca del área OCR.
        subtitleHiddenForCapture = false;
    }

    private boolean subtitleOverlapsSelector() {
        if (subtitleView == null || subtitleParams == null || selectorRect == null
                || subtitleView.getVisibility() != View.VISIBLE) return false;
        int width = subtitleParams.width > 0 ? subtitleParams.width : subtitleView.getWidth();
        int height = Math.max(dp(1), Math.max(subtitleView.getHeight(), subtitleView.getMeasuredHeight()));
        if (width <= 0) width = Math.max(dp(1), selectorRect.width());
        Rect subtitleRect = new Rect(subtitleParams.x, subtitleParams.y,
                subtitleParams.x + width, subtitleParams.y + height);
        return Rect.intersects(subtitleRect, selectorRect);
    }

    private void restoreAfterCapture() {
        if (!captureViewsHidden) return;
        captureViewsHidden = false;
        if (toolbar != null) toolbar.setVisibility(toolbarVisibilityBeforeCapture);
        if (selectorView != null) selectorView.setVisibility(selectorVisibilityBeforeCapture);
        if (statusView != null) {
            boolean statusStillValid = statusVisibilityBeforeCapture == View.VISIBLE
                    && statusVisibleUntil > System.currentTimeMillis();
            statusView.setVisibility(statusStillValid ? View.VISIBLE : View.GONE);
        }
        if (subtitleHiddenForCapture && subtitleView != null) {
            subtitleView.setVisibility(subtitleHidden ? View.GONE : subtitleVisibilityBeforeCapture);
            subtitleHiddenForCapture = false;
        }
        updateLiveIndicatorState();
    }

    private void captureAndTranslate(int attempt, int requestId, boolean manualRequest) {
        if (destroyed) return;
        if (requestId != activeRequestId || imageReader == null) {
            restoreAfterCapture();
            finishRequest(requestId);
            return;
        }

        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                if (attempt < 8) {
                    handler.postDelayed(() -> captureAndTranslate(attempt + 1, requestId, manualRequest), 20L);
                } else {
                    restoreAfterCapture();
                    finishRequest(requestId);
                    captureFailureStreak++;
                    if (captureFailureStreak >= 3) {
                        showStatus("La captura está tardando. Reintentando...", 1200);
                    }
                    if (captureFailureStreak >= 5) {
                        resizeCaptureSurface();
                        captureFailureStreak = 0;
                    }
                }
                return;
            }
            captureFailureStreak = 0;
            final Image capturedImage = image;
            final Rect requestedSelector = selectorRect == null ? defaultRect() : new Rect(selectorRect);
            final int requestedScreenWidth = Math.max(1, screenWidth);
            final int requestedScreenHeight = Math.max(1, screenHeight);
            final String requestedMode = languageModes[languageIndex];
            image = null;

            // El fotograma ya quedó adquirido: restauramos enseguida los overlays y movemos
            // conversión, recorte y preparación fuera del hilo principal para evitar ANR/cierres.
            restoreAfterCapture();
            captureWorkerActive = true;
            try {
                captureExecutor.execute(() -> processCapturedImage(
                        capturedImage, requestId, manualRequest, requestedSelector,
                        requestedScreenWidth, requestedScreenHeight, requestedMode));
            } catch (RejectedExecutionException rejected) {
                captureWorkerActive = false;
                try { capturedImage.close(); } catch (Exception ignored) { }
                finishRequest(requestId);
            }
        } catch (Exception e) {
            if (image != null) {
                try { image.close(); } catch (Exception ignored) { }
            }
            restoreAfterCapture();
            finishRequest(requestId);
            if (!destroyed) showStatus("Error captura: " + safeMessage(e), 2400);
        }
    }

    private void processCapturedImage(Image image, int requestId, boolean manualRequest,
                                      Rect requestedSelector, int requestedScreenWidth,
                                      int requestedScreenHeight, String requestedMode) {
        Bitmap crop = null;
        try {
            if (destroyed || requestId != activeRequestId) {
                handler.post(() -> finishRequest(requestId));
                return;
            }
            crop = imageToCropBitmap(image, requestedSelector, requestedScreenWidth, requestedScreenHeight);
            if (crop == null || crop.isRecycled()) {
                throw new IllegalStateException("No se pudo crear el recorte de pantalla");
            }

            final Bitmap requestCrop = crop;
            crop = null;
            final boolean requireStableText = !manualRequest;
            final String requestMode = requestedMode;
            try {
                engine.recognizeStable(requestCrop, requestMode, requireStableText, new TranslatorEngine.RecognitionCallback() {
                    @Override public void onText(String original, String sourceLanguage, String sourceName) {
                        recycleBitmap(requestCrop);
                        handler.post(() -> {
                            finishRequest(requestId);
                            if (destroyed || requestId != activeRequestId) return;
                            if (!manualRequest && !live) return;
                            if (!requestMode.equals(languageModes[languageIndex])) return;
                            handleRecognizedText(original, sourceLanguage, sourceName, manualRequest);
                        });
                    }

                    @Override public void onError(String message) {
                        recycleBitmap(requestCrop);
                        handler.post(() -> {
                            finishRequest(requestId);
                            if (destroyed || requestId != activeRequestId) return;
                            if (!manualRequest && !live) return;
                            String lower = message == null ? "" : message.toLowerCase(Locale.ROOT);
                            if (lower.contains("no se detect") || lower.contains("esperando texto claro")) {
                                // El hueco sirve para reiniciar el consenso OCR, pero la última
                                // traducción permanece visible hasta que llegue otra válida.
                                engine.noteNoTextDetected();
                            } else if (lower.contains("cambio de subtítulo detectado")) {
                                // NO borramos el consenso: esas lecturas son precisamente la evidencia
                                // del subtítulo nuevo. Antes se vaciaban aquí y la frase tenía que empezar
                                // otra vez desde cero, añadiendo retraso o perdiendo textos rápidos.
                            }
                            if (!lower.contains("no se detect")
                                    && !lower.contains("esperando subtítulo")
                                    && !lower.contains("mismo subtítulo")
                                    && !lower.contains("cambio de subtítulo detectado")
                                    && !lower.contains("esperando texto claro")) {
                                showStatus(message, 1500);
                            }
                        });
                    }
                });
            } catch (OutOfMemoryError oom) {
                recycleBitmap(requestCrop);
                throw oom;
            } catch (RuntimeException startError) {
                recycleBitmap(requestCrop);
                throw startError;
            }
        } catch (OutOfMemoryError oom) {
            recycleBitmap(crop);
            handler.post(() -> {
                finishRequest(requestId);
                if (destroyed || requestId != activeRequestId) return;
                showStatus("Memoria ajustada. Reduce el cuadro si vuelve a ocurrir.", 1500);
            });
        } catch (Exception e) {
            recycleBitmap(crop);
            handler.post(() -> {
                finishRequest(requestId);
                if (destroyed || requestId != activeRequestId) return;
                showStatus("Error captura: " + safeMessage(e), 2200);
            });
        } finally {
            captureWorkerActive = false;
            try { image.close(); } catch (Exception ignored) { }
        }
    }

    private void recycleBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try { bitmap.recycle(); } catch (Exception ignored) { }
        }
    }

    private void drainImages() {
        if (imageReader == null) return;
        Image old = null;
        try {
            while ((old = imageReader.acquireLatestImage()) != null) {
                old.close();
                old = null;
            }
        } catch (Exception ignored) {
            if (old != null) { try { old.close(); } catch (Exception ignored2) { } }
        }
    }

    private Bitmap imageToCropBitmap(Image image, Rect selection, int sourceScreenWidth, int sourceScreenHeight) {
        if (image == null) return null;
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0) return null;
        Image.Plane plane = planes[0];
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        Rect cropRect = mapSelectorToBitmap(selection, imageWidth, imageHeight,
                sourceScreenWidth, sourceScreenHeight);

        // RGBA_8888 normalmente llega con 4 bytes por píxel. Empaquetamos solo las filas
        // del área OCR en lugar de crear un bitmap de toda la pantalla en cada captura.
        if (pixelStride == 4 && cropRect.width() > 0 && cropRect.height() > 0) {
            ByteBuffer source = plane.getBuffer().duplicate();
            int base = source.position();
            int rowBytes = cropRect.width() * 4;
            long packedSize = (long) rowBytes * cropRect.height();
            if (packedSize > 8L * 1024L * 1024L) {
                throw new IllegalArgumentException("El área OCR es demasiado grande; reduce el cuadro");
            }
            if (packedSize > 0) {
                byte[] packed = new byte[(int) packedSize];
                for (int y = 0; y < cropRect.height(); y++) {
                    int sourcePos = base + (cropRect.top + y) * rowStride + cropRect.left * pixelStride;
                    int targetPos = y * rowBytes;
                    if (sourcePos < 0 || sourcePos + rowBytes > source.limit()) {
                        throw new IllegalStateException("Recorte fuera del búfer de captura");
                    }
                    source.position(sourcePos);
                    source.get(packed, targetPos, rowBytes);
                }
                Bitmap crop = Bitmap.createBitmap(cropRect.width(), cropRect.height(), Bitmap.Config.ARGB_8888);
                crop.copyPixelsFromBuffer(ByteBuffer.wrap(packed));
                return crop;
            }
        }

        // Compatibilidad con dispositivos que entreguen un formato/stride inusual.
        Bitmap full = imageToBitmapFallback(image);
        try {
            Rect safe = clampCrop(cropRect, full.getWidth(), full.getHeight());
            Bitmap result = Bitmap.createBitmap(full, safe.left, safe.top, safe.width(), safe.height());
            // createBitmap puede devolver el mismo objeto si el recorte abarca toda la imagen.
            // En ese caso hacemos una copia antes de liberar el bitmap temporal completo.
            if (result == full) {
                result = full.copy(Bitmap.Config.ARGB_8888, false);
            }
            return result;
        } finally {
            recycleBitmap(full);
        }
    }

    private Bitmap imageToBitmapFallback(Image image) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer().duplicate();
        buffer.rewind();
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = Math.max(0, rowStride - pixelStride * imageWidth);
        int bitmapWidth = imageWidth + rowPadding / Math.max(1, pixelStride);
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, imageHeight, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        if (bitmapWidth != imageWidth) {
            Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, imageWidth, imageHeight);
            bitmap.recycle();
            return cropped;
        }
        return bitmap;
    }

    private Rect mapSelectorToBitmap(Rect selection, int bitmapWidth, int bitmapHeight,
                                     int sourceScreenWidth, int sourceScreenHeight) {
        Rect safeSelection = selection == null ? defaultRect() : selection;
        float sx = sourceScreenWidth > 0 ? bitmapWidth / (float) sourceScreenWidth : 1f;
        float sy = sourceScreenHeight > 0 ? bitmapHeight / (float) sourceScreenHeight : 1f;
        Rect mapped = new Rect(
                Math.round(safeSelection.left * sx),
                Math.round(safeSelection.top * sy),
                Math.round(safeSelection.right * sx),
                Math.round(safeSelection.bottom * sy)
        );
        return clampCrop(mapped, bitmapWidth, bitmapHeight);
    }

    private Rect clampCrop(Rect r, int maxW, int maxH) {
        int left = Math.max(0, Math.min(r.left, maxW - 2));
        int top = Math.max(0, Math.min(r.top, maxH - 2));
        int right = Math.max(left + 2, Math.min(r.right, maxW));
        int bottom = Math.max(top + 2, Math.min(r.bottom, maxH));
        return new Rect(left, top, right, bottom);
    }

    private Rect clampScreenRect(Rect r) {
        int minW = Math.min(screenWidth, dp(120));
        int minH = Math.min(screenHeight, dp(44));
        int width = Math.max(minW, Math.min(r.width(), screenWidth));
        int height = Math.max(minH, Math.min(r.height(), screenHeight));
        int left = Math.max(0, Math.min(r.left, Math.max(0, screenWidth - width)));
        int top = Math.max(0, Math.min(r.top, Math.max(0, screenHeight - height)));
        return new Rect(left, top, left + width, top + height);
    }

    private void handleRecognizedText(String original, String sourceLanguage, String sourceName, boolean manualRequest) {
        String sourceKey = normalizeSourceKey(original);
        if (sourceKey.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (!manualRequest && areSourceKeysSimilar(lastFailedTranslationKey, sourceKey)
                && now - lastFailedTranslationAt < 300L) {
            return;
        }

        // Una traducción ya mostrada queda fija mientras el OCR solo esté refinando la misma
        // frase. Las negaciones/números siguen rompiendo esta similitud para no ocultar cambios
        // de significado reales.
        if (!manualRequest
                && sourceLanguage != null
                && sourceLanguage.equals(currentSourceMode)
                && now - currentSourceCommittedAt < 1400L
                && areLikelySameVisualSubtitle(currentSourceKey, sourceKey)) {
            return;
        }
        if (!manualRequest && areSourceKeysSimilar(currentSourceKey, sourceKey)) return;
        if (!manualRequest && areLikelySameVisualSubtitle(translatingSourceKey, sourceKey)) return;

        TranslationJob job = new TranslationJob(original, sourceLanguage, sourceName,
                sourceKey, manualRequest, translationGeneration);
        if (manualRequest) {
            translationQueue.addFirst(job);
        } else {
            enqueueOrRefineTranslation(job);
        }
        startNextQueuedTranslation();
    }

    private void enqueueOrRefineTranslation(TranslationJob incoming) {
        if (incoming == null) return;
        TranslationJob last = translationQueue.peekLast();
        if (last != null
                && last.generation == incoming.generation
                && safeEquals(last.sourceMode, incoming.sourceMode)
                && areLikelySameVisualSubtitle(last.sourceKey, incoming.sourceKey)) {
            // Si el nuevo OCR es una versión más completa de la MISMA línea y todavía no se
            // empezó a traducir, sustituimos la lectura parcial. No se elimina ningún subtítulo real.
            if (incoming.sourceKey.length() > last.sourceKey.length()) {
                translationQueue.removeLast();
                translationQueue.addLast(incoming);
            }
            return;
        }
        if (!isTranslationQueued(incoming.sourceKey)) translationQueue.addLast(incoming);
    }

    private boolean isTranslationQueued(String sourceKey) {
        if (sourceKey == null || sourceKey.isEmpty()) return false;
        for (TranslationJob job : translationQueue) {
            if (job != null && areLikelySameVisualSubtitle(job.sourceKey, sourceKey)) return true;
        }
        return false;
    }

    private boolean safeEquals(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private boolean areLikelySameVisualSubtitle(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        if (a.equals(b)) return true;
        if (negationSignature(a) != negationSignature(b)) return false;
        if (!numberSignature(a).equals(numberSignature(b))) return false;
        int min = Math.min(a.length(), b.length());
        int max = Math.max(a.length(), b.length());
        if (max <= 5) return false;
        if ((a.contains(b) || b.contains(a)) && min >= Math.round(max * 0.62f)) return true;
        if (min < Math.round(max * 0.80f)) return false;
        return levenshteinDistance(a, b) <= Math.max(2, max / 5);
    }

    private void startNextQueuedTranslation() {
        if (destroyed || translationBusy) return;

        TranslationJob job = null;
        while (!translationQueue.isEmpty()) {
            TranslationJob candidate = translationQueue.removeFirst();
            if (candidate.generation != translationGeneration) continue;
            // Si una entrada quedó en cola pero esa misma línea ya llegó a mostrarse por caché
            // o por una petición manual, no gastamos tiempo traduciéndola otra vez.
            if (!candidate.manualRequest
                    && safeEquals(candidate.sourceMode, currentSourceMode)
                    && areLikelySameVisualSubtitle(currentSourceKey, candidate.sourceKey)) {
                continue;
            }
            job = candidate;
            break;
        }
        if (job == null) return;

        final TranslationJob activeJob = job;
        translationBusy = true;
        translatingSourceKey = activeJob.sourceKey;

        engine.translateRecognized(activeJob.original, activeJob.sourceMode, new TranslatorEngine.Callback() {
            @Override public void onSuccess(String translatedOriginal, String translated, String translatedSourceName) {
                handler.post(() -> {
                    translationBusy = false;
                    translatingSourceKey = "";
                    if (destroyed) return;
                    if (activeJob.generation == translationGeneration) {
                        if (areSourceKeysSimilar(lastFailedTranslationKey, activeJob.sourceKey)) {
                            lastFailedTranslationKey = "";
                            lastFailedTranslationAt = 0L;
                        }
                        handleTranslationResult(translatedOriginal, translated,
                                translatedSourceName == null ? activeJob.sourceName : translatedSourceName,
                                activeJob.sourceMode, activeJob.manualRequest);
                    }
                    startNextQueuedTranslation();
                });
            }

            @Override public void onError(String message) {
                handler.post(() -> {
                    translationBusy = false;
                    translatingSourceKey = "";
                    if (destroyed) return;
                    if (activeJob.generation == translationGeneration) {
                        lastFailedTranslationKey = activeJob.sourceKey;
                        lastFailedTranslationAt = System.currentTimeMillis();
                        // Permite que el OCR vuelva a ofrecer esta misma línea si reaparece.
                        engine.forgetAcceptedSubtitle();
                        if (message != null && !message.trim().isEmpty()) showStatus(message, 850);
                    }
                    startNextQueuedTranslation();
                });
            }
        });
    }

    private void invalidateTranslationQueue() {
        translationGeneration++;
        translationQueue.clear();
        lastFailedTranslationKey = "";
        lastFailedTranslationAt = 0L;
        // Una traducción ya iniciada termina de forma natural; su generación hace que el
        // callback se descarte si el usuario cambió idioma, pausó o salió.
    }

    private void handleTranslationResult(String original, String translated, String sourceName, String sourceMode, boolean manualRequest) {
        String sourceKey = normalizeSourceKey(original);
        String cleanTranslation = makeSubtitleText(translated);
        if (sourceKey.length() == 0 || cleanTranslation.length() == 0) return;

        if (!manualRequest && areSourceKeysSimilar(currentSourceKey, sourceKey)) {
            return;
        }

        commitTranslation(sourceKey, cleanTranslation, sourceName, sourceMode);
    }

    private void commitTranslation(String sourceKey, String translated, String sourceName, String sourceMode) {
        currentSourceKey = sourceKey;
        currentSourceMode = sourceMode == null ? "" : sourceMode;
        currentSourceCommittedAt = System.currentTimeMillis();
        showSubtitle(translated, sourceName);
    }

    private void resetTranslationSwitchState(boolean resetCurrent) {
        if (resetCurrent) {
            currentSourceKey = "";
            currentSourceMode = "";
            currentSourceCommittedAt = 0L;
        }
    }

    private String normalizeSourceKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private boolean areSourceKeysSimilar(String a, String b) {
        if (a == null || b == null || a.length() == 0 || b.length() == 0) return false;
        if (a.equals(b)) return true;

        // Una negación, número o verbo corto puede cambiar todo el sentido aunque casi todas
        // las demás palabras coincidan. Por eso no usamos similitud por conjunto de palabras.
        if (negationSignature(a) != negationSignature(b)) return false;
        if (!numberSignature(a).equals(numberSignature(b))) return false;

        int min = Math.min(a.length(), b.length());
        int max = Math.max(a.length(), b.length());
        if (min >= 12 && (a.contains(b) || b.contains(a)) && min >= Math.round(max * 0.93f)) return true;
        if (Math.abs(a.length() - b.length()) > Math.max(1, max / 20)) return false;
        return levenshteinDistance(a, b) <= Math.max(1, max / 24);
    }

    private int negationSignature(String key) {
        String safe = key == null ? "" : key.toLowerCase(Locale.ROOT);
        String padded = " " + safe + " ";
        String compact = safe.replaceAll("\\s+", "");
        int mask = 0;
        if (padded.contains(" not ")) mask |= 1;
        if (padded.contains(" no ")) mask |= 2;
        if (padded.contains(" never ")) mask |= 4;
        if (padded.contains(" cant ") || padded.contains(" can t ")) mask |= 8;
        if (padded.contains(" dont ") || padded.contains(" don t ")) mask |= 16;
        if (padded.contains(" wont ") || padded.contains(" won t ")) mask |= 32;
        if (padded.contains(" isnt ") || padded.contains(" isn t ")
                || padded.contains(" arent ") || padded.contains(" aren t ")) mask |= 64;
        if (padded.contains(" didnt ") || padded.contains(" didn t ")
                || padded.contains(" doesnt ") || padded.contains(" doesn t ")) mask |= 128;
        if (compact.contains("不")) mask |= 1 << 8;
        if (compact.contains("没") || compact.contains("沒有") || compact.contains("没有")) mask |= 1 << 9;
        if (compact.contains("别") || compact.contains("別")) mask |= 1 << 10;
        if (compact.contains("无") || compact.contains("無") || compact.contains("未")) mask |= 1 << 11;
        if (compact.contains("ない") || compact.contains("ません") || compact.contains("じゃない")
                || compact.contains("ではない") || compact.endsWith("ぬ")) mask |= 1 << 12;
        if (compact.contains("않") || compact.contains("못") || compact.contains("없")
                || compact.contains("아니") || compact.contains("안돼") || compact.contains("안되")
                || compact.contains("안해") || compact.contains("안가") || compact.contains("안와")) mask |= 1 << 13;
        return mask;
    }

    private String numberSignature(String key) {
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("\\d+").matcher(key == null ? "" : key);
        StringBuilder out = new StringBuilder();
        while (matcher.find()) {
            if (out.length() > 0) out.append('|');
            out.append(matcher.group());
        }
        return out.toString();
    }

    private int levenshteinDistance(String a, String b) {
        int[] previous = new int[b.length() + 1];
        int[] current = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) previous[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            current[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                current[j] = Math.min(Math.min(current[j - 1] + 1, previous[j] + 1), previous[j - 1] + cost);
            }
            int[] swap = previous;
            previous = current;
            current = swap;
        }
        return previous[b.length()];
    }

    private void clearSubtitleForGap() {
        // Regla de Zeta: el último subtítulo traducido permanece visible hasta que exista
        // una traducción nueva válida. Un hueco del OCR nunca borra el cuadro automáticamente.
        currentSourceKey = "";
    }

    private void ensureSubtitleOverlay() {
        if (destroyed) return;
        if (subtitleView == null) {
            subtitleView = new TextView(this);
            subtitleView.setTextColor(Color.WHITE);
            subtitleView.setTextSize(18);
            subtitleView.setGravity(Gravity.CENTER);
            subtitleView.setPadding(dp(12), dp(8), dp(12), dp(8));
            subtitleView.setMinHeight(dp(44));
            subtitleView.getPaint().clearShadowLayer();
            GradientDrawable subtitleBg = new GradientDrawable();
            // Fondo negro al 59%: sigue siendo legible pero deja ver mejor el video.
            subtitleBg.setColor(Color.argb(150, 0, 0, 0));
            subtitleBg.setCornerRadius(dp(10));
            subtitleView.setBackground(subtitleBg);
            subtitleView.setIncludeFontPadding(false);
            subtitleView.setLineSpacing(0f, 1.05f);
            subtitleView.setSingleLine(false);
            subtitleView.setMaxLines(Integer.MAX_VALUE);
            subtitleView.setEllipsize(null);
            subtitleView.setMaxHeight(Math.max(dp(120), screenHeight - dp(24)));
            subtitleView.setOnTouchListener(new View.OnTouchListener() {
                int startX;
                int startY;
                float touchX;
                float touchY;

                @Override public boolean onTouch(View v, MotionEvent event) {
                    if (subtitleParams == null) return false;
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            startX = subtitleParams.x;
                            startY = subtitleParams.y;
                            touchX = event.getRawX();
                            touchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            subtitleParams.x = startX + (int) (event.getRawX() - touchX);
                            subtitleParams.y = startY + (int) (event.getRawY() - touchY);
                            clampSubtitlePosition();
                            subtitleManuallyMoved = true;
                            safeUpdate(subtitleView, subtitleParams);
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            return true;
                    }
                    return false;
                }
            });
        }
        if (subtitleParams == null) {
            subtitleParams = overlayParams(selectorRect.width(), WindowManager.LayoutParams.WRAP_CONTENT);
            subtitleParams.gravity = Gravity.TOP | Gravity.START;
            subtitleParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }
        subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
        subtitleParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
    }

    private void showSubtitle(String translated, String sourceName) {
        if (destroyed) return;
        hideSelector();
        selecting = false;
        if (areaBtn != null) areaBtn.setText("Área");

        String text = makeSubtitleText(translated);
        if (text.length() == 0) return;
        if (text.equals(lastShownSubtitle) && subtitleView != null) {
            lastSubtitleTime = System.currentTimeMillis();
            subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
            return;
        }
        lastShownSubtitle = text;
        lastSubtitleTime = System.currentTimeMillis();
        ensureSubtitleOverlay();
        engine.setOverlayTextToIgnore(text);
        subtitleView.setText(text);
        subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
        subtitleParams.height = WindowManager.LayoutParams.WRAP_CONTENT;

        // Medimos el texto NUEVO antes de mover/actualizar la ventana. Antes se actualizaba
        // primero con la altura de la frase anterior y un segundo frame después se corregía
        // la posición; ese doble salto producía el "tic" al pasar de una línea corta a una larga.
        int widthSpec = View.MeasureSpec.makeMeasureSpec(subtitleParams.width, View.MeasureSpec.EXACTLY);
        int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        subtitleView.measure(widthSpec, heightSpec);
        if (!subtitleManuallyMoved && !subtitleAutoPositionInitialized) {
            positionSubtitleNearSelector();
            subtitleAutoPositionInitialized = true;
        }
        // En cambios corto → largo conservamos el mismo anclaje. Solo se corrige si el
        // nuevo alto saldría de la pantalla; así desaparece el salto vertical del cuadro.
        clampSubtitlePosition();

        if (subtitleView.getParent() == null) safeAdd(subtitleView, subtitleParams);
        else safeUpdate(subtitleView, subtitleParams);
        subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
        updateNotification(sourceName + " → Español");
    }

    private void positionSubtitleNearSelector() {
        if (subtitleParams == null || selectorRect == null) return;
        int gap = dp(4);
        int measuredHeight = subtitleView == null ? 0 : subtitleView.getMeasuredHeight();
        if (measuredHeight <= 0 && subtitleView != null) measuredHeight = subtitleView.getHeight();
        int boxHeight = measuredHeight > 0 ? measuredHeight : dp(58);
        int aboveY = selectorRect.top - boxHeight - gap;
        int belowY = selectorRect.bottom + gap;

        subtitleParams.x = selectorRect.left;
        if (aboveY >= dp(4)) {
            subtitleParams.y = aboveY;
        } else if (belowY + boxHeight <= screenHeight - dp(4)) {
            subtitleParams.y = belowY;
        } else {
            subtitleParams.y = Math.max(dp(4), Math.min(aboveY, screenHeight - boxHeight - dp(4)));
        }
        clampSubtitlePosition();
    }

    private void clampSubtitlePosition() {
        if (subtitleParams == null || selectorRect == null) return;
        int width = subtitleParams.width > 0 ? subtitleParams.width : Math.min(selectorRect.width(), screenWidth);
        int height = dp(58);
        if (subtitleView != null) {
            int measuredHeight = subtitleView.getMeasuredHeight();
            if (measuredHeight <= 0) measuredHeight = subtitleView.getHeight();
            height = Math.max(dp(44), measuredHeight);
        }
        subtitleParams.x = Math.max(0, Math.min(subtitleParams.x, Math.max(0, screenWidth - width)));
        subtitleParams.y = Math.max(0, Math.min(subtitleParams.y, Math.max(0, screenHeight - height)));

        // El usuario decide la posicion. No expulsamos el cuadro negro del area morada.
        // Solo lo limitamos a los bordes de la pantalla, como en las primeras versiones.
    }

    private String makeSubtitleText(String text) {
        if (text == null) return "";
        return text.replace("\r", " ")
                .replace("\n", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private void showStatus(String text, long durationMs) {
        if (destroyed || text == null || text.trim().length() == 0) return;
        String lower = text.toLowerCase(Locale.ROOT);
        if (lower.contains("no se detect")
                || lower.contains("esperando subtítulo")
                || lower.contains("esperando texto claro")) return;

        if (statusView == null) {
            statusView = new TextView(this);
            statusView.setTextColor(Color.WHITE);
            statusView.setTextSize(11);
            statusView.setGravity(Gravity.CENTER);
            statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
            statusView.setBackgroundColor(Color.argb(175, 17, 24, 39));
            statusParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            statusParams.gravity = Gravity.TOP | Gravity.START;
            statusParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            updateStatusPosition();
            safeAdd(statusView, statusParams);
        } else {
            updateStatusPosition();
        }
        statusView.setText(text);
        statusView.setVisibility(View.VISIBLE);
        statusVisibleUntil = System.currentTimeMillis() + durationMs;
        if (statusHideRunnable != null) handler.removeCallbacks(statusHideRunnable);
        statusHideRunnable = () -> {
            statusVisibleUntil = 0L;
            if (!destroyed && statusView != null) statusView.setVisibility(View.GONE);
        };
        handler.postDelayed(statusHideRunnable, durationMs);
    }

    private void updateStatusPosition() {
        if (statusParams == null) return;
        statusParams.x = toolbarParams != null ? toolbarParams.x : dp(12);
        int toolbarHeight = toolbarCollapsed ? dp(38) : dp(72);
        statusParams.y = toolbarParams != null ? toolbarParams.y + toolbarHeight : dp(86);
        statusParams.x = Math.max(0, Math.min(statusParams.x, Math.max(0, screenWidth - dp(80))));
        statusParams.y = Math.max(0, Math.min(statusParams.y, Math.max(0, screenHeight - dp(36))));
        if (statusView != null && statusView.getParent() != null) safeUpdate(statusView, statusParams);
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width,
                height,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        return params;
    }

    private Notification buildNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Zeta Live Translator", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            return new Notification.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_stat_zeta)
                    .setContentTitle("Zeta Live Translator")
                    .setContentText(text)
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_stat_zeta)
                .setContentTitle("Zeta Live Translator")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String text) {
        if (destroyed) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void safeAdd(View view, WindowManager.LayoutParams params) {
        if (destroyed || view == null || params == null) return;
        try { windowManager.addView(view, params); } catch (Exception ignored) { }
    }

    private void safeUpdate(View view, WindowManager.LayoutParams params) {
        if (destroyed || view == null || params == null) return;
        try { windowManager.updateViewLayout(view, params); } catch (Exception ignored) { }
    }

    private void safeRemove(View view) {
        if (view == null) return;
        try { windowManager.removeView(view); } catch (Exception ignored) { }
    }

    private void invalidateActiveRequest() {
        requestSerial++;
        activeRequestId = requestSerial;
        // Si hay ML Kit trabajando, busy se conserva hasta que llegue su callback real.
        // Así no iniciamos un segundo OCR sobre el mismo recognizer por accidente.
        restoreAfterCapture();
    }

    private void finishRequest(int requestId) {
        if (busyRequestId == requestId) {
            busyRequestId = 0;
            busy = false;
            busyStartedAt = 0L;
        }
        if (live && !destroyed && !busy) {
            handler.removeCallbacks(liveRunnable);
            long delay = priorityCapturePending ? 0L : LIVE_CAPTURE_DELAY_MS;
            if (priorityCapturePending) {
                priorityCapturePending = false;
                engine.warmUpMode(languageModes[languageIndex]);
            }
            handler.postDelayed(liveRunnable, delay);
        }
    }

    private void releaseCaptureOnly() {
        if (virtualDisplay != null) {
            try { virtualDisplay.setSurface(null); } catch (Exception ignored) { }
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }

    @Override
    public void onDestroy() {
        destroyed = true;
        live = false;
        priorityCapturePending = false;
        busy = false;
        busyRequestId = 0;
        translationBusy = false;
        invalidateTranslationQueue();
        requestSerial++;
        activeRequestId = requestSerial;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (captureExecutor != null) captureExecutor.shutdownNow();
        if (engine != null) engine.close();
        if (toolbar != null) safeRemove(toolbar);
        if (selectorView != null) safeRemove(selectorView);
        if (subtitleView != null) safeRemove(subtitleView);
        if (engine != null) engine.setOverlayTextToIgnore("");
        if (statusView != null) safeRemove(statusView);
        releaseCaptureOnly();
        if (mediaProjection != null) {
            try { mediaProjection.stop(); } catch (Exception ignored) { }
            mediaProjection = null;
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (destroyed) return;
        final int oldWidth = Math.max(1, screenWidth);
        final int oldHeight = Math.max(1, screenHeight);
        final Rect oldSelector = selectorRect == null ? defaultRect() : new Rect(selectorRect);
        final int oldToolbarX = toolbarParams == null ? 0 : toolbarParams.x;
        final int oldToolbarY = toolbarParams == null ? 0 : toolbarParams.y;
        final int oldSubtitleX = subtitleParams == null ? 0 : subtitleParams.x;
        final int oldSubtitleY = subtitleParams == null ? 0 : subtitleParams.y;

        handler.removeCallbacks(liveRunnable);
        invalidateActiveRequest();
        handler.postDelayed(() -> {
            if (destroyed) return;
            readMetrics();
            selectorRect = scaleRect(oldSelector, oldWidth, oldHeight, screenWidth, screenHeight);
            selectorRect = clampScreenRect(selectorRect);
            if (selectorView != null) selectorView.setRect(selectorRect);

            if (toolbarParams != null) {
                toolbarParams.x = scaleCoordinate(oldToolbarX, oldWidth, screenWidth);
                toolbarParams.y = scaleCoordinate(oldToolbarY, oldHeight, screenHeight);
                toolbarParams.x = Math.max(0, Math.min(toolbarParams.x, Math.max(0, screenWidth - dp(44))));
                toolbarParams.y = Math.max(0, Math.min(toolbarParams.y, Math.max(0, screenHeight - dp(44))));
                safeUpdate(toolbar, toolbarParams);
            }

            if (subtitleParams != null) {
                subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
                if (subtitleManuallyMoved) {
                    subtitleParams.x = scaleCoordinate(oldSubtitleX, oldWidth, screenWidth);
                    subtitleParams.y = scaleCoordinate(oldSubtitleY, oldHeight, screenHeight);
                } else {
                    positionSubtitleNearSelector();
                    subtitleAutoPositionInitialized = true;
                }
                clampSubtitlePosition();
                safeUpdate(subtitleView, subtitleParams);
            }
            updateStatusPosition();
            resizeCaptureSurfaceWhenIdle(0);
            engine.resetStabilityState();
            if (live) handler.postDelayed(liveRunnable, LIVE_CAPTURE_DELAY_MS);
        }, 180);
    }

    private void resizeCaptureSurfaceWhenIdle(int attempt) {
        if (destroyed) return;
        if (captureWorkerActive && attempt < 12) {
            handler.postDelayed(() -> resizeCaptureSurfaceWhenIdle(attempt + 1), 40L);
            return;
        }
        resizeCaptureSurface();
    }

    private Rect scaleRect(Rect rect, int oldW, int oldH, int newW, int newH) {
        return new Rect(
                scaleCoordinate(rect.left, oldW, newW),
                scaleCoordinate(rect.top, oldH, newH),
                scaleCoordinate(rect.right, oldW, newW),
                scaleCoordinate(rect.bottom, oldH, newH)
        );
    }

    private int scaleCoordinate(int value, int oldSize, int newSize) {
        if (oldSize <= 0) return value;
        return Math.round((value / (float) oldSize) * newSize);
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) {
            return "desconocido";
        }
        return e.getMessage();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
