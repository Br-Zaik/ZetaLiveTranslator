# Zeta Live Translator 1.26.5 - idiomas asiáticos mejorados

Esta versión mantiene el modo **Vivo** estable y mejora únicamente chino, japonés y coreano. La traducción sigue siendo 100 % offline después de descargar el modelo de idioma. No se añadió ningún modo online ni API externa.

## Cambios principales

- El ciclo LIVE intenta una captura cada **400 ms** cuando el proceso anterior ya terminó.
- Inglés → Español queda como idioma inicial cuando el modelo inglés está instalado. Los demás idiomas continúan disponibles desde el botón de idioma.
- El OCR usa consenso de **2 de las últimas 3 lecturas** antes de traducir.
- La comparación es estricta para no confundir frases parecidas con significado distinto, especialmente negaciones.
- Se traduce la mejor lectura confirmada, no necesariamente la última captura recibida.
- Si el OCR continúa variando, no se fuerza una traducción defectuosa: se conserva el último subtítulo válido y se sigue esperando una lectura clara.
- Se eliminó el contexto automático entre el subtítulo anterior y el actual, porque podía mezclar dos diálogos diferentes.
- Se retiraron correcciones automáticas agresivas del inglés. Solo quedan unas pocas correcciones OCR de alta confianza.
- Dos capturas consecutivas sin texto reinician el estado del subtítulo anterior, permitiendo que una frase idéntica pueda aparecer nuevamente más adelante.
- Se mantienen la caché temporal, el glosario exacto, la liberación de imágenes en memoria y el descarte de resultados atrasados.
- No se cambiaron la interfaz, el cuadro morado, el cuadro negro movible, el parpadeo ni los botones principales.

## Mejora de chino, japonés y coreano

- La estabilidad LIVE conserva hanzi, kanji, hiragana, katakana y hangul.
- La caché usa una clave real por cada frase asiática; ya no confunde subtítulos distintos.
- El OCR selecciona una o dos líneas según posición y escritura del idioma elegido.
- Chino y japonés unen líneas sin espacios artificiales; coreano conserva sus espacios.
- Se eliminan indicaciones breves como música, risas o aplausos cuando vienen entre corchetes.
- Se normalizan únicamente jergas completas conocidas, sin reemplazar palabras dentro de oraciones largas.
- La ruta de inglés no fue modificada.

## Ciclo del modo Vivo

```text
Captura del cuadro morado
→ OCR
→ limpieza segura
→ consenso 2 de 3
→ seleccionar la mejor lectura
→ traducción offline con ML Kit
→ validar resultado
→ mostrar subtítulo en español
→ liberar imagen
→ repetir
```

## Uso recomendado

1. Descarga **Inglés → Español**.
2. Inicia la captura de pantalla.
3. Ajusta el cuadro morado únicamente alrededor del subtítulo original.
4. Comprueba que el botón muestre **Inglés→ES**.
5. Pulsa **Vivo**.

Un cuadro morado demasiado grande reduce la velocidad y aumenta los errores del OCR. Debe cubrir solo una o dos líneas del subtítulo.

## Glosario de correcciones

El glosario conserva coincidencias exactas de frases completas:

```text
Save point => Punto de guardado
Boss fight => Combate contra el jefe
```

No reemplaza palabras sueltas dentro de cualquier oración, para evitar cambios incorrectos.

## Compilar en GitHub

1. Crea un repositorio nuevo.
2. Sube todo el contenido de esta carpeta, incluida `.github`.
3. Abre **Actions → Build APK**.
4. Ejecuta **Run workflow**.
5. Descarga el artefacto `ZetaLiveTranslator_APK_V1_26_5_Idiomas_Asiaticos`.

## Límite real

La calidad depende de lo que el OCR consiga leer y del modelo offline de ML Kit. Esta versión prioriza no mostrar traducciones equivocadas: ante una lectura inestable conserva el subtítulo anterior en lugar de traducir basura.


## Ajustes 1.26.6
- Confirmacion mas estable del subtitulo en LIVE (~420 ms).
- Limpieza OCR extra para chino, japones y coreano.
- Normalizacion segura de jerga y frases comunes en idiomas asiaticos.
- Fallbacks directos para frases cortas muy comunes en idiomas asiaticos.
- Sin cambios en la ruta de ingles que ya funcionaba bien.
