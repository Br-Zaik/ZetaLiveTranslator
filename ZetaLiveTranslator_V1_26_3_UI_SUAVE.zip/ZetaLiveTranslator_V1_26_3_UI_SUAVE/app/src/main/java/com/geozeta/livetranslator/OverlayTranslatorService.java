package com.geozeta.livetranslator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;
import java.util.Locale;

public class OverlayTranslatorService extends Service {
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_DATA = "projection_data";

    private static final String CHANNEL_ID = "zeta_live_translator";
    private static final int NOTIFICATION_ID = 781;
    private static final long BUSY_TIMEOUT_MS = 12000L;
    private static final long LIVE_INTERVAL_MS = 400L;

    private WindowManager windowManager;
    private Handler handler;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;

    private LinearLayout toolbar;
    private TextView collapseBtn;
    private TextView areaBtn;
    private TextView liveIndicatorView;
    private TextView liveBtn;
    private TextView langBtn;
    private TextView statusView;
    private TextView subtitleView;
    private SelectorOverlayView selectorView;
    private WindowManager.LayoutParams toolbarParams;
    private WindowManager.LayoutParams subtitleParams;
    private WindowManager.LayoutParams selectorParams;
    private WindowManager.LayoutParams statusParams;

    private TranslatorEngine engine;
    private Runnable statusHideRunnable;
    private Rect selectorRect;
    private boolean selecting = false;
    private boolean live = false;
    private boolean busy = false;
    private boolean subtitleHidden = false;
    private boolean subtitleManuallyMoved = false;
    private boolean toolbarCollapsed = false;
    private boolean destroyed = false;
    private boolean captureViewsHidden = false;
    private boolean indicatorBlinkOn = true;
    private int toolbarVisibilityBeforeCapture = View.VISIBLE;
    private int selectorVisibilityBeforeCapture = View.VISIBLE;
    private int statusVisibilityBeforeCapture = View.GONE;
    private String lastShownSubtitle = "";
    private long lastSubtitleTime = 0L;
    private long statusVisibleUntil = 0L;
    private int requestSerial = 0;
    private int activeRequestId = 0;
    private long busyStartedAt = 0L;
    private int captureFailureStreak = 0;

    private final Runnable indicatorBlinkRunnable = new Runnable() {
        @Override public void run() {
            if (destroyed || liveIndicatorView == null) return;
            if (!live) {
                liveIndicatorView.setAlpha(1f);
                liveIndicatorView.setTextColor(Color.argb(170, 255, 255, 255));
                return;
            }
            indicatorBlinkOn = !indicatorBlinkOn;
            liveIndicatorView.setAlpha(indicatorBlinkOn ? 1f : 0.22f);
            liveIndicatorView.setTextColor(Color.rgb(255, 64, 64));
            handler.removeCallbacks(this);
            handler.postDelayed(this, 420L);
        }
    };

    // La estabilidad se decide antes de traducir, dentro de TranslatorEngine.
    // Aquí solo evitamos volver a mostrar la misma frase por ruido mínimo del OCR.
    private String currentSourceKey = "";

    // Auto lee Inglés, Chino, Japonés o Coreano y traduce a Español.
    private int languageIndex = 0;
    private final String[] languageModes = new String[]{
            TranslatorEngine.MODE_AUTO,
            TranslatorEngine.MODE_ENGLISH,
            TranslatorEngine.MODE_CHINESE,
            TranslatorEngine.MODE_JAPANESE,
            TranslatorEngine.MODE_KOREAN
    };

    private final Runnable liveRunnable = new Runnable() {
        @Override public void run() {
            if (!live || destroyed) return;
            translateOnce(false);
            handler.removeCallbacks(this);
            handler.postDelayed(this, LIVE_INTERVAL_MS);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        engine = new TranslatorEngine(getApplicationContext());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForeground(NOTIFICATION_ID, buildNotification("Traductor listo"));
        readMetrics();
        selectorRect = defaultRect();
        chooseInitialLanguageMode();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || destroyed) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (resultCode != 0 && data != null) {
            if (mediaProjection != null) {
                invalidateActiveRequest();
                releaseCaptureOnly();
                MediaProjection previousProjection = mediaProjection;
                mediaProjection = null;
                try { previousProjection.stop(); } catch (Exception ignored) { }
            }
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            MediaProjection newProjection = manager.getMediaProjection(resultCode, data);
            mediaProjection = newProjection;
            newProjection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    if (!destroyed && mediaProjection == newProjection) stopSelf();
                }
            }, handler);
            setupInitialCapture();
            showToolbar();
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void setupInitialCapture() {
        if (mediaProjection == null || destroyed) return;
        releaseCaptureOnly();
        readMetrics();
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 3);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ZetaLiveTranslatorScreen",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
        );
    }

    /**
     * En una rotación no se vuelve a usar createVirtualDisplay con el mismo token.
     * Se conserva el VirtualDisplay y solo se cambia su tamaño y superficie.
     */
    private void resizeCaptureSurface() {
        if (mediaProjection == null || destroyed) return;
        ImageReader replacement = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 3);
        ImageReader previous = imageReader;
        try {
            if (virtualDisplay == null) {
                replacement.close();
                showStatus("Reinicia el traductor para recuperar la captura", 2200);
                return;
            }
            virtualDisplay.resize(screenWidth, screenHeight, screenDensity);
            virtualDisplay.setSurface(replacement.getSurface());
            imageReader = replacement;
            if (previous != null && previous != imageReader) previous.close();
        } catch (Exception e) {
            replacement.close();
            imageReader = previous;
            showStatus("No se pudo ajustar la captura tras girar", 1800);
        }
    }

    private void readMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.view.WindowMetrics wm = windowManager.getMaximumWindowMetrics();
            Rect bounds = wm.getBounds();
            screenWidth = bounds.width();
            screenHeight = bounds.height();
            screenDensity = getResources().getDisplayMetrics().densityDpi;
        } else {
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.densityDpi;
        }
    }

    private Rect defaultRect() {
        int w = Math.min(screenWidth - dp(24), Math.max(dp(260), (int) (screenWidth * 0.70f)));
        int h = Math.min(screenHeight - dp(32), Math.max(dp(70), (int) (screenHeight * 0.13f)));
        int left = Math.max(0, (screenWidth - w) / 2);
        int top = Math.max(0, (int) (screenHeight * 0.70f));
        return clampScreenRect(new Rect(left, top, left + w, top + h));
    }

    private void showToolbar() {
        if (toolbar != null || destroyed) return;
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(6), dp(5), dp(6), dp(5));
        toolbar.setBackgroundColor(Color.argb(210, 17, 24, 39));

        collapseBtn = addButton("‹");
        liveIndicatorView = addIndicatorDot();
        areaBtn = addButton(selecting ? "OK" : "Área");
        TextView translateBtn = addButton("Trad.");
        liveBtn = addButton("Vivo");
        TextView subtitleBtn = addButton("Ocultar");
        langBtn = addButton(languageLabel(languageModes[languageIndex]) + "→ES");
        TextView closeBtn = addButton("×");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(15);

        collapseBtn.setOnClickListener(v -> toggleToolbarCollapsed());
        areaBtn.setOnClickListener(v -> toggleSelector());
        translateBtn.setOnClickListener(v -> translateOnce(true));
        liveBtn.setOnClickListener(v -> toggleLive());
        subtitleBtn.setOnClickListener(v -> {
            subtitleHidden = !subtitleHidden;
            if (subtitleView != null) subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
            subtitleBtn.setText(subtitleHidden ? "Mostrar" : "Ocultar");
        });
        langBtn.setOnClickListener(v -> cycleLanguage());
        closeBtn.setOnClickListener(v -> stopSelf());

        toolbarParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        toolbarParams.gravity = Gravity.TOP | Gravity.START;
        toolbarParams.x = dp(12);
        toolbarParams.y = dp(38);
        toolbarParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        View.OnTouchListener toolbarDragListener = new View.OnTouchListener() {
            int startX;
            int startY;
            float touchX;
            float touchY;
            boolean moved;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = toolbarParams.x;
                        startY = toolbarParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - touchX);
                        int dy = (int) (event.getRawY() - touchY);
                        if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true;
                        toolbarParams.x = Math.max(0, Math.min(startX + dx, Math.max(0, screenWidth - dp(44))));
                        toolbarParams.y = Math.max(0, Math.min(startY + dy, Math.max(0, screenHeight - dp(44))));
                        safeUpdate(toolbar, toolbarParams);
                        updateStatusPosition();
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) v.performClick();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                }
                return false;
            }
        };
        toolbar.setOnTouchListener(toolbarDragListener);
        // La flecha funciona además como asa de arrastre; así no depende de tocar un espacio vacío.
        collapseBtn.setOnTouchListener(toolbarDragListener);
        safeAdd(toolbar, toolbarParams);
        // Como en la version original: el cuadro negro no aparece hasta que exista
        // una traduccion real. No se muestra "Esperando subtitulo" sobre otras apps.
    }

    private void toggleToolbarCollapsed() {
        toolbarCollapsed = !toolbarCollapsed;
        if (toolbar == null || collapseBtn == null) return;
        collapseBtn.setText(toolbarCollapsed ? "›" : "‹");
        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View child = toolbar.getChildAt(i);
            boolean keepVisible = child == collapseBtn || child == liveIndicatorView;
            child.setVisibility((toolbarCollapsed && !keepVisible) ? View.GONE : View.VISIBLE);
        }
        updateLiveIndicatorState();
    }

    private TextView addButton(String text) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(9), dp(7), dp(9), dp(7));
        b.setBackgroundColor(Color.TRANSPARENT);
        toolbar.addView(b, new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT));
        return b;
    }

    private TextView addIndicatorDot() {
        TextView dot = new TextView(this);
        dot.setText("●");
        dot.setTextSize(14);
        dot.setTextColor(Color.argb(170, 255, 255, 255));
        dot.setGravity(Gravity.CENTER);
        dot.setPadding(dp(3), dp(0), dp(7), dp(0));
        dot.setBackgroundColor(Color.TRANSPARENT);
        toolbar.addView(dot, new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT));
        updateLiveIndicatorState();
        return dot;
    }

    private void updateLiveIndicatorState() {
        if (handler == null) return;
        handler.removeCallbacks(indicatorBlinkRunnable);
        if (liveIndicatorView == null) return;
        if (live) {
            indicatorBlinkOn = true;
            liveIndicatorView.setVisibility(View.VISIBLE);
            liveIndicatorView.setAlpha(1f);
            liveIndicatorView.setTextColor(Color.rgb(255, 64, 64));
            handler.post(indicatorBlinkRunnable);
        } else {
            liveIndicatorView.setVisibility(View.VISIBLE);
            liveIndicatorView.setAlpha(1f);
            liveIndicatorView.setTextColor(Color.argb(170, 255, 255, 255));
        }
    }

    private void toggleSelector() {
        if (selecting) {
            hideSelector();
            selecting = false;
            if (areaBtn != null) areaBtn.setText("Área");
            resetTranslationSwitchState(true);
            showStatus("Área guardada", 900);
        } else {
            engine.resetContextState();
            resetTranslationSwitchState(false);
            showSelector();
            selecting = true;
            if (areaBtn != null) areaBtn.setText("OK");
            showStatus("Ajusta y toca OK", 1200);
        }
    }

    private void showSelector() {
        if (selectorView != null || destroyed) return;
        selectorView = new SelectorOverlayView(this, selectorRect);
        selectorView.setOnRectChangedListener(rect -> {
            selectorRect = clampScreenRect(rect);
            if (subtitleView != null && subtitleParams != null && !subtitleManuallyMoved) {
                subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
                positionSubtitleNearSelector();
                safeUpdate(subtitleView, subtitleParams);
            }
        });
        selectorParams = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        selectorParams.gravity = Gravity.TOP | Gravity.START;
        selectorParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        safeAdd(selectorView, selectorParams);
        bringToolbarToFront();
    }

    private void bringToolbarToFront() {
        if (toolbar != null && toolbarParams != null) {
            safeRemove(toolbar);
            safeAdd(toolbar, toolbarParams);
        }
    }

    private void hideSelector() {
        if (selectorView != null) {
            safeRemove(selectorView);
            selectorView = null;
        }
    }

    private void toggleLive() {
        live = !live;
        handler.removeCallbacks(liveRunnable);
        if (live) {
            if (selecting) toggleSelector();
            if (liveBtn != null) liveBtn.setText("Pausa");
            updateLiveIndicatorState();
            showStatus("En vivo", 700);
            engine.resetStabilityState();
            engine.resetContextState();
            handler.post(liveRunnable);
        } else {
            if (liveBtn != null) liveBtn.setText("Vivo");
            updateLiveIndicatorState();
            invalidateActiveRequest();
            showStatus("Pausado", 700);
            engine.resetStabilityState();
        }
    }

    private void cycleLanguage() {
        int installedCount = installedLanguageCount();
        if (installedCount <= 1) {
            chooseInitialLanguageMode();
        } else {
            int attempts = 0;
            do {
                languageIndex = (languageIndex + 1) % languageModes.length;
                attempts++;
            } while (attempts < languageModes.length
                    && !TranslatorEngine.MODE_AUTO.equals(languageModes[languageIndex])
                    && !isModeInstalled(languageModes[languageIndex]));
        }

        engine.resetAutoState();
        engine.resetStabilityState();
        engine.resetContextState();
        resetTranslationSwitchState(true);
        if (langBtn != null) langBtn.setText(languageLabel(languageModes[languageIndex]) + "→ES");
        showStatus("Idioma: " + languageLabel(languageModes[languageIndex]) + " → Español", 1300);
    }

    private void chooseInitialLanguageMode() {
        // Inglés fijo es la opción inicial para LIVE: evita que Auto pruebe OCR/modelos
        // innecesarios y reduce errores cuando los videos están en inglés.
        if (isModeInstalled(TranslatorEngine.MODE_ENGLISH)) {
            languageIndex = 1;
            return;
        }

        int onlyIndex = -1;
        int count = 0;
        for (int i = 1; i < languageModes.length; i++) {
            if (isModeInstalled(languageModes[i])) {
                count++;
                onlyIndex = i;
            }
        }
        languageIndex = count == 1 ? onlyIndex : 0;
    }

    private int installedLanguageCount() {
        int count = 0;
        for (int i = 1; i < languageModes.length; i++) {
            if (isModeInstalled(languageModes[i])) count++;
        }
        return count;
    }

    private boolean isModeInstalled(String mode) {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.KEY_MODEL_PREFIX + mode, false);
    }

    private String languageLabel(String mode) {
        if (TranslatorEngine.MODE_AUTO.equals(mode)) return "Auto";
        if (TranslatorEngine.MODE_CHINESE.equals(mode)) return "Chino";
        if (TranslatorEngine.MODE_ENGLISH.equals(mode)) return "Inglés";
        if (TranslatorEngine.MODE_JAPANESE.equals(mode)) return "Japonés";
        if (TranslatorEngine.MODE_KOREAN.equals(mode)) return "Coreano";
        return "Auto";
    }

    private void translateOnce(boolean userRequested) {
        if (destroyed) return;
        long now = System.currentTimeMillis();
        if (busy) {
            if (userRequested || now - busyStartedAt > BUSY_TIMEOUT_MS) {
                invalidateActiveRequest();
                if (userRequested) showStatus("Reintentando traducción", 650);
            } else {
                return;
            }
        }
        if (selecting && userRequested) toggleSelector();
        if (mediaProjection == null || imageReader == null) {
            showStatus("Falta permiso de captura de pantalla", 1600);
            return;
        }
        if (userRequested) {
            lastShownSubtitle = "";
            engine.resetAutoState();
            engine.resetStabilityState();
            engine.resetContextState();
            resetTranslationSwitchState(true);
        }
        busy = true;
        busyStartedAt = now;
        int requestId = ++requestSerial;
        activeRequestId = requestId;
        // En Vivo se confirma el texto OCR antes de traducir. La traducción manual
        // conserva respuesta inmediata para que el botón Trad. no parezca bloqueado.
        drainImages();
        hideAllForCleanCapture();
        handler.postDelayed(() -> captureAndTranslate(0, requestId, userRequested), 55);
        handler.postDelayed(() -> {
            if (!destroyed && busy && activeRequestId == requestId) {
                restoreAfterCapture();
                busy = false;
                showStatus("Listo para reintentar", 700);
            }
        }, BUSY_TIMEOUT_MS);
    }

    private void hideAllForCleanCapture() {
        if (captureViewsHidden) return;
        captureViewsHidden = true;
        // La barra superior permanece estable para que sea facil tocar las opciones.
        // El indicador rojo comunica que LIVE sigue activo sin hacer parpadear toda la barra.
        if (toolbar != null) {
            toolbarVisibilityBeforeCapture = toolbar.getVisibility();
        }
        if (selectorView != null) {
            selectorVisibilityBeforeCapture = selectorView.getVisibility();
            selectorView.setVisibility(View.INVISIBLE);
        }
        if (statusView != null) {
            statusVisibilityBeforeCapture = statusView.getVisibility();
            statusView.setVisibility(View.INVISIBLE);
        }
    }

    private void restoreAfterCapture() {
        if (!captureViewsHidden) return;
        captureViewsHidden = false;
        if (toolbar != null) toolbar.setVisibility(toolbarVisibilityBeforeCapture);
        if (selectorView != null) selectorView.setVisibility(selectorVisibilityBeforeCapture);
        if (statusView != null) {
            boolean statusStillValid = statusVisibilityBeforeCapture == View.VISIBLE
                    && statusVisibleUntil > System.currentTimeMillis();
            statusView.setVisibility(statusStillValid ? View.VISIBLE : View.GONE);
        }
        updateLiveIndicatorState();
    }

    private void captureAndTranslate(int attempt, int requestId, boolean manualRequest) {
        if (destroyed) return;
        Image image = null;
        Bitmap full = null;
        Bitmap crop = null;
        try {
            if (requestId != activeRequestId || imageReader == null) {
                restoreAfterCapture();
                return;
            }
            image = imageReader.acquireLatestImage();
            if (image == null) {
                if (attempt < 10) {
                    handler.postDelayed(() -> captureAndTranslate(attempt + 1, requestId, manualRequest), 45);
                } else {
                    restoreAfterCapture();
                    if (requestId == activeRequestId) busy = false;
                    captureFailureStreak++;
                    // Un fotograma perdido es normal en algunos telefonos. Solo avisamos si se repite.
                    if (captureFailureStreak >= 3) {
                        showStatus("La captura esta tardando. Reintentando...", 1200);
                    }
                    if (captureFailureStreak >= 5) {
                        resizeCaptureSurface();
                        captureFailureStreak = 0;
                    }
                }
                return;
            }
            captureFailureStreak = 0;
            full = imageToBitmap(image);
            image.close();
            image = null;

            Rect cropRect = mapSelectorToBitmap(full.getWidth(), full.getHeight());
            crop = Bitmap.createBitmap(full, cropRect.left, cropRect.top, cropRect.width(), cropRect.height());
            recycleBitmap(full);
            full = null;
            restoreAfterCapture();

            final Bitmap requestCrop = crop;
            crop = null;
            final boolean requireStableText = !manualRequest;
            try {
                engine.process(requestCrop, languageModes[languageIndex], requireStableText, new TranslatorEngine.Callback() {
                    @Override public void onSuccess(String original, String translated, String sourceName) {
                        recycleBitmap(requestCrop);
                        if (destroyed || requestId != activeRequestId) return;
                        busy = false;
                        handleTranslationResult(original, translated, sourceName, manualRequest);
                    }

                    @Override public void onError(String message) {
                        recycleBitmap(requestCrop);
                        if (destroyed || requestId != activeRequestId) return;
                        busy = false;
                        String lower = message == null ? "" : message.toLowerCase(Locale.ROOT);
                        if (lower.contains("no se detect") || lower.contains("esperando texto claro")) {
                            engine.noteNoTextDetected();
                        }
                        if (!lower.contains("no se detect")
                                && !lower.contains("esperando subtítulo")
                                && !lower.contains("esperando texto claro")) {
                            showStatus(message, 1500);
                        }
                    }
                });
            } catch (Exception processError) {
                recycleBitmap(requestCrop);
                throw processError;
            }
        } catch (Exception e) {
            if (image != null) {
                try { image.close(); } catch (Exception ignored) { }
            }
            recycleBitmap(full);
            recycleBitmap(crop);
            restoreAfterCapture();
            if (requestId == activeRequestId) busy = false;
            if (!destroyed) showStatus("Error captura: " + safeMessage(e), 2400);
        }
    }

    private void recycleBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try { bitmap.recycle(); } catch (Exception ignored) { }
        }
    }

    private void drainImages() {
        if (imageReader == null) return;
        Image old = null;
        try {
            while ((old = imageReader.acquireLatestImage()) != null) {
                old.close();
                old = null;
            }
        } catch (Exception ignored) {
            if (old != null) { try { old.close(); } catch (Exception ignored2) { } }
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = Math.max(0, rowStride - pixelStride * imageWidth);
        int bitmapWidth = imageWidth + rowPadding / pixelStride;
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, imageHeight, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        if (bitmapWidth != imageWidth) {
            Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, imageWidth, imageHeight);
            bitmap.recycle();
            return cropped;
        }
        return bitmap;
    }

    private Rect mapSelectorToBitmap(int bitmapWidth, int bitmapHeight) {
        float sx = screenWidth > 0 ? bitmapWidth / (float) screenWidth : 1f;
        float sy = screenHeight > 0 ? bitmapHeight / (float) screenHeight : 1f;
        Rect mapped = new Rect(
                Math.round(selectorRect.left * sx),
                Math.round(selectorRect.top * sy),
                Math.round(selectorRect.right * sx),
                Math.round(selectorRect.bottom * sy)
        );
        return clampCrop(mapped, bitmapWidth, bitmapHeight);
    }

    private Rect clampCrop(Rect r, int maxW, int maxH) {
        int left = Math.max(0, Math.min(r.left, maxW - 2));
        int top = Math.max(0, Math.min(r.top, maxH - 2));
        int right = Math.max(left + 2, Math.min(r.right, maxW));
        int bottom = Math.max(top + 2, Math.min(r.bottom, maxH));
        return new Rect(left, top, right, bottom);
    }

    private Rect clampScreenRect(Rect r) {
        int minW = Math.min(screenWidth, dp(120));
        int minH = Math.min(screenHeight, dp(44));
        int width = Math.max(minW, Math.min(r.width(), screenWidth));
        int height = Math.max(minH, Math.min(r.height(), screenHeight));
        int left = Math.max(0, Math.min(r.left, Math.max(0, screenWidth - width)));
        int top = Math.max(0, Math.min(r.top, Math.max(0, screenHeight - height)));
        return new Rect(left, top, left + width, top + height);
    }

    private void handleTranslationResult(String original, String translated, String sourceName, boolean manualRequest) {
        String sourceKey = normalizeSourceKey(original);
        String cleanTranslation = makeSubtitleText(translated);
        if (sourceKey.length() == 0 || cleanTranslation.length() == 0) return;

        if (!manualRequest && areSourceKeysSimilar(currentSourceKey, sourceKey)) {
            return;
        }

        commitTranslation(sourceKey, cleanTranslation, sourceName);
    }

    private void commitTranslation(String sourceKey, String translated, String sourceName) {
        currentSourceKey = sourceKey;
        showSubtitle(translated, sourceName);
    }

    private void resetTranslationSwitchState(boolean resetCurrent) {
        if (resetCurrent) currentSourceKey = "";
    }

    private String normalizeSourceKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private boolean areSourceKeysSimilar(String a, String b) {
        if (a == null || b == null || a.length() == 0 || b.length() == 0) return false;
        if (a.equals(b)) return true;
        int min = Math.min(a.length(), b.length());
        int max = Math.max(a.length(), b.length());
        if (min >= 10 && (a.contains(b) || b.contains(a)) && min >= (int) (max * 0.72f)) return true;

        java.util.HashSet<String> left = new java.util.HashSet<>();
        java.util.HashSet<String> right = new java.util.HashSet<>();
        for (String token : a.split(" ")) if (token.length() > 1) left.add(token);
        for (String token : b.split(" ")) if (token.length() > 1) right.add(token);
        if (left.isEmpty() || right.isEmpty()) return false;
        int common = 0;
        for (String token : left) if (right.contains(token)) common++;
        int union = left.size() + right.size() - common;
        return union > 0 && common / (float) union >= 0.68f;
    }

    private void ensureSubtitleOverlay() {
        if (destroyed) return;
        if (subtitleView == null) {
            subtitleView = new TextView(this);
            subtitleView.setTextColor(Color.WHITE);
            subtitleView.setTextSize(18);
            subtitleView.setGravity(Gravity.CENTER);
            subtitleView.setPadding(dp(12), dp(8), dp(12), dp(8));
            subtitleView.setShadowLayer(dp(2), 0, 0, Color.argb(120, 0, 0, 0));
            GradientDrawable subtitleBg = new GradientDrawable();
            subtitleBg.setColor(Color.argb(205, 0, 0, 0));
            subtitleBg.setCornerRadius(dp(10));
            subtitleView.setBackground(subtitleBg);
            subtitleView.setIncludeFontPadding(false);
            subtitleView.setLineSpacing(0f, 1.05f);
            subtitleView.setMaxLines(3);
            subtitleView.setEllipsize(TextUtils.TruncateAt.END);
            subtitleView.setOnTouchListener(new View.OnTouchListener() {
                int startX;
                int startY;
                float touchX;
                float touchY;

                @Override public boolean onTouch(View v, MotionEvent event) {
                    if (subtitleParams == null) return false;
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            startX = subtitleParams.x;
                            startY = subtitleParams.y;
                            touchX = event.getRawX();
                            touchY = event.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            subtitleParams.x = startX + (int) (event.getRawX() - touchX);
                            subtitleParams.y = startY + (int) (event.getRawY() - touchY);
                            clampSubtitlePosition();
                            subtitleManuallyMoved = true;
                            safeUpdate(subtitleView, subtitleParams);
                            return true;
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            return true;
                    }
                    return false;
                }
            });
        }
        if (subtitleParams == null) {
            subtitleParams = overlayParams(selectorRect.width(), WindowManager.LayoutParams.WRAP_CONTENT);
            subtitleParams.gravity = Gravity.TOP | Gravity.START;
            subtitleParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }
        subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
        subtitleParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        if (!subtitleManuallyMoved) positionSubtitleNearSelector();
        clampSubtitlePosition();
        if (subtitleView.getParent() == null) safeAdd(subtitleView, subtitleParams);
        else safeUpdate(subtitleView, subtitleParams);
        subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
    }

    private void showSubtitle(String translated, String sourceName) {
        if (destroyed) return;
        hideSelector();
        selecting = false;
        if (areaBtn != null) areaBtn.setText("Área");

        String text = makeSubtitleText(translated);
        if (text.length() == 0) return;
        if (text.equals(lastShownSubtitle) && subtitleView != null) {
            lastSubtitleTime = System.currentTimeMillis();
            subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
            return;
        }
        lastShownSubtitle = text;
        lastSubtitleTime = System.currentTimeMillis();
        ensureSubtitleOverlay();
        subtitleView.setText(text);
        if (subtitleParams == null) {
            subtitleParams = overlayParams(selectorRect.width(), WindowManager.LayoutParams.WRAP_CONTENT);
            subtitleParams.gravity = Gravity.TOP | Gravity.START;
            subtitleParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }
        subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
        subtitleParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
        if (!subtitleManuallyMoved) positionSubtitleNearSelector();
        clampSubtitlePosition();
        if (subtitleView.getParent() == null) {
            safeAdd(subtitleView, subtitleParams);
        } else {
            safeUpdate(subtitleView, subtitleParams);
        }
        subtitleView.setVisibility(subtitleHidden ? View.GONE : View.VISIBLE);
        if (!subtitleManuallyMoved) {
            handler.post(() -> {
                if (destroyed || subtitleView == null || subtitleParams == null) return;
                positionSubtitleNearSelector();
                safeUpdate(subtitleView, subtitleParams);
            });
        }
        updateNotification(sourceName + " → Español");
    }

    private void positionSubtitleNearSelector() {
        if (subtitleParams == null || selectorRect == null) return;
        int gap = dp(4);
        int measuredHeight = subtitleView == null ? 0 : Math.max(subtitleView.getHeight(), subtitleView.getMeasuredHeight());
        int boxHeight = measuredHeight > 0 ? measuredHeight : dp(58);
        int aboveY = selectorRect.top - boxHeight - gap;
        int belowY = selectorRect.bottom + gap;

        subtitleParams.x = selectorRect.left;
        if (aboveY >= dp(4)) {
            subtitleParams.y = aboveY;
        } else if (belowY + boxHeight <= screenHeight - dp(4)) {
            subtitleParams.y = belowY;
        } else {
            subtitleParams.y = Math.max(dp(4), Math.min(aboveY, screenHeight - boxHeight - dp(4)));
        }
        clampSubtitlePosition();
    }

    private void clampSubtitlePosition() {
        if (subtitleParams == null || selectorRect == null) return;
        int width = subtitleParams.width > 0 ? subtitleParams.width : Math.min(selectorRect.width(), screenWidth);
        int height = subtitleView == null ? dp(58) : Math.max(dp(44), Math.max(subtitleView.getHeight(), subtitleView.getMeasuredHeight()));
        subtitleParams.x = Math.max(0, Math.min(subtitleParams.x, Math.max(0, screenWidth - width)));
        subtitleParams.y = Math.max(0, Math.min(subtitleParams.y, Math.max(0, screenHeight - height)));

        // El usuario decide la posicion. No expulsamos el cuadro negro del area morada.
        // Solo lo limitamos a los bordes de la pantalla, como en las primeras versiones.
    }

    private String makeSubtitleText(String text) {
        if (text == null) return "";
        return text.replace("\r", " ")
                .replace("\n", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private void showStatus(String text, long durationMs) {
        if (destroyed || text == null || text.trim().length() == 0) return;
        String lower = text.toLowerCase(Locale.ROOT);
        if (lower.contains("no se detect")
                || lower.contains("esperando subtítulo")
                || lower.contains("esperando texto claro")) return;

        if (statusView == null) {
            statusView = new TextView(this);
            statusView.setTextColor(Color.WHITE);
            statusView.setTextSize(11);
            statusView.setGravity(Gravity.CENTER);
            statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
            statusView.setBackgroundColor(Color.argb(175, 17, 24, 39));
            statusParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            statusParams.gravity = Gravity.TOP | Gravity.START;
            statusParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            updateStatusPosition();
            safeAdd(statusView, statusParams);
        } else {
            updateStatusPosition();
        }
        statusView.setText(text);
        statusView.setVisibility(View.VISIBLE);
        statusVisibleUntil = System.currentTimeMillis() + durationMs;
        if (statusHideRunnable != null) handler.removeCallbacks(statusHideRunnable);
        statusHideRunnable = () -> {
            statusVisibleUntil = 0L;
            if (!destroyed && statusView != null) statusView.setVisibility(View.GONE);
        };
        handler.postDelayed(statusHideRunnable, durationMs);
    }

    private void updateStatusPosition() {
        if (statusParams == null) return;
        statusParams.x = toolbarParams != null ? toolbarParams.x : dp(12);
        statusParams.y = toolbarParams != null ? toolbarParams.y + dp(46) : dp(86);
        statusParams.x = Math.max(0, Math.min(statusParams.x, Math.max(0, screenWidth - dp(80))));
        statusParams.y = Math.max(0, Math.min(statusParams.y, Math.max(0, screenHeight - dp(36))));
        if (statusView != null && statusView.getParent() != null) safeUpdate(statusView, statusParams);
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width,
                height,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        return params;
    }

    private Notification buildNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Zeta Live Translator", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            return new Notification.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_stat_zeta)
                    .setContentTitle("Zeta Live Translator")
                    .setContentText(text)
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_stat_zeta)
                .setContentTitle("Zeta Live Translator")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String text) {
        if (destroyed) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void safeAdd(View view, WindowManager.LayoutParams params) {
        if (destroyed || view == null || params == null) return;
        try { windowManager.addView(view, params); } catch (Exception ignored) { }
    }

    private void safeUpdate(View view, WindowManager.LayoutParams params) {
        if (destroyed || view == null || params == null) return;
        try { windowManager.updateViewLayout(view, params); } catch (Exception ignored) { }
    }

    private void safeRemove(View view) {
        if (view == null) return;
        try { windowManager.removeView(view); } catch (Exception ignored) { }
    }

    private void invalidateActiveRequest() {
        requestSerial++;
        activeRequestId = requestSerial;
        busy = false;
        restoreAfterCapture();
    }

    private void releaseCaptureOnly() {
        if (virtualDisplay != null) {
            try { virtualDisplay.setSurface(null); } catch (Exception ignored) { }
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }

    @Override
    public void onDestroy() {
        destroyed = true;
        live = false;
        busy = false;
        requestSerial++;
        activeRequestId = requestSerial;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (engine != null) engine.close();
        if (toolbar != null) safeRemove(toolbar);
        if (selectorView != null) safeRemove(selectorView);
        if (subtitleView != null) safeRemove(subtitleView);
        if (statusView != null) safeRemove(statusView);
        releaseCaptureOnly();
        if (mediaProjection != null) {
            try { mediaProjection.stop(); } catch (Exception ignored) { }
            mediaProjection = null;
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (destroyed) return;
        final int oldWidth = Math.max(1, screenWidth);
        final int oldHeight = Math.max(1, screenHeight);
        final Rect oldSelector = selectorRect == null ? defaultRect() : new Rect(selectorRect);
        final int oldToolbarX = toolbarParams == null ? 0 : toolbarParams.x;
        final int oldToolbarY = toolbarParams == null ? 0 : toolbarParams.y;
        final int oldSubtitleX = subtitleParams == null ? 0 : subtitleParams.x;
        final int oldSubtitleY = subtitleParams == null ? 0 : subtitleParams.y;

        handler.removeCallbacks(liveRunnable);
        invalidateActiveRequest();
        handler.postDelayed(() -> {
            if (destroyed) return;
            readMetrics();
            selectorRect = scaleRect(oldSelector, oldWidth, oldHeight, screenWidth, screenHeight);
            selectorRect = clampScreenRect(selectorRect);
            if (selectorView != null) selectorView.setRect(selectorRect);

            if (toolbarParams != null) {
                toolbarParams.x = scaleCoordinate(oldToolbarX, oldWidth, screenWidth);
                toolbarParams.y = scaleCoordinate(oldToolbarY, oldHeight, screenHeight);
                toolbarParams.x = Math.max(0, Math.min(toolbarParams.x, Math.max(0, screenWidth - dp(44))));
                toolbarParams.y = Math.max(0, Math.min(toolbarParams.y, Math.max(0, screenHeight - dp(44))));
                safeUpdate(toolbar, toolbarParams);
            }

            if (subtitleParams != null) {
                subtitleParams.width = Math.min(screenWidth, Math.max(dp(160), selectorRect.width()));
                if (subtitleManuallyMoved) {
                    subtitleParams.x = scaleCoordinate(oldSubtitleX, oldWidth, screenWidth);
                    subtitleParams.y = scaleCoordinate(oldSubtitleY, oldHeight, screenHeight);
                } else {
                    positionSubtitleNearSelector();
                }
                clampSubtitlePosition();
                safeUpdate(subtitleView, subtitleParams);
            }
            updateStatusPosition();
            resizeCaptureSurface();
            engine.resetStabilityState();
            if (live) handler.postDelayed(liveRunnable, 350);
        }, 180);
    }

    private Rect scaleRect(Rect rect, int oldW, int oldH, int newW, int newH) {
        return new Rect(
                scaleCoordinate(rect.left, oldW, newW),
                scaleCoordinate(rect.top, oldH, newH),
                scaleCoordinate(rect.right, oldW, newW),
                scaleCoordinate(rect.bottom, oldH, newH)
        );
    }

    private int scaleCoordinate(int value, int oldSize, int newSize) {
        if (oldSize <= 0) return value;
        return Math.round((value / (float) oldSize) * newSize);
    }

    private String safeMessage(Exception e) {
        if (e == null || e.getMessage() == null || e.getMessage().trim().length() == 0) {
            return "desconocido";
        }
        return e.getMessage();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
